// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Generated code. DO NOT EDIT!

#pragma warning disable CS8981
using gaxgrpc = Google.Api.Gax.Grpc;
using gcdv = Google.Cloud.Dialogflow.V3Alpha1;
using gcl = Google.Cloud.Location;
using gpr = Google.Protobuf.Reflection;
using lro = Google.LongRunning;
using proto = Google.Protobuf;
using scg = System.Collections.Generic;
using sys = System;

namespace Microsoft.Extensions.DependencyInjection
{
    /// <summary>Static class to provide extension methods to configure API clients.</summary>
    public static partial class ServiceCollectionExtensions
    {
        /// <summary>Adds a singleton <see cref="gcdv::AgentsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddAgentsClient(this IServiceCollection services, sys::Action<gcdv::AgentsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::AgentsClientBuilder builder = new gcdv::AgentsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::AgentsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddAgentsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::AgentsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::AgentsClientBuilder builder = new gcdv::AgentsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::ConversationHistoryClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddConversationHistoryClient(this IServiceCollection services, sys::Action<gcdv::ConversationHistoryClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::ConversationHistoryClientBuilder builder = new gcdv::ConversationHistoryClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::ConversationHistoryClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddConversationHistoryClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::ConversationHistoryClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::ConversationHistoryClientBuilder builder = new gcdv::ConversationHistoryClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::EncryptionSpecServiceClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddEncryptionSpecServiceClient(this IServiceCollection services, sys::Action<gcdv::EncryptionSpecServiceClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::EncryptionSpecServiceClientBuilder builder = new gcdv::EncryptionSpecServiceClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::EncryptionSpecServiceClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddEncryptionSpecServiceClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::EncryptionSpecServiceClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::EncryptionSpecServiceClientBuilder builder = new gcdv::EncryptionSpecServiceClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::EntityTypesClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddEntityTypesClient(this IServiceCollection services, sys::Action<gcdv::EntityTypesClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::EntityTypesClientBuilder builder = new gcdv::EntityTypesClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::EntityTypesClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddEntityTypesClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::EntityTypesClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::EntityTypesClientBuilder builder = new gcdv::EntityTypesClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::EnvironmentsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddEnvironmentsClient(this IServiceCollection services, sys::Action<gcdv::EnvironmentsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::EnvironmentsClientBuilder builder = new gcdv::EnvironmentsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::EnvironmentsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddEnvironmentsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::EnvironmentsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::EnvironmentsClientBuilder builder = new gcdv::EnvironmentsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::ExamplesClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddExamplesClient(this IServiceCollection services, sys::Action<gcdv::ExamplesClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::ExamplesClientBuilder builder = new gcdv::ExamplesClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::ExamplesClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddExamplesClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::ExamplesClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::ExamplesClientBuilder builder = new gcdv::ExamplesClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::ExperimentsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddExperimentsClient(this IServiceCollection services, sys::Action<gcdv::ExperimentsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::ExperimentsClientBuilder builder = new gcdv::ExperimentsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::ExperimentsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddExperimentsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::ExperimentsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::ExperimentsClientBuilder builder = new gcdv::ExperimentsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::FlowsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddFlowsClient(this IServiceCollection services, sys::Action<gcdv::FlowsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::FlowsClientBuilder builder = new gcdv::FlowsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::FlowsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddFlowsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::FlowsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::FlowsClientBuilder builder = new gcdv::FlowsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::GeneratorsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddGeneratorsClient(this IServiceCollection services, sys::Action<gcdv::GeneratorsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::GeneratorsClientBuilder builder = new gcdv::GeneratorsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::GeneratorsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddGeneratorsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::GeneratorsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::GeneratorsClientBuilder builder = new gcdv::GeneratorsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::IntentsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddIntentsClient(this IServiceCollection services, sys::Action<gcdv::IntentsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::IntentsClientBuilder builder = new gcdv::IntentsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::IntentsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddIntentsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::IntentsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::IntentsClientBuilder builder = new gcdv::IntentsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::PagesClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddPagesClient(this IServiceCollection services, sys::Action<gcdv::PagesClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::PagesClientBuilder builder = new gcdv::PagesClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::PagesClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddPagesClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::PagesClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::PagesClientBuilder builder = new gcdv::PagesClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::PlaybooksClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddPlaybooksClient(this IServiceCollection services, sys::Action<gcdv::PlaybooksClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::PlaybooksClientBuilder builder = new gcdv::PlaybooksClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::PlaybooksClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddPlaybooksClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::PlaybooksClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::PlaybooksClientBuilder builder = new gcdv::PlaybooksClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::SecuritySettingsServiceClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddSecuritySettingsServiceClient(this IServiceCollection services, sys::Action<gcdv::SecuritySettingsServiceClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::SecuritySettingsServiceClientBuilder builder = new gcdv::SecuritySettingsServiceClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::SecuritySettingsServiceClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddSecuritySettingsServiceClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::SecuritySettingsServiceClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::SecuritySettingsServiceClientBuilder builder = new gcdv::SecuritySettingsServiceClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::SessionEntityTypesClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddSessionEntityTypesClient(this IServiceCollection services, sys::Action<gcdv::SessionEntityTypesClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::SessionEntityTypesClientBuilder builder = new gcdv::SessionEntityTypesClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::SessionEntityTypesClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddSessionEntityTypesClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::SessionEntityTypesClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::SessionEntityTypesClientBuilder builder = new gcdv::SessionEntityTypesClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::SessionsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddSessionsClient(this IServiceCollection services, sys::Action<gcdv::SessionsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::SessionsClientBuilder builder = new gcdv::SessionsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::SessionsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddSessionsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::SessionsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::SessionsClientBuilder builder = new gcdv::SessionsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::TestCasesClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddTestCasesClient(this IServiceCollection services, sys::Action<gcdv::TestCasesClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::TestCasesClientBuilder builder = new gcdv::TestCasesClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::TestCasesClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddTestCasesClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::TestCasesClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::TestCasesClientBuilder builder = new gcdv::TestCasesClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::ToolsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddToolsClient(this IServiceCollection services, sys::Action<gcdv::ToolsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::ToolsClientBuilder builder = new gcdv::ToolsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::ToolsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddToolsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::ToolsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::ToolsClientBuilder builder = new gcdv::ToolsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::TransitionRouteGroupsClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddTransitionRouteGroupsClient(this IServiceCollection services, sys::Action<gcdv::TransitionRouteGroupsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::TransitionRouteGroupsClientBuilder builder = new gcdv::TransitionRouteGroupsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>
        /// Adds a singleton <see cref="gcdv::TransitionRouteGroupsClient"/> to <paramref name="services"/>.
        /// </summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddTransitionRouteGroupsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::TransitionRouteGroupsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::TransitionRouteGroupsClientBuilder builder = new gcdv::TransitionRouteGroupsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::UserSettingsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddUserSettingsClient(this IServiceCollection services, sys::Action<gcdv::UserSettingsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::UserSettingsClientBuilder builder = new gcdv::UserSettingsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::UserSettingsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddUserSettingsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::UserSettingsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::UserSettingsClientBuilder builder = new gcdv::UserSettingsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::VersionsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddVersionsClient(this IServiceCollection services, sys::Action<gcdv::VersionsClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::VersionsClientBuilder builder = new gcdv::VersionsClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::VersionsClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddVersionsClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::VersionsClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::VersionsClientBuilder builder = new gcdv::VersionsClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::WebhooksClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddWebhooksClient(this IServiceCollection services, sys::Action<gcdv::WebhooksClientBuilder> action = null) =>
            services.AddSingleton(provider =>
            {
                gcdv::WebhooksClientBuilder builder = new gcdv::WebhooksClientBuilder();
                action?.Invoke(builder);
                return builder.Build(provider);
            });

        /// <summary>Adds a singleton <see cref="gcdv::WebhooksClient"/> to <paramref name="services"/>.</summary>
        /// <param name="services">
        /// The service collection to add the client to. The services are used to configure the client when requested.
        /// </param>
        /// <param name="action">
        /// An optional action to invoke on the client builder. This is invoked before services from
        /// <paramref name="services"/> are used.
        /// </param>
        public static IServiceCollection AddWebhooksClient(this IServiceCollection services, sys::Action<sys::IServiceProvider, gcdv::WebhooksClientBuilder> action) =>
            services.AddSingleton(provider =>
            {
                gcdv::WebhooksClientBuilder builder = new gcdv::WebhooksClientBuilder();
                action?.Invoke(provider, builder);
                return builder.Build(provider);
            });
    }
}
