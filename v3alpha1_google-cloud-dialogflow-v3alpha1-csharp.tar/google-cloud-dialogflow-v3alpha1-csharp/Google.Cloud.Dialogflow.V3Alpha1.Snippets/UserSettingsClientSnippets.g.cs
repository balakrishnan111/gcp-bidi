// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Generated code. DO NOT EDIT!

namespace GoogleCSharpSnippets
{
    using Google.Cloud.Dialogflow.V3Alpha1;
    using Google.Protobuf.WellKnownTypes;
    using System.Threading.Tasks;

    /// <summary>Generated snippets.</summary>
    public sealed class AllGeneratedUserSettingsClientSnippets
    {
        /// <summary>Snippet for GetRecentProjects</summary>
        public void GetRecentProjectsRequestObject()
        {
            // Snippet: GetRecentProjects(GetRecentProjectsRequest, CallSettings)
            // Create client
            UserSettingsClient userSettingsClient = UserSettingsClient.Create();
            // Initialize request argument(s)
            GetRecentProjectsRequest request = new GetRecentProjectsRequest
            {
                RecentProjectsName = RecentProjectsName.FromUser("[USER]"),
            };
            // Make the request
            RecentProjects response = userSettingsClient.GetRecentProjects(request);
            // End snippet
        }

        /// <summary>Snippet for GetRecentProjectsAsync</summary>
        public async Task GetRecentProjectsRequestObjectAsync()
        {
            // Snippet: GetRecentProjectsAsync(GetRecentProjectsRequest, CallSettings)
            // Additional: GetRecentProjectsAsync(GetRecentProjectsRequest, CancellationToken)
            // Create client
            UserSettingsClient userSettingsClient = await UserSettingsClient.CreateAsync();
            // Initialize request argument(s)
            GetRecentProjectsRequest request = new GetRecentProjectsRequest
            {
                RecentProjectsName = RecentProjectsName.FromUser("[USER]"),
            };
            // Make the request
            RecentProjects response = await userSettingsClient.GetRecentProjectsAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GetRecentProjects</summary>
        public void GetRecentProjects()
        {
            // Snippet: GetRecentProjects(string, CallSettings)
            // Create client
            UserSettingsClient userSettingsClient = UserSettingsClient.Create();
            // Initialize request argument(s)
            string name = "users/[USER]/userSettings/recentProjects";
            // Make the request
            RecentProjects response = userSettingsClient.GetRecentProjects(name);
            // End snippet
        }

        /// <summary>Snippet for GetRecentProjectsAsync</summary>
        public async Task GetRecentProjectsAsync()
        {
            // Snippet: GetRecentProjectsAsync(string, CallSettings)
            // Additional: GetRecentProjectsAsync(string, CancellationToken)
            // Create client
            UserSettingsClient userSettingsClient = await UserSettingsClient.CreateAsync();
            // Initialize request argument(s)
            string name = "users/[USER]/userSettings/recentProjects";
            // Make the request
            RecentProjects response = await userSettingsClient.GetRecentProjectsAsync(name);
            // End snippet
        }

        /// <summary>Snippet for GetRecentProjects</summary>
        public void GetRecentProjectsResourceNames()
        {
            // Snippet: GetRecentProjects(RecentProjectsName, CallSettings)
            // Create client
            UserSettingsClient userSettingsClient = UserSettingsClient.Create();
            // Initialize request argument(s)
            RecentProjectsName name = RecentProjectsName.FromUser("[USER]");
            // Make the request
            RecentProjects response = userSettingsClient.GetRecentProjects(name);
            // End snippet
        }

        /// <summary>Snippet for GetRecentProjectsAsync</summary>
        public async Task GetRecentProjectsResourceNamesAsync()
        {
            // Snippet: GetRecentProjectsAsync(RecentProjectsName, CallSettings)
            // Additional: GetRecentProjectsAsync(RecentProjectsName, CancellationToken)
            // Create client
            UserSettingsClient userSettingsClient = await UserSettingsClient.CreateAsync();
            // Initialize request argument(s)
            RecentProjectsName name = RecentProjectsName.FromUser("[USER]");
            // Make the request
            RecentProjects response = await userSettingsClient.GetRecentProjectsAsync(name);
            // End snippet
        }

        /// <summary>Snippet for UpdateRecentProjects</summary>
        public void UpdateRecentProjectsRequestObject()
        {
            // Snippet: UpdateRecentProjects(UpdateRecentProjectsRequest, CallSettings)
            // Create client
            UserSettingsClient userSettingsClient = UserSettingsClient.Create();
            // Initialize request argument(s)
            UpdateRecentProjectsRequest request = new UpdateRecentProjectsRequest
            {
                RecentProjects = new RecentProjects(),
                UpdateMask = new FieldMask(),
            };
            // Make the request
            RecentProjects response = userSettingsClient.UpdateRecentProjects(request);
            // End snippet
        }

        /// <summary>Snippet for UpdateRecentProjectsAsync</summary>
        public async Task UpdateRecentProjectsRequestObjectAsync()
        {
            // Snippet: UpdateRecentProjectsAsync(UpdateRecentProjectsRequest, CallSettings)
            // Additional: UpdateRecentProjectsAsync(UpdateRecentProjectsRequest, CancellationToken)
            // Create client
            UserSettingsClient userSettingsClient = await UserSettingsClient.CreateAsync();
            // Initialize request argument(s)
            UpdateRecentProjectsRequest request = new UpdateRecentProjectsRequest
            {
                RecentProjects = new RecentProjects(),
                UpdateMask = new FieldMask(),
            };
            // Make the request
            RecentProjects response = await userSettingsClient.UpdateRecentProjectsAsync(request);
            // End snippet
        }

        /// <summary>Snippet for UpdateRecentProjects</summary>
        public void UpdateRecentProjects()
        {
            // Snippet: UpdateRecentProjects(RecentProjects, FieldMask, CallSettings)
            // Create client
            UserSettingsClient userSettingsClient = UserSettingsClient.Create();
            // Initialize request argument(s)
            RecentProjects recentProjects = new RecentProjects();
            FieldMask updateMask = new FieldMask();
            // Make the request
            RecentProjects response = userSettingsClient.UpdateRecentProjects(recentProjects, updateMask);
            // End snippet
        }

        /// <summary>Snippet for UpdateRecentProjectsAsync</summary>
        public async Task UpdateRecentProjectsAsync()
        {
            // Snippet: UpdateRecentProjectsAsync(RecentProjects, FieldMask, CallSettings)
            // Additional: UpdateRecentProjectsAsync(RecentProjects, FieldMask, CancellationToken)
            // Create client
            UserSettingsClient userSettingsClient = await UserSettingsClient.CreateAsync();
            // Initialize request argument(s)
            RecentProjects recentProjects = new RecentProjects();
            FieldMask updateMask = new FieldMask();
            // Make the request
            RecentProjects response = await userSettingsClient.UpdateRecentProjectsAsync(recentProjects, updateMask);
            // End snippet
        }
    }
}
