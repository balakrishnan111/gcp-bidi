# -*- coding: utf-8 -*-
# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v3alpha1',
    manifest={
        'RecentProjects',
        'GetRecentProjectsRequest',
        'UpdateRecentProjectsRequest',
    },
)


class RecentProjects(proto.Message):
    r"""Represents the recently-viewed projects of user.

    Attributes:
        name (str):
            Required. Resource name of recent projects. Format:
            'users/*/userSettings/recentProjects'.
        projects (MutableSequence[google.cloud.dialogflow_v3alpha1.types.RecentProjects.Project]):
            List of Projects.
    """

    class Project(proto.Message):
        r"""Represents single Project as recent projects in User
        Settings.

        Attributes:
            name (str):
                The unique identifier of a Project.
                Format: 'projects/<Project ID>'.
            view_time (google.protobuf.timestamp_pb2.Timestamp):
                The last view timestamp of a project.
        """

        name: str = proto.Field(
            proto.STRING,
            number=1,
        )
        view_time: timestamp_pb2.Timestamp = proto.Field(
            proto.MESSAGE,
            number=3,
            message=timestamp_pb2.Timestamp,
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    projects: MutableSequence[Project] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message=Project,
    )


class GetRecentProjectsRequest(proto.Message):
    r"""The request message for a
    [UserSettings.GetRecentProjects][google.cloud.dialogflow.v3alpha1.UserSettings.GetRecentProjects].

    Attributes:
        name (str):
            Required. Resource name of recent projects. Format:
            'users/*/userSettings/recentProjects'
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class UpdateRecentProjectsRequest(proto.Message):
    r"""The request message for a
    [UserSettings.UpdateRecentProjects][google.cloud.dialogflow.v3alpha1.UserSettings.UpdateRecentProjects].

    Attributes:
        recent_projects (google.cloud.dialogflow_v3alpha1.types.RecentProjects):
            Required. [RecentProjects] object that contains values for
            each of the fields to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            The mask to control which fields get updates.
            If the mask is not present, all fields will be
            updated.
    """

    recent_projects: 'RecentProjects' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='RecentProjects',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
