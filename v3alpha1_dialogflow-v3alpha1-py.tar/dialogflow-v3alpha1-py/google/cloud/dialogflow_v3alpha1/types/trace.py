# -*- coding: utf-8 -*-
# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.cloud.dialogflow_v3alpha1.types import data_store_connection
from google.protobuf import struct_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v3alpha1',
    manifest={
        'OutputState',
        'Action',
        'UserUtterance',
        'AgentUtterance',
        'ToolUse',
        'PlaybookInvocation',
        'FlowInvocation',
        'PlaybookInput',
        'PlaybookOutput',
    },
)


class OutputState(proto.Enum):
    r"""Output state.

    Values:
        OUTPUT_STATE_UNSPECIFIED (0):
            Unspecified output.
        OUTPUT_STATE_OK (1):
            Succeeded.
        OUTPUT_STATE_CANCELLED (2):
            Cancelled.
        OUTPUT_STATE_FAILED (3):
            Failed.
        OUTPUT_STATE_ESCALATED (4):
            Escalated.
        OUTPUT_STATE_PENDING (5):
            Pending.
    """
    OUTPUT_STATE_UNSPECIFIED = 0
    OUTPUT_STATE_OK = 1
    OUTPUT_STATE_CANCELLED = 2
    OUTPUT_STATE_FAILED = 3
    OUTPUT_STATE_ESCALATED = 4
    OUTPUT_STATE_PENDING = 5


class Action(proto.Message):
    r"""Action performed by end user or Dialogflow agent in the
    conversation.

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        user_utterance (google.cloud.dialogflow_v3alpha1.types.UserUtterance):
            Optional. Agent obtained a message from the
            customer.

            This field is a member of `oneof`_ ``action``.
        agent_utterance (google.cloud.dialogflow_v3alpha1.types.AgentUtterance):
            Optional. Action performed by the agent as a
            message.

            This field is a member of `oneof`_ ``action``.
        tool_use (google.cloud.dialogflow_v3alpha1.types.ToolUse):
            Optional. Action performed on behalf of the
            agent by calling a plugin tool.

            This field is a member of `oneof`_ ``action``.
        playbook_invocation (google.cloud.dialogflow_v3alpha1.types.PlaybookInvocation):
            Optional. Action performed on behalf of the
            agent by invoking a child playbook.

            This field is a member of `oneof`_ ``action``.
        flow_invocation (google.cloud.dialogflow_v3alpha1.types.FlowInvocation):
            Optional. Action performed on behalf of the
            agent by invoking a CX flow.

            This field is a member of `oneof`_ ``action``.
    """

    user_utterance: 'UserUtterance' = proto.Field(
        proto.MESSAGE,
        number=1,
        oneof='action',
        message='UserUtterance',
    )
    agent_utterance: 'AgentUtterance' = proto.Field(
        proto.MESSAGE,
        number=2,
        oneof='action',
        message='AgentUtterance',
    )
    tool_use: 'ToolUse' = proto.Field(
        proto.MESSAGE,
        number=3,
        oneof='action',
        message='ToolUse',
    )
    playbook_invocation: 'PlaybookInvocation' = proto.Field(
        proto.MESSAGE,
        number=4,
        oneof='action',
        message='PlaybookInvocation',
    )
    flow_invocation: 'FlowInvocation' = proto.Field(
        proto.MESSAGE,
        number=5,
        oneof='action',
        message='FlowInvocation',
    )


class UserUtterance(proto.Message):
    r"""UserUtterance represents one message sent by the customer.

    Attributes:
        text (str):
            Required. Message content in text.
    """

    text: str = proto.Field(
        proto.STRING,
        number=1,
    )


class AgentUtterance(proto.Message):
    r"""AgentUtterance represents one message sent by the agent.

    Attributes:
        text (str):
            Required. Message content in text.
    """

    text: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ToolUse(proto.Message):
    r"""Stores metadata of the invocation of an action supported by a
    tool.


    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        tool (str):
            Required. The [tool][google.cloud.dialogflow.v3alpha1.Tool]
            that should be used. Format:
            ``projects/<ProjectID>/locations/<LocationID>/agents/<AgentID>/tools/<ToolID>``.
        display_name (str):
            Output only. The display name of the tool.
        action (str):
            Optional. Name of the action to be called
            during the tool use.
        input_action_parameters (google.protobuf.struct_pb2.Struct):
            Optional. A list of input parameters for the
            action.
        output_action_parameters (google.protobuf.struct_pb2.Struct):
            Optional. A list of output parameters
            generated by the action.
        data_store_tool_trace (google.cloud.dialogflow_v3alpha1.types.ToolUse.DataStoreToolTrace):
            Optional. Data store tool trace.

            This field is a member of `oneof`_ ``ToolTrace``.
    """

    class DataStoreToolTrace(proto.Message):
        r"""The tracing information for the data store tool.

        Attributes:
            data_store_connection_signals (google.cloud.dialogflow_v3alpha1.types.DataStoreConnectionSignals):
                Optional. Data store connection feature
                output signals.
        """

        data_store_connection_signals: data_store_connection.DataStoreConnectionSignals = proto.Field(
            proto.MESSAGE,
            number=1,
            message=data_store_connection.DataStoreConnectionSignals,
        )

    tool: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=8,
    )
    action: str = proto.Field(
        proto.STRING,
        number=2,
    )
    input_action_parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=5,
        message=struct_pb2.Struct,
    )
    output_action_parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=6,
        message=struct_pb2.Struct,
    )
    data_store_tool_trace: DataStoreToolTrace = proto.Field(
        proto.MESSAGE,
        number=7,
        oneof='ToolTrace',
        message=DataStoreToolTrace,
    )


class PlaybookInvocation(proto.Message):
    r"""Stores metadata of the invocation of a child playbook.
    Playbook invocation actions enter the child playbook.

    Attributes:
        playbook (str):
            Required. The unique identifier of the playbook. Format:
            ``projects/<ProjectID>/locations/<LocationID>/agents/<AgentID>/playbooks/<PlaybookID>``.
        display_name (str):
            Output only. The display name of the
            playbook.
        playbook_input (google.cloud.dialogflow_v3alpha1.types.PlaybookInput):
            Optional. Input of the child playbook
            invocation.
        playbook_output (google.cloud.dialogflow_v3alpha1.types.PlaybookOutput):
            Optional. Output of the child playbook
            invocation.
        playbook_state (google.cloud.dialogflow_v3alpha1.types.OutputState):
            Required. Playbook invocation's output state.
    """

    playbook: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=5,
    )
    playbook_input: 'PlaybookInput' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='PlaybookInput',
    )
    playbook_output: 'PlaybookOutput' = proto.Field(
        proto.MESSAGE,
        number=3,
        message='PlaybookOutput',
    )
    playbook_state: 'OutputState' = proto.Field(
        proto.ENUM,
        number=4,
        enum='OutputState',
    )


class FlowInvocation(proto.Message):
    r"""Stores metadata of the invocation of a child CX flow. Flow
    invocation actions enter the child flow.

    Attributes:
        flow (str):
            Required. The unique identifier of the flow. Format:
            ``projects/<ProjectID>/locations/<LocationID>/agents/<Agentflows/<FlowID>``.
        display_name (str):
            Output only. The display name of the flow.
        input_action_parameters (google.protobuf.struct_pb2.Struct):
            Optional. A list of input parameters for the
            flow.
        output_action_parameters (google.protobuf.struct_pb2.Struct):
            Optional. A list of output parameters
            generated by the flow invocation.
        flow_state (google.cloud.dialogflow_v3alpha1.types.OutputState):
            Required. Flow invocation's output state.
    """

    flow: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=7,
    )
    input_action_parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=5,
        message=struct_pb2.Struct,
    )
    output_action_parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=6,
        message=struct_pb2.Struct,
    )
    flow_state: 'OutputState' = proto.Field(
        proto.ENUM,
        number=4,
        enum='OutputState',
    )


class PlaybookInput(proto.Message):
    r"""Input of the playbook.

    Attributes:
        preceding_conversation_summary (str):
            Optional. Summary string of the preceding
            conversation for the child playbook invocation.
        action_parameters (google.protobuf.struct_pb2.Struct):
            Optional. A list of input parameters for the
            action.
    """

    preceding_conversation_summary: str = proto.Field(
        proto.STRING,
        number=1,
    )
    action_parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=3,
        message=struct_pb2.Struct,
    )


class PlaybookOutput(proto.Message):
    r"""Output of the playbook.

    Attributes:
        execution_summary (str):
            Optional. Summary string of the execution
            result of the child playbook.
        state (google.cloud.dialogflow_v3alpha1.types.PlaybookOutput.State):
            End state of the playbook.
        action_parameters (google.protobuf.struct_pb2.Struct):
            Optional. A Struct object of output
            parameters for the action.
    """
    class State(proto.Enum):
        r"""Playbook output state.

        Values:
            STATE_UNSPECIFIED (0):
                Unspecified state.
            OK (1):
                Playbook succeeded.
            CANCELLED (2):
                Playbook cancelled.
            FAILED (3):
                Playbook failed.
            ESCALATED (4):
                Playbook failed due to escalation.
        """
        _pb_options = {'deprecated': True}
        STATE_UNSPECIFIED = 0
        OK = 1
        CANCELLED = 2
        FAILED = 3
        ESCALATED = 4

    execution_summary: str = proto.Field(
        proto.STRING,
        number=1,
    )
    state: State = proto.Field(
        proto.ENUM,
        number=2,
        enum=State,
    )
    action_parameters: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=4,
        message=struct_pb2.Struct,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
