# -*- coding: utf-8 -*-
# Copyright 2024 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import logging
import json  # type: ignore

from google.auth.transport.requests import AuthorizedSession  # type: ignore
from google.auth import credentials as ga_credentials  # type: ignore
from google.api_core import exceptions as core_exceptions
from google.api_core import retry as retries
from google.api_core import rest_helpers
from google.api_core import rest_streaming
from google.api_core import gapic_v1

from google.protobuf import json_format
from google.api_core import operations_v1
from google.cloud.location import locations_pb2 # type: ignore

from requests import __version__ as requests_version
import dataclasses
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union
import warnings


from google.cloud.dialogflow_v3alpha1.types import tool
from google.cloud.dialogflow_v3alpha1.types import tool as gcd_tool
from google.protobuf import empty_pb2  # type: ignore
from google.longrunning import operations_pb2  # type: ignore


from .rest_base import _BaseToolsRestTransport
from .base import DEFAULT_CLIENT_INFO as BASE_DEFAULT_CLIENT_INFO

try:
    OptionalRetry = Union[retries.Retry, gapic_v1.method._MethodDefault, None]
except AttributeError:  # pragma: NO COVER
    OptionalRetry = Union[retries.Retry, object, None]  # type: ignore

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = logging.getLogger(__name__)

DEFAULT_CLIENT_INFO = gapic_v1.client_info.ClientInfo(
    gapic_version=BASE_DEFAULT_CLIENT_INFO.gapic_version,
    grpc_version=None,
    rest_version=f"requests@{requests_version}",
)


class ToolsRestInterceptor:
    """Interceptor for Tools.

    Interceptors are used to manipulate requests, request metadata, and responses
    in arbitrary ways.
    Example use cases include:
    * Logging
    * Verifying requests according to service or custom semantics
    * Stripping extraneous information from responses

    These use cases and more can be enabled by injecting an
    instance of a custom subclass when constructing the ToolsRestTransport.

    .. code-block:: python
        class MyCustomToolsInterceptor(ToolsRestInterceptor):
            def pre_create_tool(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_create_tool(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_delete_tool(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def pre_export_tools(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_export_tools(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_get_tool(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_get_tool(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_tools(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_tools(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_update_tool(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_update_tool(self, response):
                logging.log(f"Received response: {response}")
                return response

        transport = ToolsRestTransport(interceptor=MyCustomToolsInterceptor())
        client = ToolsClient(transport=transport)


    """
    def pre_create_tool(self, request: gcd_tool.CreateToolRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_tool.CreateToolRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for create_tool

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_create_tool(self, response: gcd_tool.Tool) -> gcd_tool.Tool:
        """Post-rpc interceptor for create_tool

        DEPRECATED. Please use the `post_create_tool_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code. This `post_create_tool` interceptor runs
        before the `post_create_tool_with_metadata` interceptor.
        """
        return response

    def post_create_tool_with_metadata(self, response: gcd_tool.Tool, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_tool.Tool, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for create_tool

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Tools server but before it is returned to user code.

        We recommend only using this `post_create_tool_with_metadata`
        interceptor in new development instead of the `post_create_tool` interceptor.
        When both interceptors are used, this `post_create_tool_with_metadata` interceptor runs after the
        `post_create_tool` interceptor. The (possibly modified) response returned by
        `post_create_tool` will be passed to
        `post_create_tool_with_metadata`.
        """
        return response, metadata

    def pre_delete_tool(self, request: tool.DeleteToolRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[tool.DeleteToolRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for delete_tool

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def pre_export_tools(self, request: tool.ExportToolsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[tool.ExportToolsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for export_tools

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_export_tools(self, response: operations_pb2.Operation) -> operations_pb2.Operation:
        """Post-rpc interceptor for export_tools

        DEPRECATED. Please use the `post_export_tools_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code. This `post_export_tools` interceptor runs
        before the `post_export_tools_with_metadata` interceptor.
        """
        return response

    def post_export_tools_with_metadata(self, response: operations_pb2.Operation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[operations_pb2.Operation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for export_tools

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Tools server but before it is returned to user code.

        We recommend only using this `post_export_tools_with_metadata`
        interceptor in new development instead of the `post_export_tools` interceptor.
        When both interceptors are used, this `post_export_tools_with_metadata` interceptor runs after the
        `post_export_tools` interceptor. The (possibly modified) response returned by
        `post_export_tools` will be passed to
        `post_export_tools_with_metadata`.
        """
        return response, metadata

    def pre_get_tool(self, request: tool.GetToolRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[tool.GetToolRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_tool

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_get_tool(self, response: tool.Tool) -> tool.Tool:
        """Post-rpc interceptor for get_tool

        DEPRECATED. Please use the `post_get_tool_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code. This `post_get_tool` interceptor runs
        before the `post_get_tool_with_metadata` interceptor.
        """
        return response

    def post_get_tool_with_metadata(self, response: tool.Tool, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[tool.Tool, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for get_tool

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Tools server but before it is returned to user code.

        We recommend only using this `post_get_tool_with_metadata`
        interceptor in new development instead of the `post_get_tool` interceptor.
        When both interceptors are used, this `post_get_tool_with_metadata` interceptor runs after the
        `post_get_tool` interceptor. The (possibly modified) response returned by
        `post_get_tool` will be passed to
        `post_get_tool_with_metadata`.
        """
        return response, metadata

    def pre_list_tools(self, request: tool.ListToolsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[tool.ListToolsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_tools

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_list_tools(self, response: tool.ListToolsResponse) -> tool.ListToolsResponse:
        """Post-rpc interceptor for list_tools

        DEPRECATED. Please use the `post_list_tools_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code. This `post_list_tools` interceptor runs
        before the `post_list_tools_with_metadata` interceptor.
        """
        return response

    def post_list_tools_with_metadata(self, response: tool.ListToolsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[tool.ListToolsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_tools

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Tools server but before it is returned to user code.

        We recommend only using this `post_list_tools_with_metadata`
        interceptor in new development instead of the `post_list_tools` interceptor.
        When both interceptors are used, this `post_list_tools_with_metadata` interceptor runs after the
        `post_list_tools` interceptor. The (possibly modified) response returned by
        `post_list_tools` will be passed to
        `post_list_tools_with_metadata`.
        """
        return response, metadata

    def pre_update_tool(self, request: gcd_tool.UpdateToolRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_tool.UpdateToolRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for update_tool

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_update_tool(self, response: gcd_tool.Tool) -> gcd_tool.Tool:
        """Post-rpc interceptor for update_tool

        DEPRECATED. Please use the `post_update_tool_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code. This `post_update_tool` interceptor runs
        before the `post_update_tool_with_metadata` interceptor.
        """
        return response

    def post_update_tool_with_metadata(self, response: gcd_tool.Tool, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_tool.Tool, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for update_tool

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Tools server but before it is returned to user code.

        We recommend only using this `post_update_tool_with_metadata`
        interceptor in new development instead of the `post_update_tool` interceptor.
        When both interceptors are used, this `post_update_tool_with_metadata` interceptor runs after the
        `post_update_tool` interceptor. The (possibly modified) response returned by
        `post_update_tool` will be passed to
        `post_update_tool_with_metadata`.
        """
        return response, metadata

    def pre_get_location(
        self, request: locations_pb2.GetLocationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.GetLocationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_location

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_get_location(
        self, response: locations_pb2.Location
    ) -> locations_pb2.Location:
        """Post-rpc interceptor for get_location

        Override in a subclass to manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code.
        """
        return response

    def pre_list_locations(
        self, request: locations_pb2.ListLocationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.ListLocationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_locations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_list_locations(
        self, response: locations_pb2.ListLocationsResponse
    ) -> locations_pb2.ListLocationsResponse:
        """Post-rpc interceptor for list_locations

        Override in a subclass to manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code.
        """
        return response

    def pre_cancel_operation(
        self, request: operations_pb2.CancelOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.CancelOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_cancel_operation(
        self, response: None
    ) -> None:
        """Post-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code.
        """
        return response

    def pre_get_operation(
        self, request: operations_pb2.GetOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.GetOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_get_operation(
        self, response: operations_pb2.Operation
    ) -> operations_pb2.Operation:
        """Post-rpc interceptor for get_operation

        Override in a subclass to manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code.
        """
        return response

    def pre_list_operations(
        self, request: operations_pb2.ListOperationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.ListOperationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_operations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Tools server.
        """
        return request, metadata

    def post_list_operations(
        self, response: operations_pb2.ListOperationsResponse
    ) -> operations_pb2.ListOperationsResponse:
        """Post-rpc interceptor for list_operations

        Override in a subclass to manipulate the response
        after it is returned by the Tools server but before
        it is returned to user code.
        """
        return response


@dataclasses.dataclass
class ToolsRestStub:
    _session: AuthorizedSession
    _host: str
    _interceptor: ToolsRestInterceptor


class ToolsRestTransport(_BaseToolsRestTransport):
    """REST backend synchronous transport for Tools.

    Service for managing [Tools][google.cloud.dialogflow.v3alpha1.Tool].

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends JSON representations of protocol buffers over HTTP/1.1
    """

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            client_cert_source_for_mtls: Optional[Callable[[
                ], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            url_scheme: str = 'https',
            interceptor: Optional[ToolsRestInterceptor] = None,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

       NOTE: This REST transport functionality is currently in a beta
       state (preview). We welcome your feedback via a GitHub issue in
       this library's repository. Thank you!

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.

            credentials_file (Optional[str]): A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if ``channel`` is provided.
            scopes (Optional(Sequence[str])): A list of scopes. This argument is
                ignored if ``channel`` is provided.
            client_cert_source_for_mtls (Callable[[], Tuple[bytes, bytes]]): Client
                certificate to configure mutual TLS HTTP channel. It is ignored
                if ``channel`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you are developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.
            url_scheme: the protocol scheme for the API endpoint.  Normally
                "https", but for testing or local servers,
                "http" can be specified.
        """
        # Run the base constructor
        # TODO(yon-mg): resolve other ctor params i.e. scopes, quota, etc.
        # TODO: When custom host (api_endpoint) is set, `scopes` must *also* be set on the
        # credentials object
        super().__init__(
            host=host,
            credentials=credentials,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            url_scheme=url_scheme,
            api_audience=api_audience
        )
        self._session = AuthorizedSession(
            self._credentials, default_host=self.DEFAULT_HOST)
        self._operations_client: Optional[operations_v1.AbstractOperationsClient] = None
        if client_cert_source_for_mtls:
            self._session.configure_mtls_channel(client_cert_source_for_mtls)
        self._interceptor = interceptor or ToolsRestInterceptor()
        self._prep_wrapped_messages(client_info)

    @property
    def operations_client(self) -> operations_v1.AbstractOperationsClient:
        """Create the client designed to process long-running operations.

        This property caches on the instance; repeated calls return the same
        client.
        """
        # Only create a new client if we do not already have one.
        if self._operations_client is None:
            http_options: Dict[str, List[Dict[str, str]]] = {
                'google.longrunning.Operations.CancelOperation': [
                    {
                        'method': 'post',
                        'uri': '/v3alpha1/{name=projects/*/operations/*}:cancel',
                    },
                    {
                        'method': 'post',
                        'uri': '/v3alpha1/{name=projects/*/locations/*/operations/*}:cancel',
                    },
                ],
                'google.longrunning.Operations.GetOperation': [
                    {
                        'method': 'get',
                        'uri': '/v3alpha1/{name=projects/*/operations/*}',
                    },
                    {
                        'method': 'get',
                        'uri': '/v3alpha1/{name=projects/*/locations/*/operations/*}',
                    },
                ],
                'google.longrunning.Operations.ListOperations': [
                    {
                        'method': 'get',
                        'uri': '/v3alpha1/{name=projects/*}/operations',
                    },
                    {
                        'method': 'get',
                        'uri': '/v3alpha1/{name=projects/*/locations/*}/operations',
                    },
                ],
            }

            rest_transport = operations_v1.OperationsRestTransport(
                    host=self._host,
                    # use the credentials which are saved
                    credentials=self._credentials,
                    scopes=self._scopes,
                    http_options=http_options,
                    path_prefix="v3alpha1")

            self._operations_client = operations_v1.AbstractOperationsClient(transport=rest_transport)

        # Return the client from cache.
        return self._operations_client

    class _CreateTool(_BaseToolsRestTransport._BaseCreateTool, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.CreateTool")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_tool.CreateToolRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_tool.Tool:
            r"""Call the create tool method over HTTP.

            Args:
                request (~.gcd_tool.CreateToolRequest):
                    The request object. The request message for
                [Tools.CreateTool][google.cloud.dialogflow.v3alpha1.Tools.CreateTool].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_tool.Tool:
                    A tool provides a list of actions which are available to
                the
                [Playbook][google.cloud.dialogflow.v3alpha1.Playbook] to
                attain its goal. A Tool consists of a description of the
                tool's usage and a specification of the tool which
                contains the schema and authentication information.

            """

            http_options = _BaseToolsRestTransport._BaseCreateTool._get_http_options()

            request, metadata = self._interceptor.pre_create_tool(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseCreateTool._get_transcoded_request(http_options, request)

            body = _BaseToolsRestTransport._BaseCreateTool._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseCreateTool._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.CreateTool",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "CreateTool",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._CreateTool._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_tool.Tool()
            pb_resp = gcd_tool.Tool.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_create_tool(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_create_tool_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_tool.Tool.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsClient.create_tool",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "CreateTool",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _DeleteTool(_BaseToolsRestTransport._BaseDeleteTool, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.DeleteTool")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: tool.DeleteToolRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ):
            r"""Call the delete tool method over HTTP.

            Args:
                request (~.tool.DeleteToolRequest):
                    The request object. The request message for
                [Tools.DeleteTool][google.cloud.dialogflow.v3alpha1.Tools.DeleteTool].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseToolsRestTransport._BaseDeleteTool._get_http_options()

            request, metadata = self._interceptor.pre_delete_tool(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseDeleteTool._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseDeleteTool._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.DeleteTool",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "DeleteTool",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._DeleteTool._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

    class _ExportTools(_BaseToolsRestTransport._BaseExportTools, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.ExportTools")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: tool.ExportToolsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> operations_pb2.Operation:
            r"""Call the export tools method over HTTP.

            Args:
                request (~.tool.ExportToolsRequest):
                    The request object. The request message for
                [Tools.ExportTools][google.cloud.dialogflow.v3alpha1.Tools.ExportTools].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.operations_pb2.Operation:
                    This resource represents a
                long-running operation that is the
                result of a network API call.

            """

            http_options = _BaseToolsRestTransport._BaseExportTools._get_http_options()

            request, metadata = self._interceptor.pre_export_tools(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseExportTools._get_transcoded_request(http_options, request)

            body = _BaseToolsRestTransport._BaseExportTools._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseExportTools._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.ExportTools",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "ExportTools",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._ExportTools._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = operations_pb2.Operation()
            json_format.Parse(response.content, resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_export_tools(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_export_tools_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsClient.export_tools",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "ExportTools",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GetTool(_BaseToolsRestTransport._BaseGetTool, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.GetTool")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: tool.GetToolRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> tool.Tool:
            r"""Call the get tool method over HTTP.

            Args:
                request (~.tool.GetToolRequest):
                    The request object. The request message for
                [Tools.GetTool][google.cloud.dialogflow.v3alpha1.Tools.GetTool].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.tool.Tool:
                    A tool provides a list of actions which are available to
                the
                [Playbook][google.cloud.dialogflow.v3alpha1.Playbook] to
                attain its goal. A Tool consists of a description of the
                tool's usage and a specification of the tool which
                contains the schema and authentication information.

            """

            http_options = _BaseToolsRestTransport._BaseGetTool._get_http_options()

            request, metadata = self._interceptor.pre_get_tool(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseGetTool._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseGetTool._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.GetTool",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "GetTool",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._GetTool._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = tool.Tool()
            pb_resp = tool.Tool.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_get_tool(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_get_tool_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = tool.Tool.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsClient.get_tool",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "GetTool",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListTools(_BaseToolsRestTransport._BaseListTools, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.ListTools")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: tool.ListToolsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> tool.ListToolsResponse:
            r"""Call the list tools method over HTTP.

            Args:
                request (~.tool.ListToolsRequest):
                    The request object. The request message for
                [Tools.ListTools][google.cloud.dialogflow.v3alpha1.Tools.ListTools].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.tool.ListToolsResponse:
                    The response message for
                [Tools.ListTools][google.cloud.dialogflow.v3alpha1.Tools.ListTools].

            """

            http_options = _BaseToolsRestTransport._BaseListTools._get_http_options()

            request, metadata = self._interceptor.pre_list_tools(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseListTools._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseListTools._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.ListTools",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "ListTools",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._ListTools._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = tool.ListToolsResponse()
            pb_resp = tool.ListToolsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_tools(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_tools_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = tool.ListToolsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsClient.list_tools",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "ListTools",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _UpdateTool(_BaseToolsRestTransport._BaseUpdateTool, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.UpdateTool")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_tool.UpdateToolRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_tool.Tool:
            r"""Call the update tool method over HTTP.

            Args:
                request (~.gcd_tool.UpdateToolRequest):
                    The request object. The request message for
                [Tools.UpdateTool][google.cloud.dialogflow.v3alpha1.Tools.UpdateTool].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_tool.Tool:
                    A tool provides a list of actions which are available to
                the
                [Playbook][google.cloud.dialogflow.v3alpha1.Playbook] to
                attain its goal. A Tool consists of a description of the
                tool's usage and a specification of the tool which
                contains the schema and authentication information.

            """

            http_options = _BaseToolsRestTransport._BaseUpdateTool._get_http_options()

            request, metadata = self._interceptor.pre_update_tool(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseUpdateTool._get_transcoded_request(http_options, request)

            body = _BaseToolsRestTransport._BaseUpdateTool._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseUpdateTool._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.UpdateTool",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "UpdateTool",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._UpdateTool._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_tool.Tool()
            pb_resp = gcd_tool.Tool.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_update_tool(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_update_tool_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_tool.Tool.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsClient.update_tool",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "UpdateTool",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    @property
    def create_tool(self) -> Callable[
            [gcd_tool.CreateToolRequest],
            gcd_tool.Tool]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CreateTool(self._session, self._host, self._interceptor) # type: ignore

    @property
    def delete_tool(self) -> Callable[
            [tool.DeleteToolRequest],
            empty_pb2.Empty]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._DeleteTool(self._session, self._host, self._interceptor) # type: ignore

    @property
    def export_tools(self) -> Callable[
            [tool.ExportToolsRequest],
            operations_pb2.Operation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ExportTools(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_tool(self) -> Callable[
            [tool.GetToolRequest],
            tool.Tool]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GetTool(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_tools(self) -> Callable[
            [tool.ListToolsRequest],
            tool.ListToolsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListTools(self._session, self._host, self._interceptor) # type: ignore

    @property
    def update_tool(self) -> Callable[
            [gcd_tool.UpdateToolRequest],
            gcd_tool.Tool]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._UpdateTool(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_location(self):
        return self._GetLocation(self._session, self._host, self._interceptor) # type: ignore

    class _GetLocation(_BaseToolsRestTransport._BaseGetLocation, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.GetLocation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.GetLocationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.Location:

            r"""Call the get location method over HTTP.

            Args:
                request (locations_pb2.GetLocationRequest):
                    The request object for GetLocation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.Location: Response from GetLocation method.
            """

            http_options = _BaseToolsRestTransport._BaseGetLocation._get_http_options()

            request, metadata = self._interceptor.pre_get_location(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseGetLocation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseGetLocation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "GetLocation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._GetLocation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.Location()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_location(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsAsyncClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "GetLocation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_locations(self):
        return self._ListLocations(self._session, self._host, self._interceptor) # type: ignore

    class _ListLocations(_BaseToolsRestTransport._BaseListLocations, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.ListLocations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.ListLocationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.ListLocationsResponse:

            r"""Call the list locations method over HTTP.

            Args:
                request (locations_pb2.ListLocationsRequest):
                    The request object for ListLocations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.ListLocationsResponse: Response from ListLocations method.
            """

            http_options = _BaseToolsRestTransport._BaseListLocations._get_http_options()

            request, metadata = self._interceptor.pre_list_locations(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseListLocations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseListLocations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "ListLocations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._ListLocations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.ListLocationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_locations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsAsyncClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "ListLocations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def cancel_operation(self):
        return self._CancelOperation(self._session, self._host, self._interceptor) # type: ignore

    class _CancelOperation(_BaseToolsRestTransport._BaseCancelOperation, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.CancelOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.CancelOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> None:

            r"""Call the cancel operation method over HTTP.

            Args:
                request (operations_pb2.CancelOperationRequest):
                    The request object for CancelOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseToolsRestTransport._BaseCancelOperation._get_http_options()

            request, metadata = self._interceptor.pre_cancel_operation(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseCancelOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseCancelOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.CancelOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "CancelOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._CancelOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            return self._interceptor.post_cancel_operation(None)

    @property
    def get_operation(self):
        return self._GetOperation(self._session, self._host, self._interceptor) # type: ignore

    class _GetOperation(_BaseToolsRestTransport._BaseGetOperation, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.GetOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.GetOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.Operation:

            r"""Call the get operation method over HTTP.

            Args:
                request (operations_pb2.GetOperationRequest):
                    The request object for GetOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.Operation: Response from GetOperation method.
            """

            http_options = _BaseToolsRestTransport._BaseGetOperation._get_http_options()

            request, metadata = self._interceptor.pre_get_operation(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseGetOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseGetOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "GetOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._GetOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.Operation()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_operation(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsAsyncClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "GetOperation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_operations(self):
        return self._ListOperations(self._session, self._host, self._interceptor) # type: ignore

    class _ListOperations(_BaseToolsRestTransport._BaseListOperations, ToolsRestStub):
        def __hash__(self):
            return hash("ToolsRestTransport.ListOperations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.ListOperationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.ListOperationsResponse:

            r"""Call the list operations method over HTTP.

            Args:
                request (operations_pb2.ListOperationsRequest):
                    The request object for ListOperations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.ListOperationsResponse: Response from ListOperations method.
            """

            http_options = _BaseToolsRestTransport._BaseListOperations._get_http_options()

            request, metadata = self._interceptor.pre_list_operations(request, metadata)
            transcoded_request = _BaseToolsRestTransport._BaseListOperations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseToolsRestTransport._BaseListOperations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v3alpha1.ToolsClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "ListOperations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ToolsRestTransport._ListOperations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.ListOperationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_operations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v3alpha1.ToolsAsyncClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v3alpha1.Tools",
                        "rpcName": "ListOperations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def kind(self) -> str:
        return "rest"

    def close(self):
        self._session.close()


__all__=(
    'ToolsRestTransport',
)
