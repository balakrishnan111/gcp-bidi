Playbooks
---------------------------

.. automodule:: google.cloud.dialogflow_v3alpha1.services.playbooks
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v3alpha1.services.playbooks.pagers
    :members:
    :inherited-members:
