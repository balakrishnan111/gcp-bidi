# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'PhoneNumberOrder',
        'PhoneNumberSpec',
        'CreatePhoneNumberOrderRequest',
        'GetPhoneNumberOrderRequest',
        'ListPhoneNumberOrdersRequest',
        'ListPhoneNumberOrdersResponse',
        'UpdatePhoneNumberOrderRequest',
        'CancelPhoneNumberOrderRequest',
    },
)


class PhoneNumberOrder(proto.Message):
    r"""Represents a phone number order.
    Orders can assign phone numbers to projects.


    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        name (str):
            Optional. The unique identifier of this order. Required for
            [PhoneNumberOrders.UpdatePhoneNumberOrder][google.cloud.dialogflow.v2beta1.PhoneNumberOrders.UpdatePhoneNumberOrder]
            method. Format:
            ``projects/<Project ID>/phoneNumberOrders/<Order ID>``.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/phoneNumberOrders/<Order ID>``.
        phone_number_spec (google.cloud.dialogflow_v2beta1.types.PhoneNumberSpec):
            Order is for new numbers.

            This field is a member of `oneof`_ ``order``.
        description (str):
            Optional. A description of the order, limit
            is 1024 bytes.
        lifecycle_state (google.cloud.dialogflow_v2beta1.types.PhoneNumberOrder.LifecycleState):
            Output only. The current status of the order.
        phone_numbers (MutableMapping[str, str]):
            Output only. A map of ordered numbers filled so far, keyed
            by their resource name. Key format:
            ``projects/<Project ID>/phoneNumbers/<PhoneNumber ID>``.
            Value format: E.164 phone number. Output only.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The time this order was created.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. The time this order was last
            updated.
    """
    class LifecycleState(proto.Enum):
        r"""Enumeration of the different statuses the order can be in
        during its lifecycle.

        Values:
            LIFECYCLE_STATE_UNSPECIFIED (0):
                Unknown.
            PENDING (1):
                Order is awaiting action.
            IN_PROGRESS (2):
                Order is being worked on, and is partially
                fulfilled.
            COMPLETED (3):
                Order has been fulfilled.
            CANCELLED (4):
                Order has been cancelled.
        """
        LIFECYCLE_STATE_UNSPECIFIED = 0
        PENDING = 1
        IN_PROGRESS = 2
        COMPLETED = 3
        CANCELLED = 4

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    phone_number_spec: 'PhoneNumberSpec' = proto.Field(
        proto.MESSAGE,
        number=2,
        oneof='order',
        message='PhoneNumberSpec',
    )
    description: str = proto.Field(
        proto.STRING,
        number=4,
    )
    lifecycle_state: LifecycleState = proto.Field(
        proto.ENUM,
        number=5,
        enum=LifecycleState,
    )
    phone_numbers: MutableMapping[str, str] = proto.MapField(
        proto.STRING,
        proto.STRING,
        number=6,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=7,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=8,
        message=timestamp_pb2.Timestamp,
    )


class PhoneNumberSpec(proto.Message):
    r"""Request for new numbers fitting a set of parameters.
    The country code for newly requested numbers defaults to 1 (US)
    until the service is available in other regions.

    Attributes:
        country_code (int):
            Required. ITU country calling code for the
            requested numbers. Defaults to 1 (US) until the
            service is available in other regions.
        preferred_area_codes (MutableSequence[str]):
            Optional. Area codes to use. An empty list means 'any code'.
            Each value is treated as equally preferred. Each entry has a
            limit of 10 bytes. "area code" corresponds to "National
            Destination Code" described in
            `E.164 <https://en.wikipedia.org/wiki/E.164>`__ standard.
        count (int):
            Required. Total numbers requested, between 1
            and 10 inclusive.
    """

    country_code: int = proto.Field(
        proto.INT32,
        number=1,
    )
    preferred_area_codes: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=2,
    )
    count: int = proto.Field(
        proto.INT32,
        number=3,
    )


class CreatePhoneNumberOrderRequest(proto.Message):
    r"""The request message for
    [PhoneNumberOrders.CreatePhoneNumberOrder][google.cloud.dialogflow.v2beta1.PhoneNumberOrders.CreatePhoneNumberOrder].

    Attributes:
        parent (str):
            Required. Resource identifier of the project requesting the
            orders. Format: ``projects/<Project ID>``. Format:
            ``projects/<Project ID>/locations/<Location ID>``.
        phone_number_order (google.cloud.dialogflow_v2beta1.types.PhoneNumberOrder):
            Required. The order to create.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    phone_number_order: 'PhoneNumberOrder' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='PhoneNumberOrder',
    )


class GetPhoneNumberOrderRequest(proto.Message):
    r"""The request message for
    [PhoneNumberOrders.GetPhoneNumberOrder][google.cloud.dialogflow.v2beta1.PhoneNumberOrders.GetPhoneNumberOrder].

    Attributes:
        name (str):
            Required. The unique identifier of the order to retrieve.
            Format:
            ``projects/<Project ID>/phoneNumberOrders/<Order ID>``.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/phoneNumberOrders/<Order ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListPhoneNumberOrdersRequest(proto.Message):
    r"""The request message for
    [PhoneNumberOrders.ListPhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrders.ListPhoneNumberOrders].

    Attributes:
        parent (str):
            Required. The project to list all orders from. Format:
            ``projects/<Project ID>``. Format:
            ``projects/<Project ID>/locations/<Location ID>``.
        page_size (int):
            Optional. The maximum number of items to
            return in a single page. The default value is
            100. The maximum value is 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=4,
    )


class ListPhoneNumberOrdersResponse(proto.Message):
    r"""The response message for
    [PhoneNumberOrders.ListPhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrders.ListPhoneNumberOrders].

    Attributes:
        phone_number_orders (MutableSequence[google.cloud.dialogflow_v2beta1.types.PhoneNumberOrder]):
            The list of orders. There is a maximum number of items
            returned based on the page_size field in the request.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    phone_number_orders: MutableSequence['PhoneNumberOrder'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='PhoneNumberOrder',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class UpdatePhoneNumberOrderRequest(proto.Message):
    r"""The request message for
    [PhoneNumberOrders.UpdatePhoneNumberOrder][google.cloud.dialogflow.v2beta1.PhoneNumberOrders.UpdatePhoneNumberOrder].

    Attributes:
        phone_number_order (google.cloud.dialogflow_v2beta1.types.PhoneNumberOrder):
            Required. The order to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Optional. The mask to control which fields
            get updated.
    """

    phone_number_order: 'PhoneNumberOrder' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='PhoneNumberOrder',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class CancelPhoneNumberOrderRequest(proto.Message):
    r"""The request message for
    [PhoneNumberOrders.CancelPhoneNumberOrder][google.cloud.dialogflow.v2beta1.PhoneNumberOrders.CancelPhoneNumberOrder].

    Attributes:
        name (str):
            Required. The unique identifier of the order to delete.
            Format:
            ``projects/<Project ID>/phoneNumberOrders/<Order ID>``.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/phoneNumberOrders/<Order ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
