# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import field_mask_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'GetSecuritySettingsRequest',
        'UpdateSecuritySettingsRequest',
        'SecuritySettings',
    },
)


class GetSecuritySettingsRequest(proto.Message):
    r"""The request message for
    [SecuritySettingsService.GetSecuritySettings].

    Attributes:
        name (str):
            Required. Resource name of the settings. Format:
            ``projects/<Project ID>/securitySettings``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class UpdateSecuritySettingsRequest(proto.Message):
    r"""The request message for
    [SecuritySettingsService.UpdateSecuritySettings].

    Attributes:
        settings (google.cloud.dialogflow_v2beta1.types.SecuritySettings):
            Required. [SecuritySettings] object that contains values for
            each of the fields to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Required. The mask to control which fields
            get updated. Using an empty mask is an error.
    """

    settings: 'SecuritySettings' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='SecuritySettings',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class SecuritySettings(proto.Message):
    r"""Represents project-wide settings related to security issues,
    such as data redaction and data retention.
    It may take hours for updates on these settings to propagate to
    all the related components and take effect.


    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        name (str):
            Required. Resource name of the settings. Format:
            ``projects/<Project ID>/securitySettings``.
        redaction_strategy (google.cloud.dialogflow_v2beta1.types.SecuritySettings.RedactionStrategy):
            Optional. Strategy that defines how we do
            redaction.
        redaction_scope (google.cloud.dialogflow_v2beta1.types.SecuritySettings.RedactionScope):
            Optional. Defines on what data we apply
            redaction. Note that we don't redact data to
            which we don't have access, e.g., Stackdriver
            logs.
        inspect_template (str):
            Optional. `DLP <https://cloud.google.com/dlp/docs>`__
            inspect template name. Use this template to define inspect
            base settings.

            If empty, we use the default DLP inspect config.

            The template name will have one of the following formats:
            ``projects/<Project ID>/locations/<Location ID>/inspectTemplates/<Template ID>``
            OR
            ``organizations/<Organization ID>/locations/<Location ID>/inspectTemplates/<Template ID>``

            Note: ``inspect_template`` must be located in the same
            region as the ``SecuritySettings``.
        deidentify_template (str):
            Optional. `DLP <https://cloud.google.com/dlp/docs>`__
            deidentify template name. Use this template to define
            de-identification configuration for the content.

            If empty, Dialogflow replaces sensitive info with
            ``[redacted]`` text.

            The template name will have one of the following formats:
            ``projects/<Project ID>/locations/<Location ID>/deidentifyTemplates/<Template ID>``
            OR
            ``organizations/<Organization ID>/locations/<Location ID>/deidentifyTemplates/<Template ID>``

            Note: ``deidentify_template`` must be located in the same
            region as the ``SecuritySettings``.
        retention_window_days (int):
            Retains the data for the specified number of
            days. User must set a value lower than
            Dialogflow's default 365d TTL (30 days for Agent
            Assist traffic), higher value will be ignored
            and use default. Setting a value higher than
            that has no effect. A missing value or setting
            to 0 also means we use default TTL.
            When data retention configuration is changed, it
            only applies to the data created after the
            change; the TTL of existing data created before
            the change stays intact.

            This field is a member of `oneof`_ ``data_retention``.
        purge_data_types (MutableSequence[google.cloud.dialogflow_v2beta1.types.SecuritySettings.PurgeDataType]):
            Optional. List of types of data to remove
            when retention settings triggers purge.
        audio_export_settings (google.cloud.dialogflow_v2beta1.types.SecuritySettings.AudioExportSettings):
            Optional. Controls audio export settings for
            post-conversation analytics when ingesting audio to
            conversations via
            [Participants.AnalyzeContent][google.cloud.dialogflow.v2beta1.Participants.AnalyzeContent]
            or
            [Participants.StreamingAnalyzeContent][google.cloud.dialogflow.v2beta1.Participants.StreamingAnalyzeContent].

            If
            [retention_strategy][google.cloud.dialogflow.v2beta1.SecuritySettings.retention_strategy]
            is set to REMOVE_AFTER_CONVERSATION or
            [audio_export_settings.gcs_bucket][] is empty, audio export
            is disabled.

            If audio export is enabled, audio is recorded and saved to
            [audio_export_settings.gcs_bucket][], subject to retention
            policy of [audio_export_settings.gcs_bucket][].

            This setting won't effect audio input for implicit sessions
            via
            [Sessions.DetectIntent][google.cloud.dialogflow.v2beta1.Sessions.DetectIntent]
            or
            [Sessions.StreamingDetectIntent][google.cloud.dialogflow.v2beta1.Sessions.StreamingDetectIntent].
        insights_export_settings (google.cloud.dialogflow_v2beta1.types.SecuritySettings.InsightsExportSettings):
            Optional. Controls conversation exporting settings to
            Insights after conversation is completed.

            If
            [retention_strategy][google.cloud.dialogflow.v2beta1.SecuritySettings.retention_strategy]
            is set to REMOVE_AFTER_CONVERSATION, Insights export is
            disabled no matter what you configure here.
    """
    class RedactionStrategy(proto.Enum):
        r"""Defines how we redact data.

        Values:
            REDACTION_STRATEGY_UNSPECIFIED (0):
                Do not redact.
            REDACT_WITH_SERVICE (1):
                Call redaction service to clean up the data
                to be persisted.
        """
        REDACTION_STRATEGY_UNSPECIFIED = 0
        REDACT_WITH_SERVICE = 1

    class RedactionScope(proto.Enum):
        r"""Defines what types of data to redact.

        Values:
            REDACTION_SCOPE_UNSPECIFIED (0):
                Don't redact any kind of data.
            REDACT_DISK_STORAGE (2):
                On data to be written to disk or similar
                devices that are capable of holding data even if
                power is disconnected. This includes data that
                are temporarily saved on disk.
        """
        REDACTION_SCOPE_UNSPECIFIED = 0
        REDACT_DISK_STORAGE = 2

    class PurgeDataType(proto.Enum):
        r"""Type of data we purge after retention settings triggers
        purge.

        Values:
            PURGE_DATA_TYPE_UNSPECIFIED (0):
                Unspecified. Do not use.
            DIALOGFLOW_HISTORY (1):
                Dialogflow history. This does not include
                Stackdriver log, which is owned by the user not
                Dialogflow.
        """
        PURGE_DATA_TYPE_UNSPECIFIED = 0
        DIALOGFLOW_HISTORY = 1

    class AudioExportSettings(proto.Message):
        r"""Settings for exporting audio.

        Attributes:
            gcs_bucket (str):
                Cloud Storage bucket to export audio record
                to. Settings this field would grant the Storage
                Object Creator role to the Dialogflow Service
                Agent.
                API caller that tries to modify this field
                should have the permission of
                storage.buckets.setIamPolicy.
            audio_format (google.cloud.dialogflow_v2beta1.types.SecuritySettings.AudioExportSettings.AudioFormat):
                File format for exported audio file.
                Currently only in telephony recordings.
            suffix (str):
                Specify additional suffix to the exported file name. Valid
                characters are letters, numbers and underscore. You may also
                use '%var%' in the string to expand to values available at
                runtime. Valid 'var' are:

                -  participant: id of the participant of the session /
                   conversation if available.
                -  role: role of the participant of the session /
                   conversation - end user, agent, etc.
            store_tts_audio (bool):
                Whether to store TTS audio. By default, TTS
                audio from the virtual agent is not exported.
        """
        class AudioFormat(proto.Enum):
            r"""File format for exported audio file. Currently only in
            telephony recordings.

            Values:
                AUDIO_FORMAT_UNSPECIFIED (0):
                    Unspecified. Do not use.
                MULAW (1):
                    G.711 mu-law PCM with 8kHz sample rate.
                MP3 (2):
                    MP3 file format.
                OGG (3):
                    OGG Vorbis.
            """
            AUDIO_FORMAT_UNSPECIFIED = 0
            MULAW = 1
            MP3 = 2
            OGG = 3

        gcs_bucket: str = proto.Field(
            proto.STRING,
            number=1,
        )
        audio_format: 'SecuritySettings.AudioExportSettings.AudioFormat' = proto.Field(
            proto.ENUM,
            number=4,
            enum='SecuritySettings.AudioExportSettings.AudioFormat',
        )
        suffix: str = proto.Field(
            proto.STRING,
            number=5,
        )
        store_tts_audio: bool = proto.Field(
            proto.BOOL,
            number=6,
        )

    class InsightsExportSettings(proto.Message):
        r"""Settings for exporting conversations to
        `Insights <https://cloud.google.com/contact-center/insights/docs>`__.

        Attributes:
            enable_insights_export (bool):
                If enabled, we will automatically exports
                conversations to Insights and Insights runs its
                analyzers.
        """

        enable_insights_export: bool = proto.Field(
            proto.BOOL,
            number=1,
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    redaction_strategy: RedactionStrategy = proto.Field(
        proto.ENUM,
        number=2,
        enum=RedactionStrategy,
    )
    redaction_scope: RedactionScope = proto.Field(
        proto.ENUM,
        number=3,
        enum=RedactionScope,
    )
    inspect_template: str = proto.Field(
        proto.STRING,
        number=8,
    )
    deidentify_template: str = proto.Field(
        proto.STRING,
        number=14,
    )
    retention_window_days: int = proto.Field(
        proto.INT32,
        number=5,
        oneof='data_retention',
    )
    purge_data_types: MutableSequence[PurgeDataType] = proto.RepeatedField(
        proto.ENUM,
        number=7,
        enum=PurgeDataType,
    )
    audio_export_settings: AudioExportSettings = proto.Field(
        proto.MESSAGE,
        number=10,
        message=AudioExportSettings,
    )
    insights_export_settings: InsightsExportSettings = proto.Field(
        proto.MESSAGE,
        number=12,
        message=InsightsExportSettings,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
