# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'AgentCoachingInstruction',
    },
)


class AgentCoachingInstruction(proto.Message):
    r"""Agent Coaching instructions that customer can configure.

    Attributes:
        display_name (str):
            Optional. Display name for the instruction.
        display_details (str):
            Optional. The detailed description of this
            instruction.
        condition (str):
            Optional. The condition of the instruction.
            For example, "the customer wants to cancel an
            order".  If the users want the instruction to be
            triggered unconditionally, the condition can be
            empty.
        agent_action (str):
            Optional. The action that human agent should take. For
            example, "apologize for the slow shipping". If the users
            only want to use agent coaching for intent detection,
            agent_action can be empty
        metadata (MutableMapping[str, str]):
            Optional. Additional information attached to
            this instruction.
    """

    display_name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_details: str = proto.Field(
        proto.STRING,
        number=2,
    )
    condition: str = proto.Field(
        proto.STRING,
        number=3,
    )
    agent_action: str = proto.Field(
        proto.STRING,
        number=4,
    )
    metadata: MutableMapping[str, str] = proto.MapField(
        proto.STRING,
        proto.STRING,
        number=6,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
