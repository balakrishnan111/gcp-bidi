# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'CreateConversationModelOperationMetadata',
        'DeployConversationModelOperationMetadata',
        'UndeployConversationModelOperationMetadata',
        'DeleteConversationModelOperationMetadata',
        'GenerateDocumentOperationMetadata',
    },
)


class CreateConversationModelOperationMetadata(proto.Message):
    r"""Metadata for a
    [ConversationModels.CreateConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.CreateConversationModel]
    operation.

    Attributes:
        conversation_model (str):
            The resource name of the conversation model. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model Id>``
        state (google.cloud.dialogflow_v2beta1.types.CreateConversationModelOperationMetadata.State):
            State of CreateConversationModel operation.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Timestamp when the request to create
            conversation model was submitted. The time is
            measured on server side.
    """
    class State(proto.Enum):
        r"""State of CreateConversationModel operation.

        Values:
            STATE_UNSPECIFIED (0):
                Invalid.
            PENDING (1):
                Request is submitted, but training has not
                started yet. The model may remain in this state
                until there is enough capacity to start
                training.
            SUCCEEDED (2):
                The training has succeeded.
            FAILED (3):
                The training has failed.
            CANCELLED (4):
                The training has been cancelled.
            CANCELLING (5):
                The training is in cancelling state.
            TRAINING (6):
                Custom model is training.
        """
        STATE_UNSPECIFIED = 0
        PENDING = 1
        SUCCEEDED = 2
        FAILED = 3
        CANCELLED = 4
        CANCELLING = 5
        TRAINING = 6

    conversation_model: str = proto.Field(
        proto.STRING,
        number=1,
    )
    state: State = proto.Field(
        proto.ENUM,
        number=2,
        enum=State,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )


class DeployConversationModelOperationMetadata(proto.Message):
    r"""Metadata for a
    [ConversationModels.DeployConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.DeployConversationModel]
    operation.

    Attributes:
        conversation_model (str):
            The resource name of the conversation model. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model Id>``
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Timestamp when request to deploy conversation
            model was submitted. The time is measured on
            server side.
    """

    conversation_model: str = proto.Field(
        proto.STRING,
        number=1,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )


class UndeployConversationModelOperationMetadata(proto.Message):
    r"""Metadata for a
    [ConversationModels.UndeployConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.UndeployConversationModel]
    operation.

    Attributes:
        conversation_model (str):
            The resource name of the conversation model. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model Id>``
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Timestamp when the request to undeploy
            conversation model was submitted. The time is
            measured on server side.
    """

    conversation_model: str = proto.Field(
        proto.STRING,
        number=1,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )


class DeleteConversationModelOperationMetadata(proto.Message):
    r"""Metadata for a
    [ConversationModels.DeleteConversationModel][google.cloud.dialogflow.v2beta1.ConversationModels.DeleteConversationModel]
    operation.

    Attributes:
        conversation_model (str):
            The resource name of the conversation model. Format:
            ``projects/<Project ID>/conversationModels/<Conversation Model Id>``
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Timestamp when delete conversation model
            request was created. The time is measured on
            server side.
    """

    conversation_model: str = proto.Field(
        proto.STRING,
        number=1,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )


class GenerateDocumentOperationMetadata(proto.Message):
    r"""Metadata for
    [Documents.GenerateDocument][google.cloud.dialogflow.v2beta1.Documents.GenerateDocument]
    operation when customer request to generate document.

    Attributes:
        state (google.cloud.dialogflow_v2beta1.types.GenerateDocumentOperationMetadata.State):
            State of generating document operation.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            The time when the operation was submitted.
        source_conversation_datasets (MutableSequence[str]):
            The source conversation datasets used to
            generate the allowlist.
        document (str):
            The name of the document to retrieve. Format:
            ``projects/<Project ID>/knowledgeBases/<Knowledge Base ID>/documents/<Document ID>``.
    """
    class State(proto.Enum):
        r"""State of GeneratingDocument operation.

        Values:
            STATE_UNSPECIFIED (0):
                Operation status not specified.
            INITIALIZING (1):
                The operation is being prepared.
            RUNNING (2):
                The operation is running.
            CANCELLED (3):
                The operation is cancelled.
            SUCCEEDED (4):
                The operation has succeeded.
            FAILED (5):
                The operation has failed.
        """
        STATE_UNSPECIFIED = 0
        INITIALIZING = 1
        RUNNING = 2
        CANCELLED = 3
        SUCCEEDED = 4
        FAILED = 5

    state: State = proto.Field(
        proto.ENUM,
        number=1,
        enum=State,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=2,
        message=timestamp_pb2.Timestamp,
    )
    source_conversation_datasets: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=3,
    )
    document: str = proto.Field(
        proto.STRING,
        number=4,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
