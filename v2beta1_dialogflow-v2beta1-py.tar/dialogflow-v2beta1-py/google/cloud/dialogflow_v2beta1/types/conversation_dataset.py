# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.cloud.dialogflow_v2beta1.types import conversation_profile
from google.cloud.dialogflow_v2beta1.types import gcs
from google.cloud.dialogflow_v2beta1.types import human_agent_assistant
from google.protobuf import struct_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore
from google.rpc import status_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'ConversationInfo',
        'InputConfig',
        'ConversationDataset',
        'AnnotatedConversationDataset',
        'AnnotationTaskConfig',
        'CreateConversationDatasetRequest',
        'GetConversationDatasetRequest',
        'ListConversationDatasetsRequest',
        'ListConversationDatasetsResponse',
        'DeleteConversationDatasetRequest',
        'GetAnnotatedConversationDatasetRequest',
        'ListAnnotatedConversationDatasetsRequest',
        'DeleteAnnotatedConversationDatasetRequest',
        'ListAnnotatedConversationDatasetsResponse',
        'ImportConversationDataRequest',
        'LabelConversationRequest',
        'LabelConversationResponse',
        'ImportConversationDataOperationMetadata',
        'ImportConversationDataOperationResponse',
        'LabelConversationOperationMetadata',
        'CreateConversationDatasetOperationMetadata',
        'DeleteConversationDatasetOperationMetadata',
    },
)


class ConversationInfo(proto.Message):
    r"""Represents metadata of a conversation.

    Attributes:
        language_code (str):
            Optional. The language code of the conversation. See
            https://cloud.google.com/apis/design/standard_fields
        region_code (str):
            Optional. Deprecated. The region code of the conversation.
            See https://cloud.google.com/apis/design/standard_fields

            Deprecated in Q3 2021. Reason: the field is useless and
            ambiguous regarding regionalization support.
        conversation_start_time (google.protobuf.timestamp_pb2.Timestamp):
            Optional. The timestamp that user sets to
            represent what time range this dataset belongs
            to.
        custom_fields (google.protobuf.struct_pb2.Struct):
            Optional. The field reserved for customers to
            provide their customized metadata. For example,
            agent id, contact center id, and topic tag, etc.
            These metadata will be used for filtering
            conversation dataset.
    """

    language_code: str = proto.Field(
        proto.STRING,
        number=1,
    )
    region_code: str = proto.Field(
        proto.STRING,
        number=2,
    )
    conversation_start_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )
    custom_fields: struct_pb2.Struct = proto.Field(
        proto.MESSAGE,
        number=4,
        message=struct_pb2.Struct,
    )


class InputConfig(proto.Message):
    r"""Represents the configuration of importing a set of
    conversation files in Google Cloud Storage.


    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        gcs_source (google.cloud.dialogflow_v2beta1.types.GcsSources):
            The Cloud Storage URI has the form
            gs://my_bucket//agent*.json. Wildcards are allowed and will
            be expanded into all matched files.

            This field is a member of `oneof`_ ``source``.
    """

    gcs_source: gcs.GcsSources = proto.Field(
        proto.MESSAGE,
        number=1,
        oneof='source',
        message=gcs.GcsSources,
    )


class ConversationDataset(proto.Message):
    r"""Represents a conversation dataset that a user imports raw
    data into. The data inside ConversationDataset
    can not be changed after ImportConversationData finishes (and
    calling ImportConversationData on a dataset that already has
    data is not allowed).


    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        name (str):
            Output only. ConversationDataset resource name. Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>``
        display_name (str):
            Required. The display name of the dataset.
            Maximum of 64 bytes.
        description (str):
            Optional. The description of the dataset.
            Maximum of 10000 bytes.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Creation time of this dataset.
        input_config (google.cloud.dialogflow_v2beta1.types.InputConfig):
            Output only. Input configurations set during
            conversation data import.
        conversation_info (google.cloud.dialogflow_v2beta1.types.ConversationInfo):
            Output only. Metadata set during conversation
            data import.
        conversation_count (int):
            Output only. The number of conversations this
            conversation dataset contains.
        satisfies_pzi (bool):
            Output only. A read only boolean field
            reflecting Zone Isolation status of the dataset.

            This field is a member of `oneof`_ ``_satisfies_pzi``.
        satisfies_pzs (bool):
            Output only. A read only boolean field
            reflecting Zone Separation status of the
            dataset.

            This field is a member of `oneof`_ ``_satisfies_pzs``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=2,
    )
    description: str = proto.Field(
        proto.STRING,
        number=3,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=4,
        message=timestamp_pb2.Timestamp,
    )
    input_config: 'InputConfig' = proto.Field(
        proto.MESSAGE,
        number=5,
        message='InputConfig',
    )
    conversation_info: 'ConversationInfo' = proto.Field(
        proto.MESSAGE,
        number=6,
        message='ConversationInfo',
    )
    conversation_count: int = proto.Field(
        proto.INT64,
        number=7,
    )
    satisfies_pzi: bool = proto.Field(
        proto.BOOL,
        number=8,
        optional=True,
    )
    satisfies_pzs: bool = proto.Field(
        proto.BOOL,
        number=9,
        optional=True,
    )


class AnnotatedConversationDataset(proto.Message):
    r"""Represents an annotated conversation dataset.
    ConversationDataset can have multiple
    AnnotatedConversationDataset, each of them represents one result
    from one annotation task. AnnotatedConversationDataset can only
    be generated from annotation task, which will be triggered by
    LabelConversation.

    Attributes:
        name (str):
            Output only. AnnotatedConversationDataset resource name.
            Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>/annotatedConversationDatasets/<Annotated Conversation Dataset ID>``
        display_name (str):
            Required. The display name of the annotated
            conversation dataset. It's specified when user
            starts an annotation task. Maximum of 64 bytes.
        description (str):
            Optional. The description of the annotated
            conversation dataset. Maximum of 10000 bytes.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Creation time of this annotated
            conversation dataset.
        example_count (int):
            Output only. Number of examples in the
            annotated conversation dataset.
        completed_example_count (int):
            Output only. Number of examples that have
            annotations in the annotated conversation
            dataset.
        question_type_name (str):
            Output only. Question type name that
            identifies a labeling task. A question is a
            single task that a worker answers. A question
            type is set of related questions. Each question
            belongs to a particular question type. It can be
            used in CrowdCompute UI to filter and manage
            labeling tasks.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=2,
    )
    description: str = proto.Field(
        proto.STRING,
        number=3,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=4,
        message=timestamp_pb2.Timestamp,
    )
    example_count: int = proto.Field(
        proto.INT64,
        number=5,
    )
    completed_example_count: int = proto.Field(
        proto.INT64,
        number=6,
    )
    question_type_name: str = proto.Field(
        proto.STRING,
        number=7,
    )


class AnnotationTaskConfig(proto.Message):
    r"""Represents an annotation task config.

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        display_name (str):
            Required. The display name of the
            conversation annotation task. It's specified
            when user starts an annotation task. Maximum of
            64 bytes.
        description (str):
            Optional. The description of the conversation
            annotation task. Maximum of 10000 bytes.
        instruction_uri (str):
            Optional. HTTP URI containing instructions
            for the annotation.
        replica_count (int):
            Required. Replications used for annotation,
            which means how many raters a question may be
            sent to for final decision.
        annotator_accounts (MutableSequence[str]):
            Optional. List of G Suite accounts for
            annotators. The format should be an Email.
        user_email_address (str):
            Optional. Email of the user who should be
            notified by email when events occur, such as the
            creation of a labeling Task, the occurrence of
            errors during the human labeling process, or the
            completion of a labeling task. If empty no
            notification will be sent.
        article_suggestion_config (google.cloud.dialogflow_v2beta1.types.ArticleSuggestionConfig):
            Deprecated. Specifies where and how to get
            default conversation suggestions that will be
            annotated.

            This field is a member of `oneof`_ ``preprocess_config``.
        knowledge_base_query_source (google.cloud.dialogflow_v2beta1.types.HumanAgentAssistantConfig.SuggestionQueryConfig.KnowledgeBaseQuerySource):
            Specifies the source of knowledge base to get
            articles from.

            This field is a member of `oneof`_ ``preprocess_config``.
    """

    display_name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    description: str = proto.Field(
        proto.STRING,
        number=2,
    )
    instruction_uri: str = proto.Field(
        proto.STRING,
        number=3,
    )
    replica_count: int = proto.Field(
        proto.INT32,
        number=4,
    )
    annotator_accounts: MutableSequence[str] = proto.RepeatedField(
        proto.STRING,
        number=5,
    )
    user_email_address: str = proto.Field(
        proto.STRING,
        number=7,
    )
    article_suggestion_config: human_agent_assistant.ArticleSuggestionConfig = proto.Field(
        proto.MESSAGE,
        number=6,
        oneof='preprocess_config',
        message=human_agent_assistant.ArticleSuggestionConfig,
    )
    knowledge_base_query_source: conversation_profile.HumanAgentAssistantConfig.SuggestionQueryConfig.KnowledgeBaseQuerySource = proto.Field(
        proto.MESSAGE,
        number=8,
        oneof='preprocess_config',
        message=conversation_profile.HumanAgentAssistantConfig.SuggestionQueryConfig.KnowledgeBaseQuerySource,
    )


class CreateConversationDatasetRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.CreateConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.CreateConversationDataset].

    Attributes:
        parent (str):
            Required. The project to create conversation dataset for.
            Format: ``projects/<Project ID>``
        conversation_dataset (google.cloud.dialogflow_v2beta1.types.ConversationDataset):
            Required. The conversation dataset to create.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    conversation_dataset: 'ConversationDataset' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='ConversationDataset',
    )


class GetConversationDatasetRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.GetConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.GetConversationDataset].

    Attributes:
        name (str):
            Required. The conversation dataset to retrieve. Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListConversationDatasetsRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.ListConversationDatasets][google.cloud.dialogflow.v2beta1.ConversationDatasets.ListConversationDatasets].

    Attributes:
        parent (str):
            Required. The project to list all conversation datasets for.
            Format: ``projects/<Project ID>``
        page_size (int):
            Optional. Maximum number of conversation
            datasets to return in a single page. By default
            100 and at most 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListConversationDatasetsResponse(proto.Message):
    r"""The response message for
    [ConversationDatasets.ListConversationDatasets][google.cloud.dialogflow.v2beta1.ConversationDatasets.ListConversationDatasets].

    Attributes:
        conversation_datasets (MutableSequence[google.cloud.dialogflow_v2beta1.types.ConversationDataset]):
            The list of datasets to return.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    conversation_datasets: MutableSequence['ConversationDataset'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='ConversationDataset',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteConversationDatasetRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.DeleteConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.DeleteConversationDataset].

    Attributes:
        name (str):
            Required. The conversation dataset to delete. Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class GetAnnotatedConversationDatasetRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.GetAnnotatedConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.GetAnnotatedConversationDataset].

    Attributes:
        name (str):
            Required. The annotated conversation dataset to retrieve.
            Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>/annotatedConversationDatasets/<Annotated Conversation Dataset ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListAnnotatedConversationDatasetsRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.ListAnnotatedConversationDatasets][google.cloud.dialogflow.v2beta1.ConversationDatasets.ListAnnotatedConversationDatasets].

    Attributes:
        parent (str):
            Required. The conversation dataset to list all annotated
            conversation datasets for. Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>``
        page_size (int):
            Optional. The maximum number of items to
            return in a single page. By default 100 and at
            most 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class DeleteAnnotatedConversationDatasetRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.DeleteAnnotatedConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDatasets.DeleteAnnotatedConversationDataset].

    Attributes:
        name (str):
            Required. The annotated conversation dataset to delete.
            Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>/annotatedConversationDatasets/<Annotated Conversation Dataset ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListAnnotatedConversationDatasetsResponse(proto.Message):
    r"""The response message for
    [ConversationDatasets.ListAnnotatedConversationDatasets][google.cloud.dialogflow.v2beta1.ConversationDatasets.ListAnnotatedConversationDatasets].

    Attributes:
        annotated_conversation_datasets (MutableSequence[google.cloud.dialogflow_v2beta1.types.AnnotatedConversationDataset]):
            The list of annotated conversation datasets
            to return.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    annotated_conversation_datasets: MutableSequence['AnnotatedConversationDataset'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='AnnotatedConversationDataset',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class ImportConversationDataRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.ImportConversationData][google.cloud.dialogflow.v2beta1.ConversationDatasets.ImportConversationData].

    Attributes:
        name (str):
            Required. Dataset resource name. Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>``
        input_config (google.cloud.dialogflow_v2beta1.types.InputConfig):
            Required. Configurations that contains
            information of raw file location, raw file type,
            etc.
        conversation_info (google.cloud.dialogflow_v2beta1.types.ConversationInfo):
            Optional. Conversation info contains extra
            information on location, time, and customized
            metadata for the batch of raw conversation files
            to be imported.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    input_config: 'InputConfig' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='InputConfig',
    )
    conversation_info: 'ConversationInfo' = proto.Field(
        proto.MESSAGE,
        number=3,
        message='ConversationInfo',
    )


class LabelConversationRequest(proto.Message):
    r"""The request message for
    [ConversationDatasets.LabelConversation][google.cloud.dialogflow.v2beta1.ConversationDatasets.LabelConversation].

    Attributes:
        parent (str):
            Required. Dataset resource name to create the annotation
            task for. Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>``
        annotation_task_config (google.cloud.dialogflow_v2beta1.types.AnnotationTaskConfig):
            Required. Configs to create and start a
            labeling task.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    annotation_task_config: 'AnnotationTaskConfig' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='AnnotationTaskConfig',
    )


class LabelConversationResponse(proto.Message):
    r"""The response for
    [ConversationDatasets.LabelConversation][google.cloud.dialogflow.v2beta1.ConversationDatasets.LabelConversation].

    Attributes:
        annotated_conversation_dataset (google.cloud.dialogflow_v2beta1.types.AnnotatedConversationDataset):
            New annotated conversation dataset created by
            the labeling task.
    """

    annotated_conversation_dataset: 'AnnotatedConversationDataset' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='AnnotatedConversationDataset',
    )


class ImportConversationDataOperationMetadata(proto.Message):
    r"""Metadata for a
    [ConversationDatasets.ImportConversationData][google.cloud.dialogflow.v2beta1.ConversationDatasets.ImportConversationData]
    operation.

    Attributes:
        conversation_dataset (str):
            The resource name of the imported conversation dataset.
            Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset Id>``
        partial_failures (MutableSequence[google.rpc.status_pb2.Status]):
            Partial failures are failures that don't fail
            the whole long running operation, e.g. single
            files that couldn't be read.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Timestamp when import conversation data
            request was created. The time is measured on
            server side.
    """

    conversation_dataset: str = proto.Field(
        proto.STRING,
        number=1,
    )
    partial_failures: MutableSequence[status_pb2.Status] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message=status_pb2.Status,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )


class ImportConversationDataOperationResponse(proto.Message):
    r"""Response used for
    [ConversationDatasets.ImportConversationData][google.cloud.dialogflow.v2beta1.ConversationDatasets.ImportConversationData]
    long running operation.

    Attributes:
        conversation_dataset (str):
            The resource name of the imported conversation dataset.
            Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset Id>``
        request_count (int):
            Number of conversations requested to import.
        import_count (int):
            Number of conversations imported
            successfully.
    """

    conversation_dataset: str = proto.Field(
        proto.STRING,
        number=1,
    )
    request_count: int = proto.Field(
        proto.INT32,
        number=2,
    )
    import_count: int = proto.Field(
        proto.INT32,
        number=3,
    )


class LabelConversationOperationMetadata(proto.Message):
    r"""Metadata for a
    [ConversationDatasets.LabelConversation][google.cloud.dialogflow.v2beta1.ConversationDatasets.LabelConversation]
    operation.

    Attributes:
        conversation_dataset (str):
            Conversation dataset to be labelled. Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset Id>``
        annotated_conversation_dataset (str):
            Output only. Annotated conversation dataset generated.
            Format:
            ``projects/<Project ID>/conversationDatasets/<Conversation Dataset ID>/annotatedConversationDatasets/<Annotated Conversation Dataset ID>``
        progress_percent (int):
            Progress of label operation. Range: [0, 100].
        partial_failures (MutableSequence[google.rpc.status_pb2.Status]):
            Partial failures encountered.
            E.g. single files that couldn't be read.
            Status details field will contain standard
            Google Cloud error details.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Timestamp when labeling request was created.
            The time is measured on server side.
        annotation_task_config (google.cloud.dialogflow_v2beta1.types.AnnotationTaskConfig):
            Config for label conversation annotation
            task.
    """

    conversation_dataset: str = proto.Field(
        proto.STRING,
        number=5,
    )
    annotated_conversation_dataset: str = proto.Field(
        proto.STRING,
        number=6,
    )
    progress_percent: int = proto.Field(
        proto.INT32,
        number=1,
    )
    partial_failures: MutableSequence[status_pb2.Status] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message=status_pb2.Status,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=3,
        message=timestamp_pb2.Timestamp,
    )
    annotation_task_config: 'AnnotationTaskConfig' = proto.Field(
        proto.MESSAGE,
        number=4,
        message='AnnotationTaskConfig',
    )


class CreateConversationDatasetOperationMetadata(proto.Message):
    r"""Metadata for [ConversationDatasets][CreateConversationDataset].

    Attributes:
        conversation_dataset (str):
            The resource name of the conversation dataset that will be
            created. Format:
            ``projects/<Project ID>/locations/<Location ID>/conversationDatasets/<Conversation Dataset Id>``
    """

    conversation_dataset: str = proto.Field(
        proto.STRING,
        number=1,
    )


class DeleteConversationDatasetOperationMetadata(proto.Message):
    r"""Metadata for [ConversationDatasets][DeleteConversationDataset].
    """


__all__ = tuple(sorted(__protobuf__.manifest))
