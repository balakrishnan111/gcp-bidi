# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.cloud.dialogflow_v2beta1.types import document
from google.cloud.dialogflow_v2beta1.types import participant
from google.protobuf import field_mask_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'TriggerModelMode',
        'HumanAgentAssistant',
        'ArticleSuggestionConfig',
        'FaqAnswersConfig',
        'SmartReplyConfig',
        'DialogflowAssistConfig',
        'ListHumanAgentAssistantsRequest',
        'ListHumanAgentAssistantsResponse',
        'GetHumanAgentAssistantRequest',
        'CreateHumanAgentAssistantRequest',
        'UpdateHumanAgentAssistantRequest',
        'DeleteHumanAgentAssistantRequest',
        'CompileSuggestionsRequest',
        'CompileSuggestionsResponse',
    },
)


class TriggerModelMode(proto.Enum):
    r"""Deprecated, use
    [HumanAgentAssistantConfig.SuggestionTriggerSettings][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionTriggerSettings]
    instead. Enumeration of different values of TriggerModelMode.

    Values:
        TRIGGER_MODEL_MODE_UNSPECIFIED (0):
            TriggerModelMode not set.
        TRIGGER_MODEL_MODE_ENABLED (1):
            TriggerModel enabled.
        TRIGGER_MODEL_MODE_DISABLED (2):
            TriggerModelMode disabled.
        TRIGGER_MODEL_MODE_END_USER_ONLY (3):
            Enables a lite trigger model. Suggestion will only be
            computed when the latest message is from ``END_USER``.
    """
    _pb_options = {'deprecated': True}
    TRIGGER_MODEL_MODE_UNSPECIFIED = 0
    TRIGGER_MODEL_MODE_ENABLED = 1
    TRIGGER_MODEL_MODE_DISABLED = 2
    TRIGGER_MODEL_MODE_END_USER_ONLY = 3


class HumanAgentAssistant(proto.Message):
    r"""Deprecated: use configs in
    [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
    of
    [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]

    Represents a human agent assistant that provides suggestions to help
    human agents to resolve customer issues. This defines the types of
    content that the human agent assistant can present to a human agent.

    Attributes:
        name (str):
            The unique identifier of human agent assistant. Required for
            [HumanAgentAssistants.UpdateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.UpdateHumanAgentAssistant]
            method. Format:
            ``projects/<Project ID>/humanAgentAssistants/<Human Agent Assistant ID>``.
        display_name (str):
            Optional. Human readable name. Max length
            1024 bytes.
        article_suggestion_config (google.cloud.dialogflow_v2beta1.types.ArticleSuggestionConfig):
            Optional. Settings for article suggestion.
        faq_answers_config (google.cloud.dialogflow_v2beta1.types.FaqAnswersConfig):
            Optional. Settings for knowledge service.
        smart_reply_config (google.cloud.dialogflow_v2beta1.types.SmartReplyConfig):
            Optional. Settings for smart reply service.
        dialogflow_assist_config (google.cloud.dialogflow_v2beta1.types.DialogflowAssistConfig):
            Optional. Settings for Dialogflow assist
            service.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    display_name: str = proto.Field(
        proto.STRING,
        number=6,
    )
    article_suggestion_config: 'ArticleSuggestionConfig' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='ArticleSuggestionConfig',
    )
    faq_answers_config: 'FaqAnswersConfig' = proto.Field(
        proto.MESSAGE,
        number=4,
        message='FaqAnswersConfig',
    )
    smart_reply_config: 'SmartReplyConfig' = proto.Field(
        proto.MESSAGE,
        number=3,
        message='SmartReplyConfig',
    )
    dialogflow_assist_config: 'DialogflowAssistConfig' = proto.Field(
        proto.MESSAGE,
        number=8,
        message='DialogflowAssistConfig',
    )


class ArticleSuggestionConfig(proto.Message):
    r"""Settings for article suggestions.
    Articles are uploaded by contact center operators and saved in a
    knowledge base. They are used by the service to choose the best
    articles during a conversation.

    Attributes:
        knowledge_base_name (str):
            Required. Settings for knowledge base, Format:
            ``projects/<Project ID>/knowledgeBases/<Knowledge Base ID>``.
        max_results (int):
            Optional. Maximum number of results to
            return. If unset, defaults to 10.
        trigger_model_mode (google.cloud.dialogflow_v2beta1.types.TriggerModelMode):
            Deprecated. Will only take effect in ``legacy`` workflow. In
            new workflow, it is moved to
            [HumanAgentAssistantConfig.SuggestionFeatureConfig.trigger_model_mode][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig.trigger_model_mode].
            See
            [HumanAgentAssistantConfig.name][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.name]
            for more details.

            Optional. Trigger Model is a feature that predicts whether
            human agent assistant needs to provide suggestions on
            current message with the context of current conversation.
            User can choose whether to enable this feature or not by
            setting up this field. If TriggerModelMode is enabled, human
            agent assistant will only generate suggestions when the
            score from the model prediction result exceeds certain
            threshold. If the TriggerModelMode is disabled, human agent
            assistant will try to generate suggestions for every
            message. If it is set to TRIGGER_MODEL_MODE_UNSPECIFIED, it
            will be automatically set to TRIGGER_MODEL_MODE_ENABLED
            during the human agent assistant creation. Note that for
            previously created human agent assistants before this
            feature launch, the default value of this flag is disabled
            so their behavior won't change unless updating this field
            using UpdateHumanAgentAssistant.
        model (str):
            Optional. Custom conversation model name. Format:
            ``projects/<Project ID>/conversationModels/<Model ID>``.
        confidence_threshold (float):
            Optional. Confidence threshold to filter out
            low score article suggestions. If not set,
            filter out suggestions with score equal to 0.
    """

    knowledge_base_name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    max_results: int = proto.Field(
        proto.INT32,
        number=4,
    )
    trigger_model_mode: 'TriggerModelMode' = proto.Field(
        proto.ENUM,
        number=10,
        enum='TriggerModelMode',
    )
    model: str = proto.Field(
        proto.STRING,
        number=11,
    )
    confidence_threshold: float = proto.Field(
        proto.DOUBLE,
        number=12,
    )


class FaqAnswersConfig(proto.Message):
    r"""Settings for a FAQ response.
    Question and answer pairs are uploaded by contact center
    operators and saved in a knowledge base. They are used by the
    service to choose the best answer given the question extracted
    from a conversation.

    Attributes:
        knowledge_base_name (str):
            Required. Settings for knowledge base, Format:
            ``projects/<Project ID>/knowledgeBases/<Knowledge Base ID>``.
        max_results (int):
            Optional. Maximum number of results to
            return. If unset, defaults to 10.
        knowledge_types (MutableSequence[google.cloud.dialogflow_v2beta1.types.Document.KnowledgeType]):
            This field is no longer has any effect.
            We will only return FAQ doc in faq suggestion.
    """

    knowledge_base_name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    max_results: int = proto.Field(
        proto.INT32,
        number=2,
    )
    knowledge_types: MutableSequence[document.Document.KnowledgeType] = proto.RepeatedField(
        proto.ENUM,
        number=4,
        enum=document.Document.KnowledgeType,
    )


class SmartReplyConfig(proto.Message):
    r"""Settings for a smart reply.
    Candidate replies are automatically generated by the service
    based on raw conversations and independent from model training.
    These replies are then revised for correctness and improvement
    by contact center operators. These candidate replies are saved
    in a knowledge document, which is used by the service to choose
    the best replies during a conversation.

    Attributes:
        model (str):
            Required. Smart reply model resource name. Format:
            ``projects/<Project ID>/conversationModels/<Model ID>``.
        candidate_document (str):
            Required. Knowledge document with candidate reply responses.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/knowledgeBases/<KnowledgeBase ID>/documents/<Document ID>``.
        max_replies (int):
            Optional. Maximum number of smart reply
            options to return. If unspecified or zero,
            defaults to 3.
    """

    model: str = proto.Field(
        proto.STRING,
        number=1,
    )
    candidate_document: str = proto.Field(
        proto.STRING,
        number=2,
    )
    max_replies: int = proto.Field(
        proto.INT32,
        number=3,
    )


class DialogflowAssistConfig(proto.Message):
    r"""The configuration for Dialogflow assist.

    Attributes:
        agent (str):
            Required. Name of a Dialogflow virtual agent. Format:
            ``projects/<Project ID>/agent``. It may be extended to
            include Agent ID when multiple agents are allowed in the
            same Dialogflow project.
        max_result_count (int):
            Optional. Maximum number of Dialogflow assist
            suggestions to return. If unspecified or zero,
            defaults to 1.
    """

    agent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    max_result_count: int = proto.Field(
        proto.INT32,
        number=2,
    )


class ListHumanAgentAssistantsRequest(proto.Message):
    r"""The request message for
    [HumanAgentAssistants.ListHumanAgentAssistants][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.ListHumanAgentAssistants].

    Attributes:
        parent (str):
            Required. The project to list all agent assistants from.
            Format: ``projects/<Project ID>``.
        page_size (int):
            Optional. The maximum number of items to
            return in a single page. The default value is
            100; the maximum value is 1000.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListHumanAgentAssistantsResponse(proto.Message):
    r"""The response message for
    [HumanAgentAssistants.ListHumanAgentAssistants][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.ListHumanAgentAssistants].

    Attributes:
        human_agent_assistants (MutableSequence[google.cloud.dialogflow_v2beta1.types.HumanAgentAssistant]):
            The list of project agent assistants. There is a maximum
            number of items returned based on the page_size field in the
            request.
        next_page_token (str):
            Token to retrieve the next page of results or
            empty if there are no more results in the list.
    """

    @property
    def raw_page(self):
        return self

    human_agent_assistants: MutableSequence['HumanAgentAssistant'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='HumanAgentAssistant',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class GetHumanAgentAssistantRequest(proto.Message):
    r"""The request message for
    [HumanAgentAssistants.GetHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.GetHumanAgentAssistant].

    Attributes:
        name (str):
            Required. The resource name of the agent assistant. Format:
            ``projects/<Project ID>/humanAgentAssistants/<Human Agent Assistant ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class CreateHumanAgentAssistantRequest(proto.Message):
    r"""The request message for
    [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].

    Attributes:
        parent (str):
            Required. The project to create a agent assistant for.
            Format: ``projects/<Project ID>``.
        human_agent_assistant (google.cloud.dialogflow_v2beta1.types.HumanAgentAssistant):
            Required. The agent assistant to create.
        bypass_deprecation (bool):
            Starting 2020-06-08, the deprecated
            [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant]
            method will always return INVALID_ARGUMENT. If you need to
            continue using this method, you can set
            ``bypass_deprecation`` to true. The bypass flag will be
            removed after 2020-09-01, so you will need to stop using
            this method by that date.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    human_agent_assistant: 'HumanAgentAssistant' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='HumanAgentAssistant',
    )
    bypass_deprecation: bool = proto.Field(
        proto.BOOL,
        number=3,
    )


class UpdateHumanAgentAssistantRequest(proto.Message):
    r"""The request message for
    [HumanAgentAssistants.UpdateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.UpdateHumanAgentAssistant].

    Attributes:
        human_agent_assistant (google.cloud.dialogflow_v2beta1.types.HumanAgentAssistant):
            Required. The agent assistant to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Optional. The mask to specify which fields to
            update.
    """

    human_agent_assistant: 'HumanAgentAssistant' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='HumanAgentAssistant',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class DeleteHumanAgentAssistantRequest(proto.Message):
    r"""The request message for
    [HumanAgentAssistants.DeleteHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.DeleteHumanAgentAssistant].

    Attributes:
        name (str):
            Required. The resource name of the agent assistant. Format:
            ``projects/<Project ID>/humanAgentAssistants/<Human Agent Assistant ID>``.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class CompileSuggestionsRequest(proto.Message):
    r"""The request message for
    [HumanAgentAssistants.CompileSuggestions][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CompileSuggestions].

    Attributes:
        name (str):
            Required. The resource name of the agent assistant. Format:
            ``projects/<Project ID>/humanAgentAssistants/<Human Agent Assistant ID>``.
        messages (MutableSequence[google.cloud.dialogflow_v2beta1.types.Message]):
            Required. List of messages in a conversation
            in chronological order.
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    messages: MutableSequence[participant.Message] = proto.RepeatedField(
        proto.MESSAGE,
        number=2,
        message=participant.Message,
    )


class CompileSuggestionsResponse(proto.Message):
    r"""The response message for
    [HumanAgentAssistants.CompileSuggestions][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CompileSuggestions]

    Attributes:
        suggestions (MutableSequence[google.cloud.dialogflow_v2beta1.types.Suggestion]):
            Required.
    """

    suggestions: MutableSequence[participant.Suggestion] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message=participant.Suggestion,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
