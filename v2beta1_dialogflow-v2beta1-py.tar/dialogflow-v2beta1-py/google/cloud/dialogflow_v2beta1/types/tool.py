# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
from __future__ import annotations

from typing import MutableMapping, MutableSequence

import proto  # type: ignore

from google.protobuf import field_mask_pb2  # type: ignore
from google.protobuf import struct_pb2  # type: ignore
from google.protobuf import timestamp_pb2  # type: ignore


__protobuf__ = proto.module(
    package='google.cloud.dialogflow.v2beta1',
    manifest={
        'CreateToolRequest',
        'GetToolRequest',
        'ListToolsRequest',
        'ListToolsResponse',
        'DeleteToolRequest',
        'UpdateToolRequest',
        'Tool',
    },
)


class CreateToolRequest(proto.Message):
    r"""Request message of CreateTool.

    Attributes:
        parent (str):
            Required. The project/location to create tool for. Format:
            ``projects/<Project ID>/locations/<Location ID>``
        tool (google.cloud.dialogflow_v2beta1.types.Tool):
            Required. The tool to create.
        tool_id (str):
            Optional. The ID to use for the tool, which will become the
            final component of the tool's resource name.

            The tool ID must be compliant with the regression formula
            ``[a-zA-Z][a-zA-Z0-9_-]*`` with the characters length in
            range of [3,64]. If the field is not provide, an Id will be
            auto-generated. If the field is provided, the caller is
            responsible for

            1. the uniqueness of the ID, otherwise the request will be
               rejected.
            2. the consistency for whether to use custom ID or not under
               a project to better ensure uniqueness.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    tool: 'Tool' = proto.Field(
        proto.MESSAGE,
        number=2,
        message='Tool',
    )
    tool_id: str = proto.Field(
        proto.STRING,
        number=3,
    )


class GetToolRequest(proto.Message):
    r"""Request message of GetTool.

    Attributes:
        name (str):
            Required. The tool resource name to retrieve. Format:
            ``projects/<Project ID>/locations/<Location ID>/tools/<Tool ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class ListToolsRequest(proto.Message):
    r"""Request message of ListTools.

    Attributes:
        parent (str):
            Required. The project/location to list tools for. Format:
            ``projects/<Project ID>/locations/<Location ID>``
        page_size (int):
            Optional. Maximum number of conversation
            models to return in a single page. Default to
            10.
        page_token (str):
            Optional. The next_page_token value returned from a previous
            list request.
    """

    parent: str = proto.Field(
        proto.STRING,
        number=1,
    )
    page_size: int = proto.Field(
        proto.INT32,
        number=2,
    )
    page_token: str = proto.Field(
        proto.STRING,
        number=3,
    )


class ListToolsResponse(proto.Message):
    r"""Response of ListTools.

    Attributes:
        tools (MutableSequence[google.cloud.dialogflow_v2beta1.types.Tool]):
            List of tools retrieved.
        next_page_token (str):
            Token to retrieve the next page of results,
            or empty if there are no more results in the
            list.
    """

    @property
    def raw_page(self):
        return self

    tools: MutableSequence['Tool'] = proto.RepeatedField(
        proto.MESSAGE,
        number=1,
        message='Tool',
    )
    next_page_token: str = proto.Field(
        proto.STRING,
        number=2,
    )


class DeleteToolRequest(proto.Message):
    r"""Request of DeleteTool.

    Attributes:
        name (str):
            Required. The tool resource name to delete. Format:
            ``projects/<Project ID>/locations/<Location ID>/tools/<Tool ID>``
    """

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )


class UpdateToolRequest(proto.Message):
    r"""Request of UpdateTool.

    Attributes:
        tool (google.cloud.dialogflow_v2beta1.types.Tool):
            Required. The tool to update.
            The name field of tool is to identify the tool
            to update.
        update_mask (google.protobuf.field_mask_pb2.FieldMask):
            Optional. The list of fields to update.
    """

    tool: 'Tool' = proto.Field(
        proto.MESSAGE,
        number=1,
        message='Tool',
    )
    update_mask: field_mask_pb2.FieldMask = proto.Field(
        proto.MESSAGE,
        number=2,
        message=field_mask_pb2.FieldMask,
    )


class Tool(proto.Message):
    r"""Represents a tool.

    This message has `oneof`_ fields (mutually exclusive fields).
    For each oneof, at most one member field can be set at the same time.
    Setting any member of the oneof automatically clears all other
    members.

    .. _oneof: https://proto-plus-python.readthedocs.io/en/stable/fields.html#oneofs-mutually-exclusive-fields

    Attributes:
        name (str):
            Output only. Identifier. The resource name of the tool.
            Format:
            ``projects/<Project ID>/locations/<Location ID>/tools/<Tool ID>``.
        tool_key (str):
            Required. A human readable short name of the
            tool, which should be unique within the project.
            It should only contain letters, numbers, and
            underscores, and it will be used by LLM to
            identify the tool.
        description (str):
            Optional. A human readable description of the
            tool.
        action_confirmation_requirement (MutableMapping[str, google.cloud.dialogflow_v2beta1.types.Tool.ConfirmationRequirement]):
            Optional. Confirmation requirement for the actions. Each key
            is an action name in the action_schemas. If an action's
            confirmation requirement is unspecified (either the key is
            not present, or its value is
            CONFIRMATION_REQUIREMENT_UNSPECIFIED), the requirement is
            inferred from the action's method_type - confirmation is not
            required if and only if method_type is GET.
        extension_spec (google.cloud.dialogflow_v2beta1.types.Tool.ExtensionTool):
            Vertex extension tool specification.

            This field is a member of `oneof`_ ``specification``.
        function_spec (google.cloud.dialogflow_v2beta1.types.Tool.FunctionTool):
            Client side executed function specification.

            This field is a member of `oneof`_ ``specification``.
        create_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Creation time of this tool.
        update_time (google.protobuf.timestamp_pb2.Timestamp):
            Output only. Update time of this tool.
        satisfies_pzs (bool):
            Output only. A read only boolean field
            reflecting Zone Separation status of the tool.
            If the field is absent, it means the status is
            unknown.

            This field is a member of `oneof`_ ``_satisfies_pzs``.
        satisfies_pzi (bool):
            Output only. A read only boolean field
            reflecting Zone Isolation status of the tool. If
            the field is absent, it means the status is
            unknown.

            This field is a member of `oneof`_ ``_satisfies_pzi``.
        execution_mode (google.cloud.dialogflow_v2beta1.types.Tool.ExecutionMode):
            Optional. The execution mode of the tool. By default, the
            extension tool and data store tools are executed by the
            server unless execution_mode is set to CLIENT_SIDE.
    """
    class ConfirmationRequirement(proto.Enum):
        r"""Types of confirmation requirement.

        Values:
            CONFIRMATION_REQUIREMENT_UNSPECIFIED (0):
                Unspecified. Whether the action requires confirmation is
                inferred from method_type.
            REQUIRED (1):
                Conformation is required.
            NOT_REQUIRED (2):
                Conformation is not required.
        """
        CONFIRMATION_REQUIREMENT_UNSPECIFIED = 0
        REQUIRED = 1
        NOT_REQUIRED = 2

    class MethodType(proto.Enum):
        r"""The method type of the function.

        Values:
            METHOD_TYPE_UNSPECIFIED (0):
                Unspecified.
            GET (1):
                GET method.
            POST (2):
                POST method.
            PUT (3):
                PUT method.
            DELETE (4):
                DELETE method.
            PATCH (5):
                PATCH method.
        """
        METHOD_TYPE_UNSPECIFIED = 0
        GET = 1
        POST = 2
        PUT = 3
        DELETE = 4
        PATCH = 5

    class ExecutionMode(proto.Enum):
        r"""The execution mode of the tool.

        Values:
            EXECUTION_MODE_UNSPECIFIED (0):
                Execution mode unspecified.
            CLIENT_SIDE (1):
                Client side execution mode. Generator will
                return the tool call request to the client, let
                the client execute the tool and return the
                result through the IngestContextReference API.
        """
        EXECUTION_MODE_UNSPECIFIED = 0
        CLIENT_SIDE = 1

    class ExtensionTool(proto.Message):
        r"""An ExtensionTool is a way to use Vertex Extensions as a tool.

        Attributes:
            name (str):
                Required. The full name of the referenced vertex extension.
                Format:
                ``projects/{project}/locations/{location}/extensions/{extension}``
        """

        name: str = proto.Field(
            proto.STRING,
            number=1,
        )

    class FunctionTool(proto.Message):
        r"""A Function tool describes the functions to be invoked on the
        client side.

        Attributes:
            input_schema (google.protobuf.struct_pb2.Struct):
                Optional. The JSON schema is encapsulated in a
                [google.protobuf.Struct][google.protobuf.Struct] to describe
                the input of the function. This input is a JSON object that
                contains the function's parameters as properties of the
                object.
            output_schema (google.protobuf.struct_pb2.Struct):
                Optional. The JSON schema is encapsulated in a
                [google.protobuf.Struct][google.protobuf.Struct] to describe
                the output of the function. This output is a JSON object
                that contains the function's parameters as properties of the
                object.
            method_type (google.cloud.dialogflow_v2beta1.types.Tool.MethodType):
                Optional. The method type of the function. If
                not specified, the default value is GET.
        """

        input_schema: struct_pb2.Struct = proto.Field(
            proto.MESSAGE,
            number=1,
            message=struct_pb2.Struct,
        )
        output_schema: struct_pb2.Struct = proto.Field(
            proto.MESSAGE,
            number=2,
            message=struct_pb2.Struct,
        )
        method_type: 'Tool.MethodType' = proto.Field(
            proto.ENUM,
            number=4,
            enum='Tool.MethodType',
        )

    name: str = proto.Field(
        proto.STRING,
        number=1,
    )
    tool_key: str = proto.Field(
        proto.STRING,
        number=2,
    )
    description: str = proto.Field(
        proto.STRING,
        number=3,
    )
    action_confirmation_requirement: MutableMapping[str, ConfirmationRequirement] = proto.MapField(
        proto.STRING,
        proto.ENUM,
        number=17,
        enum=ConfirmationRequirement,
    )
    extension_spec: ExtensionTool = proto.Field(
        proto.MESSAGE,
        number=4,
        oneof='specification',
        message=ExtensionTool,
    )
    function_spec: FunctionTool = proto.Field(
        proto.MESSAGE,
        number=13,
        oneof='specification',
        message=FunctionTool,
    )
    create_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=5,
        message=timestamp_pb2.Timestamp,
    )
    update_time: timestamp_pb2.Timestamp = proto.Field(
        proto.MESSAGE,
        number=6,
        message=timestamp_pb2.Timestamp,
    )
    satisfies_pzs: bool = proto.Field(
        proto.BOOL,
        number=14,
        optional=True,
    )
    satisfies_pzi: bool = proto.Field(
        proto.BOOL,
        number=15,
        optional=True,
    )
    execution_mode: ExecutionMode = proto.Field(
        proto.ENUM,
        number=16,
        enum=ExecutionMode,
    )


__all__ = tuple(sorted(__protobuf__.manifest))
