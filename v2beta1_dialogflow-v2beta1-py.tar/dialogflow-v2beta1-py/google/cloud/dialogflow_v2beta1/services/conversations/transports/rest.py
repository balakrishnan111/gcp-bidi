# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import logging
import json  # type: ignore

from google.auth.transport.requests import AuthorizedSession  # type: ignore
from google.auth import credentials as ga_credentials  # type: ignore
from google.api_core import exceptions as core_exceptions
from google.api_core import retry as retries
from google.api_core import rest_helpers
from google.api_core import rest_streaming
from google.api_core import gapic_v1
import google.protobuf

from google.protobuf import json_format
from google.api_core import operations_v1
from google.cloud.location import locations_pb2 # type: ignore

from requests import __version__ as requests_version
import dataclasses
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union
import warnings


from google.cloud.dialogflow_v2beta1.types import conversation
from google.cloud.dialogflow_v2beta1.types import conversation as gcd_conversation
from google.cloud.dialogflow_v2beta1.types import participant
from google.protobuf import empty_pb2  # type: ignore
from google.longrunning import operations_pb2  # type: ignore


from .rest_base import _BaseConversationsRestTransport
from .base import DEFAULT_CLIENT_INFO as BASE_DEFAULT_CLIENT_INFO

try:
    OptionalRetry = Union[retries.Retry, gapic_v1.method._MethodDefault, None]
except AttributeError:  # pragma: NO COVER
    OptionalRetry = Union[retries.Retry, object, None]  # type: ignore

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = logging.getLogger(__name__)

DEFAULT_CLIENT_INFO = gapic_v1.client_info.ClientInfo(
    gapic_version=BASE_DEFAULT_CLIENT_INFO.gapic_version,
    grpc_version=None,
    rest_version=f"requests@{requests_version}",
)

if hasattr(DEFAULT_CLIENT_INFO, "protobuf_runtime_version"):  # pragma: NO COVER
    DEFAULT_CLIENT_INFO.protobuf_runtime_version = google.protobuf.__version__


class ConversationsRestInterceptor:
    """Interceptor for Conversations.

    Interceptors are used to manipulate requests, request metadata, and responses
    in arbitrary ways.
    Example use cases include:
    * Logging
    * Verifying requests according to service or custom semantics
    * Stripping extraneous information from responses

    These use cases and more can be enabled by injecting an
    instance of a custom subclass when constructing the ConversationsRestTransport.

    .. code-block:: python
        class MyCustomConversationsInterceptor(ConversationsRestInterceptor):
            def pre_activate_conversation(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_activate_conversation(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_add_conversation_phone_number(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_add_conversation_phone_number(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_batch_create_messages(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_batch_create_messages(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_complete_conversation(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_complete_conversation(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_create_call_matcher(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_create_call_matcher(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_create_conversation(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_create_conversation(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_deactivate_conversation(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_deactivate_conversation(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_delete_call_matcher(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def pre_export_messages(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_export_messages(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_generate_stateless_suggestion(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_generate_stateless_suggestion(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_generate_stateless_summary(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_generate_stateless_summary(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_generate_suggestions(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_generate_suggestions(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_get_call_companion_settings(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_get_call_companion_settings(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_get_conversation(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_get_conversation(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_ingest_context_references(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_ingest_context_references(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_initialize_call_companion(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def pre_initiate_phone_call(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_initiate_phone_call(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_inject_call_companion_input(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_inject_call_companion_input(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_inject_call_companion_user_input(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_inject_call_companion_user_input(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_call_matchers(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_call_matchers(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_conversations(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_conversations(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_messages(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_messages(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_past_call_companion_events(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_past_call_companion_events(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_search_articles(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_search_articles(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_search_knowledge(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_search_knowledge(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_streaming_list_call_companion_events(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_streaming_list_call_companion_events(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_streaming_list_upcoming_call_companion_events(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_streaming_list_upcoming_call_companion_events(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_suggest_conversation_key_moments(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_suggest_conversation_key_moments(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_suggest_conversation_summary(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_suggest_conversation_summary(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_update_conversation(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_update_conversation(self, response):
                logging.log(f"Received response: {response}")
                return response

        transport = ConversationsRestTransport(interceptor=MyCustomConversationsInterceptor())
        client = ConversationsClient(transport=transport)


    """
    def pre_activate_conversation(self, request: gcd_conversation.ActivateConversationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.ActivateConversationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for activate_conversation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_activate_conversation(self, response: gcd_conversation.Conversation) -> gcd_conversation.Conversation:
        """Post-rpc interceptor for activate_conversation

        DEPRECATED. Please use the `post_activate_conversation_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_activate_conversation` interceptor runs
        before the `post_activate_conversation_with_metadata` interceptor.
        """
        return response

    def post_activate_conversation_with_metadata(self, response: gcd_conversation.Conversation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.Conversation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for activate_conversation

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_activate_conversation_with_metadata`
        interceptor in new development instead of the `post_activate_conversation` interceptor.
        When both interceptors are used, this `post_activate_conversation_with_metadata` interceptor runs after the
        `post_activate_conversation` interceptor. The (possibly modified) response returned by
        `post_activate_conversation` will be passed to
        `post_activate_conversation_with_metadata`.
        """
        return response, metadata

    def pre_add_conversation_phone_number(self, request: conversation.AddConversationPhoneNumberRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.AddConversationPhoneNumberRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for add_conversation_phone_number

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_add_conversation_phone_number(self, response: conversation.ConversationPhoneNumber) -> conversation.ConversationPhoneNumber:
        """Post-rpc interceptor for add_conversation_phone_number

        DEPRECATED. Please use the `post_add_conversation_phone_number_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_add_conversation_phone_number` interceptor runs
        before the `post_add_conversation_phone_number_with_metadata` interceptor.
        """
        return response

    def post_add_conversation_phone_number_with_metadata(self, response: conversation.ConversationPhoneNumber, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.ConversationPhoneNumber, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for add_conversation_phone_number

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_add_conversation_phone_number_with_metadata`
        interceptor in new development instead of the `post_add_conversation_phone_number` interceptor.
        When both interceptors are used, this `post_add_conversation_phone_number_with_metadata` interceptor runs after the
        `post_add_conversation_phone_number` interceptor. The (possibly modified) response returned by
        `post_add_conversation_phone_number` will be passed to
        `post_add_conversation_phone_number_with_metadata`.
        """
        return response, metadata

    def pre_batch_create_messages(self, request: conversation.BatchCreateMessagesRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.BatchCreateMessagesRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for batch_create_messages

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_batch_create_messages(self, response: conversation.BatchCreateMessagesResponse) -> conversation.BatchCreateMessagesResponse:
        """Post-rpc interceptor for batch_create_messages

        DEPRECATED. Please use the `post_batch_create_messages_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_batch_create_messages` interceptor runs
        before the `post_batch_create_messages_with_metadata` interceptor.
        """
        return response

    def post_batch_create_messages_with_metadata(self, response: conversation.BatchCreateMessagesResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.BatchCreateMessagesResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for batch_create_messages

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_batch_create_messages_with_metadata`
        interceptor in new development instead of the `post_batch_create_messages` interceptor.
        When both interceptors are used, this `post_batch_create_messages_with_metadata` interceptor runs after the
        `post_batch_create_messages` interceptor. The (possibly modified) response returned by
        `post_batch_create_messages` will be passed to
        `post_batch_create_messages_with_metadata`.
        """
        return response, metadata

    def pre_complete_conversation(self, request: conversation.CompleteConversationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.CompleteConversationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for complete_conversation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_complete_conversation(self, response: conversation.Conversation) -> conversation.Conversation:
        """Post-rpc interceptor for complete_conversation

        DEPRECATED. Please use the `post_complete_conversation_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_complete_conversation` interceptor runs
        before the `post_complete_conversation_with_metadata` interceptor.
        """
        return response

    def post_complete_conversation_with_metadata(self, response: conversation.Conversation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.Conversation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for complete_conversation

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_complete_conversation_with_metadata`
        interceptor in new development instead of the `post_complete_conversation` interceptor.
        When both interceptors are used, this `post_complete_conversation_with_metadata` interceptor runs after the
        `post_complete_conversation` interceptor. The (possibly modified) response returned by
        `post_complete_conversation` will be passed to
        `post_complete_conversation_with_metadata`.
        """
        return response, metadata

    def pre_create_call_matcher(self, request: conversation.CreateCallMatcherRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.CreateCallMatcherRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for create_call_matcher

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_create_call_matcher(self, response: conversation.CallMatcher) -> conversation.CallMatcher:
        """Post-rpc interceptor for create_call_matcher

        DEPRECATED. Please use the `post_create_call_matcher_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_create_call_matcher` interceptor runs
        before the `post_create_call_matcher_with_metadata` interceptor.
        """
        return response

    def post_create_call_matcher_with_metadata(self, response: conversation.CallMatcher, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.CallMatcher, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for create_call_matcher

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_create_call_matcher_with_metadata`
        interceptor in new development instead of the `post_create_call_matcher` interceptor.
        When both interceptors are used, this `post_create_call_matcher_with_metadata` interceptor runs after the
        `post_create_call_matcher` interceptor. The (possibly modified) response returned by
        `post_create_call_matcher` will be passed to
        `post_create_call_matcher_with_metadata`.
        """
        return response, metadata

    def pre_create_conversation(self, request: gcd_conversation.CreateConversationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.CreateConversationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for create_conversation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_create_conversation(self, response: gcd_conversation.Conversation) -> gcd_conversation.Conversation:
        """Post-rpc interceptor for create_conversation

        DEPRECATED. Please use the `post_create_conversation_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_create_conversation` interceptor runs
        before the `post_create_conversation_with_metadata` interceptor.
        """
        return response

    def post_create_conversation_with_metadata(self, response: gcd_conversation.Conversation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.Conversation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for create_conversation

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_create_conversation_with_metadata`
        interceptor in new development instead of the `post_create_conversation` interceptor.
        When both interceptors are used, this `post_create_conversation_with_metadata` interceptor runs after the
        `post_create_conversation` interceptor. The (possibly modified) response returned by
        `post_create_conversation` will be passed to
        `post_create_conversation_with_metadata`.
        """
        return response, metadata

    def pre_deactivate_conversation(self, request: gcd_conversation.DeactivateConversationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.DeactivateConversationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for deactivate_conversation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_deactivate_conversation(self, response: gcd_conversation.Conversation) -> gcd_conversation.Conversation:
        """Post-rpc interceptor for deactivate_conversation

        DEPRECATED. Please use the `post_deactivate_conversation_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_deactivate_conversation` interceptor runs
        before the `post_deactivate_conversation_with_metadata` interceptor.
        """
        return response

    def post_deactivate_conversation_with_metadata(self, response: gcd_conversation.Conversation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.Conversation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for deactivate_conversation

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_deactivate_conversation_with_metadata`
        interceptor in new development instead of the `post_deactivate_conversation` interceptor.
        When both interceptors are used, this `post_deactivate_conversation_with_metadata` interceptor runs after the
        `post_deactivate_conversation` interceptor. The (possibly modified) response returned by
        `post_deactivate_conversation` will be passed to
        `post_deactivate_conversation_with_metadata`.
        """
        return response, metadata

    def pre_delete_call_matcher(self, request: conversation.DeleteCallMatcherRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.DeleteCallMatcherRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for delete_call_matcher

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def pre_export_messages(self, request: conversation.ExportMessagesRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.ExportMessagesRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for export_messages

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_export_messages(self, response: operations_pb2.Operation) -> operations_pb2.Operation:
        """Post-rpc interceptor for export_messages

        DEPRECATED. Please use the `post_export_messages_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_export_messages` interceptor runs
        before the `post_export_messages_with_metadata` interceptor.
        """
        return response

    def post_export_messages_with_metadata(self, response: operations_pb2.Operation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[operations_pb2.Operation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for export_messages

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_export_messages_with_metadata`
        interceptor in new development instead of the `post_export_messages` interceptor.
        When both interceptors are used, this `post_export_messages_with_metadata` interceptor runs after the
        `post_export_messages` interceptor. The (possibly modified) response returned by
        `post_export_messages` will be passed to
        `post_export_messages_with_metadata`.
        """
        return response, metadata

    def pre_generate_stateless_suggestion(self, request: conversation.GenerateStatelessSuggestionRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.GenerateStatelessSuggestionRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for generate_stateless_suggestion

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_generate_stateless_suggestion(self, response: conversation.GenerateStatelessSuggestionResponse) -> conversation.GenerateStatelessSuggestionResponse:
        """Post-rpc interceptor for generate_stateless_suggestion

        DEPRECATED. Please use the `post_generate_stateless_suggestion_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_generate_stateless_suggestion` interceptor runs
        before the `post_generate_stateless_suggestion_with_metadata` interceptor.
        """
        return response

    def post_generate_stateless_suggestion_with_metadata(self, response: conversation.GenerateStatelessSuggestionResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.GenerateStatelessSuggestionResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for generate_stateless_suggestion

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_generate_stateless_suggestion_with_metadata`
        interceptor in new development instead of the `post_generate_stateless_suggestion` interceptor.
        When both interceptors are used, this `post_generate_stateless_suggestion_with_metadata` interceptor runs after the
        `post_generate_stateless_suggestion` interceptor. The (possibly modified) response returned by
        `post_generate_stateless_suggestion` will be passed to
        `post_generate_stateless_suggestion_with_metadata`.
        """
        return response, metadata

    def pre_generate_stateless_summary(self, request: conversation.GenerateStatelessSummaryRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.GenerateStatelessSummaryRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for generate_stateless_summary

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_generate_stateless_summary(self, response: conversation.GenerateStatelessSummaryResponse) -> conversation.GenerateStatelessSummaryResponse:
        """Post-rpc interceptor for generate_stateless_summary

        DEPRECATED. Please use the `post_generate_stateless_summary_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_generate_stateless_summary` interceptor runs
        before the `post_generate_stateless_summary_with_metadata` interceptor.
        """
        return response

    def post_generate_stateless_summary_with_metadata(self, response: conversation.GenerateStatelessSummaryResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.GenerateStatelessSummaryResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for generate_stateless_summary

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_generate_stateless_summary_with_metadata`
        interceptor in new development instead of the `post_generate_stateless_summary` interceptor.
        When both interceptors are used, this `post_generate_stateless_summary_with_metadata` interceptor runs after the
        `post_generate_stateless_summary` interceptor. The (possibly modified) response returned by
        `post_generate_stateless_summary` will be passed to
        `post_generate_stateless_summary_with_metadata`.
        """
        return response, metadata

    def pre_generate_suggestions(self, request: gcd_conversation.GenerateSuggestionsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.GenerateSuggestionsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for generate_suggestions

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_generate_suggestions(self, response: participant.GenerateSuggestionsResponse) -> participant.GenerateSuggestionsResponse:
        """Post-rpc interceptor for generate_suggestions

        DEPRECATED. Please use the `post_generate_suggestions_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_generate_suggestions` interceptor runs
        before the `post_generate_suggestions_with_metadata` interceptor.
        """
        return response

    def post_generate_suggestions_with_metadata(self, response: participant.GenerateSuggestionsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[participant.GenerateSuggestionsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for generate_suggestions

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_generate_suggestions_with_metadata`
        interceptor in new development instead of the `post_generate_suggestions` interceptor.
        When both interceptors are used, this `post_generate_suggestions_with_metadata` interceptor runs after the
        `post_generate_suggestions` interceptor. The (possibly modified) response returned by
        `post_generate_suggestions` will be passed to
        `post_generate_suggestions_with_metadata`.
        """
        return response, metadata

    def pre_get_call_companion_settings(self, request: gcd_conversation.GetCallCompanionSettingsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.GetCallCompanionSettingsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_call_companion_settings

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_get_call_companion_settings(self, response: gcd_conversation.CallCompanionSettings) -> gcd_conversation.CallCompanionSettings:
        """Post-rpc interceptor for get_call_companion_settings

        DEPRECATED. Please use the `post_get_call_companion_settings_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_get_call_companion_settings` interceptor runs
        before the `post_get_call_companion_settings_with_metadata` interceptor.
        """
        return response

    def post_get_call_companion_settings_with_metadata(self, response: gcd_conversation.CallCompanionSettings, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.CallCompanionSettings, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for get_call_companion_settings

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_get_call_companion_settings_with_metadata`
        interceptor in new development instead of the `post_get_call_companion_settings` interceptor.
        When both interceptors are used, this `post_get_call_companion_settings_with_metadata` interceptor runs after the
        `post_get_call_companion_settings` interceptor. The (possibly modified) response returned by
        `post_get_call_companion_settings` will be passed to
        `post_get_call_companion_settings_with_metadata`.
        """
        return response, metadata

    def pre_get_conversation(self, request: conversation.GetConversationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.GetConversationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_conversation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_get_conversation(self, response: conversation.Conversation) -> conversation.Conversation:
        """Post-rpc interceptor for get_conversation

        DEPRECATED. Please use the `post_get_conversation_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_get_conversation` interceptor runs
        before the `post_get_conversation_with_metadata` interceptor.
        """
        return response

    def post_get_conversation_with_metadata(self, response: conversation.Conversation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.Conversation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for get_conversation

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_get_conversation_with_metadata`
        interceptor in new development instead of the `post_get_conversation` interceptor.
        When both interceptors are used, this `post_get_conversation_with_metadata` interceptor runs after the
        `post_get_conversation` interceptor. The (possibly modified) response returned by
        `post_get_conversation` will be passed to
        `post_get_conversation_with_metadata`.
        """
        return response, metadata

    def pre_ingest_context_references(self, request: gcd_conversation.IngestContextReferencesRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.IngestContextReferencesRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for ingest_context_references

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_ingest_context_references(self, response: gcd_conversation.IngestContextReferencesResponse) -> gcd_conversation.IngestContextReferencesResponse:
        """Post-rpc interceptor for ingest_context_references

        DEPRECATED. Please use the `post_ingest_context_references_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_ingest_context_references` interceptor runs
        before the `post_ingest_context_references_with_metadata` interceptor.
        """
        return response

    def post_ingest_context_references_with_metadata(self, response: gcd_conversation.IngestContextReferencesResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.IngestContextReferencesResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for ingest_context_references

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_ingest_context_references_with_metadata`
        interceptor in new development instead of the `post_ingest_context_references` interceptor.
        When both interceptors are used, this `post_ingest_context_references_with_metadata` interceptor runs after the
        `post_ingest_context_references` interceptor. The (possibly modified) response returned by
        `post_ingest_context_references` will be passed to
        `post_ingest_context_references_with_metadata`.
        """
        return response, metadata

    def pre_initialize_call_companion(self, request: gcd_conversation.InitializeCallCompanionRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.InitializeCallCompanionRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for initialize_call_companion

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def pre_initiate_phone_call(self, request: gcd_conversation.InitiatePhoneCallRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.InitiatePhoneCallRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for initiate_phone_call

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_initiate_phone_call(self, response: gcd_conversation.InitiatePhoneCallResponse) -> gcd_conversation.InitiatePhoneCallResponse:
        """Post-rpc interceptor for initiate_phone_call

        DEPRECATED. Please use the `post_initiate_phone_call_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_initiate_phone_call` interceptor runs
        before the `post_initiate_phone_call_with_metadata` interceptor.
        """
        return response

    def post_initiate_phone_call_with_metadata(self, response: gcd_conversation.InitiatePhoneCallResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.InitiatePhoneCallResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for initiate_phone_call

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_initiate_phone_call_with_metadata`
        interceptor in new development instead of the `post_initiate_phone_call` interceptor.
        When both interceptors are used, this `post_initiate_phone_call_with_metadata` interceptor runs after the
        `post_initiate_phone_call` interceptor. The (possibly modified) response returned by
        `post_initiate_phone_call` will be passed to
        `post_initiate_phone_call_with_metadata`.
        """
        return response, metadata

    def pre_inject_call_companion_input(self, request: gcd_conversation.InjectCallCompanionInputRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.InjectCallCompanionInputRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for inject_call_companion_input

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_inject_call_companion_input(self, response: gcd_conversation.InjectCallCompanionInputResponse) -> gcd_conversation.InjectCallCompanionInputResponse:
        """Post-rpc interceptor for inject_call_companion_input

        DEPRECATED. Please use the `post_inject_call_companion_input_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_inject_call_companion_input` interceptor runs
        before the `post_inject_call_companion_input_with_metadata` interceptor.
        """
        return response

    def post_inject_call_companion_input_with_metadata(self, response: gcd_conversation.InjectCallCompanionInputResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.InjectCallCompanionInputResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for inject_call_companion_input

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_inject_call_companion_input_with_metadata`
        interceptor in new development instead of the `post_inject_call_companion_input` interceptor.
        When both interceptors are used, this `post_inject_call_companion_input_with_metadata` interceptor runs after the
        `post_inject_call_companion_input` interceptor. The (possibly modified) response returned by
        `post_inject_call_companion_input` will be passed to
        `post_inject_call_companion_input_with_metadata`.
        """
        return response, metadata

    def pre_inject_call_companion_user_input(self, request: gcd_conversation.InjectCallCompanionUserInputRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.InjectCallCompanionUserInputRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for inject_call_companion_user_input

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_inject_call_companion_user_input(self, response: gcd_conversation.InjectCallCompanionUserInputResponse) -> gcd_conversation.InjectCallCompanionUserInputResponse:
        """Post-rpc interceptor for inject_call_companion_user_input

        DEPRECATED. Please use the `post_inject_call_companion_user_input_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_inject_call_companion_user_input` interceptor runs
        before the `post_inject_call_companion_user_input_with_metadata` interceptor.
        """
        return response

    def post_inject_call_companion_user_input_with_metadata(self, response: gcd_conversation.InjectCallCompanionUserInputResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.InjectCallCompanionUserInputResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for inject_call_companion_user_input

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_inject_call_companion_user_input_with_metadata`
        interceptor in new development instead of the `post_inject_call_companion_user_input` interceptor.
        When both interceptors are used, this `post_inject_call_companion_user_input_with_metadata` interceptor runs after the
        `post_inject_call_companion_user_input` interceptor. The (possibly modified) response returned by
        `post_inject_call_companion_user_input` will be passed to
        `post_inject_call_companion_user_input_with_metadata`.
        """
        return response, metadata

    def pre_list_call_matchers(self, request: conversation.ListCallMatchersRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.ListCallMatchersRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_call_matchers

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_list_call_matchers(self, response: conversation.ListCallMatchersResponse) -> conversation.ListCallMatchersResponse:
        """Post-rpc interceptor for list_call_matchers

        DEPRECATED. Please use the `post_list_call_matchers_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_list_call_matchers` interceptor runs
        before the `post_list_call_matchers_with_metadata` interceptor.
        """
        return response

    def post_list_call_matchers_with_metadata(self, response: conversation.ListCallMatchersResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.ListCallMatchersResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_call_matchers

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_list_call_matchers_with_metadata`
        interceptor in new development instead of the `post_list_call_matchers` interceptor.
        When both interceptors are used, this `post_list_call_matchers_with_metadata` interceptor runs after the
        `post_list_call_matchers` interceptor. The (possibly modified) response returned by
        `post_list_call_matchers` will be passed to
        `post_list_call_matchers_with_metadata`.
        """
        return response, metadata

    def pre_list_conversations(self, request: conversation.ListConversationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.ListConversationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_conversations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_list_conversations(self, response: conversation.ListConversationsResponse) -> conversation.ListConversationsResponse:
        """Post-rpc interceptor for list_conversations

        DEPRECATED. Please use the `post_list_conversations_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_list_conversations` interceptor runs
        before the `post_list_conversations_with_metadata` interceptor.
        """
        return response

    def post_list_conversations_with_metadata(self, response: conversation.ListConversationsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.ListConversationsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_conversations

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_list_conversations_with_metadata`
        interceptor in new development instead of the `post_list_conversations` interceptor.
        When both interceptors are used, this `post_list_conversations_with_metadata` interceptor runs after the
        `post_list_conversations` interceptor. The (possibly modified) response returned by
        `post_list_conversations` will be passed to
        `post_list_conversations_with_metadata`.
        """
        return response, metadata

    def pre_list_messages(self, request: conversation.ListMessagesRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.ListMessagesRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_messages

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_list_messages(self, response: conversation.ListMessagesResponse) -> conversation.ListMessagesResponse:
        """Post-rpc interceptor for list_messages

        DEPRECATED. Please use the `post_list_messages_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_list_messages` interceptor runs
        before the `post_list_messages_with_metadata` interceptor.
        """
        return response

    def post_list_messages_with_metadata(self, response: conversation.ListMessagesResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.ListMessagesResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_messages

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_list_messages_with_metadata`
        interceptor in new development instead of the `post_list_messages` interceptor.
        When both interceptors are used, this `post_list_messages_with_metadata` interceptor runs after the
        `post_list_messages` interceptor. The (possibly modified) response returned by
        `post_list_messages` will be passed to
        `post_list_messages_with_metadata`.
        """
        return response, metadata

    def pre_list_past_call_companion_events(self, request: gcd_conversation.ListPastCallCompanionEventsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.ListPastCallCompanionEventsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_past_call_companion_events

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_list_past_call_companion_events(self, response: gcd_conversation.ListPastCallCompanionEventsResponse) -> gcd_conversation.ListPastCallCompanionEventsResponse:
        """Post-rpc interceptor for list_past_call_companion_events

        DEPRECATED. Please use the `post_list_past_call_companion_events_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_list_past_call_companion_events` interceptor runs
        before the `post_list_past_call_companion_events_with_metadata` interceptor.
        """
        return response

    def post_list_past_call_companion_events_with_metadata(self, response: gcd_conversation.ListPastCallCompanionEventsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.ListPastCallCompanionEventsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_past_call_companion_events

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_list_past_call_companion_events_with_metadata`
        interceptor in new development instead of the `post_list_past_call_companion_events` interceptor.
        When both interceptors are used, this `post_list_past_call_companion_events_with_metadata` interceptor runs after the
        `post_list_past_call_companion_events` interceptor. The (possibly modified) response returned by
        `post_list_past_call_companion_events` will be passed to
        `post_list_past_call_companion_events_with_metadata`.
        """
        return response, metadata

    def pre_search_articles(self, request: gcd_conversation.SearchArticlesRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.SearchArticlesRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for search_articles

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_search_articles(self, response: gcd_conversation.SearchArticlesResponse) -> gcd_conversation.SearchArticlesResponse:
        """Post-rpc interceptor for search_articles

        DEPRECATED. Please use the `post_search_articles_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_search_articles` interceptor runs
        before the `post_search_articles_with_metadata` interceptor.
        """
        return response

    def post_search_articles_with_metadata(self, response: gcd_conversation.SearchArticlesResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.SearchArticlesResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for search_articles

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_search_articles_with_metadata`
        interceptor in new development instead of the `post_search_articles` interceptor.
        When both interceptors are used, this `post_search_articles_with_metadata` interceptor runs after the
        `post_search_articles` interceptor. The (possibly modified) response returned by
        `post_search_articles` will be passed to
        `post_search_articles_with_metadata`.
        """
        return response, metadata

    def pre_search_knowledge(self, request: conversation.SearchKnowledgeRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.SearchKnowledgeRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for search_knowledge

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_search_knowledge(self, response: conversation.SearchKnowledgeResponse) -> conversation.SearchKnowledgeResponse:
        """Post-rpc interceptor for search_knowledge

        DEPRECATED. Please use the `post_search_knowledge_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_search_knowledge` interceptor runs
        before the `post_search_knowledge_with_metadata` interceptor.
        """
        return response

    def post_search_knowledge_with_metadata(self, response: conversation.SearchKnowledgeResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[conversation.SearchKnowledgeResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for search_knowledge

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_search_knowledge_with_metadata`
        interceptor in new development instead of the `post_search_knowledge` interceptor.
        When both interceptors are used, this `post_search_knowledge_with_metadata` interceptor runs after the
        `post_search_knowledge` interceptor. The (possibly modified) response returned by
        `post_search_knowledge` will be passed to
        `post_search_knowledge_with_metadata`.
        """
        return response, metadata

    def pre_streaming_list_call_companion_events(self, request: gcd_conversation.StreamingListCallCompanionEventsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.StreamingListCallCompanionEventsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for streaming_list_call_companion_events

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_streaming_list_call_companion_events(self, response: rest_streaming.ResponseIterator) -> rest_streaming.ResponseIterator:
        """Post-rpc interceptor for streaming_list_call_companion_events

        DEPRECATED. Please use the `post_streaming_list_call_companion_events_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_streaming_list_call_companion_events` interceptor runs
        before the `post_streaming_list_call_companion_events_with_metadata` interceptor.
        """
        return response

    def post_streaming_list_call_companion_events_with_metadata(self, response: rest_streaming.ResponseIterator, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[rest_streaming.ResponseIterator, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for streaming_list_call_companion_events

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_streaming_list_call_companion_events_with_metadata`
        interceptor in new development instead of the `post_streaming_list_call_companion_events` interceptor.
        When both interceptors are used, this `post_streaming_list_call_companion_events_with_metadata` interceptor runs after the
        `post_streaming_list_call_companion_events` interceptor. The (possibly modified) response returned by
        `post_streaming_list_call_companion_events` will be passed to
        `post_streaming_list_call_companion_events_with_metadata`.
        """
        return response, metadata

    def pre_streaming_list_upcoming_call_companion_events(self, request: gcd_conversation.StreamingListUpcomingCallCompanionEventsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.StreamingListUpcomingCallCompanionEventsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for streaming_list_upcoming_call_companion_events

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_streaming_list_upcoming_call_companion_events(self, response: rest_streaming.ResponseIterator) -> rest_streaming.ResponseIterator:
        """Post-rpc interceptor for streaming_list_upcoming_call_companion_events

        DEPRECATED. Please use the `post_streaming_list_upcoming_call_companion_events_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_streaming_list_upcoming_call_companion_events` interceptor runs
        before the `post_streaming_list_upcoming_call_companion_events_with_metadata` interceptor.
        """
        return response

    def post_streaming_list_upcoming_call_companion_events_with_metadata(self, response: rest_streaming.ResponseIterator, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[rest_streaming.ResponseIterator, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for streaming_list_upcoming_call_companion_events

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_streaming_list_upcoming_call_companion_events_with_metadata`
        interceptor in new development instead of the `post_streaming_list_upcoming_call_companion_events` interceptor.
        When both interceptors are used, this `post_streaming_list_upcoming_call_companion_events_with_metadata` interceptor runs after the
        `post_streaming_list_upcoming_call_companion_events` interceptor. The (possibly modified) response returned by
        `post_streaming_list_upcoming_call_companion_events` will be passed to
        `post_streaming_list_upcoming_call_companion_events_with_metadata`.
        """
        return response, metadata

    def pre_suggest_conversation_key_moments(self, request: gcd_conversation.SuggestConversationKeyMomentsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.SuggestConversationKeyMomentsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for suggest_conversation_key_moments

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_suggest_conversation_key_moments(self, response: gcd_conversation.SuggestConversationKeyMomentsResponse) -> gcd_conversation.SuggestConversationKeyMomentsResponse:
        """Post-rpc interceptor for suggest_conversation_key_moments

        DEPRECATED. Please use the `post_suggest_conversation_key_moments_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_suggest_conversation_key_moments` interceptor runs
        before the `post_suggest_conversation_key_moments_with_metadata` interceptor.
        """
        return response

    def post_suggest_conversation_key_moments_with_metadata(self, response: gcd_conversation.SuggestConversationKeyMomentsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.SuggestConversationKeyMomentsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for suggest_conversation_key_moments

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_suggest_conversation_key_moments_with_metadata`
        interceptor in new development instead of the `post_suggest_conversation_key_moments` interceptor.
        When both interceptors are used, this `post_suggest_conversation_key_moments_with_metadata` interceptor runs after the
        `post_suggest_conversation_key_moments` interceptor. The (possibly modified) response returned by
        `post_suggest_conversation_key_moments` will be passed to
        `post_suggest_conversation_key_moments_with_metadata`.
        """
        return response, metadata

    def pre_suggest_conversation_summary(self, request: gcd_conversation.SuggestConversationSummaryRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.SuggestConversationSummaryRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for suggest_conversation_summary

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_suggest_conversation_summary(self, response: gcd_conversation.SuggestConversationSummaryResponse) -> gcd_conversation.SuggestConversationSummaryResponse:
        """Post-rpc interceptor for suggest_conversation_summary

        DEPRECATED. Please use the `post_suggest_conversation_summary_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_suggest_conversation_summary` interceptor runs
        before the `post_suggest_conversation_summary_with_metadata` interceptor.
        """
        return response

    def post_suggest_conversation_summary_with_metadata(self, response: gcd_conversation.SuggestConversationSummaryResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.SuggestConversationSummaryResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for suggest_conversation_summary

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_suggest_conversation_summary_with_metadata`
        interceptor in new development instead of the `post_suggest_conversation_summary` interceptor.
        When both interceptors are used, this `post_suggest_conversation_summary_with_metadata` interceptor runs after the
        `post_suggest_conversation_summary` interceptor. The (possibly modified) response returned by
        `post_suggest_conversation_summary` will be passed to
        `post_suggest_conversation_summary_with_metadata`.
        """
        return response, metadata

    def pre_update_conversation(self, request: gcd_conversation.UpdateConversationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.UpdateConversationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for update_conversation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_update_conversation(self, response: gcd_conversation.Conversation) -> gcd_conversation.Conversation:
        """Post-rpc interceptor for update_conversation

        DEPRECATED. Please use the `post_update_conversation_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code. This `post_update_conversation` interceptor runs
        before the `post_update_conversation_with_metadata` interceptor.
        """
        return response

    def post_update_conversation_with_metadata(self, response: gcd_conversation.Conversation, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[gcd_conversation.Conversation, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for update_conversation

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the Conversations server but before it is returned to user code.

        We recommend only using this `post_update_conversation_with_metadata`
        interceptor in new development instead of the `post_update_conversation` interceptor.
        When both interceptors are used, this `post_update_conversation_with_metadata` interceptor runs after the
        `post_update_conversation` interceptor. The (possibly modified) response returned by
        `post_update_conversation` will be passed to
        `post_update_conversation_with_metadata`.
        """
        return response, metadata

    def pre_get_location(
        self, request: locations_pb2.GetLocationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.GetLocationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_location

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_get_location(
        self, response: locations_pb2.Location
    ) -> locations_pb2.Location:
        """Post-rpc interceptor for get_location

        Override in a subclass to manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code.
        """
        return response

    def pre_list_locations(
        self, request: locations_pb2.ListLocationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.ListLocationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_locations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_list_locations(
        self, response: locations_pb2.ListLocationsResponse
    ) -> locations_pb2.ListLocationsResponse:
        """Post-rpc interceptor for list_locations

        Override in a subclass to manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code.
        """
        return response

    def pre_cancel_operation(
        self, request: operations_pb2.CancelOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.CancelOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_cancel_operation(
        self, response: None
    ) -> None:
        """Post-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code.
        """
        return response

    def pre_get_operation(
        self, request: operations_pb2.GetOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.GetOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_get_operation(
        self, response: operations_pb2.Operation
    ) -> operations_pb2.Operation:
        """Post-rpc interceptor for get_operation

        Override in a subclass to manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code.
        """
        return response

    def pre_list_operations(
        self, request: operations_pb2.ListOperationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.ListOperationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_operations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the Conversations server.
        """
        return request, metadata

    def post_list_operations(
        self, response: operations_pb2.ListOperationsResponse
    ) -> operations_pb2.ListOperationsResponse:
        """Post-rpc interceptor for list_operations

        Override in a subclass to manipulate the response
        after it is returned by the Conversations server but before
        it is returned to user code.
        """
        return response


@dataclasses.dataclass
class ConversationsRestStub:
    _session: AuthorizedSession
    _host: str
    _interceptor: ConversationsRestInterceptor


class ConversationsRestTransport(_BaseConversationsRestTransport):
    """REST backend synchronous transport for Conversations.

    Service for managing
    [Conversations][google.cloud.dialogflow.v2beta1.Conversation].

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends JSON representations of protocol buffers over HTTP/1.1
    """

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            client_cert_source_for_mtls: Optional[Callable[[
                ], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            url_scheme: str = 'https',
            interceptor: Optional[ConversationsRestInterceptor] = None,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

       NOTE: This REST transport functionality is currently in a beta
       state (preview). We welcome your feedback via a GitHub issue in
       this library's repository. Thank you!

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.

            credentials_file (Optional[str]): A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if ``channel`` is provided.
            scopes (Optional(Sequence[str])): A list of scopes. This argument is
                ignored if ``channel`` is provided.
            client_cert_source_for_mtls (Callable[[], Tuple[bytes, bytes]]): Client
                certificate to configure mutual TLS HTTP channel. It is ignored
                if ``channel`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you are developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.
            url_scheme: the protocol scheme for the API endpoint.  Normally
                "https", but for testing or local servers,
                "http" can be specified.
        """
        # Run the base constructor
        # TODO(yon-mg): resolve other ctor params i.e. scopes, quota, etc.
        # TODO: When custom host (api_endpoint) is set, `scopes` must *also* be set on the
        # credentials object
        super().__init__(
            host=host,
            credentials=credentials,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            url_scheme=url_scheme,
            api_audience=api_audience
        )
        self._session = AuthorizedSession(
            self._credentials, default_host=self.DEFAULT_HOST)
        self._operations_client: Optional[operations_v1.AbstractOperationsClient] = None
        if client_cert_source_for_mtls:
            self._session.configure_mtls_channel(client_cert_source_for_mtls)
        self._interceptor = interceptor or ConversationsRestInterceptor()
        self._prep_wrapped_messages(client_info)

    @property
    def operations_client(self) -> operations_v1.AbstractOperationsClient:
        """Create the client designed to process long-running operations.

        This property caches on the instance; repeated calls return the same
        client.
        """
        # Only create a new client if we do not already have one.
        if self._operations_client is None:
            http_options: Dict[str, List[Dict[str, str]]] = {
                'google.longrunning.Operations.CancelOperation': [
                    {
                        'method': 'post',
                        'uri': '/v2beta1/{name=projects/*/operations/*}:cancel',
                    },
                    {
                        'method': 'post',
                        'uri': '/v2beta1/{name=projects/*/locations/*/operations/*}:cancel',
                    },
                ],
                'google.longrunning.Operations.GetOperation': [
                    {
                        'method': 'get',
                        'uri': '/v2beta1/{name=projects/*/operations/*}',
                    },
                    {
                        'method': 'get',
                        'uri': '/v2beta1/{name=projects/*/locations/*/operations/*}',
                    },
                ],
                'google.longrunning.Operations.ListOperations': [
                    {
                        'method': 'get',
                        'uri': '/v2beta1/{name=projects/*}/operations',
                    },
                    {
                        'method': 'get',
                        'uri': '/v2beta1/{name=projects/*/locations/*}/operations',
                    },
                ],
            }

            rest_transport = operations_v1.OperationsRestTransport(
                    host=self._host,
                    # use the credentials which are saved
                    credentials=self._credentials,
                    scopes=self._scopes,
                    http_options=http_options,
                    path_prefix="v2beta1")

            self._operations_client = operations_v1.AbstractOperationsClient(transport=rest_transport)

        # Return the client from cache.
        return self._operations_client

    class _ActivateConversation(_BaseConversationsRestTransport._BaseActivateConversation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.ActivateConversation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.ActivateConversationRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.Conversation:
            r"""Call the activate conversation method over HTTP.

            Args:
                request (~.gcd_conversation.ActivateConversationRequest):
                    The request object. The request message for
                [Conversations.ActiveConversation][].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.Conversation:
                    Represents a conversation.
                A conversation is an interaction between
                an agent, including live agents and
                Dialogflow agents, and a support
                customer. Conversations can include
                phone calls and text-based chat
                sessions.

            """

            http_options = _BaseConversationsRestTransport._BaseActivateConversation._get_http_options()

            request, metadata = self._interceptor.pre_activate_conversation(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseActivateConversation._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseActivateConversation._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseActivateConversation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.ActivateConversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ActivateConversation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._ActivateConversation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.Conversation()
            pb_resp = gcd_conversation.Conversation.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_activate_conversation(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_activate_conversation_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.Conversation.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.activate_conversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ActivateConversation",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _AddConversationPhoneNumber(_BaseConversationsRestTransport._BaseAddConversationPhoneNumber, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.AddConversationPhoneNumber")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation.AddConversationPhoneNumberRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.ConversationPhoneNumber:
            r"""Call the add conversation phone
        number method over HTTP.

            Args:
                request (~.conversation.AddConversationPhoneNumberRequest):
                    The request object. The request message for
                [Conversations.AddConversationPhoneNumber][google.cloud.dialogflow.v2beta1.Conversations.AddConversationPhoneNumber].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.ConversationPhoneNumber:
                    Represents a phone number for
                telephony integration. It allows for
                connecting a particular conversation
                over telephony.

            """

            http_options = _BaseConversationsRestTransport._BaseAddConversationPhoneNumber._get_http_options()

            request, metadata = self._interceptor.pre_add_conversation_phone_number(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseAddConversationPhoneNumber._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseAddConversationPhoneNumber._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseAddConversationPhoneNumber._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.AddConversationPhoneNumber",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "AddConversationPhoneNumber",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._AddConversationPhoneNumber._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.ConversationPhoneNumber()
            pb_resp = conversation.ConversationPhoneNumber.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_add_conversation_phone_number(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_add_conversation_phone_number_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.ConversationPhoneNumber.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.add_conversation_phone_number",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "AddConversationPhoneNumber",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _BatchCreateMessages(_BaseConversationsRestTransport._BaseBatchCreateMessages, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.BatchCreateMessages")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation.BatchCreateMessagesRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.BatchCreateMessagesResponse:
            r"""Call the batch create messages method over HTTP.

            Args:
                request (~.conversation.BatchCreateMessagesRequest):
                    The request object. The request message for
                [Conversations.BatchCreateMessagesRequest][].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.BatchCreateMessagesResponse:
                    The request message for
                [Conversations.BatchCreateMessagesResponse][].

            """

            http_options = _BaseConversationsRestTransport._BaseBatchCreateMessages._get_http_options()

            request, metadata = self._interceptor.pre_batch_create_messages(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseBatchCreateMessages._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseBatchCreateMessages._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseBatchCreateMessages._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.BatchCreateMessages",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "BatchCreateMessages",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._BatchCreateMessages._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.BatchCreateMessagesResponse()
            pb_resp = conversation.BatchCreateMessagesResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_batch_create_messages(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_batch_create_messages_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.BatchCreateMessagesResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.batch_create_messages",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "BatchCreateMessages",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _CompleteConversation(_BaseConversationsRestTransport._BaseCompleteConversation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.CompleteConversation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation.CompleteConversationRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.Conversation:
            r"""Call the complete conversation method over HTTP.

            Args:
                request (~.conversation.CompleteConversationRequest):
                    The request object. The request message for
                [Conversations.CompleteConversation][google.cloud.dialogflow.v2beta1.Conversations.CompleteConversation].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.Conversation:
                    Represents a conversation.
                A conversation is an interaction between
                an agent, including live agents and
                Dialogflow agents, and a support
                customer. Conversations can include
                phone calls and text-based chat
                sessions.

            """

            http_options = _BaseConversationsRestTransport._BaseCompleteConversation._get_http_options()

            request, metadata = self._interceptor.pre_complete_conversation(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseCompleteConversation._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseCompleteConversation._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseCompleteConversation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.CompleteConversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "CompleteConversation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._CompleteConversation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.Conversation()
            pb_resp = conversation.Conversation.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_complete_conversation(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_complete_conversation_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.Conversation.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.complete_conversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "CompleteConversation",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _CreateCallMatcher(_BaseConversationsRestTransport._BaseCreateCallMatcher, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.CreateCallMatcher")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation.CreateCallMatcherRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.CallMatcher:
            r"""Call the create call matcher method over HTTP.

            Args:
                request (~.conversation.CreateCallMatcherRequest):
                    The request object. The request message for
                [Conversations.CreateCallMatcher][google.cloud.dialogflow.v2beta1.Conversations.CreateCallMatcher].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.CallMatcher:
                    Represents a call matcher that describes criteria for
                matching incoming SIP calls to a conversation. When
                Dialogflow get a SIP call from a third-party carrier,
                Dialogflow matches the call to an existing conversation
                by either:

                -  Extracting the conversation id from the `Call-Info
                   header <https://tools.ietf.org/html/rfc3261#section-20.9>`__,
                   e.g.,
                   ``Call-Info: <http://dialogflow.googleapis.com/v2beta1/projects/111/conversations/222> ;purpose=Goog-ContactCenter-Conversation``.
                -  Or, if that doesn't work, matching incoming `SIP
                   headers <https://tools.ietf.org/html/rfc3261#section-7.3>`__
                   against any
                   [CallMatcher][google.cloud.dialogflow.v2beta1.CallMatcher]
                   for the conversation.

                If an incoming SIP call without valid ``Call-Info``
                header matches to zero or multiple conversations with
                ``CallMatcher``, we reject it.

                A call matcher contains equality conditions for SIP
                headers that all have to be fulfilled in order for a SIP
                call to match.

                The matched SIP headers consist of well-known headers
                (``To``, ``From``, ``Call-ID``) and custom headers. A
                [CallMatcher][google.cloud.dialogflow.v2beta1.CallMatcher]
                is only valid if it specifies:

                -  At least 1 custom header,
                -  or at least 2 well-known headers.

            """

            http_options = _BaseConversationsRestTransport._BaseCreateCallMatcher._get_http_options()

            request, metadata = self._interceptor.pre_create_call_matcher(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseCreateCallMatcher._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseCreateCallMatcher._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseCreateCallMatcher._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.CreateCallMatcher",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "CreateCallMatcher",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._CreateCallMatcher._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.CallMatcher()
            pb_resp = conversation.CallMatcher.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_create_call_matcher(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_create_call_matcher_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.CallMatcher.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.create_call_matcher",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "CreateCallMatcher",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _CreateConversation(_BaseConversationsRestTransport._BaseCreateConversation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.CreateConversation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.CreateConversationRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.Conversation:
            r"""Call the create conversation method over HTTP.

            Args:
                request (~.gcd_conversation.CreateConversationRequest):
                    The request object. The request message for
                [Conversations.CreateConversation][google.cloud.dialogflow.v2beta1.Conversations.CreateConversation].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.Conversation:
                    Represents a conversation.
                A conversation is an interaction between
                an agent, including live agents and
                Dialogflow agents, and a support
                customer. Conversations can include
                phone calls and text-based chat
                sessions.

            """

            http_options = _BaseConversationsRestTransport._BaseCreateConversation._get_http_options()

            request, metadata = self._interceptor.pre_create_conversation(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseCreateConversation._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseCreateConversation._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseCreateConversation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.CreateConversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "CreateConversation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._CreateConversation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.Conversation()
            pb_resp = gcd_conversation.Conversation.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_create_conversation(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_create_conversation_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.Conversation.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.create_conversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "CreateConversation",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _DeactivateConversation(_BaseConversationsRestTransport._BaseDeactivateConversation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.DeactivateConversation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.DeactivateConversationRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.Conversation:
            r"""Call the deactivate conversation method over HTTP.

            Args:
                request (~.gcd_conversation.DeactivateConversationRequest):
                    The request object. The request message for
                [Conversations.DeactiveConversation][].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.Conversation:
                    Represents a conversation.
                A conversation is an interaction between
                an agent, including live agents and
                Dialogflow agents, and a support
                customer. Conversations can include
                phone calls and text-based chat
                sessions.

            """

            http_options = _BaseConversationsRestTransport._BaseDeactivateConversation._get_http_options()

            request, metadata = self._interceptor.pre_deactivate_conversation(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseDeactivateConversation._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseDeactivateConversation._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseDeactivateConversation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.DeactivateConversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "DeactivateConversation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._DeactivateConversation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.Conversation()
            pb_resp = gcd_conversation.Conversation.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_deactivate_conversation(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_deactivate_conversation_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.Conversation.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.deactivate_conversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "DeactivateConversation",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _DeleteCallMatcher(_BaseConversationsRestTransport._BaseDeleteCallMatcher, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.DeleteCallMatcher")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation.DeleteCallMatcherRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ):
            r"""Call the delete call matcher method over HTTP.

            Args:
                request (~.conversation.DeleteCallMatcherRequest):
                    The request object. The request message for
                [Conversations.DeleteCallMatcher][google.cloud.dialogflow.v2beta1.Conversations.DeleteCallMatcher].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseConversationsRestTransport._BaseDeleteCallMatcher._get_http_options()

            request, metadata = self._interceptor.pre_delete_call_matcher(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseDeleteCallMatcher._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseDeleteCallMatcher._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.DeleteCallMatcher",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "DeleteCallMatcher",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._DeleteCallMatcher._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

    class _ExportMessages(_BaseConversationsRestTransport._BaseExportMessages, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.ExportMessages")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation.ExportMessagesRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> operations_pb2.Operation:
            r"""Call the export messages method over HTTP.

            Args:
                request (~.conversation.ExportMessagesRequest):
                    The request object. The request message for
                [Conversations.ExportMessages][google.cloud.dialogflow.v2beta1.Conversations.ExportMessages].
                Note: this message is pre-alpha and is subject to
                incompatible changes.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.operations_pb2.Operation:
                    This resource represents a
                long-running operation that is the
                result of a network API call.

            """

            http_options = _BaseConversationsRestTransport._BaseExportMessages._get_http_options()

            request, metadata = self._interceptor.pre_export_messages(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseExportMessages._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseExportMessages._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.ExportMessages",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ExportMessages",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._ExportMessages._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = operations_pb2.Operation()
            json_format.Parse(response.content, resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_export_messages(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_export_messages_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.export_messages",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ExportMessages",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GenerateStatelessSuggestion(_BaseConversationsRestTransport._BaseGenerateStatelessSuggestion, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.GenerateStatelessSuggestion")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation.GenerateStatelessSuggestionRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.GenerateStatelessSuggestionResponse:
            r"""Call the generate stateless
        suggestion method over HTTP.

            Args:
                request (~.conversation.GenerateStatelessSuggestionRequest):
                    The request object. The request message for
                [Conversations.GenerateStatelessSuggestion][google.cloud.dialogflow.v2beta1.Conversations.GenerateStatelessSuggestion].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.GenerateStatelessSuggestionResponse:
                    The response message for
                [Conversations.GenerateStatelessSuggestion][google.cloud.dialogflow.v2beta1.Conversations.GenerateStatelessSuggestion].

            """

            http_options = _BaseConversationsRestTransport._BaseGenerateStatelessSuggestion._get_http_options()

            request, metadata = self._interceptor.pre_generate_stateless_suggestion(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseGenerateStatelessSuggestion._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseGenerateStatelessSuggestion._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseGenerateStatelessSuggestion._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.GenerateStatelessSuggestion",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GenerateStatelessSuggestion",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._GenerateStatelessSuggestion._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.GenerateStatelessSuggestionResponse()
            pb_resp = conversation.GenerateStatelessSuggestionResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_generate_stateless_suggestion(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_generate_stateless_suggestion_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.GenerateStatelessSuggestionResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.generate_stateless_suggestion",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GenerateStatelessSuggestion",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GenerateStatelessSummary(_BaseConversationsRestTransport._BaseGenerateStatelessSummary, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.GenerateStatelessSummary")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation.GenerateStatelessSummaryRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.GenerateStatelessSummaryResponse:
            r"""Call the generate stateless
        summary method over HTTP.

            Args:
                request (~.conversation.GenerateStatelessSummaryRequest):
                    The request object. The request message for
                [Conversations.GenerateStatelessSummary][google.cloud.dialogflow.v2beta1.Conversations.GenerateStatelessSummary].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.GenerateStatelessSummaryResponse:
                    The response message for
                [Conversations.GenerateStatelessSummary][google.cloud.dialogflow.v2beta1.Conversations.GenerateStatelessSummary].

            """

            http_options = _BaseConversationsRestTransport._BaseGenerateStatelessSummary._get_http_options()

            request, metadata = self._interceptor.pre_generate_stateless_summary(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseGenerateStatelessSummary._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseGenerateStatelessSummary._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseGenerateStatelessSummary._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.GenerateStatelessSummary",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GenerateStatelessSummary",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._GenerateStatelessSummary._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.GenerateStatelessSummaryResponse()
            pb_resp = conversation.GenerateStatelessSummaryResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_generate_stateless_summary(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_generate_stateless_summary_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.GenerateStatelessSummaryResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.generate_stateless_summary",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GenerateStatelessSummary",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GenerateSuggestions(_BaseConversationsRestTransport._BaseGenerateSuggestions, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.GenerateSuggestions")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.GenerateSuggestionsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> participant.GenerateSuggestionsResponse:
            r"""Call the generate suggestions method over HTTP.

            Args:
                request (~.gcd_conversation.GenerateSuggestionsRequest):
                    The request object. The request message for
                [Conversations.GenerateSuggestions][google.cloud.dialogflow.v2beta1.Conversations.GenerateSuggestions].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.participant.GenerateSuggestionsResponse:
                    The response message for
                [Conversations.GenerateSuggestions][google.cloud.dialogflow.v2beta1.Conversations.GenerateSuggestions].

            """

            http_options = _BaseConversationsRestTransport._BaseGenerateSuggestions._get_http_options()

            request, metadata = self._interceptor.pre_generate_suggestions(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseGenerateSuggestions._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseGenerateSuggestions._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseGenerateSuggestions._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.GenerateSuggestions",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GenerateSuggestions",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._GenerateSuggestions._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = participant.GenerateSuggestionsResponse()
            pb_resp = participant.GenerateSuggestionsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_generate_suggestions(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_generate_suggestions_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = participant.GenerateSuggestionsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.generate_suggestions",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GenerateSuggestions",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GetCallCompanionSettings(_BaseConversationsRestTransport._BaseGetCallCompanionSettings, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.GetCallCompanionSettings")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.GetCallCompanionSettingsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.CallCompanionSettings:
            r"""Call the get call companion
        settings method over HTTP.

            Args:
                request (~.gcd_conversation.GetCallCompanionSettingsRequest):
                    The request object. Request message for [GetCallCompanionSettings][].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.CallCompanionSettings:
                    Response message for [GetCallCompanionSettings][].
            """

            http_options = _BaseConversationsRestTransport._BaseGetCallCompanionSettings._get_http_options()

            request, metadata = self._interceptor.pre_get_call_companion_settings(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseGetCallCompanionSettings._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseGetCallCompanionSettings._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseGetCallCompanionSettings._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.GetCallCompanionSettings",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GetCallCompanionSettings",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._GetCallCompanionSettings._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.CallCompanionSettings()
            pb_resp = gcd_conversation.CallCompanionSettings.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_get_call_companion_settings(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_get_call_companion_settings_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.CallCompanionSettings.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.get_call_companion_settings",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GetCallCompanionSettings",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _GetConversation(_BaseConversationsRestTransport._BaseGetConversation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.GetConversation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation.GetConversationRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.Conversation:
            r"""Call the get conversation method over HTTP.

            Args:
                request (~.conversation.GetConversationRequest):
                    The request object. The request message for
                [Conversations.GetConversation][google.cloud.dialogflow.v2beta1.Conversations.GetConversation].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.Conversation:
                    Represents a conversation.
                A conversation is an interaction between
                an agent, including live agents and
                Dialogflow agents, and a support
                customer. Conversations can include
                phone calls and text-based chat
                sessions.

            """

            http_options = _BaseConversationsRestTransport._BaseGetConversation._get_http_options()

            request, metadata = self._interceptor.pre_get_conversation(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseGetConversation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseGetConversation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.GetConversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GetConversation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._GetConversation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.Conversation()
            pb_resp = conversation.Conversation.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_get_conversation(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_get_conversation_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.Conversation.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.get_conversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GetConversation",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _IngestContextReferences(_BaseConversationsRestTransport._BaseIngestContextReferences, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.IngestContextReferences")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.IngestContextReferencesRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.IngestContextReferencesResponse:
            r"""Call the ingest context references method over HTTP.

            Args:
                request (~.gcd_conversation.IngestContextReferencesRequest):
                    The request object. The request message for
                [ConversationsService.IngestContextReferences][].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.IngestContextReferencesResponse:
                    The response message for
                [ConversationsService.IngestContextReferences][].

            """

            http_options = _BaseConversationsRestTransport._BaseIngestContextReferences._get_http_options()

            request, metadata = self._interceptor.pre_ingest_context_references(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseIngestContextReferences._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseIngestContextReferences._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseIngestContextReferences._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.IngestContextReferences",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "IngestContextReferences",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._IngestContextReferences._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.IngestContextReferencesResponse()
            pb_resp = gcd_conversation.IngestContextReferencesResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_ingest_context_references(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_ingest_context_references_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.IngestContextReferencesResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.ingest_context_references",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "IngestContextReferences",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _InitializeCallCompanion(_BaseConversationsRestTransport._BaseInitializeCallCompanion, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.InitializeCallCompanion")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.InitializeCallCompanionRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ):
            r"""Call the initialize call companion method over HTTP.

            Args:
                request (~.gcd_conversation.InitializeCallCompanionRequest):
                    The request object. Request message for [InitializeCallCompanion][].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseConversationsRestTransport._BaseInitializeCallCompanion._get_http_options()

            request, metadata = self._interceptor.pre_initialize_call_companion(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseInitializeCallCompanion._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseInitializeCallCompanion._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseInitializeCallCompanion._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.InitializeCallCompanion",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "InitializeCallCompanion",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._InitializeCallCompanion._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

    class _InitiatePhoneCall(_BaseConversationsRestTransport._BaseInitiatePhoneCall, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.InitiatePhoneCall")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.InitiatePhoneCallRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.InitiatePhoneCallResponse:
            r"""Call the initiate phone call method over HTTP.

            Args:
                request (~.gcd_conversation.InitiatePhoneCallRequest):
                    The request object. The request message for
                [Conversations.InitiatePhoneCall][google.cloud.dialogflow.v2beta1.Conversations.InitiatePhoneCall].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.InitiatePhoneCallResponse:
                    The response message for
                [Conversations.InitiatePhoneCall][google.cloud.dialogflow.v2beta1.Conversations.InitiatePhoneCall].

            """

            http_options = _BaseConversationsRestTransport._BaseInitiatePhoneCall._get_http_options()

            request, metadata = self._interceptor.pre_initiate_phone_call(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseInitiatePhoneCall._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseInitiatePhoneCall._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseInitiatePhoneCall._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.InitiatePhoneCall",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "InitiatePhoneCall",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._InitiatePhoneCall._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.InitiatePhoneCallResponse()
            pb_resp = gcd_conversation.InitiatePhoneCallResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_initiate_phone_call(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_initiate_phone_call_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.InitiatePhoneCallResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.initiate_phone_call",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "InitiatePhoneCall",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _InjectCallCompanionInput(_BaseConversationsRestTransport._BaseInjectCallCompanionInput, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.InjectCallCompanionInput")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.InjectCallCompanionInputRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.InjectCallCompanionInputResponse:
            r"""Call the inject call companion
        input method over HTTP.

            Args:
                request (~.gcd_conversation.InjectCallCompanionInputRequest):
                    The request object. Request message for [InjectCallCompanionInput][].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.InjectCallCompanionInputResponse:
                    Response message for [InjectCallCompanionInput][]'.
            """

            http_options = _BaseConversationsRestTransport._BaseInjectCallCompanionInput._get_http_options()

            request, metadata = self._interceptor.pre_inject_call_companion_input(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseInjectCallCompanionInput._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseInjectCallCompanionInput._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseInjectCallCompanionInput._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.InjectCallCompanionInput",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "InjectCallCompanionInput",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._InjectCallCompanionInput._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.InjectCallCompanionInputResponse()
            pb_resp = gcd_conversation.InjectCallCompanionInputResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_inject_call_companion_input(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_inject_call_companion_input_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.InjectCallCompanionInputResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.inject_call_companion_input",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "InjectCallCompanionInput",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _InjectCallCompanionUserInput(_BaseConversationsRestTransport._BaseInjectCallCompanionUserInput, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.InjectCallCompanionUserInput")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.InjectCallCompanionUserInputRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.InjectCallCompanionUserInputResponse:
            r"""Call the inject call companion
        user input method over HTTP.

            Args:
                request (~.gcd_conversation.InjectCallCompanionUserInputRequest):
                    The request object. Request message for
                'InjectCallCompanionUserInput' method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.InjectCallCompanionUserInputResponse:
                    Response message for
                'InjectCallCompanionUserInput' method.

            """

            http_options = _BaseConversationsRestTransport._BaseInjectCallCompanionUserInput._get_http_options()

            request, metadata = self._interceptor.pre_inject_call_companion_user_input(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseInjectCallCompanionUserInput._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseInjectCallCompanionUserInput._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseInjectCallCompanionUserInput._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.InjectCallCompanionUserInput",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "InjectCallCompanionUserInput",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._InjectCallCompanionUserInput._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.InjectCallCompanionUserInputResponse()
            pb_resp = gcd_conversation.InjectCallCompanionUserInputResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_inject_call_companion_user_input(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_inject_call_companion_user_input_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.InjectCallCompanionUserInputResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.inject_call_companion_user_input",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "InjectCallCompanionUserInput",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListCallMatchers(_BaseConversationsRestTransport._BaseListCallMatchers, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.ListCallMatchers")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation.ListCallMatchersRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.ListCallMatchersResponse:
            r"""Call the list call matchers method over HTTP.

            Args:
                request (~.conversation.ListCallMatchersRequest):
                    The request object. The request message for
                [Conversations.ListCallMatchers][google.cloud.dialogflow.v2beta1.Conversations.ListCallMatchers].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.ListCallMatchersResponse:
                    The response message for
                [Conversations.ListCallMatchers][google.cloud.dialogflow.v2beta1.Conversations.ListCallMatchers].

            """

            http_options = _BaseConversationsRestTransport._BaseListCallMatchers._get_http_options()

            request, metadata = self._interceptor.pre_list_call_matchers(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseListCallMatchers._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseListCallMatchers._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.ListCallMatchers",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListCallMatchers",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._ListCallMatchers._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.ListCallMatchersResponse()
            pb_resp = conversation.ListCallMatchersResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_call_matchers(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_call_matchers_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.ListCallMatchersResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.list_call_matchers",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListCallMatchers",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListConversations(_BaseConversationsRestTransport._BaseListConversations, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.ListConversations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation.ListConversationsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.ListConversationsResponse:
            r"""Call the list conversations method over HTTP.

            Args:
                request (~.conversation.ListConversationsRequest):
                    The request object. The request message for
                [Conversations.ListConversations][google.cloud.dialogflow.v2beta1.Conversations.ListConversations].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.ListConversationsResponse:
                    The response message for
                [Conversations.ListConversations][google.cloud.dialogflow.v2beta1.Conversations.ListConversations].

            """

            http_options = _BaseConversationsRestTransport._BaseListConversations._get_http_options()

            request, metadata = self._interceptor.pre_list_conversations(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseListConversations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseListConversations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.ListConversations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListConversations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._ListConversations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.ListConversationsResponse()
            pb_resp = conversation.ListConversationsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_conversations(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_conversations_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.ListConversationsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.list_conversations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListConversations",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListMessages(_BaseConversationsRestTransport._BaseListMessages, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.ListMessages")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: conversation.ListMessagesRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.ListMessagesResponse:
            r"""Call the list messages method over HTTP.

            Args:
                request (~.conversation.ListMessagesRequest):
                    The request object. The request message for
                [Conversations.ListMessages][google.cloud.dialogflow.v2beta1.Conversations.ListMessages].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.ListMessagesResponse:
                    The response message for
                [Conversations.ListMessages][google.cloud.dialogflow.v2beta1.Conversations.ListMessages].

            """

            http_options = _BaseConversationsRestTransport._BaseListMessages._get_http_options()

            request, metadata = self._interceptor.pre_list_messages(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseListMessages._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseListMessages._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.ListMessages",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListMessages",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._ListMessages._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.ListMessagesResponse()
            pb_resp = conversation.ListMessagesResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_messages(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_messages_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.ListMessagesResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.list_messages",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListMessages",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListPastCallCompanionEvents(_BaseConversationsRestTransport._BaseListPastCallCompanionEvents, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.ListPastCallCompanionEvents")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: gcd_conversation.ListPastCallCompanionEventsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.ListPastCallCompanionEventsResponse:
            r"""Call the list past call companion
        events method over HTTP.

            Args:
                request (~.gcd_conversation.ListPastCallCompanionEventsRequest):
                    The request object. Request message for
                'ListPastCallCompanionEvents' method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.ListPastCallCompanionEventsResponse:
                    Response message for
                'ListPastCallCompanionEvents' method.

            """

            http_options = _BaseConversationsRestTransport._BaseListPastCallCompanionEvents._get_http_options()

            request, metadata = self._interceptor.pre_list_past_call_companion_events(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseListPastCallCompanionEvents._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseListPastCallCompanionEvents._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.ListPastCallCompanionEvents",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListPastCallCompanionEvents",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._ListPastCallCompanionEvents._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.ListPastCallCompanionEventsResponse()
            pb_resp = gcd_conversation.ListPastCallCompanionEventsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_past_call_companion_events(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_past_call_companion_events_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.ListPastCallCompanionEventsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.list_past_call_companion_events",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListPastCallCompanionEvents",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _SearchArticles(_BaseConversationsRestTransport._BaseSearchArticles, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.SearchArticles")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: gcd_conversation.SearchArticlesRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.SearchArticlesResponse:
            r"""Call the search articles method over HTTP.

            Args:
                request (~.gcd_conversation.SearchArticlesRequest):
                    The request object. The request message for
                [Conversations.SearchArticles][google.cloud.dialogflow.v2beta1.Conversations.SearchArticles].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.SearchArticlesResponse:
                    The response message for
                [Conversations.SearchArticles][google.cloud.dialogflow.v2beta1.Conversations.SearchArticles].

            """

            http_options = _BaseConversationsRestTransport._BaseSearchArticles._get_http_options()

            request, metadata = self._interceptor.pre_search_articles(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseSearchArticles._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseSearchArticles._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.SearchArticles",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "SearchArticles",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._SearchArticles._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.SearchArticlesResponse()
            pb_resp = gcd_conversation.SearchArticlesResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_search_articles(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_search_articles_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.SearchArticlesResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.search_articles",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "SearchArticles",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _SearchKnowledge(_BaseConversationsRestTransport._BaseSearchKnowledge, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.SearchKnowledge")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: conversation.SearchKnowledgeRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> conversation.SearchKnowledgeResponse:
            r"""Call the search knowledge method over HTTP.

            Args:
                request (~.conversation.SearchKnowledgeRequest):
                    The request object. The request message for
                [Conversations.SearchKnowledge][google.cloud.dialogflow.v2beta1.Conversations.SearchKnowledge].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.conversation.SearchKnowledgeResponse:
                    The response message for
                [Conversations.SearchKnowledge][google.cloud.dialogflow.v2beta1.Conversations.SearchKnowledge].

            """

            http_options = _BaseConversationsRestTransport._BaseSearchKnowledge._get_http_options()

            request, metadata = self._interceptor.pre_search_knowledge(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseSearchKnowledge._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseSearchKnowledge._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseSearchKnowledge._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.SearchKnowledge",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "SearchKnowledge",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._SearchKnowledge._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = conversation.SearchKnowledgeResponse()
            pb_resp = conversation.SearchKnowledgeResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_search_knowledge(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_search_knowledge_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = conversation.SearchKnowledgeResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.search_knowledge",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "SearchKnowledge",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _StreamingListCallCompanionEvents(_BaseConversationsRestTransport._BaseStreamingListCallCompanionEvents, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.StreamingListCallCompanionEvents")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                stream=True,
                )
            return response

        def __call__(self,
                request: gcd_conversation.StreamingListCallCompanionEventsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> rest_streaming.ResponseIterator:
            r"""Call the streaming list call
        companion events method over HTTP.

            Args:
                request (~.gcd_conversation.StreamingListCallCompanionEventsRequest):
                    The request object. Request message for
                [StreamingListCallCompanionEvents][]. method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.StreamingListCallCompanionEventsResponse:
                    Response message for
                [StreamingListCallCompanionEvents][]. method.

            """

            http_options = _BaseConversationsRestTransport._BaseStreamingListCallCompanionEvents._get_http_options()

            request, metadata = self._interceptor.pre_streaming_list_call_companion_events(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseStreamingListCallCompanionEvents._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseStreamingListCallCompanionEvents._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.StreamingListCallCompanionEvents",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "StreamingListCallCompanionEvents",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._StreamingListCallCompanionEvents._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = rest_streaming.ResponseIterator(response, gcd_conversation.StreamingListCallCompanionEventsResponse)

            resp = self._interceptor.post_streaming_list_call_companion_events(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_streaming_list_call_companion_events_with_metadata(resp, response_metadata)
            return resp

    class _StreamingListUpcomingCallCompanionEvents(_BaseConversationsRestTransport._BaseStreamingListUpcomingCallCompanionEvents, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.StreamingListUpcomingCallCompanionEvents")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                stream=True,
                )
            return response

        def __call__(self,
                request: gcd_conversation.StreamingListUpcomingCallCompanionEventsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> rest_streaming.ResponseIterator:
            r"""Call the streaming list upcoming
        call companion events method over HTTP.

            Args:
                request (~.gcd_conversation.StreamingListUpcomingCallCompanionEventsRequest):
                    The request object. Request message for
                'StreamingListUpcomingCallCompanionEvents'
                method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.StreamingListUpcomingCallCompanionEventsResponse:
                    Response message for
                'StreamingListUpcomingCallCompanionEvents'
                method.

            """

            http_options = _BaseConversationsRestTransport._BaseStreamingListUpcomingCallCompanionEvents._get_http_options()

            request, metadata = self._interceptor.pre_streaming_list_upcoming_call_companion_events(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseStreamingListUpcomingCallCompanionEvents._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseStreamingListUpcomingCallCompanionEvents._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.StreamingListUpcomingCallCompanionEvents",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "StreamingListUpcomingCallCompanionEvents",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._StreamingListUpcomingCallCompanionEvents._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = rest_streaming.ResponseIterator(response, gcd_conversation.StreamingListUpcomingCallCompanionEventsResponse)

            resp = self._interceptor.post_streaming_list_upcoming_call_companion_events(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_streaming_list_upcoming_call_companion_events_with_metadata(resp, response_metadata)
            return resp

    class _SuggestConversationKeyMoments(_BaseConversationsRestTransport._BaseSuggestConversationKeyMoments, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.SuggestConversationKeyMoments")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.SuggestConversationKeyMomentsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.SuggestConversationKeyMomentsResponse:
            r"""Call the suggest conversation key
        moments method over HTTP.

            Args:
                request (~.gcd_conversation.SuggestConversationKeyMomentsRequest):
                    The request object. The request message for
                [Participants.SuggestConversationKeyMoments][].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.SuggestConversationKeyMomentsResponse:
                    The response message for
                [Participants.SuggestConversationKeyMoments][].

            """

            http_options = _BaseConversationsRestTransport._BaseSuggestConversationKeyMoments._get_http_options()

            request, metadata = self._interceptor.pre_suggest_conversation_key_moments(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseSuggestConversationKeyMoments._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseSuggestConversationKeyMoments._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseSuggestConversationKeyMoments._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.SuggestConversationKeyMoments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "SuggestConversationKeyMoments",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._SuggestConversationKeyMoments._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.SuggestConversationKeyMomentsResponse()
            pb_resp = gcd_conversation.SuggestConversationKeyMomentsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_suggest_conversation_key_moments(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_suggest_conversation_key_moments_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.SuggestConversationKeyMomentsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.suggest_conversation_key_moments",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "SuggestConversationKeyMoments",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _SuggestConversationSummary(_BaseConversationsRestTransport._BaseSuggestConversationSummary, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.SuggestConversationSummary")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.SuggestConversationSummaryRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.SuggestConversationSummaryResponse:
            r"""Call the suggest conversation
        summary method over HTTP.

            Args:
                request (~.gcd_conversation.SuggestConversationSummaryRequest):
                    The request object. The request message for
                [Conversations.SuggestConversationSummary][google.cloud.dialogflow.v2beta1.Conversations.SuggestConversationSummary].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.SuggestConversationSummaryResponse:
                    The response message for
                [Conversations.SuggestConversationSummary][google.cloud.dialogflow.v2beta1.Conversations.SuggestConversationSummary].

            """

            http_options = _BaseConversationsRestTransport._BaseSuggestConversationSummary._get_http_options()

            request, metadata = self._interceptor.pre_suggest_conversation_summary(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseSuggestConversationSummary._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseSuggestConversationSummary._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseSuggestConversationSummary._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.SuggestConversationSummary",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "SuggestConversationSummary",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._SuggestConversationSummary._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.SuggestConversationSummaryResponse()
            pb_resp = gcd_conversation.SuggestConversationSummaryResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_suggest_conversation_summary(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_suggest_conversation_summary_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.SuggestConversationSummaryResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.suggest_conversation_summary",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "SuggestConversationSummary",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _UpdateConversation(_BaseConversationsRestTransport._BaseUpdateConversation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.UpdateConversation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: gcd_conversation.UpdateConversationRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> gcd_conversation.Conversation:
            r"""Call the update conversation method over HTTP.

            Args:
                request (~.gcd_conversation.UpdateConversationRequest):
                    The request object. The request message for
                [Conversations.UpdateConversation][google.cloud.dialogflow.v2beta1.Conversations.UpdateConversation].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.gcd_conversation.Conversation:
                    Represents a conversation.
                A conversation is an interaction between
                an agent, including live agents and
                Dialogflow agents, and a support
                customer. Conversations can include
                phone calls and text-based chat
                sessions.

            """

            http_options = _BaseConversationsRestTransport._BaseUpdateConversation._get_http_options()

            request, metadata = self._interceptor.pre_update_conversation(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseUpdateConversation._get_transcoded_request(http_options, request)

            body = _BaseConversationsRestTransport._BaseUpdateConversation._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseUpdateConversation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.UpdateConversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "UpdateConversation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._UpdateConversation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = gcd_conversation.Conversation()
            pb_resp = gcd_conversation.Conversation.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_update_conversation(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_update_conversation_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = gcd_conversation.Conversation.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsClient.update_conversation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "UpdateConversation",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    @property
    def activate_conversation(self) -> Callable[
            [gcd_conversation.ActivateConversationRequest],
            gcd_conversation.Conversation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ActivateConversation(self._session, self._host, self._interceptor) # type: ignore

    @property
    def add_conversation_phone_number(self) -> Callable[
            [conversation.AddConversationPhoneNumberRequest],
            conversation.ConversationPhoneNumber]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._AddConversationPhoneNumber(self._session, self._host, self._interceptor) # type: ignore

    @property
    def batch_create_messages(self) -> Callable[
            [conversation.BatchCreateMessagesRequest],
            conversation.BatchCreateMessagesResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._BatchCreateMessages(self._session, self._host, self._interceptor) # type: ignore

    @property
    def complete_conversation(self) -> Callable[
            [conversation.CompleteConversationRequest],
            conversation.Conversation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CompleteConversation(self._session, self._host, self._interceptor) # type: ignore

    @property
    def create_call_matcher(self) -> Callable[
            [conversation.CreateCallMatcherRequest],
            conversation.CallMatcher]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CreateCallMatcher(self._session, self._host, self._interceptor) # type: ignore

    @property
    def create_conversation(self) -> Callable[
            [gcd_conversation.CreateConversationRequest],
            gcd_conversation.Conversation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CreateConversation(self._session, self._host, self._interceptor) # type: ignore

    @property
    def deactivate_conversation(self) -> Callable[
            [gcd_conversation.DeactivateConversationRequest],
            gcd_conversation.Conversation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._DeactivateConversation(self._session, self._host, self._interceptor) # type: ignore

    @property
    def delete_call_matcher(self) -> Callable[
            [conversation.DeleteCallMatcherRequest],
            empty_pb2.Empty]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._DeleteCallMatcher(self._session, self._host, self._interceptor) # type: ignore

    @property
    def export_messages(self) -> Callable[
            [conversation.ExportMessagesRequest],
            operations_pb2.Operation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ExportMessages(self._session, self._host, self._interceptor) # type: ignore

    @property
    def generate_stateless_suggestion(self) -> Callable[
            [conversation.GenerateStatelessSuggestionRequest],
            conversation.GenerateStatelessSuggestionResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GenerateStatelessSuggestion(self._session, self._host, self._interceptor) # type: ignore

    @property
    def generate_stateless_summary(self) -> Callable[
            [conversation.GenerateStatelessSummaryRequest],
            conversation.GenerateStatelessSummaryResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GenerateStatelessSummary(self._session, self._host, self._interceptor) # type: ignore

    @property
    def generate_suggestions(self) -> Callable[
            [gcd_conversation.GenerateSuggestionsRequest],
            participant.GenerateSuggestionsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GenerateSuggestions(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_call_companion_settings(self) -> Callable[
            [gcd_conversation.GetCallCompanionSettingsRequest],
            gcd_conversation.CallCompanionSettings]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GetCallCompanionSettings(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_conversation(self) -> Callable[
            [conversation.GetConversationRequest],
            conversation.Conversation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GetConversation(self._session, self._host, self._interceptor) # type: ignore

    @property
    def ingest_context_references(self) -> Callable[
            [gcd_conversation.IngestContextReferencesRequest],
            gcd_conversation.IngestContextReferencesResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._IngestContextReferences(self._session, self._host, self._interceptor) # type: ignore

    @property
    def initialize_call_companion(self) -> Callable[
            [gcd_conversation.InitializeCallCompanionRequest],
            empty_pb2.Empty]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._InitializeCallCompanion(self._session, self._host, self._interceptor) # type: ignore

    @property
    def initiate_phone_call(self) -> Callable[
            [gcd_conversation.InitiatePhoneCallRequest],
            gcd_conversation.InitiatePhoneCallResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._InitiatePhoneCall(self._session, self._host, self._interceptor) # type: ignore

    @property
    def inject_call_companion_input(self) -> Callable[
            [gcd_conversation.InjectCallCompanionInputRequest],
            gcd_conversation.InjectCallCompanionInputResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._InjectCallCompanionInput(self._session, self._host, self._interceptor) # type: ignore

    @property
    def inject_call_companion_user_input(self) -> Callable[
            [gcd_conversation.InjectCallCompanionUserInputRequest],
            gcd_conversation.InjectCallCompanionUserInputResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._InjectCallCompanionUserInput(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_call_matchers(self) -> Callable[
            [conversation.ListCallMatchersRequest],
            conversation.ListCallMatchersResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListCallMatchers(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_conversations(self) -> Callable[
            [conversation.ListConversationsRequest],
            conversation.ListConversationsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListConversations(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_messages(self) -> Callable[
            [conversation.ListMessagesRequest],
            conversation.ListMessagesResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListMessages(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_past_call_companion_events(self) -> Callable[
            [gcd_conversation.ListPastCallCompanionEventsRequest],
            gcd_conversation.ListPastCallCompanionEventsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListPastCallCompanionEvents(self._session, self._host, self._interceptor) # type: ignore

    @property
    def search_articles(self) -> Callable[
            [gcd_conversation.SearchArticlesRequest],
            gcd_conversation.SearchArticlesResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._SearchArticles(self._session, self._host, self._interceptor) # type: ignore

    @property
    def search_knowledge(self) -> Callable[
            [conversation.SearchKnowledgeRequest],
            conversation.SearchKnowledgeResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._SearchKnowledge(self._session, self._host, self._interceptor) # type: ignore

    @property
    def streaming_list_call_companion_events(self) -> Callable[
            [gcd_conversation.StreamingListCallCompanionEventsRequest],
            gcd_conversation.StreamingListCallCompanionEventsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._StreamingListCallCompanionEvents(self._session, self._host, self._interceptor) # type: ignore

    @property
    def streaming_list_upcoming_call_companion_events(self) -> Callable[
            [gcd_conversation.StreamingListUpcomingCallCompanionEventsRequest],
            gcd_conversation.StreamingListUpcomingCallCompanionEventsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._StreamingListUpcomingCallCompanionEvents(self._session, self._host, self._interceptor) # type: ignore

    @property
    def suggest_conversation_key_moments(self) -> Callable[
            [gcd_conversation.SuggestConversationKeyMomentsRequest],
            gcd_conversation.SuggestConversationKeyMomentsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._SuggestConversationKeyMoments(self._session, self._host, self._interceptor) # type: ignore

    @property
    def suggest_conversation_summary(self) -> Callable[
            [gcd_conversation.SuggestConversationSummaryRequest],
            gcd_conversation.SuggestConversationSummaryResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._SuggestConversationSummary(self._session, self._host, self._interceptor) # type: ignore

    @property
    def update_conversation(self) -> Callable[
            [gcd_conversation.UpdateConversationRequest],
            gcd_conversation.Conversation]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._UpdateConversation(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_location(self):
        return self._GetLocation(self._session, self._host, self._interceptor) # type: ignore

    class _GetLocation(_BaseConversationsRestTransport._BaseGetLocation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.GetLocation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.GetLocationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.Location:

            r"""Call the get location method over HTTP.

            Args:
                request (locations_pb2.GetLocationRequest):
                    The request object for GetLocation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.Location: Response from GetLocation method.
            """

            http_options = _BaseConversationsRestTransport._BaseGetLocation._get_http_options()

            request, metadata = self._interceptor.pre_get_location(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseGetLocation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseGetLocation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GetLocation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._GetLocation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.Location()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_location(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsAsyncClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GetLocation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_locations(self):
        return self._ListLocations(self._session, self._host, self._interceptor) # type: ignore

    class _ListLocations(_BaseConversationsRestTransport._BaseListLocations, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.ListLocations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.ListLocationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.ListLocationsResponse:

            r"""Call the list locations method over HTTP.

            Args:
                request (locations_pb2.ListLocationsRequest):
                    The request object for ListLocations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.ListLocationsResponse: Response from ListLocations method.
            """

            http_options = _BaseConversationsRestTransport._BaseListLocations._get_http_options()

            request, metadata = self._interceptor.pre_list_locations(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseListLocations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseListLocations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListLocations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._ListLocations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.ListLocationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_locations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsAsyncClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListLocations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def cancel_operation(self):
        return self._CancelOperation(self._session, self._host, self._interceptor) # type: ignore

    class _CancelOperation(_BaseConversationsRestTransport._BaseCancelOperation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.CancelOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.CancelOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> None:

            r"""Call the cancel operation method over HTTP.

            Args:
                request (operations_pb2.CancelOperationRequest):
                    The request object for CancelOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseConversationsRestTransport._BaseCancelOperation._get_http_options()

            request, metadata = self._interceptor.pre_cancel_operation(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseCancelOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseCancelOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.CancelOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "CancelOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._CancelOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            return self._interceptor.post_cancel_operation(None)

    @property
    def get_operation(self):
        return self._GetOperation(self._session, self._host, self._interceptor) # type: ignore

    class _GetOperation(_BaseConversationsRestTransport._BaseGetOperation, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.GetOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.GetOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.Operation:

            r"""Call the get operation method over HTTP.

            Args:
                request (operations_pb2.GetOperationRequest):
                    The request object for GetOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.Operation: Response from GetOperation method.
            """

            http_options = _BaseConversationsRestTransport._BaseGetOperation._get_http_options()

            request, metadata = self._interceptor.pre_get_operation(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseGetOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseGetOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GetOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._GetOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.Operation()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_operation(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsAsyncClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "GetOperation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_operations(self):
        return self._ListOperations(self._session, self._host, self._interceptor) # type: ignore

    class _ListOperations(_BaseConversationsRestTransport._BaseListOperations, ConversationsRestStub):
        def __hash__(self):
            return hash("ConversationsRestTransport.ListOperations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.ListOperationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.ListOperationsResponse:

            r"""Call the list operations method over HTTP.

            Args:
                request (operations_pb2.ListOperationsRequest):
                    The request object for ListOperations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.ListOperationsResponse: Response from ListOperations method.
            """

            http_options = _BaseConversationsRestTransport._BaseListOperations._get_http_options()

            request, metadata = self._interceptor.pre_list_operations(request, metadata)
            transcoded_request = _BaseConversationsRestTransport._BaseListOperations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseConversationsRestTransport._BaseListOperations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.ConversationsClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListOperations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = ConversationsRestTransport._ListOperations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.ListOperationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_operations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.ConversationsAsyncClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.Conversations",
                        "rpcName": "ListOperations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def kind(self) -> str:
        return "rest"

    def close(self):
        self._session.close()


__all__=(
    'ConversationsRestTransport',
)
