# -*- coding: utf-8 -*-
# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#
import logging
import json  # type: ignore

from google.auth.transport.requests import AuthorizedSession  # type: ignore
from google.auth import credentials as ga_credentials  # type: ignore
from google.api_core import exceptions as core_exceptions
from google.api_core import retry as retries
from google.api_core import rest_helpers
from google.api_core import rest_streaming
from google.api_core import gapic_v1
import google.protobuf

from google.protobuf import json_format
from google.cloud.location import locations_pb2 # type: ignore

from requests import __version__ as requests_version
import dataclasses
from typing import Any, Callable, Dict, List, Optional, Sequence, Tuple, Union
import warnings


from google.cloud.dialogflow_v2beta1.types import human_agent_assistant
from google.protobuf import empty_pb2  # type: ignore
from google.longrunning import operations_pb2  # type: ignore


from .rest_base import _BaseHumanAgentAssistantsRestTransport
from .base import DEFAULT_CLIENT_INFO as BASE_DEFAULT_CLIENT_INFO

try:
    OptionalRetry = Union[retries.Retry, gapic_v1.method._MethodDefault, None]
except AttributeError:  # pragma: NO COVER
    OptionalRetry = Union[retries.Retry, object, None]  # type: ignore

try:
    from google.api_core import client_logging  # type: ignore
    CLIENT_LOGGING_SUPPORTED = True  # pragma: NO COVER
except ImportError:  # pragma: NO COVER
    CLIENT_LOGGING_SUPPORTED = False

_LOGGER = logging.getLogger(__name__)

DEFAULT_CLIENT_INFO = gapic_v1.client_info.ClientInfo(
    gapic_version=BASE_DEFAULT_CLIENT_INFO.gapic_version,
    grpc_version=None,
    rest_version=f"requests@{requests_version}",
)

if hasattr(DEFAULT_CLIENT_INFO, "protobuf_runtime_version"):  # pragma: NO COVER
    DEFAULT_CLIENT_INFO.protobuf_runtime_version = google.protobuf.__version__


class HumanAgentAssistantsRestInterceptor:
    """Interceptor for HumanAgentAssistants.

    Interceptors are used to manipulate requests, request metadata, and responses
    in arbitrary ways.
    Example use cases include:
    * Logging
    * Verifying requests according to service or custom semantics
    * Stripping extraneous information from responses

    These use cases and more can be enabled by injecting an
    instance of a custom subclass when constructing the HumanAgentAssistantsRestTransport.

    .. code-block:: python
        class MyCustomHumanAgentAssistantsInterceptor(HumanAgentAssistantsRestInterceptor):
            def pre_compile_suggestions(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_compile_suggestions(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_create_human_agent_assistant(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_create_human_agent_assistant(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_delete_human_agent_assistant(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def pre_get_human_agent_assistant(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_get_human_agent_assistant(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_list_human_agent_assistants(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_list_human_agent_assistants(self, response):
                logging.log(f"Received response: {response}")
                return response

            def pre_update_human_agent_assistant(self, request, metadata):
                logging.log(f"Received request: {request}")
                return request, metadata

            def post_update_human_agent_assistant(self, response):
                logging.log(f"Received response: {response}")
                return response

        transport = HumanAgentAssistantsRestTransport(interceptor=MyCustomHumanAgentAssistantsInterceptor())
        client = HumanAgentAssistantsClient(transport=transport)


    """
    def pre_compile_suggestions(self, request: human_agent_assistant.CompileSuggestionsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.CompileSuggestionsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for compile_suggestions

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_compile_suggestions(self, response: human_agent_assistant.CompileSuggestionsResponse) -> human_agent_assistant.CompileSuggestionsResponse:
        """Post-rpc interceptor for compile_suggestions

        DEPRECATED. Please use the `post_compile_suggestions_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code. This `post_compile_suggestions` interceptor runs
        before the `post_compile_suggestions_with_metadata` interceptor.
        """
        return response

    def post_compile_suggestions_with_metadata(self, response: human_agent_assistant.CompileSuggestionsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.CompileSuggestionsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for compile_suggestions

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the HumanAgentAssistants server but before it is returned to user code.

        We recommend only using this `post_compile_suggestions_with_metadata`
        interceptor in new development instead of the `post_compile_suggestions` interceptor.
        When both interceptors are used, this `post_compile_suggestions_with_metadata` interceptor runs after the
        `post_compile_suggestions` interceptor. The (possibly modified) response returned by
        `post_compile_suggestions` will be passed to
        `post_compile_suggestions_with_metadata`.
        """
        return response, metadata

    def pre_create_human_agent_assistant(self, request: human_agent_assistant.CreateHumanAgentAssistantRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.CreateHumanAgentAssistantRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for create_human_agent_assistant

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_create_human_agent_assistant(self, response: human_agent_assistant.HumanAgentAssistant) -> human_agent_assistant.HumanAgentAssistant:
        """Post-rpc interceptor for create_human_agent_assistant

        DEPRECATED. Please use the `post_create_human_agent_assistant_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code. This `post_create_human_agent_assistant` interceptor runs
        before the `post_create_human_agent_assistant_with_metadata` interceptor.
        """
        return response

    def post_create_human_agent_assistant_with_metadata(self, response: human_agent_assistant.HumanAgentAssistant, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.HumanAgentAssistant, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for create_human_agent_assistant

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the HumanAgentAssistants server but before it is returned to user code.

        We recommend only using this `post_create_human_agent_assistant_with_metadata`
        interceptor in new development instead of the `post_create_human_agent_assistant` interceptor.
        When both interceptors are used, this `post_create_human_agent_assistant_with_metadata` interceptor runs after the
        `post_create_human_agent_assistant` interceptor. The (possibly modified) response returned by
        `post_create_human_agent_assistant` will be passed to
        `post_create_human_agent_assistant_with_metadata`.
        """
        return response, metadata

    def pre_delete_human_agent_assistant(self, request: human_agent_assistant.DeleteHumanAgentAssistantRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.DeleteHumanAgentAssistantRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for delete_human_agent_assistant

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def pre_get_human_agent_assistant(self, request: human_agent_assistant.GetHumanAgentAssistantRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.GetHumanAgentAssistantRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_human_agent_assistant

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_get_human_agent_assistant(self, response: human_agent_assistant.HumanAgentAssistant) -> human_agent_assistant.HumanAgentAssistant:
        """Post-rpc interceptor for get_human_agent_assistant

        DEPRECATED. Please use the `post_get_human_agent_assistant_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code. This `post_get_human_agent_assistant` interceptor runs
        before the `post_get_human_agent_assistant_with_metadata` interceptor.
        """
        return response

    def post_get_human_agent_assistant_with_metadata(self, response: human_agent_assistant.HumanAgentAssistant, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.HumanAgentAssistant, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for get_human_agent_assistant

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the HumanAgentAssistants server but before it is returned to user code.

        We recommend only using this `post_get_human_agent_assistant_with_metadata`
        interceptor in new development instead of the `post_get_human_agent_assistant` interceptor.
        When both interceptors are used, this `post_get_human_agent_assistant_with_metadata` interceptor runs after the
        `post_get_human_agent_assistant` interceptor. The (possibly modified) response returned by
        `post_get_human_agent_assistant` will be passed to
        `post_get_human_agent_assistant_with_metadata`.
        """
        return response, metadata

    def pre_list_human_agent_assistants(self, request: human_agent_assistant.ListHumanAgentAssistantsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.ListHumanAgentAssistantsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_human_agent_assistants

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_list_human_agent_assistants(self, response: human_agent_assistant.ListHumanAgentAssistantsResponse) -> human_agent_assistant.ListHumanAgentAssistantsResponse:
        """Post-rpc interceptor for list_human_agent_assistants

        DEPRECATED. Please use the `post_list_human_agent_assistants_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code. This `post_list_human_agent_assistants` interceptor runs
        before the `post_list_human_agent_assistants_with_metadata` interceptor.
        """
        return response

    def post_list_human_agent_assistants_with_metadata(self, response: human_agent_assistant.ListHumanAgentAssistantsResponse, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.ListHumanAgentAssistantsResponse, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for list_human_agent_assistants

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the HumanAgentAssistants server but before it is returned to user code.

        We recommend only using this `post_list_human_agent_assistants_with_metadata`
        interceptor in new development instead of the `post_list_human_agent_assistants` interceptor.
        When both interceptors are used, this `post_list_human_agent_assistants_with_metadata` interceptor runs after the
        `post_list_human_agent_assistants` interceptor. The (possibly modified) response returned by
        `post_list_human_agent_assistants` will be passed to
        `post_list_human_agent_assistants_with_metadata`.
        """
        return response, metadata

    def pre_update_human_agent_assistant(self, request: human_agent_assistant.UpdateHumanAgentAssistantRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.UpdateHumanAgentAssistantRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for update_human_agent_assistant

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_update_human_agent_assistant(self, response: human_agent_assistant.HumanAgentAssistant) -> human_agent_assistant.HumanAgentAssistant:
        """Post-rpc interceptor for update_human_agent_assistant

        DEPRECATED. Please use the `post_update_human_agent_assistant_with_metadata`
        interceptor instead.

        Override in a subclass to read or manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code. This `post_update_human_agent_assistant` interceptor runs
        before the `post_update_human_agent_assistant_with_metadata` interceptor.
        """
        return response

    def post_update_human_agent_assistant_with_metadata(self, response: human_agent_assistant.HumanAgentAssistant, metadata: Sequence[Tuple[str, Union[str, bytes]]]) -> Tuple[human_agent_assistant.HumanAgentAssistant, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Post-rpc interceptor for update_human_agent_assistant

        Override in a subclass to read or manipulate the response or metadata after it
        is returned by the HumanAgentAssistants server but before it is returned to user code.

        We recommend only using this `post_update_human_agent_assistant_with_metadata`
        interceptor in new development instead of the `post_update_human_agent_assistant` interceptor.
        When both interceptors are used, this `post_update_human_agent_assistant_with_metadata` interceptor runs after the
        `post_update_human_agent_assistant` interceptor. The (possibly modified) response returned by
        `post_update_human_agent_assistant` will be passed to
        `post_update_human_agent_assistant_with_metadata`.
        """
        return response, metadata

    def pre_get_location(
        self, request: locations_pb2.GetLocationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.GetLocationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_location

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_get_location(
        self, response: locations_pb2.Location
    ) -> locations_pb2.Location:
        """Post-rpc interceptor for get_location

        Override in a subclass to manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code.
        """
        return response

    def pre_list_locations(
        self, request: locations_pb2.ListLocationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[locations_pb2.ListLocationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_locations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_list_locations(
        self, response: locations_pb2.ListLocationsResponse
    ) -> locations_pb2.ListLocationsResponse:
        """Post-rpc interceptor for list_locations

        Override in a subclass to manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code.
        """
        return response

    def pre_cancel_operation(
        self, request: operations_pb2.CancelOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.CancelOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_cancel_operation(
        self, response: None
    ) -> None:
        """Post-rpc interceptor for cancel_operation

        Override in a subclass to manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code.
        """
        return response

    def pre_get_operation(
        self, request: operations_pb2.GetOperationRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.GetOperationRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for get_operation

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_get_operation(
        self, response: operations_pb2.Operation
    ) -> operations_pb2.Operation:
        """Post-rpc interceptor for get_operation

        Override in a subclass to manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code.
        """
        return response

    def pre_list_operations(
        self, request: operations_pb2.ListOperationsRequest, metadata: Sequence[Tuple[str, Union[str, bytes]]]
    ) -> Tuple[operations_pb2.ListOperationsRequest, Sequence[Tuple[str, Union[str, bytes]]]]:
        """Pre-rpc interceptor for list_operations

        Override in a subclass to manipulate the request or metadata
        before they are sent to the HumanAgentAssistants server.
        """
        return request, metadata

    def post_list_operations(
        self, response: operations_pb2.ListOperationsResponse
    ) -> operations_pb2.ListOperationsResponse:
        """Post-rpc interceptor for list_operations

        Override in a subclass to manipulate the response
        after it is returned by the HumanAgentAssistants server but before
        it is returned to user code.
        """
        return response


@dataclasses.dataclass
class HumanAgentAssistantsRestStub:
    _session: AuthorizedSession
    _host: str
    _interceptor: HumanAgentAssistantsRestInterceptor


class HumanAgentAssistantsRestTransport(_BaseHumanAgentAssistantsRestTransport):
    """REST backend synchronous transport for HumanAgentAssistants.

    Deprecated: use configs in
    [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
    of
    [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
    Removal Date: 2020-09-01. From 2020-06-08, we will disable
    [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
    After 2020-09-01, all configuration will be migrated into
    [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
    automatically.

    Manages a collection of human agent assistants.

    A human agent assistant provides prompts and information to a live,
    human agent to use with end users. Each human agent participating in
    a conversation can use a different human agent assistant.

    The life cycle of human agent assistant resources is independent of
    the lifecycle of conversations.

    This class defines the same methods as the primary client, so the
    primary client can load the underlying transport implementation
    and call it.

    It sends JSON representations of protocol buffers over HTTP/1.1
    """

    def __init__(self, *,
            host: str = 'dialogflow.googleapis.com',
            credentials: Optional[ga_credentials.Credentials] = None,
            credentials_file: Optional[str] = None,
            scopes: Optional[Sequence[str]] = None,
            client_cert_source_for_mtls: Optional[Callable[[
                ], Tuple[bytes, bytes]]] = None,
            quota_project_id: Optional[str] = None,
            client_info: gapic_v1.client_info.ClientInfo = DEFAULT_CLIENT_INFO,
            always_use_jwt_access: Optional[bool] = False,
            url_scheme: str = 'https',
            interceptor: Optional[HumanAgentAssistantsRestInterceptor] = None,
            api_audience: Optional[str] = None,
            ) -> None:
        """Instantiate the transport.

       NOTE: This REST transport functionality is currently in a beta
       state (preview). We welcome your feedback via a GitHub issue in
       this library's repository. Thank you!

        Args:
            host (Optional[str]):
                 The hostname to connect to (default: 'dialogflow.googleapis.com').
            credentials (Optional[google.auth.credentials.Credentials]): The
                authorization credentials to attach to requests. These
                credentials identify the application to the service; if none
                are specified, the client will attempt to ascertain the
                credentials from the environment.

            credentials_file (Optional[str]): A file with credentials that can
                be loaded with :func:`google.auth.load_credentials_from_file`.
                This argument is ignored if ``channel`` is provided.
            scopes (Optional(Sequence[str])): A list of scopes. This argument is
                ignored if ``channel`` is provided.
            client_cert_source_for_mtls (Callable[[], Tuple[bytes, bytes]]): Client
                certificate to configure mutual TLS HTTP channel. It is ignored
                if ``channel`` is provided.
            quota_project_id (Optional[str]): An optional project to use for billing
                and quota.
            client_info (google.api_core.gapic_v1.client_info.ClientInfo):
                The client info used to send a user-agent string along with
                API requests. If ``None``, then default info will be used.
                Generally, you only need to set this if you are developing
                your own client library.
            always_use_jwt_access (Optional[bool]): Whether self signed JWT should
                be used for service account credentials.
            url_scheme: the protocol scheme for the API endpoint.  Normally
                "https", but for testing or local servers,
                "http" can be specified.
        """
        # Run the base constructor
        # TODO(yon-mg): resolve other ctor params i.e. scopes, quota, etc.
        # TODO: When custom host (api_endpoint) is set, `scopes` must *also* be set on the
        # credentials object
        super().__init__(
            host=host,
            credentials=credentials,
            client_info=client_info,
            always_use_jwt_access=always_use_jwt_access,
            url_scheme=url_scheme,
            api_audience=api_audience
        )
        self._session = AuthorizedSession(
            self._credentials, default_host=self.DEFAULT_HOST)
        if client_cert_source_for_mtls:
            self._session.configure_mtls_channel(client_cert_source_for_mtls)
        self._interceptor = interceptor or HumanAgentAssistantsRestInterceptor()
        self._prep_wrapped_messages(client_info)

    class _CompileSuggestions(_BaseHumanAgentAssistantsRestTransport._BaseCompileSuggestions, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.CompileSuggestions")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: human_agent_assistant.CompileSuggestionsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> human_agent_assistant.CompileSuggestionsResponse:
            r"""Call the compile suggestions method over HTTP.

            Args:
                request (~.human_agent_assistant.CompileSuggestionsRequest):
                    The request object. The request message for
                [HumanAgentAssistants.CompileSuggestions][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CompileSuggestions].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.human_agent_assistant.CompileSuggestionsResponse:
                    The response message for
                [HumanAgentAssistants.CompileSuggestions][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CompileSuggestions]

            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseCompileSuggestions._get_http_options()

            request, metadata = self._interceptor.pre_compile_suggestions(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseCompileSuggestions._get_transcoded_request(http_options, request)

            body = _BaseHumanAgentAssistantsRestTransport._BaseCompileSuggestions._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseCompileSuggestions._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.CompileSuggestions",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "CompileSuggestions",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._CompileSuggestions._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = human_agent_assistant.CompileSuggestionsResponse()
            pb_resp = human_agent_assistant.CompileSuggestionsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_compile_suggestions(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_compile_suggestions_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = human_agent_assistant.CompileSuggestionsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.compile_suggestions",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "CompileSuggestions",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _CreateHumanAgentAssistant(_BaseHumanAgentAssistantsRestTransport._BaseCreateHumanAgentAssistant, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.CreateHumanAgentAssistant")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: human_agent_assistant.CreateHumanAgentAssistantRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> human_agent_assistant.HumanAgentAssistant:
            r"""Call the create human agent
        assistant method over HTTP.

            Args:
                request (~.human_agent_assistant.CreateHumanAgentAssistantRequest):
                    The request object. The request message for
                [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.human_agent_assistant.HumanAgentAssistant:
                    Deprecated: use configs in
                [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
                of
                [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]

                Represents a human agent assistant that provides
                suggestions to help human agents to resolve customer
                issues. This defines the types of content that the human
                agent assistant can present to a human agent.

            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseCreateHumanAgentAssistant._get_http_options()

            request, metadata = self._interceptor.pre_create_human_agent_assistant(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseCreateHumanAgentAssistant._get_transcoded_request(http_options, request)

            body = _BaseHumanAgentAssistantsRestTransport._BaseCreateHumanAgentAssistant._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseCreateHumanAgentAssistant._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.CreateHumanAgentAssistant",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "CreateHumanAgentAssistant",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._CreateHumanAgentAssistant._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = human_agent_assistant.HumanAgentAssistant()
            pb_resp = human_agent_assistant.HumanAgentAssistant.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_create_human_agent_assistant(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_create_human_agent_assistant_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = human_agent_assistant.HumanAgentAssistant.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.create_human_agent_assistant",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "CreateHumanAgentAssistant",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _DeleteHumanAgentAssistant(_BaseHumanAgentAssistantsRestTransport._BaseDeleteHumanAgentAssistant, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.DeleteHumanAgentAssistant")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: human_agent_assistant.DeleteHumanAgentAssistantRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ):
            r"""Call the delete human agent
        assistant method over HTTP.

            Args:
                request (~.human_agent_assistant.DeleteHumanAgentAssistantRequest):
                    The request object. The request message for
                [HumanAgentAssistants.DeleteHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.DeleteHumanAgentAssistant].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseDeleteHumanAgentAssistant._get_http_options()

            request, metadata = self._interceptor.pre_delete_human_agent_assistant(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseDeleteHumanAgentAssistant._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseDeleteHumanAgentAssistant._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.DeleteHumanAgentAssistant",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "DeleteHumanAgentAssistant",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._DeleteHumanAgentAssistant._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

    class _GetHumanAgentAssistant(_BaseHumanAgentAssistantsRestTransport._BaseGetHumanAgentAssistant, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.GetHumanAgentAssistant")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: human_agent_assistant.GetHumanAgentAssistantRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> human_agent_assistant.HumanAgentAssistant:
            r"""Call the get human agent assistant method over HTTP.

            Args:
                request (~.human_agent_assistant.GetHumanAgentAssistantRequest):
                    The request object. The request message for
                [HumanAgentAssistants.GetHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.GetHumanAgentAssistant].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.human_agent_assistant.HumanAgentAssistant:
                    Deprecated: use configs in
                [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
                of
                [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]

                Represents a human agent assistant that provides
                suggestions to help human agents to resolve customer
                issues. This defines the types of content that the human
                agent assistant can present to a human agent.

            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseGetHumanAgentAssistant._get_http_options()

            request, metadata = self._interceptor.pre_get_human_agent_assistant(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseGetHumanAgentAssistant._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseGetHumanAgentAssistant._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.GetHumanAgentAssistant",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "GetHumanAgentAssistant",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._GetHumanAgentAssistant._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = human_agent_assistant.HumanAgentAssistant()
            pb_resp = human_agent_assistant.HumanAgentAssistant.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_get_human_agent_assistant(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_get_human_agent_assistant_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = human_agent_assistant.HumanAgentAssistant.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.get_human_agent_assistant",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "GetHumanAgentAssistant",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _ListHumanAgentAssistants(_BaseHumanAgentAssistantsRestTransport._BaseListHumanAgentAssistants, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.ListHumanAgentAssistants")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
                request: human_agent_assistant.ListHumanAgentAssistantsRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> human_agent_assistant.ListHumanAgentAssistantsResponse:
            r"""Call the list human agent
        assistants method over HTTP.

            Args:
                request (~.human_agent_assistant.ListHumanAgentAssistantsRequest):
                    The request object. The request message for
                [HumanAgentAssistants.ListHumanAgentAssistants][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.ListHumanAgentAssistants].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.human_agent_assistant.ListHumanAgentAssistantsResponse:
                    The response message for
                [HumanAgentAssistants.ListHumanAgentAssistants][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.ListHumanAgentAssistants].

            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseListHumanAgentAssistants._get_http_options()

            request, metadata = self._interceptor.pre_list_human_agent_assistants(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseListHumanAgentAssistants._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseListHumanAgentAssistants._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.ListHumanAgentAssistants",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "ListHumanAgentAssistants",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._ListHumanAgentAssistants._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = human_agent_assistant.ListHumanAgentAssistantsResponse()
            pb_resp = human_agent_assistant.ListHumanAgentAssistantsResponse.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_list_human_agent_assistants(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_list_human_agent_assistants_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = human_agent_assistant.ListHumanAgentAssistantsResponse.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.list_human_agent_assistants",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "ListHumanAgentAssistants",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    class _UpdateHumanAgentAssistant(_BaseHumanAgentAssistantsRestTransport._BaseUpdateHumanAgentAssistant, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.UpdateHumanAgentAssistant")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                data=body,
                )
            return response

        def __call__(self,
                request: human_agent_assistant.UpdateHumanAgentAssistantRequest, *,
                retry: OptionalRetry=gapic_v1.method.DEFAULT,
                timeout: Optional[float]=None,
                metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
                ) -> human_agent_assistant.HumanAgentAssistant:
            r"""Call the update human agent
        assistant method over HTTP.

            Args:
                request (~.human_agent_assistant.UpdateHumanAgentAssistantRequest):
                    The request object. The request message for
                [HumanAgentAssistants.UpdateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.UpdateHumanAgentAssistant].
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                ~.human_agent_assistant.HumanAgentAssistant:
                    Deprecated: use configs in
                [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
                of
                [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]

                Represents a human agent assistant that provides
                suggestions to help human agents to resolve customer
                issues. This defines the types of content that the human
                agent assistant can present to a human agent.

            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseUpdateHumanAgentAssistant._get_http_options()

            request, metadata = self._interceptor.pre_update_human_agent_assistant(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseUpdateHumanAgentAssistant._get_transcoded_request(http_options, request)

            body = _BaseHumanAgentAssistantsRestTransport._BaseUpdateHumanAgentAssistant._get_request_body_json(transcoded_request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseUpdateHumanAgentAssistant._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = type(request).to_json(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.UpdateHumanAgentAssistant",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "UpdateHumanAgentAssistant",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._UpdateHumanAgentAssistant._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request, body)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            # Return the response
            resp = human_agent_assistant.HumanAgentAssistant()
            pb_resp = human_agent_assistant.HumanAgentAssistant.pb(resp)

            json_format.Parse(response.content, pb_resp, ignore_unknown_fields=True)

            resp = self._interceptor.post_update_human_agent_assistant(resp)
            response_metadata = [(k, str(v)) for k, v in response.headers.items()]
            resp, _ = self._interceptor.post_update_human_agent_assistant_with_metadata(resp, response_metadata)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = human_agent_assistant.HumanAgentAssistant.to_json(response)
                except:
                    response_payload = None
                http_response = {
                "payload": response_payload,
                "headers":  dict(response.headers),
                "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.update_human_agent_assistant",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "UpdateHumanAgentAssistant",
                        "metadata": http_response["headers"],
                        "httpResponse": http_response,
                    },
                )
            return resp

    @property
    def compile_suggestions(self) -> Callable[
            [human_agent_assistant.CompileSuggestionsRequest],
            human_agent_assistant.CompileSuggestionsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CompileSuggestions(self._session, self._host, self._interceptor) # type: ignore

    @property
    def create_human_agent_assistant(self) -> Callable[
            [human_agent_assistant.CreateHumanAgentAssistantRequest],
            human_agent_assistant.HumanAgentAssistant]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._CreateHumanAgentAssistant(self._session, self._host, self._interceptor) # type: ignore

    @property
    def delete_human_agent_assistant(self) -> Callable[
            [human_agent_assistant.DeleteHumanAgentAssistantRequest],
            empty_pb2.Empty]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._DeleteHumanAgentAssistant(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_human_agent_assistant(self) -> Callable[
            [human_agent_assistant.GetHumanAgentAssistantRequest],
            human_agent_assistant.HumanAgentAssistant]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._GetHumanAgentAssistant(self._session, self._host, self._interceptor) # type: ignore

    @property
    def list_human_agent_assistants(self) -> Callable[
            [human_agent_assistant.ListHumanAgentAssistantsRequest],
            human_agent_assistant.ListHumanAgentAssistantsResponse]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._ListHumanAgentAssistants(self._session, self._host, self._interceptor) # type: ignore

    @property
    def update_human_agent_assistant(self) -> Callable[
            [human_agent_assistant.UpdateHumanAgentAssistantRequest],
            human_agent_assistant.HumanAgentAssistant]:
        # The return type is fine, but mypy isn't sophisticated enough to determine what's going on here.
        # In C++ this would require a dynamic_cast
        return self._UpdateHumanAgentAssistant(self._session, self._host, self._interceptor) # type: ignore

    @property
    def get_location(self):
        return self._GetLocation(self._session, self._host, self._interceptor) # type: ignore

    class _GetLocation(_BaseHumanAgentAssistantsRestTransport._BaseGetLocation, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.GetLocation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.GetLocationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.Location:

            r"""Call the get location method over HTTP.

            Args:
                request (locations_pb2.GetLocationRequest):
                    The request object for GetLocation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.Location: Response from GetLocation method.
            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseGetLocation._get_http_options()

            request, metadata = self._interceptor.pre_get_location(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseGetLocation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseGetLocation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "GetLocation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._GetLocation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.Location()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_location(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsAsyncClient.GetLocation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "GetLocation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_locations(self):
        return self._ListLocations(self._session, self._host, self._interceptor) # type: ignore

    class _ListLocations(_BaseHumanAgentAssistantsRestTransport._BaseListLocations, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.ListLocations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: locations_pb2.ListLocationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> locations_pb2.ListLocationsResponse:

            r"""Call the list locations method over HTTP.

            Args:
                request (locations_pb2.ListLocationsRequest):
                    The request object for ListLocations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                locations_pb2.ListLocationsResponse: Response from ListLocations method.
            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseListLocations._get_http_options()

            request, metadata = self._interceptor.pre_list_locations(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseListLocations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseListLocations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "ListLocations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._ListLocations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = locations_pb2.ListLocationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_locations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsAsyncClient.ListLocations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "ListLocations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def cancel_operation(self):
        return self._CancelOperation(self._session, self._host, self._interceptor) # type: ignore

    class _CancelOperation(_BaseHumanAgentAssistantsRestTransport._BaseCancelOperation, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.CancelOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.CancelOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> None:

            r"""Call the cancel operation method over HTTP.

            Args:
                request (operations_pb2.CancelOperationRequest):
                    The request object for CancelOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.
            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseCancelOperation._get_http_options()

            request, metadata = self._interceptor.pre_cancel_operation(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseCancelOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseCancelOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.CancelOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "CancelOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._CancelOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            return self._interceptor.post_cancel_operation(None)

    @property
    def get_operation(self):
        return self._GetOperation(self._session, self._host, self._interceptor) # type: ignore

    class _GetOperation(_BaseHumanAgentAssistantsRestTransport._BaseGetOperation, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.GetOperation")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.GetOperationRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.Operation:

            r"""Call the get operation method over HTTP.

            Args:
                request (operations_pb2.GetOperationRequest):
                    The request object for GetOperation method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.Operation: Response from GetOperation method.
            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseGetOperation._get_http_options()

            request, metadata = self._interceptor.pre_get_operation(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseGetOperation._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseGetOperation._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "GetOperation",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._GetOperation._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.Operation()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_get_operation(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsAsyncClient.GetOperation",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "GetOperation",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def list_operations(self):
        return self._ListOperations(self._session, self._host, self._interceptor) # type: ignore

    class _ListOperations(_BaseHumanAgentAssistantsRestTransport._BaseListOperations, HumanAgentAssistantsRestStub):
        def __hash__(self):
            return hash("HumanAgentAssistantsRestTransport.ListOperations")

        @staticmethod
        def _get_response(
            host,
            metadata,
            query_params,
            session,
            timeout,
            transcoded_request,
            body=None):

            uri = transcoded_request['uri']
            method = transcoded_request['method']
            headers = dict(metadata)
            headers['Content-Type'] = 'application/json'
            response = getattr(session, method)(
                "{host}{uri}".format(host=host, uri=uri),
                timeout=timeout,
                headers=headers,
                params=rest_helpers.flatten_query_params(query_params, strict=True),
                )
            return response

        def __call__(self,
            request: operations_pb2.ListOperationsRequest, *,
            retry: OptionalRetry=gapic_v1.method.DEFAULT,
            timeout: Optional[float]=None,
            metadata: Sequence[Tuple[str, Union[str, bytes]]]=(),
            ) -> operations_pb2.ListOperationsResponse:

            r"""Call the list operations method over HTTP.

            Args:
                request (operations_pb2.ListOperationsRequest):
                    The request object for ListOperations method.
                retry (google.api_core.retry.Retry): Designation of what errors, if any,
                    should be retried.
                timeout (float): The timeout for this request.
                metadata (Sequence[Tuple[str, Union[str, bytes]]]): Key/value pairs which should be
                    sent along with the request as metadata. Normally, each value must be of type `str`,
                    but for metadata keys ending with the suffix `-bin`, the corresponding values must
                    be of type `bytes`.

            Returns:
                operations_pb2.ListOperationsResponse: Response from ListOperations method.
            """

            http_options = _BaseHumanAgentAssistantsRestTransport._BaseListOperations._get_http_options()

            request, metadata = self._interceptor.pre_list_operations(request, metadata)
            transcoded_request = _BaseHumanAgentAssistantsRestTransport._BaseListOperations._get_transcoded_request(http_options, request)

            # Jsonify the query params
            query_params = _BaseHumanAgentAssistantsRestTransport._BaseListOperations._get_query_params_json(transcoded_request)

            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                request_url = "{host}{uri}".format(host=self._host, uri=transcoded_request['uri'])
                method = transcoded_request['method']
                try:
                    request_payload = json_format.MessageToJson(request)
                except:
                    request_payload = None
                http_request = {
                  "payload": request_payload,
                  "requestMethod": method,
                  "requestUrl": request_url,
                  "headers": dict(metadata),
                }
                _LOGGER.debug(
                    f"Sending request for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "ListOperations",
                        "httpRequest": http_request,
                        "metadata": http_request["headers"],
                    },
                )

            # Send the request
            response = HumanAgentAssistantsRestTransport._ListOperations._get_response(self._host, metadata, query_params, self._session, timeout, transcoded_request)

            # In case of error, raise the appropriate core_exceptions.GoogleAPICallError exception
            # subclass.
            if response.status_code >= 400:
                raise core_exceptions.from_http_response(response)

            content = response.content.decode("utf-8")
            resp = operations_pb2.ListOperationsResponse()
            resp = json_format.Parse(content, resp)
            resp = self._interceptor.post_list_operations(resp)
            if CLIENT_LOGGING_SUPPORTED and _LOGGER.isEnabledFor(logging.DEBUG):  # pragma: NO COVER
                try:
                    response_payload = json_format.MessageToJson(resp)
                except:
                    response_payload = None
                http_response = {
                    "payload": response_payload,
                    "headers":  dict(response.headers),
                    "status": response.status_code,
                }
                _LOGGER.debug(
                    "Received response for google.cloud.dialogflow_v2beta1.HumanAgentAssistantsAsyncClient.ListOperations",
                    extra = {
                        "serviceName": "google.cloud.dialogflow.v2beta1.HumanAgentAssistants",
                        "rpcName": "ListOperations",
                        "httpResponse": http_response,
                        "metadata": http_response["headers"],
                    },
                )
            return resp

    @property
    def kind(self) -> str:
        return "rest"

    def close(self):
        self._session.close()


__all__=(
    'HumanAgentAssistantsRestTransport',
)
