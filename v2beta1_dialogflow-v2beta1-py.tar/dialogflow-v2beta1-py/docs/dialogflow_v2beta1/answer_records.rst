AnswerRecords
-------------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.answer_records
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.answer_records.pagers
    :members:
    :inherited-members:
