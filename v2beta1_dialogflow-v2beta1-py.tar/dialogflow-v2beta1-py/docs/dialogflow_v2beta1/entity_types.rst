EntityTypes
-----------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.entity_types
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.entity_types.pagers
    :members:
    :inherited-members:
