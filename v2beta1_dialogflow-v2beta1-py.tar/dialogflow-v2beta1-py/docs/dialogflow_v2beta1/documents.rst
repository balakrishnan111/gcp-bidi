Documents
---------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.documents
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.documents.pagers
    :members:
    :inherited-members:
