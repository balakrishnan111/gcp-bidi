HumanAgentAssistants
--------------------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.human_agent_assistants
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.human_agent_assistants.pagers
    :members:
    :inherited-members:
