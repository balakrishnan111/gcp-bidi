Versions
--------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.versions
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.versions.pagers
    :members:
    :inherited-members:
