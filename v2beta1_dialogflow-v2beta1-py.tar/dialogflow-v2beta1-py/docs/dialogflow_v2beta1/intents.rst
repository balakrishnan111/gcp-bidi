Intents
-------------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.intents
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.intents.pagers
    :members:
    :inherited-members:
