Tools
-----------------------

.. automodule:: google.cloud.dialogflow_v2beta1.services.tools
    :members:
    :inherited-members:

.. automodule:: google.cloud.dialogflow_v2beta1.services.tools.pagers
    :members:
    :inherited-members:
