package com.google.cloud.dialogflow.v3alpha1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * User settings include user metadata (e.g, recently-viewed projects) and
 * project-scoped settings (e.g, recent search terms, saved filters).
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler",
    comments = "Source: google/cloud/dialogflow/v3alpha1/user_setting.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class UserSettingsGrpc {

  private UserSettingsGrpc() {}

  public static final java.lang.String SERVICE_NAME = "google.cloud.dialogflow.v3alpha1.UserSettings";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest,
      com.google.cloud.dialogflow.v3alpha1.RecentProjects> getGetRecentProjectsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetRecentProjects",
      requestType = com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest.class,
      responseType = com.google.cloud.dialogflow.v3alpha1.RecentProjects.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest,
      com.google.cloud.dialogflow.v3alpha1.RecentProjects> getGetRecentProjectsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest, com.google.cloud.dialogflow.v3alpha1.RecentProjects> getGetRecentProjectsMethod;
    if ((getGetRecentProjectsMethod = UserSettingsGrpc.getGetRecentProjectsMethod) == null) {
      synchronized (UserSettingsGrpc.class) {
        if ((getGetRecentProjectsMethod = UserSettingsGrpc.getGetRecentProjectsMethod) == null) {
          UserSettingsGrpc.getGetRecentProjectsMethod = getGetRecentProjectsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest, com.google.cloud.dialogflow.v3alpha1.RecentProjects>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetRecentProjects"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v3alpha1.RecentProjects.getDefaultInstance()))
              .setSchemaDescriptor(new UserSettingsMethodDescriptorSupplier("GetRecentProjects"))
              .build();
        }
      }
    }
    return getGetRecentProjectsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest,
      com.google.cloud.dialogflow.v3alpha1.RecentProjects> getUpdateRecentProjectsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateRecentProjects",
      requestType = com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest.class,
      responseType = com.google.cloud.dialogflow.v3alpha1.RecentProjects.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest,
      com.google.cloud.dialogflow.v3alpha1.RecentProjects> getUpdateRecentProjectsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest, com.google.cloud.dialogflow.v3alpha1.RecentProjects> getUpdateRecentProjectsMethod;
    if ((getUpdateRecentProjectsMethod = UserSettingsGrpc.getUpdateRecentProjectsMethod) == null) {
      synchronized (UserSettingsGrpc.class) {
        if ((getUpdateRecentProjectsMethod = UserSettingsGrpc.getUpdateRecentProjectsMethod) == null) {
          UserSettingsGrpc.getUpdateRecentProjectsMethod = getUpdateRecentProjectsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest, com.google.cloud.dialogflow.v3alpha1.RecentProjects>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateRecentProjects"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v3alpha1.RecentProjects.getDefaultInstance()))
              .setSchemaDescriptor(new UserSettingsMethodDescriptorSupplier("UpdateRecentProjects"))
              .build();
        }
      }
    }
    return getUpdateRecentProjectsMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static UserSettingsStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<UserSettingsStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<UserSettingsStub>() {
        @java.lang.Override
        public UserSettingsStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new UserSettingsStub(channel, callOptions);
        }
      };
    return UserSettingsStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static UserSettingsBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<UserSettingsBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<UserSettingsBlockingV2Stub>() {
        @java.lang.Override
        public UserSettingsBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new UserSettingsBlockingV2Stub(channel, callOptions);
        }
      };
    return UserSettingsBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static UserSettingsBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<UserSettingsBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<UserSettingsBlockingStub>() {
        @java.lang.Override
        public UserSettingsBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new UserSettingsBlockingStub(channel, callOptions);
        }
      };
    return UserSettingsBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static UserSettingsFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<UserSettingsFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<UserSettingsFutureStub>() {
        @java.lang.Override
        public UserSettingsFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new UserSettingsFutureStub(channel, callOptions);
        }
      };
    return UserSettingsFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * User settings include user metadata (e.g, recently-viewed projects) and
   * project-scoped settings (e.g, recent search terms, saved filters).
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Get list of recent-viewed projects.
     * </pre>
     */
    default void getRecentProjects(com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v3alpha1.RecentProjects> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetRecentProjectsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Update recent-viewed projects.
     * </pre>
     */
    default void updateRecentProjects(com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v3alpha1.RecentProjects> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateRecentProjectsMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service UserSettings.
   * <pre>
   * User settings include user metadata (e.g, recently-viewed projects) and
   * project-scoped settings (e.g, recent search terms, saved filters).
   * </pre>
   */
  public static abstract class UserSettingsImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return UserSettingsGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service UserSettings.
   * <pre>
   * User settings include user metadata (e.g, recently-viewed projects) and
   * project-scoped settings (e.g, recent search terms, saved filters).
   * </pre>
   */
  public static final class UserSettingsStub
      extends io.grpc.stub.AbstractAsyncStub<UserSettingsStub> {
    private UserSettingsStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserSettingsStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new UserSettingsStub(channel, callOptions);
    }

    /**
     * <pre>
     * Get list of recent-viewed projects.
     * </pre>
     */
    public void getRecentProjects(com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v3alpha1.RecentProjects> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetRecentProjectsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Update recent-viewed projects.
     * </pre>
     */
    public void updateRecentProjects(com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v3alpha1.RecentProjects> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateRecentProjectsMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service UserSettings.
   * <pre>
   * User settings include user metadata (e.g, recently-viewed projects) and
   * project-scoped settings (e.g, recent search terms, saved filters).
   * </pre>
   */
  public static final class UserSettingsBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<UserSettingsBlockingV2Stub> {
    private UserSettingsBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserSettingsBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new UserSettingsBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Get list of recent-viewed projects.
     * </pre>
     */
    public com.google.cloud.dialogflow.v3alpha1.RecentProjects getRecentProjects(com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetRecentProjectsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Update recent-viewed projects.
     * </pre>
     */
    public com.google.cloud.dialogflow.v3alpha1.RecentProjects updateRecentProjects(com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateRecentProjectsMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service UserSettings.
   * <pre>
   * User settings include user metadata (e.g, recently-viewed projects) and
   * project-scoped settings (e.g, recent search terms, saved filters).
   * </pre>
   */
  public static final class UserSettingsBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<UserSettingsBlockingStub> {
    private UserSettingsBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserSettingsBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new UserSettingsBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Get list of recent-viewed projects.
     * </pre>
     */
    public com.google.cloud.dialogflow.v3alpha1.RecentProjects getRecentProjects(com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetRecentProjectsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Update recent-viewed projects.
     * </pre>
     */
    public com.google.cloud.dialogflow.v3alpha1.RecentProjects updateRecentProjects(com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateRecentProjectsMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service UserSettings.
   * <pre>
   * User settings include user metadata (e.g, recently-viewed projects) and
   * project-scoped settings (e.g, recent search terms, saved filters).
   * </pre>
   */
  public static final class UserSettingsFutureStub
      extends io.grpc.stub.AbstractFutureStub<UserSettingsFutureStub> {
    private UserSettingsFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected UserSettingsFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new UserSettingsFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Get list of recent-viewed projects.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v3alpha1.RecentProjects> getRecentProjects(
        com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetRecentProjectsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Update recent-viewed projects.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v3alpha1.RecentProjects> updateRecentProjects(
        com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateRecentProjectsMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_GET_RECENT_PROJECTS = 0;
  private static final int METHODID_UPDATE_RECENT_PROJECTS = 1;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_GET_RECENT_PROJECTS:
          serviceImpl.getRecentProjects((com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v3alpha1.RecentProjects>) responseObserver);
          break;
        case METHODID_UPDATE_RECENT_PROJECTS:
          serviceImpl.updateRecentProjects((com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v3alpha1.RecentProjects>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getGetRecentProjectsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v3alpha1.GetRecentProjectsRequest,
              com.google.cloud.dialogflow.v3alpha1.RecentProjects>(
                service, METHODID_GET_RECENT_PROJECTS)))
        .addMethod(
          getUpdateRecentProjectsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v3alpha1.UpdateRecentProjectsRequest,
              com.google.cloud.dialogflow.v3alpha1.RecentProjects>(
                service, METHODID_UPDATE_RECENT_PROJECTS)))
        .build();
  }

  private static abstract class UserSettingsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    UserSettingsBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.google.cloud.dialogflow.v3alpha1.UserSettingProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("UserSettings");
    }
  }

  private static final class UserSettingsFileDescriptorSupplier
      extends UserSettingsBaseDescriptorSupplier {
    UserSettingsFileDescriptorSupplier() {}
  }

  private static final class UserSettingsMethodDescriptorSupplier
      extends UserSettingsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    UserSettingsMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (UserSettingsGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new UserSettingsFileDescriptorSupplier())
              .addMethod(getGetRecentProjectsMethod())
              .addMethod(getUpdateRecentProjectsMethod())
              .build();
        }
      }
    }
    return result;
  }
}
