// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Generated code. DO NOT EDIT!

namespace GoogleCSharpSnippets
{
    using Google.Api.Gax;
    using Google.Cloud.Dialogflow.V2Beta1;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>Generated snippets.</summary>
    [ObsoleteAttribute]
    public sealed class AllGeneratedHumanAgentAssistantsClientSnippets
    {
        /// <summary>Snippet for ListHumanAgentAssistants</summary>
        public void ListHumanAgentAssistantsRequestObject()
        {
            // Snippet: ListHumanAgentAssistants(ListHumanAgentAssistantsRequest, CallSettings)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = HumanAgentAssistantsClient.Create();
            // Initialize request argument(s)
#pragma warning disable CS0612
            ListHumanAgentAssistantsRequest request = new ListHumanAgentAssistantsRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            PagedEnumerable<ListHumanAgentAssistantsResponse, HumanAgentAssistant> response = humanAgentAssistantsClient.ListHumanAgentAssistants(request);
#pragma warning restore CS0612

            // Iterate over all response items, lazily performing RPCs as required
#pragma warning disable CS0612
            foreach (HumanAgentAssistant item in response)
#pragma warning restore CS0612
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
#pragma warning disable CS0612
            foreach (ListHumanAgentAssistantsResponse page in response.AsRawResponses())
#pragma warning restore CS0612
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
#pragma warning disable CS0612
                foreach (HumanAgentAssistant item in page)
#pragma warning restore CS0612
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
#pragma warning disable CS0612
            Page<HumanAgentAssistant> singlePage = response.ReadPage(pageSize);
#pragma warning restore CS0612
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
#pragma warning disable CS0612
            foreach (HumanAgentAssistant item in singlePage)
#pragma warning restore CS0612
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListHumanAgentAssistantsAsync</summary>
        public async Task ListHumanAgentAssistantsRequestObjectAsync()
        {
            // Snippet: ListHumanAgentAssistantsAsync(ListHumanAgentAssistantsRequest, CallSettings)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = await HumanAgentAssistantsClient.CreateAsync();
            // Initialize request argument(s)
#pragma warning disable CS0612
            ListHumanAgentAssistantsRequest request = new ListHumanAgentAssistantsRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            PagedAsyncEnumerable<ListHumanAgentAssistantsResponse, HumanAgentAssistant> response = humanAgentAssistantsClient.ListHumanAgentAssistantsAsync(request);
#pragma warning restore CS0612

            // Iterate over all response items, lazily performing RPCs as required
#pragma warning disable CS0612
            await response.ForEachAsync((HumanAgentAssistant item) =>
#pragma warning restore CS0612
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
#pragma warning disable CS0612
            await response.AsRawResponses().ForEachAsync((ListHumanAgentAssistantsResponse page) =>
#pragma warning restore CS0612
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
#pragma warning disable CS0612
                foreach (HumanAgentAssistant item in page)
#pragma warning restore CS0612
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
#pragma warning disable CS0612
            Page<HumanAgentAssistant> singlePage = await response.ReadPageAsync(pageSize);
#pragma warning restore CS0612
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
#pragma warning disable CS0612
            foreach (HumanAgentAssistant item in singlePage)
#pragma warning restore CS0612
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for GetHumanAgentAssistant</summary>
        public void GetHumanAgentAssistantRequestObject()
        {
            // Snippet: GetHumanAgentAssistant(GetHumanAgentAssistantRequest, CallSettings)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = HumanAgentAssistantsClient.Create();
            // Initialize request argument(s)
#pragma warning disable CS0612
            GetHumanAgentAssistantRequest request = new GetHumanAgentAssistantRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            HumanAgentAssistant response = humanAgentAssistantsClient.GetHumanAgentAssistant(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for GetHumanAgentAssistantAsync</summary>
        public async Task GetHumanAgentAssistantRequestObjectAsync()
        {
            // Snippet: GetHumanAgentAssistantAsync(GetHumanAgentAssistantRequest, CallSettings)
            // Additional: GetHumanAgentAssistantAsync(GetHumanAgentAssistantRequest, CancellationToken)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = await HumanAgentAssistantsClient.CreateAsync();
            // Initialize request argument(s)
#pragma warning disable CS0612
            GetHumanAgentAssistantRequest request = new GetHumanAgentAssistantRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            HumanAgentAssistant response = await humanAgentAssistantsClient.GetHumanAgentAssistantAsync(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for CreateHumanAgentAssistant</summary>
        public void CreateHumanAgentAssistantRequestObject()
        {
            // Snippet: CreateHumanAgentAssistant(CreateHumanAgentAssistantRequest, CallSettings)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = HumanAgentAssistantsClient.Create();
            // Initialize request argument(s)
#pragma warning disable CS0612
            CreateHumanAgentAssistantRequest request = new CreateHumanAgentAssistantRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            HumanAgentAssistant response = humanAgentAssistantsClient.CreateHumanAgentAssistant(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for CreateHumanAgentAssistantAsync</summary>
        public async Task CreateHumanAgentAssistantRequestObjectAsync()
        {
            // Snippet: CreateHumanAgentAssistantAsync(CreateHumanAgentAssistantRequest, CallSettings)
            // Additional: CreateHumanAgentAssistantAsync(CreateHumanAgentAssistantRequest, CancellationToken)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = await HumanAgentAssistantsClient.CreateAsync();
            // Initialize request argument(s)
#pragma warning disable CS0612
            CreateHumanAgentAssistantRequest request = new CreateHumanAgentAssistantRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            HumanAgentAssistant response = await humanAgentAssistantsClient.CreateHumanAgentAssistantAsync(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for UpdateHumanAgentAssistant</summary>
        public void UpdateHumanAgentAssistantRequestObject()
        {
            // Snippet: UpdateHumanAgentAssistant(UpdateHumanAgentAssistantRequest, CallSettings)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = HumanAgentAssistantsClient.Create();
            // Initialize request argument(s)
#pragma warning disable CS0612
            UpdateHumanAgentAssistantRequest request = new UpdateHumanAgentAssistantRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            HumanAgentAssistant response = humanAgentAssistantsClient.UpdateHumanAgentAssistant(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for UpdateHumanAgentAssistantAsync</summary>
        public async Task UpdateHumanAgentAssistantRequestObjectAsync()
        {
            // Snippet: UpdateHumanAgentAssistantAsync(UpdateHumanAgentAssistantRequest, CallSettings)
            // Additional: UpdateHumanAgentAssistantAsync(UpdateHumanAgentAssistantRequest, CancellationToken)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = await HumanAgentAssistantsClient.CreateAsync();
            // Initialize request argument(s)
#pragma warning disable CS0612
            UpdateHumanAgentAssistantRequest request = new UpdateHumanAgentAssistantRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            HumanAgentAssistant response = await humanAgentAssistantsClient.UpdateHumanAgentAssistantAsync(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for DeleteHumanAgentAssistant</summary>
        public void DeleteHumanAgentAssistantRequestObject()
        {
            // Snippet: DeleteHumanAgentAssistant(DeleteHumanAgentAssistantRequest, CallSettings)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = HumanAgentAssistantsClient.Create();
            // Initialize request argument(s)
#pragma warning disable CS0612
            DeleteHumanAgentAssistantRequest request = new DeleteHumanAgentAssistantRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            humanAgentAssistantsClient.DeleteHumanAgentAssistant(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for DeleteHumanAgentAssistantAsync</summary>
        public async Task DeleteHumanAgentAssistantRequestObjectAsync()
        {
            // Snippet: DeleteHumanAgentAssistantAsync(DeleteHumanAgentAssistantRequest, CallSettings)
            // Additional: DeleteHumanAgentAssistantAsync(DeleteHumanAgentAssistantRequest, CancellationToken)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = await HumanAgentAssistantsClient.CreateAsync();
            // Initialize request argument(s)
#pragma warning disable CS0612
            DeleteHumanAgentAssistantRequest request = new DeleteHumanAgentAssistantRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            await humanAgentAssistantsClient.DeleteHumanAgentAssistantAsync(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for CompileSuggestions</summary>
        public void CompileSuggestionsRequestObject()
        {
            // Snippet: CompileSuggestions(CompileSuggestionsRequest, CallSettings)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = HumanAgentAssistantsClient.Create();
            // Initialize request argument(s)
#pragma warning disable CS0612
            CompileSuggestionsRequest request = new CompileSuggestionsRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            CompileSuggestionsResponse response = humanAgentAssistantsClient.CompileSuggestions(request);
#pragma warning restore CS0612
            // End snippet
        }

        /// <summary>Snippet for CompileSuggestionsAsync</summary>
        public async Task CompileSuggestionsRequestObjectAsync()
        {
            // Snippet: CompileSuggestionsAsync(CompileSuggestionsRequest, CallSettings)
            // Additional: CompileSuggestionsAsync(CompileSuggestionsRequest, CancellationToken)
            // Create client
            HumanAgentAssistantsClient humanAgentAssistantsClient = await HumanAgentAssistantsClient.CreateAsync();
            // Initialize request argument(s)
#pragma warning disable CS0612
            CompileSuggestionsRequest request = new CompileSuggestionsRequest { };
#pragma warning restore CS0612
            // Make the request
#pragma warning disable CS0612
            CompileSuggestionsResponse response = await humanAgentAssistantsClient.CompileSuggestionsAsync(request);
#pragma warning restore CS0612
            // End snippet
        }
    }
}
