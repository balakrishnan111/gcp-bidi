// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Generated code. DO NOT EDIT!

namespace GoogleCSharpSnippets
{
    using Google.Api.Gax;
    using Google.Api.Gax.ResourceNames;
    using Google.Cloud.Dialogflow.V2Beta1;
    using Google.Protobuf.WellKnownTypes;
    using System;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>Generated snippets.</summary>
    public sealed class AllGeneratedPhoneNumberOrdersClientSnippets
    {
        /// <summary>Snippet for CreatePhoneNumberOrder</summary>
        public void CreatePhoneNumberOrderRequestObject()
        {
            // Snippet: CreatePhoneNumberOrder(CreatePhoneNumberOrderRequest, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            CreatePhoneNumberOrderRequest request = new CreatePhoneNumberOrderRequest
            {
                ParentAsProjectName = ProjectName.FromProject("[PROJECT]"),
                PhoneNumberOrder = new PhoneNumberOrder(),
            };
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.CreatePhoneNumberOrder(request);
            // End snippet
        }

        /// <summary>Snippet for CreatePhoneNumberOrderAsync</summary>
        public async Task CreatePhoneNumberOrderRequestObjectAsync()
        {
            // Snippet: CreatePhoneNumberOrderAsync(CreatePhoneNumberOrderRequest, CallSettings)
            // Additional: CreatePhoneNumberOrderAsync(CreatePhoneNumberOrderRequest, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            CreatePhoneNumberOrderRequest request = new CreatePhoneNumberOrderRequest
            {
                ParentAsProjectName = ProjectName.FromProject("[PROJECT]"),
                PhoneNumberOrder = new PhoneNumberOrder(),
            };
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.CreatePhoneNumberOrderAsync(request);
            // End snippet
        }

        /// <summary>Snippet for CreatePhoneNumberOrder</summary>
        public void CreatePhoneNumberOrder()
        {
            // Snippet: CreatePhoneNumberOrder(string, PhoneNumberOrder, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]";
            PhoneNumberOrder phoneNumberOrder = new PhoneNumberOrder();
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.CreatePhoneNumberOrder(parent, phoneNumberOrder);
            // End snippet
        }

        /// <summary>Snippet for CreatePhoneNumberOrderAsync</summary>
        public async Task CreatePhoneNumberOrderAsync()
        {
            // Snippet: CreatePhoneNumberOrderAsync(string, PhoneNumberOrder, CallSettings)
            // Additional: CreatePhoneNumberOrderAsync(string, PhoneNumberOrder, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]";
            PhoneNumberOrder phoneNumberOrder = new PhoneNumberOrder();
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.CreatePhoneNumberOrderAsync(parent, phoneNumberOrder);
            // End snippet
        }

        /// <summary>Snippet for CreatePhoneNumberOrder</summary>
        public void CreatePhoneNumberOrderResourceNames1()
        {
            // Snippet: CreatePhoneNumberOrder(ProjectName, PhoneNumberOrder, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            ProjectName parent = ProjectName.FromProject("[PROJECT]");
            PhoneNumberOrder phoneNumberOrder = new PhoneNumberOrder();
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.CreatePhoneNumberOrder(parent, phoneNumberOrder);
            // End snippet
        }

        /// <summary>Snippet for CreatePhoneNumberOrderAsync</summary>
        public async Task CreatePhoneNumberOrderResourceNames1Async()
        {
            // Snippet: CreatePhoneNumberOrderAsync(ProjectName, PhoneNumberOrder, CallSettings)
            // Additional: CreatePhoneNumberOrderAsync(ProjectName, PhoneNumberOrder, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            ProjectName parent = ProjectName.FromProject("[PROJECT]");
            PhoneNumberOrder phoneNumberOrder = new PhoneNumberOrder();
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.CreatePhoneNumberOrderAsync(parent, phoneNumberOrder);
            // End snippet
        }

        /// <summary>Snippet for CreatePhoneNumberOrder</summary>
        public void CreatePhoneNumberOrderResourceNames2()
        {
            // Snippet: CreatePhoneNumberOrder(LocationName, PhoneNumberOrder, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            LocationName parent = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]");
            PhoneNumberOrder phoneNumberOrder = new PhoneNumberOrder();
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.CreatePhoneNumberOrder(parent, phoneNumberOrder);
            // End snippet
        }

        /// <summary>Snippet for CreatePhoneNumberOrderAsync</summary>
        public async Task CreatePhoneNumberOrderResourceNames2Async()
        {
            // Snippet: CreatePhoneNumberOrderAsync(LocationName, PhoneNumberOrder, CallSettings)
            // Additional: CreatePhoneNumberOrderAsync(LocationName, PhoneNumberOrder, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            LocationName parent = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]");
            PhoneNumberOrder phoneNumberOrder = new PhoneNumberOrder();
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.CreatePhoneNumberOrderAsync(parent, phoneNumberOrder);
            // End snippet
        }

        /// <summary>Snippet for GetPhoneNumberOrder</summary>
        public void GetPhoneNumberOrderRequestObject()
        {
            // Snippet: GetPhoneNumberOrder(GetPhoneNumberOrderRequest, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            GetPhoneNumberOrderRequest request = new GetPhoneNumberOrderRequest
            {
                PhoneNumberOrderName = PhoneNumberOrderName.FromProjectPhoneNumberOrder("[PROJECT]", "[PHONE_NUMBER_ORDER]"),
            };
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.GetPhoneNumberOrder(request);
            // End snippet
        }

        /// <summary>Snippet for GetPhoneNumberOrderAsync</summary>
        public async Task GetPhoneNumberOrderRequestObjectAsync()
        {
            // Snippet: GetPhoneNumberOrderAsync(GetPhoneNumberOrderRequest, CallSettings)
            // Additional: GetPhoneNumberOrderAsync(GetPhoneNumberOrderRequest, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            GetPhoneNumberOrderRequest request = new GetPhoneNumberOrderRequest
            {
                PhoneNumberOrderName = PhoneNumberOrderName.FromProjectPhoneNumberOrder("[PROJECT]", "[PHONE_NUMBER_ORDER]"),
            };
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.GetPhoneNumberOrderAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GetPhoneNumberOrder</summary>
        public void GetPhoneNumberOrder()
        {
            // Snippet: GetPhoneNumberOrder(string, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/phoneNumberOrders/[PHONE_NUMBER_ORDER]";
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.GetPhoneNumberOrder(name);
            // End snippet
        }

        /// <summary>Snippet for GetPhoneNumberOrderAsync</summary>
        public async Task GetPhoneNumberOrderAsync()
        {
            // Snippet: GetPhoneNumberOrderAsync(string, CallSettings)
            // Additional: GetPhoneNumberOrderAsync(string, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/phoneNumberOrders/[PHONE_NUMBER_ORDER]";
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.GetPhoneNumberOrderAsync(name);
            // End snippet
        }

        /// <summary>Snippet for GetPhoneNumberOrder</summary>
        public void GetPhoneNumberOrderResourceNames()
        {
            // Snippet: GetPhoneNumberOrder(PhoneNumberOrderName, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            PhoneNumberOrderName name = PhoneNumberOrderName.FromProjectPhoneNumberOrder("[PROJECT]", "[PHONE_NUMBER_ORDER]");
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.GetPhoneNumberOrder(name);
            // End snippet
        }

        /// <summary>Snippet for GetPhoneNumberOrderAsync</summary>
        public async Task GetPhoneNumberOrderResourceNamesAsync()
        {
            // Snippet: GetPhoneNumberOrderAsync(PhoneNumberOrderName, CallSettings)
            // Additional: GetPhoneNumberOrderAsync(PhoneNumberOrderName, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            PhoneNumberOrderName name = PhoneNumberOrderName.FromProjectPhoneNumberOrder("[PROJECT]", "[PHONE_NUMBER_ORDER]");
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.GetPhoneNumberOrderAsync(name);
            // End snippet
        }

        /// <summary>Snippet for ListPhoneNumberOrders</summary>
        public void ListPhoneNumberOrdersRequestObject()
        {
            // Snippet: ListPhoneNumberOrders(ListPhoneNumberOrdersRequest, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            ListPhoneNumberOrdersRequest request = new ListPhoneNumberOrdersRequest
            {
                ParentAsProjectName = ProjectName.FromProject("[PROJECT]"),
            };
            // Make the request
            PagedEnumerable<ListPhoneNumberOrdersResponse, PhoneNumberOrder> response = phoneNumberOrdersClient.ListPhoneNumberOrders(request);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (PhoneNumberOrder item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPhoneNumberOrdersResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (PhoneNumberOrder item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<PhoneNumberOrder> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (PhoneNumberOrder item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPhoneNumberOrdersAsync</summary>
        public async Task ListPhoneNumberOrdersRequestObjectAsync()
        {
            // Snippet: ListPhoneNumberOrdersAsync(ListPhoneNumberOrdersRequest, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            ListPhoneNumberOrdersRequest request = new ListPhoneNumberOrdersRequest
            {
                ParentAsProjectName = ProjectName.FromProject("[PROJECT]"),
            };
            // Make the request
            PagedAsyncEnumerable<ListPhoneNumberOrdersResponse, PhoneNumberOrder> response = phoneNumberOrdersClient.ListPhoneNumberOrdersAsync(request);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((PhoneNumberOrder item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPhoneNumberOrdersResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (PhoneNumberOrder item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<PhoneNumberOrder> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (PhoneNumberOrder item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPhoneNumberOrders</summary>
        public void ListPhoneNumberOrders()
        {
            // Snippet: ListPhoneNumberOrders(string, string, int?, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]";
            // Make the request
            PagedEnumerable<ListPhoneNumberOrdersResponse, PhoneNumberOrder> response = phoneNumberOrdersClient.ListPhoneNumberOrders(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (PhoneNumberOrder item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPhoneNumberOrdersResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (PhoneNumberOrder item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<PhoneNumberOrder> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (PhoneNumberOrder item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPhoneNumberOrdersAsync</summary>
        public async Task ListPhoneNumberOrdersAsync()
        {
            // Snippet: ListPhoneNumberOrdersAsync(string, string, int?, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]";
            // Make the request
            PagedAsyncEnumerable<ListPhoneNumberOrdersResponse, PhoneNumberOrder> response = phoneNumberOrdersClient.ListPhoneNumberOrdersAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((PhoneNumberOrder item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPhoneNumberOrdersResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (PhoneNumberOrder item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<PhoneNumberOrder> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (PhoneNumberOrder item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPhoneNumberOrders</summary>
        public void ListPhoneNumberOrdersResourceNames1()
        {
            // Snippet: ListPhoneNumberOrders(ProjectName, string, int?, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            ProjectName parent = ProjectName.FromProject("[PROJECT]");
            // Make the request
            PagedEnumerable<ListPhoneNumberOrdersResponse, PhoneNumberOrder> response = phoneNumberOrdersClient.ListPhoneNumberOrders(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (PhoneNumberOrder item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPhoneNumberOrdersResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (PhoneNumberOrder item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<PhoneNumberOrder> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (PhoneNumberOrder item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPhoneNumberOrdersAsync</summary>
        public async Task ListPhoneNumberOrdersResourceNames1Async()
        {
            // Snippet: ListPhoneNumberOrdersAsync(ProjectName, string, int?, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            ProjectName parent = ProjectName.FromProject("[PROJECT]");
            // Make the request
            PagedAsyncEnumerable<ListPhoneNumberOrdersResponse, PhoneNumberOrder> response = phoneNumberOrdersClient.ListPhoneNumberOrdersAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((PhoneNumberOrder item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPhoneNumberOrdersResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (PhoneNumberOrder item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<PhoneNumberOrder> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (PhoneNumberOrder item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPhoneNumberOrders</summary>
        public void ListPhoneNumberOrdersResourceNames2()
        {
            // Snippet: ListPhoneNumberOrders(LocationName, string, int?, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            LocationName parent = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]");
            // Make the request
            PagedEnumerable<ListPhoneNumberOrdersResponse, PhoneNumberOrder> response = phoneNumberOrdersClient.ListPhoneNumberOrders(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (PhoneNumberOrder item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPhoneNumberOrdersResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (PhoneNumberOrder item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<PhoneNumberOrder> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (PhoneNumberOrder item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPhoneNumberOrdersAsync</summary>
        public async Task ListPhoneNumberOrdersResourceNames2Async()
        {
            // Snippet: ListPhoneNumberOrdersAsync(LocationName, string, int?, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            LocationName parent = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]");
            // Make the request
            PagedAsyncEnumerable<ListPhoneNumberOrdersResponse, PhoneNumberOrder> response = phoneNumberOrdersClient.ListPhoneNumberOrdersAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((PhoneNumberOrder item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPhoneNumberOrdersResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (PhoneNumberOrder item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<PhoneNumberOrder> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (PhoneNumberOrder item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for UpdatePhoneNumberOrder</summary>
        public void UpdatePhoneNumberOrderRequestObject()
        {
            // Snippet: UpdatePhoneNumberOrder(UpdatePhoneNumberOrderRequest, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            UpdatePhoneNumberOrderRequest request = new UpdatePhoneNumberOrderRequest
            {
                PhoneNumberOrder = new PhoneNumberOrder(),
                UpdateMask = new FieldMask(),
            };
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.UpdatePhoneNumberOrder(request);
            // End snippet
        }

        /// <summary>Snippet for UpdatePhoneNumberOrderAsync</summary>
        public async Task UpdatePhoneNumberOrderRequestObjectAsync()
        {
            // Snippet: UpdatePhoneNumberOrderAsync(UpdatePhoneNumberOrderRequest, CallSettings)
            // Additional: UpdatePhoneNumberOrderAsync(UpdatePhoneNumberOrderRequest, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            UpdatePhoneNumberOrderRequest request = new UpdatePhoneNumberOrderRequest
            {
                PhoneNumberOrder = new PhoneNumberOrder(),
                UpdateMask = new FieldMask(),
            };
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.UpdatePhoneNumberOrderAsync(request);
            // End snippet
        }

        /// <summary>Snippet for UpdatePhoneNumberOrder</summary>
        public void UpdatePhoneNumberOrder()
        {
            // Snippet: UpdatePhoneNumberOrder(PhoneNumberOrder, FieldMask, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            PhoneNumberOrder phoneNumberOrder = new PhoneNumberOrder();
            FieldMask updateMask = new FieldMask();
            // Make the request
            PhoneNumberOrder response = phoneNumberOrdersClient.UpdatePhoneNumberOrder(phoneNumberOrder, updateMask);
            // End snippet
        }

        /// <summary>Snippet for UpdatePhoneNumberOrderAsync</summary>
        public async Task UpdatePhoneNumberOrderAsync()
        {
            // Snippet: UpdatePhoneNumberOrderAsync(PhoneNumberOrder, FieldMask, CallSettings)
            // Additional: UpdatePhoneNumberOrderAsync(PhoneNumberOrder, FieldMask, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            PhoneNumberOrder phoneNumberOrder = new PhoneNumberOrder();
            FieldMask updateMask = new FieldMask();
            // Make the request
            PhoneNumberOrder response = await phoneNumberOrdersClient.UpdatePhoneNumberOrderAsync(phoneNumberOrder, updateMask);
            // End snippet
        }

        /// <summary>Snippet for CancelPhoneNumberOrder</summary>
        public void CancelPhoneNumberOrderRequestObject()
        {
            // Snippet: CancelPhoneNumberOrder(CancelPhoneNumberOrderRequest, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            CancelPhoneNumberOrderRequest request = new CancelPhoneNumberOrderRequest
            {
                PhoneNumberOrderName = PhoneNumberOrderName.FromProjectPhoneNumberOrder("[PROJECT]", "[PHONE_NUMBER_ORDER]"),
            };
            // Make the request
            phoneNumberOrdersClient.CancelPhoneNumberOrder(request);
            // End snippet
        }

        /// <summary>Snippet for CancelPhoneNumberOrderAsync</summary>
        public async Task CancelPhoneNumberOrderRequestObjectAsync()
        {
            // Snippet: CancelPhoneNumberOrderAsync(CancelPhoneNumberOrderRequest, CallSettings)
            // Additional: CancelPhoneNumberOrderAsync(CancelPhoneNumberOrderRequest, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            CancelPhoneNumberOrderRequest request = new CancelPhoneNumberOrderRequest
            {
                PhoneNumberOrderName = PhoneNumberOrderName.FromProjectPhoneNumberOrder("[PROJECT]", "[PHONE_NUMBER_ORDER]"),
            };
            // Make the request
            await phoneNumberOrdersClient.CancelPhoneNumberOrderAsync(request);
            // End snippet
        }

        /// <summary>Snippet for CancelPhoneNumberOrder</summary>
        public void CancelPhoneNumberOrder()
        {
            // Snippet: CancelPhoneNumberOrder(string, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/phoneNumberOrders/[PHONE_NUMBER_ORDER]";
            // Make the request
            phoneNumberOrdersClient.CancelPhoneNumberOrder(name);
            // End snippet
        }

        /// <summary>Snippet for CancelPhoneNumberOrderAsync</summary>
        public async Task CancelPhoneNumberOrderAsync()
        {
            // Snippet: CancelPhoneNumberOrderAsync(string, CallSettings)
            // Additional: CancelPhoneNumberOrderAsync(string, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/phoneNumberOrders/[PHONE_NUMBER_ORDER]";
            // Make the request
            await phoneNumberOrdersClient.CancelPhoneNumberOrderAsync(name);
            // End snippet
        }

        /// <summary>Snippet for CancelPhoneNumberOrder</summary>
        public void CancelPhoneNumberOrderResourceNames()
        {
            // Snippet: CancelPhoneNumberOrder(PhoneNumberOrderName, CallSettings)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.Create();
            // Initialize request argument(s)
            PhoneNumberOrderName name = PhoneNumberOrderName.FromProjectPhoneNumberOrder("[PROJECT]", "[PHONE_NUMBER_ORDER]");
            // Make the request
            phoneNumberOrdersClient.CancelPhoneNumberOrder(name);
            // End snippet
        }

        /// <summary>Snippet for CancelPhoneNumberOrderAsync</summary>
        public async Task CancelPhoneNumberOrderResourceNamesAsync()
        {
            // Snippet: CancelPhoneNumberOrderAsync(PhoneNumberOrderName, CallSettings)
            // Additional: CancelPhoneNumberOrderAsync(PhoneNumberOrderName, CancellationToken)
            // Create client
            PhoneNumberOrdersClient phoneNumberOrdersClient = await PhoneNumberOrdersClient.CreateAsync();
            // Initialize request argument(s)
            PhoneNumberOrderName name = PhoneNumberOrderName.FromProjectPhoneNumberOrder("[PROJECT]", "[PHONE_NUMBER_ORDER]");
            // Make the request
            await phoneNumberOrdersClient.CancelPhoneNumberOrderAsync(name);
            // End snippet
        }
    }
}
