// Copyright 2025 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     https://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

// Generated code. DO NOT EDIT!

namespace GoogleCSharpSnippets
{
    using Google.Api.Gax;
    using Google.Api.Gax.Grpc;
    using Google.Api.Gax.ResourceNames;
    using Google.Cloud.Dialogflow.V2Beta1;
    using Google.LongRunning;
    using Google.Protobuf;
    using Google.Protobuf.WellKnownTypes;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;

    /// <summary>Generated snippets.</summary>
    public sealed class AllGeneratedConversationsClientSnippets
    {
        /// <summary>Snippet for CreateConversation</summary>
        public void CreateConversationRequestObject()
        {
            // Snippet: CreateConversation(CreateConversationRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            CreateConversationRequest request = new CreateConversationRequest
            {
                ParentAsProjectName = ProjectName.FromProject("[PROJECT]"),
                Conversation = new Conversation(),
                ConversationId = "",
            };
            // Make the request
            Conversation response = conversationsClient.CreateConversation(request);
            // End snippet
        }

        /// <summary>Snippet for CreateConversationAsync</summary>
        public async Task CreateConversationRequestObjectAsync()
        {
            // Snippet: CreateConversationAsync(CreateConversationRequest, CallSettings)
            // Additional: CreateConversationAsync(CreateConversationRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            CreateConversationRequest request = new CreateConversationRequest
            {
                ParentAsProjectName = ProjectName.FromProject("[PROJECT]"),
                Conversation = new Conversation(),
                ConversationId = "",
            };
            // Make the request
            Conversation response = await conversationsClient.CreateConversationAsync(request);
            // End snippet
        }

        /// <summary>Snippet for CreateConversation</summary>
        public void CreateConversation()
        {
            // Snippet: CreateConversation(string, Conversation, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]";
            Conversation conversation = new Conversation();
            // Make the request
            Conversation response = conversationsClient.CreateConversation(parent, conversation);
            // End snippet
        }

        /// <summary>Snippet for CreateConversationAsync</summary>
        public async Task CreateConversationAsync()
        {
            // Snippet: CreateConversationAsync(string, Conversation, CallSettings)
            // Additional: CreateConversationAsync(string, Conversation, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]";
            Conversation conversation = new Conversation();
            // Make the request
            Conversation response = await conversationsClient.CreateConversationAsync(parent, conversation);
            // End snippet
        }

        /// <summary>Snippet for CreateConversation</summary>
        public void CreateConversationResourceNames1()
        {
            // Snippet: CreateConversation(ProjectName, Conversation, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ProjectName parent = ProjectName.FromProject("[PROJECT]");
            Conversation conversation = new Conversation();
            // Make the request
            Conversation response = conversationsClient.CreateConversation(parent, conversation);
            // End snippet
        }

        /// <summary>Snippet for CreateConversationAsync</summary>
        public async Task CreateConversationResourceNames1Async()
        {
            // Snippet: CreateConversationAsync(ProjectName, Conversation, CallSettings)
            // Additional: CreateConversationAsync(ProjectName, Conversation, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ProjectName parent = ProjectName.FromProject("[PROJECT]");
            Conversation conversation = new Conversation();
            // Make the request
            Conversation response = await conversationsClient.CreateConversationAsync(parent, conversation);
            // End snippet
        }

        /// <summary>Snippet for CreateConversation</summary>
        public void CreateConversationResourceNames2()
        {
            // Snippet: CreateConversation(LocationName, Conversation, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            LocationName parent = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]");
            Conversation conversation = new Conversation();
            // Make the request
            Conversation response = conversationsClient.CreateConversation(parent, conversation);
            // End snippet
        }

        /// <summary>Snippet for CreateConversationAsync</summary>
        public async Task CreateConversationResourceNames2Async()
        {
            // Snippet: CreateConversationAsync(LocationName, Conversation, CallSettings)
            // Additional: CreateConversationAsync(LocationName, Conversation, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            LocationName parent = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]");
            Conversation conversation = new Conversation();
            // Make the request
            Conversation response = await conversationsClient.CreateConversationAsync(parent, conversation);
            // End snippet
        }

        /// <summary>Snippet for ListConversations</summary>
        public void ListConversationsRequestObject()
        {
            // Snippet: ListConversations(ListConversationsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ListConversationsRequest request = new ListConversationsRequest
            {
                ParentAsProjectName = ProjectName.FromProject("[PROJECT]"),
                Filter = "",
            };
            // Make the request
            PagedEnumerable<ListConversationsResponse, Conversation> response = conversationsClient.ListConversations(request);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Conversation item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListConversationsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Conversation item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Conversation> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Conversation item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListConversationsAsync</summary>
        public async Task ListConversationsRequestObjectAsync()
        {
            // Snippet: ListConversationsAsync(ListConversationsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ListConversationsRequest request = new ListConversationsRequest
            {
                ParentAsProjectName = ProjectName.FromProject("[PROJECT]"),
                Filter = "",
            };
            // Make the request
            PagedAsyncEnumerable<ListConversationsResponse, Conversation> response = conversationsClient.ListConversationsAsync(request);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Conversation item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListConversationsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Conversation item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Conversation> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Conversation item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListConversations</summary>
        public void ListConversations()
        {
            // Snippet: ListConversations(string, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]";
            // Make the request
            PagedEnumerable<ListConversationsResponse, Conversation> response = conversationsClient.ListConversations(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Conversation item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListConversationsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Conversation item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Conversation> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Conversation item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListConversationsAsync</summary>
        public async Task ListConversationsAsync()
        {
            // Snippet: ListConversationsAsync(string, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]";
            // Make the request
            PagedAsyncEnumerable<ListConversationsResponse, Conversation> response = conversationsClient.ListConversationsAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Conversation item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListConversationsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Conversation item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Conversation> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Conversation item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListConversations</summary>
        public void ListConversationsResourceNames1()
        {
            // Snippet: ListConversations(ProjectName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ProjectName parent = ProjectName.FromProject("[PROJECT]");
            // Make the request
            PagedEnumerable<ListConversationsResponse, Conversation> response = conversationsClient.ListConversations(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Conversation item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListConversationsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Conversation item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Conversation> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Conversation item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListConversationsAsync</summary>
        public async Task ListConversationsResourceNames1Async()
        {
            // Snippet: ListConversationsAsync(ProjectName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ProjectName parent = ProjectName.FromProject("[PROJECT]");
            // Make the request
            PagedAsyncEnumerable<ListConversationsResponse, Conversation> response = conversationsClient.ListConversationsAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Conversation item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListConversationsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Conversation item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Conversation> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Conversation item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListConversations</summary>
        public void ListConversationsResourceNames2()
        {
            // Snippet: ListConversations(LocationName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            LocationName parent = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]");
            // Make the request
            PagedEnumerable<ListConversationsResponse, Conversation> response = conversationsClient.ListConversations(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Conversation item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListConversationsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Conversation item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Conversation> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Conversation item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListConversationsAsync</summary>
        public async Task ListConversationsResourceNames2Async()
        {
            // Snippet: ListConversationsAsync(LocationName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            LocationName parent = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]");
            // Make the request
            PagedAsyncEnumerable<ListConversationsResponse, Conversation> response = conversationsClient.ListConversationsAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Conversation item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListConversationsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Conversation item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Conversation> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Conversation item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for GetConversation</summary>
        public void GetConversationRequestObject()
        {
            // Snippet: GetConversation(GetConversationRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            GetConversationRequest request = new GetConversationRequest
            {
                ConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            Conversation response = conversationsClient.GetConversation(request);
            // End snippet
        }

        /// <summary>Snippet for GetConversationAsync</summary>
        public async Task GetConversationRequestObjectAsync()
        {
            // Snippet: GetConversationAsync(GetConversationRequest, CallSettings)
            // Additional: GetConversationAsync(GetConversationRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            GetConversationRequest request = new GetConversationRequest
            {
                ConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            Conversation response = await conversationsClient.GetConversationAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GetConversation</summary>
        public void GetConversation()
        {
            // Snippet: GetConversation(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            Conversation response = conversationsClient.GetConversation(name);
            // End snippet
        }

        /// <summary>Snippet for GetConversationAsync</summary>
        public async Task GetConversationAsync()
        {
            // Snippet: GetConversationAsync(string, CallSettings)
            // Additional: GetConversationAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            Conversation response = await conversationsClient.GetConversationAsync(name);
            // End snippet
        }

        /// <summary>Snippet for GetConversation</summary>
        public void GetConversationResourceNames()
        {
            // Snippet: GetConversation(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName name = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            Conversation response = conversationsClient.GetConversation(name);
            // End snippet
        }

        /// <summary>Snippet for GetConversationAsync</summary>
        public async Task GetConversationResourceNamesAsync()
        {
            // Snippet: GetConversationAsync(ConversationName, CallSettings)
            // Additional: GetConversationAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName name = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            Conversation response = await conversationsClient.GetConversationAsync(name);
            // End snippet
        }

        /// <summary>Snippet for AddConversationPhoneNumber</summary>
        public void AddConversationPhoneNumberRequestObject()
        {
            // Snippet: AddConversationPhoneNumber(AddConversationPhoneNumberRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            AddConversationPhoneNumberRequest request = new AddConversationPhoneNumberRequest
            {
                ConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            ConversationPhoneNumber response = conversationsClient.AddConversationPhoneNumber(request);
            // End snippet
        }

        /// <summary>Snippet for AddConversationPhoneNumberAsync</summary>
        public async Task AddConversationPhoneNumberRequestObjectAsync()
        {
            // Snippet: AddConversationPhoneNumberAsync(AddConversationPhoneNumberRequest, CallSettings)
            // Additional: AddConversationPhoneNumberAsync(AddConversationPhoneNumberRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            AddConversationPhoneNumberRequest request = new AddConversationPhoneNumberRequest
            {
                ConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            ConversationPhoneNumber response = await conversationsClient.AddConversationPhoneNumberAsync(request);
            // End snippet
        }

        /// <summary>Snippet for AddConversationPhoneNumber</summary>
        public void AddConversationPhoneNumber()
        {
            // Snippet: AddConversationPhoneNumber(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            ConversationPhoneNumber response = conversationsClient.AddConversationPhoneNumber(name);
            // End snippet
        }

        /// <summary>Snippet for AddConversationPhoneNumberAsync</summary>
        public async Task AddConversationPhoneNumberAsync()
        {
            // Snippet: AddConversationPhoneNumberAsync(string, CallSettings)
            // Additional: AddConversationPhoneNumberAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            ConversationPhoneNumber response = await conversationsClient.AddConversationPhoneNumberAsync(name);
            // End snippet
        }

        /// <summary>Snippet for AddConversationPhoneNumber</summary>
        public void AddConversationPhoneNumberResourceNames()
        {
            // Snippet: AddConversationPhoneNumber(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName name = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            ConversationPhoneNumber response = conversationsClient.AddConversationPhoneNumber(name);
            // End snippet
        }

        /// <summary>Snippet for AddConversationPhoneNumberAsync</summary>
        public async Task AddConversationPhoneNumberResourceNamesAsync()
        {
            // Snippet: AddConversationPhoneNumberAsync(ConversationName, CallSettings)
            // Additional: AddConversationPhoneNumberAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName name = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            ConversationPhoneNumber response = await conversationsClient.AddConversationPhoneNumberAsync(name);
            // End snippet
        }

        /// <summary>Snippet for ActivateConversation</summary>
        public void ActivateConversationRequestObject()
        {
            // Snippet: ActivateConversation(ActivateConversationRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ActivateConversationRequest request = new ActivateConversationRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            Conversation response = conversationsClient.ActivateConversation(request);
            // End snippet
        }

        /// <summary>Snippet for ActivateConversationAsync</summary>
        public async Task ActivateConversationRequestObjectAsync()
        {
            // Snippet: ActivateConversationAsync(ActivateConversationRequest, CallSettings)
            // Additional: ActivateConversationAsync(ActivateConversationRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ActivateConversationRequest request = new ActivateConversationRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            Conversation response = await conversationsClient.ActivateConversationAsync(request);
            // End snippet
        }

        /// <summary>Snippet for ActivateConversation</summary>
        public void ActivateConversation()
        {
            // Snippet: ActivateConversation(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            Conversation response = conversationsClient.ActivateConversation(conversation);
            // End snippet
        }

        /// <summary>Snippet for ActivateConversationAsync</summary>
        public async Task ActivateConversationAsync()
        {
            // Snippet: ActivateConversationAsync(string, CallSettings)
            // Additional: ActivateConversationAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            Conversation response = await conversationsClient.ActivateConversationAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for ActivateConversation</summary>
        public void ActivateConversationResourceNames()
        {
            // Snippet: ActivateConversation(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            Conversation response = conversationsClient.ActivateConversation(conversation);
            // End snippet
        }

        /// <summary>Snippet for ActivateConversationAsync</summary>
        public async Task ActivateConversationResourceNamesAsync()
        {
            // Snippet: ActivateConversationAsync(ConversationName, CallSettings)
            // Additional: ActivateConversationAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            Conversation response = await conversationsClient.ActivateConversationAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for DeactivateConversation</summary>
        public void DeactivateConversationRequestObject()
        {
            // Snippet: DeactivateConversation(DeactivateConversationRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            DeactivateConversationRequest request = new DeactivateConversationRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            Conversation response = conversationsClient.DeactivateConversation(request);
            // End snippet
        }

        /// <summary>Snippet for DeactivateConversationAsync</summary>
        public async Task DeactivateConversationRequestObjectAsync()
        {
            // Snippet: DeactivateConversationAsync(DeactivateConversationRequest, CallSettings)
            // Additional: DeactivateConversationAsync(DeactivateConversationRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            DeactivateConversationRequest request = new DeactivateConversationRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            Conversation response = await conversationsClient.DeactivateConversationAsync(request);
            // End snippet
        }

        /// <summary>Snippet for DeactivateConversation</summary>
        public void DeactivateConversation()
        {
            // Snippet: DeactivateConversation(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            Conversation response = conversationsClient.DeactivateConversation(conversation);
            // End snippet
        }

        /// <summary>Snippet for DeactivateConversationAsync</summary>
        public async Task DeactivateConversationAsync()
        {
            // Snippet: DeactivateConversationAsync(string, CallSettings)
            // Additional: DeactivateConversationAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            Conversation response = await conversationsClient.DeactivateConversationAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for DeactivateConversation</summary>
        public void DeactivateConversationResourceNames()
        {
            // Snippet: DeactivateConversation(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            Conversation response = conversationsClient.DeactivateConversation(conversation);
            // End snippet
        }

        /// <summary>Snippet for DeactivateConversationAsync</summary>
        public async Task DeactivateConversationResourceNamesAsync()
        {
            // Snippet: DeactivateConversationAsync(ConversationName, CallSettings)
            // Additional: DeactivateConversationAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            Conversation response = await conversationsClient.DeactivateConversationAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for CompleteConversation</summary>
        public void CompleteConversationRequestObject()
        {
            // Snippet: CompleteConversation(CompleteConversationRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            CompleteConversationRequest request = new CompleteConversationRequest
            {
                ConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            Conversation response = conversationsClient.CompleteConversation(request);
            // End snippet
        }

        /// <summary>Snippet for CompleteConversationAsync</summary>
        public async Task CompleteConversationRequestObjectAsync()
        {
            // Snippet: CompleteConversationAsync(CompleteConversationRequest, CallSettings)
            // Additional: CompleteConversationAsync(CompleteConversationRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            CompleteConversationRequest request = new CompleteConversationRequest
            {
                ConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            Conversation response = await conversationsClient.CompleteConversationAsync(request);
            // End snippet
        }

        /// <summary>Snippet for CompleteConversation</summary>
        public void CompleteConversation()
        {
            // Snippet: CompleteConversation(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            Conversation response = conversationsClient.CompleteConversation(name);
            // End snippet
        }

        /// <summary>Snippet for CompleteConversationAsync</summary>
        public async Task CompleteConversationAsync()
        {
            // Snippet: CompleteConversationAsync(string, CallSettings)
            // Additional: CompleteConversationAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            Conversation response = await conversationsClient.CompleteConversationAsync(name);
            // End snippet
        }

        /// <summary>Snippet for CompleteConversation</summary>
        public void CompleteConversationResourceNames()
        {
            // Snippet: CompleteConversation(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName name = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            Conversation response = conversationsClient.CompleteConversation(name);
            // End snippet
        }

        /// <summary>Snippet for CompleteConversationAsync</summary>
        public async Task CompleteConversationResourceNamesAsync()
        {
            // Snippet: CompleteConversationAsync(ConversationName, CallSettings)
            // Additional: CompleteConversationAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName name = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            Conversation response = await conversationsClient.CompleteConversationAsync(name);
            // End snippet
        }

        /// <summary>Snippet for UpdateConversation</summary>
        public void UpdateConversationRequestObject()
        {
            // Snippet: UpdateConversation(UpdateConversationRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            UpdateConversationRequest request = new UpdateConversationRequest
            {
                Conversation = new Conversation(),
                UpdateMask = new FieldMask(),
            };
            // Make the request
            Conversation response = conversationsClient.UpdateConversation(request);
            // End snippet
        }

        /// <summary>Snippet for UpdateConversationAsync</summary>
        public async Task UpdateConversationRequestObjectAsync()
        {
            // Snippet: UpdateConversationAsync(UpdateConversationRequest, CallSettings)
            // Additional: UpdateConversationAsync(UpdateConversationRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            UpdateConversationRequest request = new UpdateConversationRequest
            {
                Conversation = new Conversation(),
                UpdateMask = new FieldMask(),
            };
            // Make the request
            Conversation response = await conversationsClient.UpdateConversationAsync(request);
            // End snippet
        }

        /// <summary>Snippet for UpdateConversation</summary>
        public void UpdateConversation()
        {
            // Snippet: UpdateConversation(Conversation, FieldMask, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            Conversation conversation = new Conversation();
            FieldMask updateMask = new FieldMask();
            // Make the request
            Conversation response = conversationsClient.UpdateConversation(conversation, updateMask);
            // End snippet
        }

        /// <summary>Snippet for UpdateConversationAsync</summary>
        public async Task UpdateConversationAsync()
        {
            // Snippet: UpdateConversationAsync(Conversation, FieldMask, CallSettings)
            // Additional: UpdateConversationAsync(Conversation, FieldMask, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            Conversation conversation = new Conversation();
            FieldMask updateMask = new FieldMask();
            // Make the request
            Conversation response = await conversationsClient.UpdateConversationAsync(conversation, updateMask);
            // End snippet
        }

        /// <summary>Snippet for IngestContextReferences</summary>
        public void IngestContextReferencesRequestObject()
        {
            // Snippet: IngestContextReferences(IngestContextReferencesRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            IngestContextReferencesRequest request = new IngestContextReferencesRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                ContextReferences =
                {
                    {
                        "",
                        new Conversation.Types.ContextReference()
                    },
                },
            };
            // Make the request
            IngestContextReferencesResponse response = conversationsClient.IngestContextReferences(request);
            // End snippet
        }

        /// <summary>Snippet for IngestContextReferencesAsync</summary>
        public async Task IngestContextReferencesRequestObjectAsync()
        {
            // Snippet: IngestContextReferencesAsync(IngestContextReferencesRequest, CallSettings)
            // Additional: IngestContextReferencesAsync(IngestContextReferencesRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            IngestContextReferencesRequest request = new IngestContextReferencesRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                ContextReferences =
                {
                    {
                        "",
                        new Conversation.Types.ContextReference()
                    },
                },
            };
            // Make the request
            IngestContextReferencesResponse response = await conversationsClient.IngestContextReferencesAsync(request);
            // End snippet
        }

        /// <summary>Snippet for IngestContextReferences</summary>
        public void IngestContextReferences()
        {
            // Snippet: IngestContextReferences(string, IDictionary<string,Conversation.Types.ContextReference>, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            IDictionary<string, Conversation.Types.ContextReference> contextReferences = new Dictionary<string, Conversation.Types.ContextReference>
            {
                {
                    "",
                    new Conversation.Types.ContextReference()
                },
            };
            // Make the request
            IngestContextReferencesResponse response = conversationsClient.IngestContextReferences(conversation, contextReferences);
            // End snippet
        }

        /// <summary>Snippet for IngestContextReferencesAsync</summary>
        public async Task IngestContextReferencesAsync()
        {
            // Snippet: IngestContextReferencesAsync(string, IDictionary<string,Conversation.Types.ContextReference>, CallSettings)
            // Additional: IngestContextReferencesAsync(string, IDictionary<string,Conversation.Types.ContextReference>, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            IDictionary<string, Conversation.Types.ContextReference> contextReferences = new Dictionary<string, Conversation.Types.ContextReference>
            {
                {
                    "",
                    new Conversation.Types.ContextReference()
                },
            };
            // Make the request
            IngestContextReferencesResponse response = await conversationsClient.IngestContextReferencesAsync(conversation, contextReferences);
            // End snippet
        }

        /// <summary>Snippet for IngestContextReferences</summary>
        public void IngestContextReferencesResourceNames()
        {
            // Snippet: IngestContextReferences(ConversationName, IDictionary<string,Conversation.Types.ContextReference>, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            IDictionary<string, Conversation.Types.ContextReference> contextReferences = new Dictionary<string, Conversation.Types.ContextReference>
            {
                {
                    "",
                    new Conversation.Types.ContextReference()
                },
            };
            // Make the request
            IngestContextReferencesResponse response = conversationsClient.IngestContextReferences(conversation, contextReferences);
            // End snippet
        }

        /// <summary>Snippet for IngestContextReferencesAsync</summary>
        public async Task IngestContextReferencesResourceNamesAsync()
        {
            // Snippet: IngestContextReferencesAsync(ConversationName, IDictionary<string,Conversation.Types.ContextReference>, CallSettings)
            // Additional: IngestContextReferencesAsync(ConversationName, IDictionary<string,Conversation.Types.ContextReference>, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            IDictionary<string, Conversation.Types.ContextReference> contextReferences = new Dictionary<string, Conversation.Types.ContextReference>
            {
                {
                    "",
                    new Conversation.Types.ContextReference()
                },
            };
            // Make the request
            IngestContextReferencesResponse response = await conversationsClient.IngestContextReferencesAsync(conversation, contextReferences);
            // End snippet
        }

        /// <summary>Snippet for CreateCallMatcher</summary>
        public void CreateCallMatcherRequestObject()
        {
            // Snippet: CreateCallMatcher(CreateCallMatcherRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            CreateCallMatcherRequest request = new CreateCallMatcherRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                CallMatcher = new CallMatcher(),
            };
            // Make the request
            CallMatcher response = conversationsClient.CreateCallMatcher(request);
            // End snippet
        }

        /// <summary>Snippet for CreateCallMatcherAsync</summary>
        public async Task CreateCallMatcherRequestObjectAsync()
        {
            // Snippet: CreateCallMatcherAsync(CreateCallMatcherRequest, CallSettings)
            // Additional: CreateCallMatcherAsync(CreateCallMatcherRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            CreateCallMatcherRequest request = new CreateCallMatcherRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                CallMatcher = new CallMatcher(),
            };
            // Make the request
            CallMatcher response = await conversationsClient.CreateCallMatcherAsync(request);
            // End snippet
        }

        /// <summary>Snippet for CreateCallMatcher</summary>
        public void CreateCallMatcher()
        {
            // Snippet: CreateCallMatcher(string, CallMatcher, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]/conversations/[CONVERSATION]";
            CallMatcher callMatcher = new CallMatcher();
            // Make the request
            CallMatcher response = conversationsClient.CreateCallMatcher(parent, callMatcher);
            // End snippet
        }

        /// <summary>Snippet for CreateCallMatcherAsync</summary>
        public async Task CreateCallMatcherAsync()
        {
            // Snippet: CreateCallMatcherAsync(string, CallMatcher, CallSettings)
            // Additional: CreateCallMatcherAsync(string, CallMatcher, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]/conversations/[CONVERSATION]";
            CallMatcher callMatcher = new CallMatcher();
            // Make the request
            CallMatcher response = await conversationsClient.CreateCallMatcherAsync(parent, callMatcher);
            // End snippet
        }

        /// <summary>Snippet for CreateCallMatcher</summary>
        public void CreateCallMatcherResourceNames()
        {
            // Snippet: CreateCallMatcher(ConversationName, CallMatcher, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName parent = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            CallMatcher callMatcher = new CallMatcher();
            // Make the request
            CallMatcher response = conversationsClient.CreateCallMatcher(parent, callMatcher);
            // End snippet
        }

        /// <summary>Snippet for CreateCallMatcherAsync</summary>
        public async Task CreateCallMatcherResourceNamesAsync()
        {
            // Snippet: CreateCallMatcherAsync(ConversationName, CallMatcher, CallSettings)
            // Additional: CreateCallMatcherAsync(ConversationName, CallMatcher, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName parent = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            CallMatcher callMatcher = new CallMatcher();
            // Make the request
            CallMatcher response = await conversationsClient.CreateCallMatcherAsync(parent, callMatcher);
            // End snippet
        }

        /// <summary>Snippet for ListCallMatchers</summary>
        public void ListCallMatchersRequestObject()
        {
            // Snippet: ListCallMatchers(ListCallMatchersRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ListCallMatchersRequest request = new ListCallMatchersRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            PagedEnumerable<ListCallMatchersResponse, CallMatcher> response = conversationsClient.ListCallMatchers(request);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (CallMatcher item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListCallMatchersResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallMatcher item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallMatcher> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallMatcher item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListCallMatchersAsync</summary>
        public async Task ListCallMatchersRequestObjectAsync()
        {
            // Snippet: ListCallMatchersAsync(ListCallMatchersRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ListCallMatchersRequest request = new ListCallMatchersRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            PagedAsyncEnumerable<ListCallMatchersResponse, CallMatcher> response = conversationsClient.ListCallMatchersAsync(request);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((CallMatcher item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListCallMatchersResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallMatcher item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallMatcher> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallMatcher item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListCallMatchers</summary>
        public void ListCallMatchers()
        {
            // Snippet: ListCallMatchers(string, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            PagedEnumerable<ListCallMatchersResponse, CallMatcher> response = conversationsClient.ListCallMatchers(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (CallMatcher item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListCallMatchersResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallMatcher item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallMatcher> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallMatcher item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListCallMatchersAsync</summary>
        public async Task ListCallMatchersAsync()
        {
            // Snippet: ListCallMatchersAsync(string, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            PagedAsyncEnumerable<ListCallMatchersResponse, CallMatcher> response = conversationsClient.ListCallMatchersAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((CallMatcher item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListCallMatchersResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallMatcher item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallMatcher> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallMatcher item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListCallMatchers</summary>
        public void ListCallMatchersResourceNames()
        {
            // Snippet: ListCallMatchers(ConversationName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName parent = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            PagedEnumerable<ListCallMatchersResponse, CallMatcher> response = conversationsClient.ListCallMatchers(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (CallMatcher item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListCallMatchersResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallMatcher item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallMatcher> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallMatcher item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListCallMatchersAsync</summary>
        public async Task ListCallMatchersResourceNamesAsync()
        {
            // Snippet: ListCallMatchersAsync(ConversationName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName parent = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            PagedAsyncEnumerable<ListCallMatchersResponse, CallMatcher> response = conversationsClient.ListCallMatchersAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((CallMatcher item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListCallMatchersResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallMatcher item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallMatcher> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallMatcher item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for DeleteCallMatcher</summary>
        public void DeleteCallMatcherRequestObject()
        {
            // Snippet: DeleteCallMatcher(DeleteCallMatcherRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            DeleteCallMatcherRequest request = new DeleteCallMatcherRequest
            {
                CallMatcherName = CallMatcherName.FromProjectConversationCallMatcher("[PROJECT]", "[CONVERSATION]", "[CALL_MATCHER]"),
            };
            // Make the request
            conversationsClient.DeleteCallMatcher(request);
            // End snippet
        }

        /// <summary>Snippet for DeleteCallMatcherAsync</summary>
        public async Task DeleteCallMatcherRequestObjectAsync()
        {
            // Snippet: DeleteCallMatcherAsync(DeleteCallMatcherRequest, CallSettings)
            // Additional: DeleteCallMatcherAsync(DeleteCallMatcherRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            DeleteCallMatcherRequest request = new DeleteCallMatcherRequest
            {
                CallMatcherName = CallMatcherName.FromProjectConversationCallMatcher("[PROJECT]", "[CONVERSATION]", "[CALL_MATCHER]"),
            };
            // Make the request
            await conversationsClient.DeleteCallMatcherAsync(request);
            // End snippet
        }

        /// <summary>Snippet for DeleteCallMatcher</summary>
        public void DeleteCallMatcher()
        {
            // Snippet: DeleteCallMatcher(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/conversations/[CONVERSATION]/callMatchers/[CALL_MATCHER]";
            // Make the request
            conversationsClient.DeleteCallMatcher(name);
            // End snippet
        }

        /// <summary>Snippet for DeleteCallMatcherAsync</summary>
        public async Task DeleteCallMatcherAsync()
        {
            // Snippet: DeleteCallMatcherAsync(string, CallSettings)
            // Additional: DeleteCallMatcherAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string name = "projects/[PROJECT]/conversations/[CONVERSATION]/callMatchers/[CALL_MATCHER]";
            // Make the request
            await conversationsClient.DeleteCallMatcherAsync(name);
            // End snippet
        }

        /// <summary>Snippet for DeleteCallMatcher</summary>
        public void DeleteCallMatcherResourceNames()
        {
            // Snippet: DeleteCallMatcher(CallMatcherName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            CallMatcherName name = CallMatcherName.FromProjectConversationCallMatcher("[PROJECT]", "[CONVERSATION]", "[CALL_MATCHER]");
            // Make the request
            conversationsClient.DeleteCallMatcher(name);
            // End snippet
        }

        /// <summary>Snippet for DeleteCallMatcherAsync</summary>
        public async Task DeleteCallMatcherResourceNamesAsync()
        {
            // Snippet: DeleteCallMatcherAsync(CallMatcherName, CallSettings)
            // Additional: DeleteCallMatcherAsync(CallMatcherName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            CallMatcherName name = CallMatcherName.FromProjectConversationCallMatcher("[PROJECT]", "[CONVERSATION]", "[CALL_MATCHER]");
            // Make the request
            await conversationsClient.DeleteCallMatcherAsync(name);
            // End snippet
        }

        /// <summary>Snippet for BatchCreateMessages</summary>
        public void BatchCreateMessagesRequestObject()
        {
            // Snippet: BatchCreateMessages(BatchCreateMessagesRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            BatchCreateMessagesRequest request = new BatchCreateMessagesRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Requests =
                {
                    new CreateMessageRequest(),
                },
            };
            // Make the request
            BatchCreateMessagesResponse response = conversationsClient.BatchCreateMessages(request);
            // End snippet
        }

        /// <summary>Snippet for BatchCreateMessagesAsync</summary>
        public async Task BatchCreateMessagesRequestObjectAsync()
        {
            // Snippet: BatchCreateMessagesAsync(BatchCreateMessagesRequest, CallSettings)
            // Additional: BatchCreateMessagesAsync(BatchCreateMessagesRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            BatchCreateMessagesRequest request = new BatchCreateMessagesRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Requests =
                {
                    new CreateMessageRequest(),
                },
            };
            // Make the request
            BatchCreateMessagesResponse response = await conversationsClient.BatchCreateMessagesAsync(request);
            // End snippet
        }

        /// <summary>Snippet for BatchCreateMessages</summary>
        public void BatchCreateMessages()
        {
            // Snippet: BatchCreateMessages(string, IEnumerable<CreateMessageRequest>, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]/conversations/[CONVERSATION]";
            IEnumerable<CreateMessageRequest> requests = new CreateMessageRequest[]
            {
                new CreateMessageRequest(),
            };
            // Make the request
            BatchCreateMessagesResponse response = conversationsClient.BatchCreateMessages(parent, requests);
            // End snippet
        }

        /// <summary>Snippet for BatchCreateMessagesAsync</summary>
        public async Task BatchCreateMessagesAsync()
        {
            // Snippet: BatchCreateMessagesAsync(string, IEnumerable<CreateMessageRequest>, CallSettings)
            // Additional: BatchCreateMessagesAsync(string, IEnumerable<CreateMessageRequest>, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]/conversations/[CONVERSATION]";
            IEnumerable<CreateMessageRequest> requests = new CreateMessageRequest[]
            {
                new CreateMessageRequest(),
            };
            // Make the request
            BatchCreateMessagesResponse response = await conversationsClient.BatchCreateMessagesAsync(parent, requests);
            // End snippet
        }

        /// <summary>Snippet for BatchCreateMessages</summary>
        public void BatchCreateMessagesResourceNames()
        {
            // Snippet: BatchCreateMessages(ConversationName, IEnumerable<CreateMessageRequest>, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName parent = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            IEnumerable<CreateMessageRequest> requests = new CreateMessageRequest[]
            {
                new CreateMessageRequest(),
            };
            // Make the request
            BatchCreateMessagesResponse response = conversationsClient.BatchCreateMessages(parent, requests);
            // End snippet
        }

        /// <summary>Snippet for BatchCreateMessagesAsync</summary>
        public async Task BatchCreateMessagesResourceNamesAsync()
        {
            // Snippet: BatchCreateMessagesAsync(ConversationName, IEnumerable<CreateMessageRequest>, CallSettings)
            // Additional: BatchCreateMessagesAsync(ConversationName, IEnumerable<CreateMessageRequest>, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName parent = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            IEnumerable<CreateMessageRequest> requests = new CreateMessageRequest[]
            {
                new CreateMessageRequest(),
            };
            // Make the request
            BatchCreateMessagesResponse response = await conversationsClient.BatchCreateMessagesAsync(parent, requests);
            // End snippet
        }

        /// <summary>Snippet for ListMessages</summary>
        public void ListMessagesRequestObject()
        {
            // Snippet: ListMessages(ListMessagesRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ListMessagesRequest request = new ListMessagesRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Filter = "",
            };
            // Make the request
            PagedEnumerable<ListMessagesResponse, Message> response = conversationsClient.ListMessages(request);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Message item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListMessagesResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Message item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Message> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Message item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListMessagesAsync</summary>
        public async Task ListMessagesRequestObjectAsync()
        {
            // Snippet: ListMessagesAsync(ListMessagesRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ListMessagesRequest request = new ListMessagesRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Filter = "",
            };
            // Make the request
            PagedAsyncEnumerable<ListMessagesResponse, Message> response = conversationsClient.ListMessagesAsync(request);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Message item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListMessagesResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Message item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Message> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Message item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListMessages</summary>
        public void ListMessages()
        {
            // Snippet: ListMessages(string, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            PagedEnumerable<ListMessagesResponse, Message> response = conversationsClient.ListMessages(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Message item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListMessagesResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Message item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Message> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Message item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListMessagesAsync</summary>
        public async Task ListMessagesAsync()
        {
            // Snippet: ListMessagesAsync(string, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string parent = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            PagedAsyncEnumerable<ListMessagesResponse, Message> response = conversationsClient.ListMessagesAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Message item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListMessagesResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Message item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Message> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Message item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListMessages</summary>
        public void ListMessagesResourceNames()
        {
            // Snippet: ListMessages(ConversationName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName parent = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            PagedEnumerable<ListMessagesResponse, Message> response = conversationsClient.ListMessages(parent);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (Message item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListMessagesResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Message item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Message> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Message item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListMessagesAsync</summary>
        public async Task ListMessagesResourceNamesAsync()
        {
            // Snippet: ListMessagesAsync(ConversationName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName parent = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            PagedAsyncEnumerable<ListMessagesResponse, Message> response = conversationsClient.ListMessagesAsync(parent);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((Message item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListMessagesResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (Message item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<Message> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (Message item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ExportMessages</summary>
        public void ExportMessagesRequestObject()
        {
            // Snippet: ExportMessages(ExportMessagesRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ExportMessagesRequest request = new ExportMessagesRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Filter = "",
                GcsDestination = new GcsDestination(),
            };
            // Make the request
            Operation<ExportMessagesResponse, Struct> response = conversationsClient.ExportMessages(request);

            // Poll until the returned long-running operation is complete
            Operation<ExportMessagesResponse, Struct> completedResponse = response.PollUntilCompleted();
            // Retrieve the operation result
            ExportMessagesResponse result = completedResponse.Result;

            // Or get the name of the operation
            string operationName = response.Name;
            // This name can be stored, then the long-running operation retrieved later by name
            Operation<ExportMessagesResponse, Struct> retrievedResponse = conversationsClient.PollOnceExportMessages(operationName);
            // Check if the retrieved long-running operation has completed
            if (retrievedResponse.IsCompleted)
            {
                // If it has completed, then access the result
                ExportMessagesResponse retrievedResult = retrievedResponse.Result;
            }
            // End snippet
        }

        /// <summary>Snippet for ExportMessagesAsync</summary>
        public async Task ExportMessagesRequestObjectAsync()
        {
            // Snippet: ExportMessagesAsync(ExportMessagesRequest, CallSettings)
            // Additional: ExportMessagesAsync(ExportMessagesRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ExportMessagesRequest request = new ExportMessagesRequest
            {
                ParentAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Filter = "",
                GcsDestination = new GcsDestination(),
            };
            // Make the request
            Operation<ExportMessagesResponse, Struct> response = await conversationsClient.ExportMessagesAsync(request);

            // Poll until the returned long-running operation is complete
            Operation<ExportMessagesResponse, Struct> completedResponse = await response.PollUntilCompletedAsync();
            // Retrieve the operation result
            ExportMessagesResponse result = completedResponse.Result;

            // Or get the name of the operation
            string operationName = response.Name;
            // This name can be stored, then the long-running operation retrieved later by name
            Operation<ExportMessagesResponse, Struct> retrievedResponse = await conversationsClient.PollOnceExportMessagesAsync(operationName);
            // Check if the retrieved long-running operation has completed
            if (retrievedResponse.IsCompleted)
            {
                // If it has completed, then access the result
                ExportMessagesResponse retrievedResult = retrievedResponse.Result;
            }
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationSummary</summary>
        public void SuggestConversationSummaryRequestObject()
        {
            // Snippet: SuggestConversationSummary(SuggestConversationSummaryRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            SuggestConversationSummaryRequest request = new SuggestConversationSummaryRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                ContextSize = 0,
                AssistQueryParams = new AssistQueryParameters(),
                Filter = "",
            };
            // Make the request
            SuggestConversationSummaryResponse response = conversationsClient.SuggestConversationSummary(request);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationSummaryAsync</summary>
        public async Task SuggestConversationSummaryRequestObjectAsync()
        {
            // Snippet: SuggestConversationSummaryAsync(SuggestConversationSummaryRequest, CallSettings)
            // Additional: SuggestConversationSummaryAsync(SuggestConversationSummaryRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            SuggestConversationSummaryRequest request = new SuggestConversationSummaryRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                ContextSize = 0,
                AssistQueryParams = new AssistQueryParameters(),
                Filter = "",
            };
            // Make the request
            SuggestConversationSummaryResponse response = await conversationsClient.SuggestConversationSummaryAsync(request);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationSummary</summary>
        public void SuggestConversationSummary()
        {
            // Snippet: SuggestConversationSummary(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            SuggestConversationSummaryResponse response = conversationsClient.SuggestConversationSummary(conversation);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationSummaryAsync</summary>
        public async Task SuggestConversationSummaryAsync()
        {
            // Snippet: SuggestConversationSummaryAsync(string, CallSettings)
            // Additional: SuggestConversationSummaryAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            SuggestConversationSummaryResponse response = await conversationsClient.SuggestConversationSummaryAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationSummary</summary>
        public void SuggestConversationSummaryResourceNames()
        {
            // Snippet: SuggestConversationSummary(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            SuggestConversationSummaryResponse response = conversationsClient.SuggestConversationSummary(conversation);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationSummaryAsync</summary>
        public async Task SuggestConversationSummaryResourceNamesAsync()
        {
            // Snippet: SuggestConversationSummaryAsync(ConversationName, CallSettings)
            // Additional: SuggestConversationSummaryAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            SuggestConversationSummaryResponse response = await conversationsClient.SuggestConversationSummaryAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for GenerateStatelessSummary</summary>
        public void GenerateStatelessSummaryRequestObject()
        {
            // Snippet: GenerateStatelessSummary(GenerateStatelessSummaryRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            GenerateStatelessSummaryRequest request = new GenerateStatelessSummaryRequest
            {
                StatelessConversation = new GenerateStatelessSummaryRequest.Types.MinimalConversation(),
                ConversationProfile = new ConversationProfile(),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                MaxContextSize = 0,
            };
            // Make the request
            GenerateStatelessSummaryResponse response = conversationsClient.GenerateStatelessSummary(request);
            // End snippet
        }

        /// <summary>Snippet for GenerateStatelessSummaryAsync</summary>
        public async Task GenerateStatelessSummaryRequestObjectAsync()
        {
            // Snippet: GenerateStatelessSummaryAsync(GenerateStatelessSummaryRequest, CallSettings)
            // Additional: GenerateStatelessSummaryAsync(GenerateStatelessSummaryRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            GenerateStatelessSummaryRequest request = new GenerateStatelessSummaryRequest
            {
                StatelessConversation = new GenerateStatelessSummaryRequest.Types.MinimalConversation(),
                ConversationProfile = new ConversationProfile(),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                MaxContextSize = 0,
            };
            // Make the request
            GenerateStatelessSummaryResponse response = await conversationsClient.GenerateStatelessSummaryAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GenerateStatelessSuggestion</summary>
        public void GenerateStatelessSuggestionRequestObject()
        {
            // Snippet: GenerateStatelessSuggestion(GenerateStatelessSuggestionRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            GenerateStatelessSuggestionRequest request = new GenerateStatelessSuggestionRequest
            {
                ParentAsLocationName = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]"),
                Generator = new Generator(),
                ContextReferences =
                {
                    {
                        "",
                        new Conversation.Types.ContextReference()
                    },
                },
                ConversationContext = new ConversationContext(),
                TriggerEvents =
                {
                    TriggerEvent.Unspecified,
                },
                SecuritySettings = "",
            };
            // Make the request
            GenerateStatelessSuggestionResponse response = conversationsClient.GenerateStatelessSuggestion(request);
            // End snippet
        }

        /// <summary>Snippet for GenerateStatelessSuggestionAsync</summary>
        public async Task GenerateStatelessSuggestionRequestObjectAsync()
        {
            // Snippet: GenerateStatelessSuggestionAsync(GenerateStatelessSuggestionRequest, CallSettings)
            // Additional: GenerateStatelessSuggestionAsync(GenerateStatelessSuggestionRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            GenerateStatelessSuggestionRequest request = new GenerateStatelessSuggestionRequest
            {
                ParentAsLocationName = LocationName.FromProjectLocation("[PROJECT]", "[LOCATION]"),
                Generator = new Generator(),
                ContextReferences =
                {
                    {
                        "",
                        new Conversation.Types.ContextReference()
                    },
                },
                ConversationContext = new ConversationContext(),
                TriggerEvents =
                {
                    TriggerEvent.Unspecified,
                },
                SecuritySettings = "",
            };
            // Make the request
            GenerateStatelessSuggestionResponse response = await conversationsClient.GenerateStatelessSuggestionAsync(request);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationKeyMoments</summary>
        public void SuggestConversationKeyMomentsRequestObject()
        {
            // Snippet: SuggestConversationKeyMoments(SuggestConversationKeyMomentsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            SuggestConversationKeyMomentsRequest request = new SuggestConversationKeyMomentsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                ContextSize = 0,
            };
            // Make the request
            SuggestConversationKeyMomentsResponse response = conversationsClient.SuggestConversationKeyMoments(request);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationKeyMomentsAsync</summary>
        public async Task SuggestConversationKeyMomentsRequestObjectAsync()
        {
            // Snippet: SuggestConversationKeyMomentsAsync(SuggestConversationKeyMomentsRequest, CallSettings)
            // Additional: SuggestConversationKeyMomentsAsync(SuggestConversationKeyMomentsRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            SuggestConversationKeyMomentsRequest request = new SuggestConversationKeyMomentsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                ContextSize = 0,
            };
            // Make the request
            SuggestConversationKeyMomentsResponse response = await conversationsClient.SuggestConversationKeyMomentsAsync(request);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationKeyMoments</summary>
        public void SuggestConversationKeyMoments()
        {
            // Snippet: SuggestConversationKeyMoments(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            SuggestConversationKeyMomentsResponse response = conversationsClient.SuggestConversationKeyMoments(conversation);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationKeyMomentsAsync</summary>
        public async Task SuggestConversationKeyMomentsAsync()
        {
            // Snippet: SuggestConversationKeyMomentsAsync(string, CallSettings)
            // Additional: SuggestConversationKeyMomentsAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            SuggestConversationKeyMomentsResponse response = await conversationsClient.SuggestConversationKeyMomentsAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationKeyMoments</summary>
        public void SuggestConversationKeyMomentsResourceNames()
        {
            // Snippet: SuggestConversationKeyMoments(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            SuggestConversationKeyMomentsResponse response = conversationsClient.SuggestConversationKeyMoments(conversation);
            // End snippet
        }

        /// <summary>Snippet for SuggestConversationKeyMomentsAsync</summary>
        public async Task SuggestConversationKeyMomentsResourceNamesAsync()
        {
            // Snippet: SuggestConversationKeyMomentsAsync(ConversationName, CallSettings)
            // Additional: SuggestConversationKeyMomentsAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            SuggestConversationKeyMomentsResponse response = await conversationsClient.SuggestConversationKeyMomentsAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for SearchArticles</summary>
        public void SearchArticlesRequestObject()
        {
            // Snippet: SearchArticles(SearchArticlesRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            SearchArticlesRequest request = new SearchArticlesRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Query = new TextInput(),
            };
            // Make the request
            SearchArticlesResponse response = conversationsClient.SearchArticles(request);
            // End snippet
        }

        /// <summary>Snippet for SearchArticlesAsync</summary>
        public async Task SearchArticlesRequestObjectAsync()
        {
            // Snippet: SearchArticlesAsync(SearchArticlesRequest, CallSettings)
            // Additional: SearchArticlesAsync(SearchArticlesRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            SearchArticlesRequest request = new SearchArticlesRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Query = new TextInput(),
            };
            // Make the request
            SearchArticlesResponse response = await conversationsClient.SearchArticlesAsync(request);
            // End snippet
        }

        /// <summary>Snippet for SearchArticles</summary>
        public void SearchArticles()
        {
            // Snippet: SearchArticles(string, TextInput, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            TextInput query = new TextInput();
            // Make the request
            SearchArticlesResponse response = conversationsClient.SearchArticles(conversation, query);
            // End snippet
        }

        /// <summary>Snippet for SearchArticlesAsync</summary>
        public async Task SearchArticlesAsync()
        {
            // Snippet: SearchArticlesAsync(string, TextInput, CallSettings)
            // Additional: SearchArticlesAsync(string, TextInput, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            TextInput query = new TextInput();
            // Make the request
            SearchArticlesResponse response = await conversationsClient.SearchArticlesAsync(conversation, query);
            // End snippet
        }

        /// <summary>Snippet for SearchArticles</summary>
        public void SearchArticlesResourceNames()
        {
            // Snippet: SearchArticles(ConversationName, TextInput, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            TextInput query = new TextInput();
            // Make the request
            SearchArticlesResponse response = conversationsClient.SearchArticles(conversation, query);
            // End snippet
        }

        /// <summary>Snippet for SearchArticlesAsync</summary>
        public async Task SearchArticlesResourceNamesAsync()
        {
            // Snippet: SearchArticlesAsync(ConversationName, TextInput, CallSettings)
            // Additional: SearchArticlesAsync(ConversationName, TextInput, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            TextInput query = new TextInput();
            // Make the request
            SearchArticlesResponse response = await conversationsClient.SearchArticlesAsync(conversation, query);
            // End snippet
        }

        /// <summary>Snippet for ListPastCallCompanionEvents</summary>
        public void ListPastCallCompanionEventsRequestObject()
        {
            // Snippet: ListPastCallCompanionEvents(ListPastCallCompanionEventsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ListPastCallCompanionEventsRequest request = new ListPastCallCompanionEventsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            PagedEnumerable<ListPastCallCompanionEventsResponse, CallCompanionConversationEvent> response = conversationsClient.ListPastCallCompanionEvents(request);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (CallCompanionConversationEvent item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPastCallCompanionEventsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallCompanionConversationEvent item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallCompanionConversationEvent> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallCompanionConversationEvent item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPastCallCompanionEventsAsync</summary>
        public async Task ListPastCallCompanionEventsRequestObjectAsync()
        {
            // Snippet: ListPastCallCompanionEventsAsync(ListPastCallCompanionEventsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ListPastCallCompanionEventsRequest request = new ListPastCallCompanionEventsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            PagedAsyncEnumerable<ListPastCallCompanionEventsResponse, CallCompanionConversationEvent> response = conversationsClient.ListPastCallCompanionEventsAsync(request);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((CallCompanionConversationEvent item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPastCallCompanionEventsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallCompanionConversationEvent item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallCompanionConversationEvent> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallCompanionConversationEvent item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPastCallCompanionEvents</summary>
        public void ListPastCallCompanionEvents()
        {
            // Snippet: ListPastCallCompanionEvents(string, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            PagedEnumerable<ListPastCallCompanionEventsResponse, CallCompanionConversationEvent> response = conversationsClient.ListPastCallCompanionEvents(conversation);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (CallCompanionConversationEvent item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPastCallCompanionEventsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallCompanionConversationEvent item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallCompanionConversationEvent> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallCompanionConversationEvent item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPastCallCompanionEventsAsync</summary>
        public async Task ListPastCallCompanionEventsAsync()
        {
            // Snippet: ListPastCallCompanionEventsAsync(string, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            PagedAsyncEnumerable<ListPastCallCompanionEventsResponse, CallCompanionConversationEvent> response = conversationsClient.ListPastCallCompanionEventsAsync(conversation);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((CallCompanionConversationEvent item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPastCallCompanionEventsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallCompanionConversationEvent item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallCompanionConversationEvent> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallCompanionConversationEvent item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPastCallCompanionEvents</summary>
        public void ListPastCallCompanionEventsResourceNames()
        {
            // Snippet: ListPastCallCompanionEvents(ConversationName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            PagedEnumerable<ListPastCallCompanionEventsResponse, CallCompanionConversationEvent> response = conversationsClient.ListPastCallCompanionEvents(conversation);

            // Iterate over all response items, lazily performing RPCs as required
            foreach (CallCompanionConversationEvent item in response)
            {
                // Do something with each item
                Console.WriteLine(item);
            }

            // Or iterate over pages (of server-defined size), performing one RPC per page
            foreach (ListPastCallCompanionEventsResponse page in response.AsRawResponses())
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallCompanionConversationEvent item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            }

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallCompanionConversationEvent> singlePage = response.ReadPage(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallCompanionConversationEvent item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for ListPastCallCompanionEventsAsync</summary>
        public async Task ListPastCallCompanionEventsResourceNamesAsync()
        {
            // Snippet: ListPastCallCompanionEventsAsync(ConversationName, string, int?, CallSettings)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            PagedAsyncEnumerable<ListPastCallCompanionEventsResponse, CallCompanionConversationEvent> response = conversationsClient.ListPastCallCompanionEventsAsync(conversation);

            // Iterate over all response items, lazily performing RPCs as required
            await response.ForEachAsync((CallCompanionConversationEvent item) =>
            {
                // Do something with each item
                Console.WriteLine(item);
            });

            // Or iterate over pages (of server-defined size), performing one RPC per page
            await response.AsRawResponses().ForEachAsync((ListPastCallCompanionEventsResponse page) =>
            {
                // Do something with each page of items
                Console.WriteLine("A page of results:");
                foreach (CallCompanionConversationEvent item in page)
                {
                    // Do something with each item
                    Console.WriteLine(item);
                }
            });

            // Or retrieve a single page of known size (unless it's the final page), performing as many RPCs as required
            int pageSize = 10;
            Page<CallCompanionConversationEvent> singlePage = await response.ReadPageAsync(pageSize);
            // Do something with the page of items
            Console.WriteLine($"A page of {pageSize} results (unless it's the final page):");
            foreach (CallCompanionConversationEvent item in singlePage)
            {
                // Do something with each item
                Console.WriteLine(item);
            }
            // Store the pageToken, for when the next page is required.
            string nextPageToken = singlePage.NextPageToken;
            // End snippet
        }

        /// <summary>Snippet for StreamingListUpcomingCallCompanionEvents</summary>
        public async Task StreamingListUpcomingCallCompanionEventsRequestObject()
        {
            // Snippet: StreamingListUpcomingCallCompanionEvents(StreamingListUpcomingCallCompanionEventsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            StreamingListUpcomingCallCompanionEventsRequest request = new StreamingListUpcomingCallCompanionEventsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request, returning a streaming response
            using ConversationsClient.StreamingListUpcomingCallCompanionEventsStream response = conversationsClient.StreamingListUpcomingCallCompanionEvents(request);

            // Read streaming responses from server until complete
            // Note that C# 8 code can use await foreach
            AsyncResponseStream<StreamingListUpcomingCallCompanionEventsResponse> responseStream = response.GetResponseStream();
            while (await responseStream.MoveNextAsync())
            {
                StreamingListUpcomingCallCompanionEventsResponse responseItem = responseStream.Current;
                // Do something with streamed response
            }
            // The response stream has completed
            // End snippet
        }

        /// <summary>Snippet for StreamingListUpcomingCallCompanionEvents</summary>
        public async Task StreamingListUpcomingCallCompanionEvents()
        {
            // Snippet: StreamingListUpcomingCallCompanionEvents(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request, returning a streaming response
            using ConversationsClient.StreamingListUpcomingCallCompanionEventsStream response = conversationsClient.StreamingListUpcomingCallCompanionEvents(conversation);

            // Read streaming responses from server until complete
            // Note that C# 8 code can use await foreach
            AsyncResponseStream<StreamingListUpcomingCallCompanionEventsResponse> responseStream = response.GetResponseStream();
            while (await responseStream.MoveNextAsync())
            {
                StreamingListUpcomingCallCompanionEventsResponse responseItem = responseStream.Current;
                // Do something with streamed response
            }
            // The response stream has completed
            // End snippet
        }

        /// <summary>Snippet for StreamingListUpcomingCallCompanionEvents</summary>
        public async Task StreamingListUpcomingCallCompanionEventsResourceNames()
        {
            // Snippet: StreamingListUpcomingCallCompanionEvents(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request, returning a streaming response
            using ConversationsClient.StreamingListUpcomingCallCompanionEventsStream response = conversationsClient.StreamingListUpcomingCallCompanionEvents(conversation);

            // Read streaming responses from server until complete
            // Note that C# 8 code can use await foreach
            AsyncResponseStream<StreamingListUpcomingCallCompanionEventsResponse> responseStream = response.GetResponseStream();
            while (await responseStream.MoveNextAsync())
            {
                StreamingListUpcomingCallCompanionEventsResponse responseItem = responseStream.Current;
                // Do something with streamed response
            }
            // The response stream has completed
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionUserInput</summary>
        public void InjectCallCompanionUserInputRequestObject()
        {
            // Snippet: InjectCallCompanionUserInput(InjectCallCompanionUserInputRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            InjectCallCompanionUserInputRequest request = new InjectCallCompanionUserInputRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                UserInput = new CallCompanionUserInput(),
            };
            // Make the request
            InjectCallCompanionUserInputResponse response = conversationsClient.InjectCallCompanionUserInput(request);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionUserInputAsync</summary>
        public async Task InjectCallCompanionUserInputRequestObjectAsync()
        {
            // Snippet: InjectCallCompanionUserInputAsync(InjectCallCompanionUserInputRequest, CallSettings)
            // Additional: InjectCallCompanionUserInputAsync(InjectCallCompanionUserInputRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            InjectCallCompanionUserInputRequest request = new InjectCallCompanionUserInputRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                UserInput = new CallCompanionUserInput(),
            };
            // Make the request
            InjectCallCompanionUserInputResponse response = await conversationsClient.InjectCallCompanionUserInputAsync(request);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionUserInput</summary>
        public void InjectCallCompanionUserInput()
        {
            // Snippet: InjectCallCompanionUserInput(string, CallCompanionUserInput, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            CallCompanionUserInput userInput = new CallCompanionUserInput();
            // Make the request
            InjectCallCompanionUserInputResponse response = conversationsClient.InjectCallCompanionUserInput(conversation, userInput);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionUserInputAsync</summary>
        public async Task InjectCallCompanionUserInputAsync()
        {
            // Snippet: InjectCallCompanionUserInputAsync(string, CallCompanionUserInput, CallSettings)
            // Additional: InjectCallCompanionUserInputAsync(string, CallCompanionUserInput, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            CallCompanionUserInput userInput = new CallCompanionUserInput();
            // Make the request
            InjectCallCompanionUserInputResponse response = await conversationsClient.InjectCallCompanionUserInputAsync(conversation, userInput);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionUserInput</summary>
        public void InjectCallCompanionUserInputResourceNames()
        {
            // Snippet: InjectCallCompanionUserInput(ConversationName, CallCompanionUserInput, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            CallCompanionUserInput userInput = new CallCompanionUserInput();
            // Make the request
            InjectCallCompanionUserInputResponse response = conversationsClient.InjectCallCompanionUserInput(conversation, userInput);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionUserInputAsync</summary>
        public async Task InjectCallCompanionUserInputResourceNamesAsync()
        {
            // Snippet: InjectCallCompanionUserInputAsync(ConversationName, CallCompanionUserInput, CallSettings)
            // Additional: InjectCallCompanionUserInputAsync(ConversationName, CallCompanionUserInput, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            CallCompanionUserInput userInput = new CallCompanionUserInput();
            // Make the request
            InjectCallCompanionUserInputResponse response = await conversationsClient.InjectCallCompanionUserInputAsync(conversation, userInput);
            // End snippet
        }

        /// <summary>Snippet for StreamingListCallCompanionEvents</summary>
        public async Task StreamingListCallCompanionEventsRequestObject()
        {
            // Snippet: StreamingListCallCompanionEvents(StreamingListCallCompanionEventsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            StreamingListCallCompanionEventsRequest request = new StreamingListCallCompanionEventsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                AuthenticationCode = ByteString.Empty,
                IncludePastEvents = false,
            };
            // Make the request, returning a streaming response
            using ConversationsClient.StreamingListCallCompanionEventsStream response = conversationsClient.StreamingListCallCompanionEvents(request);

            // Read streaming responses from server until complete
            // Note that C# 8 code can use await foreach
            AsyncResponseStream<StreamingListCallCompanionEventsResponse> responseStream = response.GetResponseStream();
            while (await responseStream.MoveNextAsync())
            {
                StreamingListCallCompanionEventsResponse responseItem = responseStream.Current;
                // Do something with streamed response
            }
            // The response stream has completed
            // End snippet
        }

        /// <summary>Snippet for StreamingListCallCompanionEvents</summary>
        public async Task StreamingListCallCompanionEvents()
        {
            // Snippet: StreamingListCallCompanionEvents(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request, returning a streaming response
            using ConversationsClient.StreamingListCallCompanionEventsStream response = conversationsClient.StreamingListCallCompanionEvents(conversation);

            // Read streaming responses from server until complete
            // Note that C# 8 code can use await foreach
            AsyncResponseStream<StreamingListCallCompanionEventsResponse> responseStream = response.GetResponseStream();
            while (await responseStream.MoveNextAsync())
            {
                StreamingListCallCompanionEventsResponse responseItem = responseStream.Current;
                // Do something with streamed response
            }
            // The response stream has completed
            // End snippet
        }

        /// <summary>Snippet for StreamingListCallCompanionEvents</summary>
        public async Task StreamingListCallCompanionEventsResourceNames()
        {
            // Snippet: StreamingListCallCompanionEvents(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request, returning a streaming response
            using ConversationsClient.StreamingListCallCompanionEventsStream response = conversationsClient.StreamingListCallCompanionEvents(conversation);

            // Read streaming responses from server until complete
            // Note that C# 8 code can use await foreach
            AsyncResponseStream<StreamingListCallCompanionEventsResponse> responseStream = response.GetResponseStream();
            while (await responseStream.MoveNextAsync())
            {
                StreamingListCallCompanionEventsResponse responseItem = responseStream.Current;
                // Do something with streamed response
            }
            // The response stream has completed
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionInput</summary>
        public void InjectCallCompanionInputRequestObject()
        {
            // Snippet: InjectCallCompanionInput(InjectCallCompanionInputRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            InjectCallCompanionInputRequest request = new InjectCallCompanionInputRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                UserInput = new CallCompanionUserInput(),
                AuthenticationCode = ByteString.Empty,
            };
            // Make the request
            InjectCallCompanionInputResponse response = conversationsClient.InjectCallCompanionInput(request);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionInputAsync</summary>
        public async Task InjectCallCompanionInputRequestObjectAsync()
        {
            // Snippet: InjectCallCompanionInputAsync(InjectCallCompanionInputRequest, CallSettings)
            // Additional: InjectCallCompanionInputAsync(InjectCallCompanionInputRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            InjectCallCompanionInputRequest request = new InjectCallCompanionInputRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                UserInput = new CallCompanionUserInput(),
                AuthenticationCode = ByteString.Empty,
            };
            // Make the request
            InjectCallCompanionInputResponse response = await conversationsClient.InjectCallCompanionInputAsync(request);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionInput</summary>
        public void InjectCallCompanionInput()
        {
            // Snippet: InjectCallCompanionInput(string, CallCompanionUserInput, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            CallCompanionUserInput userInput = new CallCompanionUserInput();
            // Make the request
            InjectCallCompanionInputResponse response = conversationsClient.InjectCallCompanionInput(conversation, userInput);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionInputAsync</summary>
        public async Task InjectCallCompanionInputAsync()
        {
            // Snippet: InjectCallCompanionInputAsync(string, CallCompanionUserInput, CallSettings)
            // Additional: InjectCallCompanionInputAsync(string, CallCompanionUserInput, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            CallCompanionUserInput userInput = new CallCompanionUserInput();
            // Make the request
            InjectCallCompanionInputResponse response = await conversationsClient.InjectCallCompanionInputAsync(conversation, userInput);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionInput</summary>
        public void InjectCallCompanionInputResourceNames()
        {
            // Snippet: InjectCallCompanionInput(ConversationName, CallCompanionUserInput, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            CallCompanionUserInput userInput = new CallCompanionUserInput();
            // Make the request
            InjectCallCompanionInputResponse response = conversationsClient.InjectCallCompanionInput(conversation, userInput);
            // End snippet
        }

        /// <summary>Snippet for InjectCallCompanionInputAsync</summary>
        public async Task InjectCallCompanionInputResourceNamesAsync()
        {
            // Snippet: InjectCallCompanionInputAsync(ConversationName, CallCompanionUserInput, CallSettings)
            // Additional: InjectCallCompanionInputAsync(ConversationName, CallCompanionUserInput, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            CallCompanionUserInput userInput = new CallCompanionUserInput();
            // Make the request
            InjectCallCompanionInputResponse response = await conversationsClient.InjectCallCompanionInputAsync(conversation, userInput);
            // End snippet
        }

        /// <summary>Snippet for InitializeCallCompanion</summary>
        public void InitializeCallCompanionRequestObject()
        {
            // Snippet: InitializeCallCompanion(InitializeCallCompanionRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            InitializeCallCompanionRequest request = new InitializeCallCompanionRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            conversationsClient.InitializeCallCompanion(request);
            // End snippet
        }

        /// <summary>Snippet for InitializeCallCompanionAsync</summary>
        public async Task InitializeCallCompanionRequestObjectAsync()
        {
            // Snippet: InitializeCallCompanionAsync(InitializeCallCompanionRequest, CallSettings)
            // Additional: InitializeCallCompanionAsync(InitializeCallCompanionRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            InitializeCallCompanionRequest request = new InitializeCallCompanionRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
            };
            // Make the request
            await conversationsClient.InitializeCallCompanionAsync(request);
            // End snippet
        }

        /// <summary>Snippet for InitializeCallCompanion</summary>
        public void InitializeCallCompanion()
        {
            // Snippet: InitializeCallCompanion(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            conversationsClient.InitializeCallCompanion(conversation);
            // End snippet
        }

        /// <summary>Snippet for InitializeCallCompanionAsync</summary>
        public async Task InitializeCallCompanionAsync()
        {
            // Snippet: InitializeCallCompanionAsync(string, CallSettings)
            // Additional: InitializeCallCompanionAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            await conversationsClient.InitializeCallCompanionAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for InitializeCallCompanion</summary>
        public void InitializeCallCompanionResourceNames()
        {
            // Snippet: InitializeCallCompanion(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            conversationsClient.InitializeCallCompanion(conversation);
            // End snippet
        }

        /// <summary>Snippet for InitializeCallCompanionAsync</summary>
        public async Task InitializeCallCompanionResourceNamesAsync()
        {
            // Snippet: InitializeCallCompanionAsync(ConversationName, CallSettings)
            // Additional: InitializeCallCompanionAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            await conversationsClient.InitializeCallCompanionAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for GetCallCompanionSettings</summary>
        public void GetCallCompanionSettingsRequestObject()
        {
            // Snippet: GetCallCompanionSettings(GetCallCompanionSettingsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            GetCallCompanionSettingsRequest request = new GetCallCompanionSettingsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                AuthenticationCode = ByteString.Empty,
            };
            // Make the request
            CallCompanionSettings response = conversationsClient.GetCallCompanionSettings(request);
            // End snippet
        }

        /// <summary>Snippet for GetCallCompanionSettingsAsync</summary>
        public async Task GetCallCompanionSettingsRequestObjectAsync()
        {
            // Snippet: GetCallCompanionSettingsAsync(GetCallCompanionSettingsRequest, CallSettings)
            // Additional: GetCallCompanionSettingsAsync(GetCallCompanionSettingsRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            GetCallCompanionSettingsRequest request = new GetCallCompanionSettingsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                AuthenticationCode = ByteString.Empty,
            };
            // Make the request
            CallCompanionSettings response = await conversationsClient.GetCallCompanionSettingsAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GetCallCompanionSettings</summary>
        public void GetCallCompanionSettings()
        {
            // Snippet: GetCallCompanionSettings(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            CallCompanionSettings response = conversationsClient.GetCallCompanionSettings(conversation);
            // End snippet
        }

        /// <summary>Snippet for GetCallCompanionSettingsAsync</summary>
        public async Task GetCallCompanionSettingsAsync()
        {
            // Snippet: GetCallCompanionSettingsAsync(string, CallSettings)
            // Additional: GetCallCompanionSettingsAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            CallCompanionSettings response = await conversationsClient.GetCallCompanionSettingsAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for GetCallCompanionSettings</summary>
        public void GetCallCompanionSettingsResourceNames()
        {
            // Snippet: GetCallCompanionSettings(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            CallCompanionSettings response = conversationsClient.GetCallCompanionSettings(conversation);
            // End snippet
        }

        /// <summary>Snippet for GetCallCompanionSettingsAsync</summary>
        public async Task GetCallCompanionSettingsResourceNamesAsync()
        {
            // Snippet: GetCallCompanionSettingsAsync(ConversationName, CallSettings)
            // Additional: GetCallCompanionSettingsAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            CallCompanionSettings response = await conversationsClient.GetCallCompanionSettingsAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for SearchKnowledge</summary>
        public void SearchKnowledgeRequestObject()
        {
            // Snippet: SearchKnowledge(SearchKnowledgeRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            SearchKnowledgeRequest request = new SearchKnowledgeRequest
            {
                Query = new TextInput(),
                ConversationProfileAsConversationProfileName = ConversationProfileName.FromProjectConversationProfile("[PROJECT]", "[CONVERSATION_PROFILE]"),
                SessionId = "",
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                Parent = "",
                QuerySource = SearchKnowledgeRequest.Types.QuerySource.Unspecified,
                EndUserMetadata = new Struct(),
                SearchConfig = new SearchKnowledgeRequest.Types.SearchConfig(),
                QueryParams = new QueryParameters(),
                CxParameters = new Struct(),
                ExactSearch = false,
                CxCurrentPage = "",
            };
            // Make the request
            SearchKnowledgeResponse response = conversationsClient.SearchKnowledge(request);
            // End snippet
        }

        /// <summary>Snippet for SearchKnowledgeAsync</summary>
        public async Task SearchKnowledgeRequestObjectAsync()
        {
            // Snippet: SearchKnowledgeAsync(SearchKnowledgeRequest, CallSettings)
            // Additional: SearchKnowledgeAsync(SearchKnowledgeRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            SearchKnowledgeRequest request = new SearchKnowledgeRequest
            {
                Query = new TextInput(),
                ConversationProfileAsConversationProfileName = ConversationProfileName.FromProjectConversationProfile("[PROJECT]", "[CONVERSATION_PROFILE]"),
                SessionId = "",
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                Parent = "",
                QuerySource = SearchKnowledgeRequest.Types.QuerySource.Unspecified,
                EndUserMetadata = new Struct(),
                SearchConfig = new SearchKnowledgeRequest.Types.SearchConfig(),
                QueryParams = new QueryParameters(),
                CxParameters = new Struct(),
                ExactSearch = false,
                CxCurrentPage = "",
            };
            // Make the request
            SearchKnowledgeResponse response = await conversationsClient.SearchKnowledgeAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GenerateSuggestions</summary>
        public void GenerateSuggestionsRequestObject()
        {
            // Snippet: GenerateSuggestions(GenerateSuggestionsRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            GenerateSuggestionsRequest request = new GenerateSuggestionsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                TriggerEvents =
                {
                    TriggerEvent.Unspecified,
                },
            };
            // Make the request
            GenerateSuggestionsResponse response = conversationsClient.GenerateSuggestions(request);
            // End snippet
        }

        /// <summary>Snippet for GenerateSuggestionsAsync</summary>
        public async Task GenerateSuggestionsRequestObjectAsync()
        {
            // Snippet: GenerateSuggestionsAsync(GenerateSuggestionsRequest, CallSettings)
            // Additional: GenerateSuggestionsAsync(GenerateSuggestionsRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            GenerateSuggestionsRequest request = new GenerateSuggestionsRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                LatestMessageAsMessageName = MessageName.FromProjectConversationMessage("[PROJECT]", "[CONVERSATION]", "[MESSAGE]"),
                TriggerEvents =
                {
                    TriggerEvent.Unspecified,
                },
            };
            // Make the request
            GenerateSuggestionsResponse response = await conversationsClient.GenerateSuggestionsAsync(request);
            // End snippet
        }

        /// <summary>Snippet for GenerateSuggestions</summary>
        public void GenerateSuggestions()
        {
            // Snippet: GenerateSuggestions(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            GenerateSuggestionsResponse response = conversationsClient.GenerateSuggestions(conversation);
            // End snippet
        }

        /// <summary>Snippet for GenerateSuggestionsAsync</summary>
        public async Task GenerateSuggestionsAsync()
        {
            // Snippet: GenerateSuggestionsAsync(string, CallSettings)
            // Additional: GenerateSuggestionsAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            GenerateSuggestionsResponse response = await conversationsClient.GenerateSuggestionsAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for GenerateSuggestions</summary>
        public void GenerateSuggestionsResourceNames()
        {
            // Snippet: GenerateSuggestions(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            GenerateSuggestionsResponse response = conversationsClient.GenerateSuggestions(conversation);
            // End snippet
        }

        /// <summary>Snippet for GenerateSuggestionsAsync</summary>
        public async Task GenerateSuggestionsResourceNamesAsync()
        {
            // Snippet: GenerateSuggestionsAsync(ConversationName, CallSettings)
            // Additional: GenerateSuggestionsAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            GenerateSuggestionsResponse response = await conversationsClient.GenerateSuggestionsAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for InitiatePhoneCall</summary>
        public void InitiatePhoneCallRequestObject()
        {
            // Snippet: InitiatePhoneCall(InitiatePhoneCallRequest, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            InitiatePhoneCallRequest request = new InitiatePhoneCallRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Callee = "",
            };
            // Make the request
            InitiatePhoneCallResponse response = conversationsClient.InitiatePhoneCall(request);
            // End snippet
        }

        /// <summary>Snippet for InitiatePhoneCallAsync</summary>
        public async Task InitiatePhoneCallRequestObjectAsync()
        {
            // Snippet: InitiatePhoneCallAsync(InitiatePhoneCallRequest, CallSettings)
            // Additional: InitiatePhoneCallAsync(InitiatePhoneCallRequest, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            InitiatePhoneCallRequest request = new InitiatePhoneCallRequest
            {
                ConversationAsConversationName = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]"),
                Callee = "",
            };
            // Make the request
            InitiatePhoneCallResponse response = await conversationsClient.InitiatePhoneCallAsync(request);
            // End snippet
        }

        /// <summary>Snippet for InitiatePhoneCall</summary>
        public void InitiatePhoneCall()
        {
            // Snippet: InitiatePhoneCall(string, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            InitiatePhoneCallResponse response = conversationsClient.InitiatePhoneCall(conversation);
            // End snippet
        }

        /// <summary>Snippet for InitiatePhoneCallAsync</summary>
        public async Task InitiatePhoneCallAsync()
        {
            // Snippet: InitiatePhoneCallAsync(string, CallSettings)
            // Additional: InitiatePhoneCallAsync(string, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            string conversation = "projects/[PROJECT]/conversations/[CONVERSATION]";
            // Make the request
            InitiatePhoneCallResponse response = await conversationsClient.InitiatePhoneCallAsync(conversation);
            // End snippet
        }

        /// <summary>Snippet for InitiatePhoneCall</summary>
        public void InitiatePhoneCallResourceNames()
        {
            // Snippet: InitiatePhoneCall(ConversationName, CallSettings)
            // Create client
            ConversationsClient conversationsClient = ConversationsClient.Create();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            InitiatePhoneCallResponse response = conversationsClient.InitiatePhoneCall(conversation);
            // End snippet
        }

        /// <summary>Snippet for InitiatePhoneCallAsync</summary>
        public async Task InitiatePhoneCallResourceNamesAsync()
        {
            // Snippet: InitiatePhoneCallAsync(ConversationName, CallSettings)
            // Additional: InitiatePhoneCallAsync(ConversationName, CancellationToken)
            // Create client
            ConversationsClient conversationsClient = await ConversationsClient.CreateAsync();
            // Initialize request argument(s)
            ConversationName conversation = ConversationName.FromProjectConversation("[PROJECT]", "[CONVERSATION]");
            // Make the request
            InitiatePhoneCallResponse response = await conversationsClient.InitiatePhoneCallAsync(conversation);
            // End snippet
        }
    }
}
