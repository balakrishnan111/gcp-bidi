/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1;

import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListHumanAgentAssistantsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListLocationsPagedResponse;

import com.google.api.gax.core.NoCredentialsProvider;
import com.google.api.gax.httpjson.GaxHttpJsonProperties;
import com.google.api.gax.httpjson.testing.MockHttpService;
import com.google.api.gax.rpc.ApiClientHeaderProvider;
import com.google.api.gax.rpc.ApiException;
import com.google.api.gax.rpc.ApiExceptionFactory;
import com.google.api.gax.rpc.InvalidArgumentException;
import com.google.api.gax.rpc.StatusCode;
import com.google.api.gax.rpc.testing.FakeStatusCode;
import com.google.cloud.dialogflow.v2beta1.stub.HttpJsonHumanAgentAssistantsStub;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.common.collect.Lists;
import com.google.protobuf.Any;
import com.google.protobuf.Empty;
import com.google.protobuf.FieldMask;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import javax.annotation.Generated;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

@Generated("by gapic-generator-java")
public class HumanAgentAssistantsClientHttpJsonTest {
  private static MockHttpService mockService;
  private static HumanAgentAssistantsClient client;

  @BeforeClass
  public static void startStaticServer() throws IOException {
    mockService =
        new MockHttpService(
            HttpJsonHumanAgentAssistantsStub.getMethodDescriptors(),
            HumanAgentAssistantsSettings.getDefaultEndpoint());
    HumanAgentAssistantsSettings settings =
        HumanAgentAssistantsSettings.newHttpJsonBuilder()
            .setTransportChannelProvider(
                HumanAgentAssistantsSettings.defaultHttpJsonTransportProviderBuilder()
                    .setHttpTransport(mockService)
                    .build())
            .setCredentialsProvider(NoCredentialsProvider.create())
            .build();
    client = HumanAgentAssistantsClient.create(settings);
  }

  @AfterClass
  public static void stopServer() {
    client.close();
  }

  @Before
  public void setUp() {}

  @After
  public void tearDown() throws Exception {
    mockService.reset();
  }

  @Test
  public void listHumanAgentAssistantsTest() throws Exception {
    HumanAgentAssistant responsesElement = HumanAgentAssistant.newBuilder().build();
    ListHumanAgentAssistantsResponse expectedResponse =
        ListHumanAgentAssistantsResponse.newBuilder()
            .setNextPageToken("")
            .addAllHumanAgentAssistants(Arrays.asList(responsesElement))
            .build();
    mockService.addResponse(expectedResponse);

    ListHumanAgentAssistantsRequest request =
        ListHumanAgentAssistantsRequest.newBuilder()
            .setParent("projects/project-2353")
            .setPageSize(883849137)
            .setPageToken("pageToken873572522")
            .build();

    ListHumanAgentAssistantsPagedResponse pagedListResponse =
        client.listHumanAgentAssistants(request);

    List<HumanAgentAssistant> resources = Lists.newArrayList(pagedListResponse.iterateAll());

    Assert.assertEquals(1, resources.size());
    Assert.assertEquals(expectedResponse.getHumanAgentAssistantsList().get(0), resources.get(0));

    List<String> actualRequests = mockService.getRequestPaths();
    Assert.assertEquals(1, actualRequests.size());

    String apiClientHeaderKey =
        mockService
            .getRequestHeaders()
            .get(ApiClientHeaderProvider.getDefaultApiClientHeaderKey())
            .iterator()
            .next();
    Assert.assertTrue(
        GaxHttpJsonProperties.getDefaultApiClientHeaderPattern()
            .matcher(apiClientHeaderKey)
            .matches());
  }

  @Test
  public void listHumanAgentAssistantsExceptionTest() throws Exception {
    ApiException exception =
        ApiExceptionFactory.createException(
            new Exception(), FakeStatusCode.of(StatusCode.Code.INVALID_ARGUMENT), false);
    mockService.addException(exception);

    try {
      ListHumanAgentAssistantsRequest request =
          ListHumanAgentAssistantsRequest.newBuilder()
              .setParent("projects/project-2353")
              .setPageSize(883849137)
              .setPageToken("pageToken873572522")
              .build();
      client.listHumanAgentAssistants(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void getHumanAgentAssistantTest() throws Exception {
    HumanAgentAssistant expectedResponse =
        HumanAgentAssistant.newBuilder()
            .setName("name3373707")
            .setDisplayName("displayName1714148973")
            .setArticleSuggestionConfig(ArticleSuggestionConfig.newBuilder().build())
            .setFaqAnswersConfig(FaqAnswersConfig.newBuilder().build())
            .setSmartReplyConfig(SmartReplyConfig.newBuilder().build())
            .setDialogflowAssistConfig(DialogflowAssistConfig.newBuilder().build())
            .build();
    mockService.addResponse(expectedResponse);

    GetHumanAgentAssistantRequest request =
        GetHumanAgentAssistantRequest.newBuilder()
            .setName("projects/project-7193/humanAgentAssistants/humanAgentAssistant-7193")
            .build();

    HumanAgentAssistant actualResponse = client.getHumanAgentAssistant(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<String> actualRequests = mockService.getRequestPaths();
    Assert.assertEquals(1, actualRequests.size());

    String apiClientHeaderKey =
        mockService
            .getRequestHeaders()
            .get(ApiClientHeaderProvider.getDefaultApiClientHeaderKey())
            .iterator()
            .next();
    Assert.assertTrue(
        GaxHttpJsonProperties.getDefaultApiClientHeaderPattern()
            .matcher(apiClientHeaderKey)
            .matches());
  }

  @Test
  public void getHumanAgentAssistantExceptionTest() throws Exception {
    ApiException exception =
        ApiExceptionFactory.createException(
            new Exception(), FakeStatusCode.of(StatusCode.Code.INVALID_ARGUMENT), false);
    mockService.addException(exception);

    try {
      GetHumanAgentAssistantRequest request =
          GetHumanAgentAssistantRequest.newBuilder()
              .setName("projects/project-7193/humanAgentAssistants/humanAgentAssistant-7193")
              .build();
      client.getHumanAgentAssistant(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void createHumanAgentAssistantTest() throws Exception {
    HumanAgentAssistant expectedResponse =
        HumanAgentAssistant.newBuilder()
            .setName("name3373707")
            .setDisplayName("displayName1714148973")
            .setArticleSuggestionConfig(ArticleSuggestionConfig.newBuilder().build())
            .setFaqAnswersConfig(FaqAnswersConfig.newBuilder().build())
            .setSmartReplyConfig(SmartReplyConfig.newBuilder().build())
            .setDialogflowAssistConfig(DialogflowAssistConfig.newBuilder().build())
            .build();
    mockService.addResponse(expectedResponse);

    CreateHumanAgentAssistantRequest request =
        CreateHumanAgentAssistantRequest.newBuilder()
            .setParent("projects/project-2353")
            .setHumanAgentAssistant(HumanAgentAssistant.newBuilder().build())
            .setBypassDeprecation(true)
            .build();

    HumanAgentAssistant actualResponse = client.createHumanAgentAssistant(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<String> actualRequests = mockService.getRequestPaths();
    Assert.assertEquals(1, actualRequests.size());

    String apiClientHeaderKey =
        mockService
            .getRequestHeaders()
            .get(ApiClientHeaderProvider.getDefaultApiClientHeaderKey())
            .iterator()
            .next();
    Assert.assertTrue(
        GaxHttpJsonProperties.getDefaultApiClientHeaderPattern()
            .matcher(apiClientHeaderKey)
            .matches());
  }

  @Test
  public void createHumanAgentAssistantExceptionTest() throws Exception {
    ApiException exception =
        ApiExceptionFactory.createException(
            new Exception(), FakeStatusCode.of(StatusCode.Code.INVALID_ARGUMENT), false);
    mockService.addException(exception);

    try {
      CreateHumanAgentAssistantRequest request =
          CreateHumanAgentAssistantRequest.newBuilder()
              .setParent("projects/project-2353")
              .setHumanAgentAssistant(HumanAgentAssistant.newBuilder().build())
              .setBypassDeprecation(true)
              .build();
      client.createHumanAgentAssistant(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void updateHumanAgentAssistantTest() throws Exception {
    HumanAgentAssistant expectedResponse =
        HumanAgentAssistant.newBuilder()
            .setName("name3373707")
            .setDisplayName("displayName1714148973")
            .setArticleSuggestionConfig(ArticleSuggestionConfig.newBuilder().build())
            .setFaqAnswersConfig(FaqAnswersConfig.newBuilder().build())
            .setSmartReplyConfig(SmartReplyConfig.newBuilder().build())
            .setDialogflowAssistConfig(DialogflowAssistConfig.newBuilder().build())
            .build();
    mockService.addResponse(expectedResponse);

    UpdateHumanAgentAssistantRequest request =
        UpdateHumanAgentAssistantRequest.newBuilder()
            .setHumanAgentAssistant(
                HumanAgentAssistant.newBuilder()
                    .setName("projects/project-7193/humanAgentAssistants/humanAgentAssistant-7193")
                    .setDisplayName("displayName1714148973")
                    .setArticleSuggestionConfig(ArticleSuggestionConfig.newBuilder().build())
                    .setFaqAnswersConfig(FaqAnswersConfig.newBuilder().build())
                    .setSmartReplyConfig(SmartReplyConfig.newBuilder().build())
                    .setDialogflowAssistConfig(DialogflowAssistConfig.newBuilder().build())
                    .build())
            .setUpdateMask(FieldMask.newBuilder().build())
            .build();

    HumanAgentAssistant actualResponse = client.updateHumanAgentAssistant(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<String> actualRequests = mockService.getRequestPaths();
    Assert.assertEquals(1, actualRequests.size());

    String apiClientHeaderKey =
        mockService
            .getRequestHeaders()
            .get(ApiClientHeaderProvider.getDefaultApiClientHeaderKey())
            .iterator()
            .next();
    Assert.assertTrue(
        GaxHttpJsonProperties.getDefaultApiClientHeaderPattern()
            .matcher(apiClientHeaderKey)
            .matches());
  }

  @Test
  public void updateHumanAgentAssistantExceptionTest() throws Exception {
    ApiException exception =
        ApiExceptionFactory.createException(
            new Exception(), FakeStatusCode.of(StatusCode.Code.INVALID_ARGUMENT), false);
    mockService.addException(exception);

    try {
      UpdateHumanAgentAssistantRequest request =
          UpdateHumanAgentAssistantRequest.newBuilder()
              .setHumanAgentAssistant(
                  HumanAgentAssistant.newBuilder()
                      .setName(
                          "projects/project-7193/humanAgentAssistants/humanAgentAssistant-7193")
                      .setDisplayName("displayName1714148973")
                      .setArticleSuggestionConfig(ArticleSuggestionConfig.newBuilder().build())
                      .setFaqAnswersConfig(FaqAnswersConfig.newBuilder().build())
                      .setSmartReplyConfig(SmartReplyConfig.newBuilder().build())
                      .setDialogflowAssistConfig(DialogflowAssistConfig.newBuilder().build())
                      .build())
              .setUpdateMask(FieldMask.newBuilder().build())
              .build();
      client.updateHumanAgentAssistant(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void deleteHumanAgentAssistantTest() throws Exception {
    Empty expectedResponse = Empty.newBuilder().build();
    mockService.addResponse(expectedResponse);

    DeleteHumanAgentAssistantRequest request =
        DeleteHumanAgentAssistantRequest.newBuilder()
            .setName("projects/project-7193/humanAgentAssistants/humanAgentAssistant-7193")
            .build();

    client.deleteHumanAgentAssistant(request);

    List<String> actualRequests = mockService.getRequestPaths();
    Assert.assertEquals(1, actualRequests.size());

    String apiClientHeaderKey =
        mockService
            .getRequestHeaders()
            .get(ApiClientHeaderProvider.getDefaultApiClientHeaderKey())
            .iterator()
            .next();
    Assert.assertTrue(
        GaxHttpJsonProperties.getDefaultApiClientHeaderPattern()
            .matcher(apiClientHeaderKey)
            .matches());
  }

  @Test
  public void deleteHumanAgentAssistantExceptionTest() throws Exception {
    ApiException exception =
        ApiExceptionFactory.createException(
            new Exception(), FakeStatusCode.of(StatusCode.Code.INVALID_ARGUMENT), false);
    mockService.addException(exception);

    try {
      DeleteHumanAgentAssistantRequest request =
          DeleteHumanAgentAssistantRequest.newBuilder()
              .setName("projects/project-7193/humanAgentAssistants/humanAgentAssistant-7193")
              .build();
      client.deleteHumanAgentAssistant(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void compileSuggestionsTest() throws Exception {
    CompileSuggestionsResponse expectedResponse =
        CompileSuggestionsResponse.newBuilder()
            .addAllSuggestions(new ArrayList<Suggestion>())
            .build();
    mockService.addResponse(expectedResponse);

    CompileSuggestionsRequest request =
        CompileSuggestionsRequest.newBuilder()
            .setName("projects/project-7193/humanAgentAssistants/humanAgentAssistant-7193")
            .addAllMessages(new ArrayList<Message>())
            .build();

    CompileSuggestionsResponse actualResponse = client.compileSuggestions(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<String> actualRequests = mockService.getRequestPaths();
    Assert.assertEquals(1, actualRequests.size());

    String apiClientHeaderKey =
        mockService
            .getRequestHeaders()
            .get(ApiClientHeaderProvider.getDefaultApiClientHeaderKey())
            .iterator()
            .next();
    Assert.assertTrue(
        GaxHttpJsonProperties.getDefaultApiClientHeaderPattern()
            .matcher(apiClientHeaderKey)
            .matches());
  }

  @Test
  public void compileSuggestionsExceptionTest() throws Exception {
    ApiException exception =
        ApiExceptionFactory.createException(
            new Exception(), FakeStatusCode.of(StatusCode.Code.INVALID_ARGUMENT), false);
    mockService.addException(exception);

    try {
      CompileSuggestionsRequest request =
          CompileSuggestionsRequest.newBuilder()
              .setName("projects/project-7193/humanAgentAssistants/humanAgentAssistant-7193")
              .addAllMessages(new ArrayList<Message>())
              .build();
      client.compileSuggestions(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void listLocationsTest() throws Exception {
    Location responsesElement = Location.newBuilder().build();
    ListLocationsResponse expectedResponse =
        ListLocationsResponse.newBuilder()
            .setNextPageToken("")
            .addAllLocations(Arrays.asList(responsesElement))
            .build();
    mockService.addResponse(expectedResponse);

    ListLocationsRequest request =
        ListLocationsRequest.newBuilder()
            .setName("projects/project-3664")
            .setFilter("filter-1274492040")
            .setPageSize(883849137)
            .setPageToken("pageToken873572522")
            .build();

    ListLocationsPagedResponse pagedListResponse = client.listLocations(request);

    List<Location> resources = Lists.newArrayList(pagedListResponse.iterateAll());

    Assert.assertEquals(1, resources.size());
    Assert.assertEquals(expectedResponse.getLocationsList().get(0), resources.get(0));

    List<String> actualRequests = mockService.getRequestPaths();
    Assert.assertEquals(1, actualRequests.size());

    String apiClientHeaderKey =
        mockService
            .getRequestHeaders()
            .get(ApiClientHeaderProvider.getDefaultApiClientHeaderKey())
            .iterator()
            .next();
    Assert.assertTrue(
        GaxHttpJsonProperties.getDefaultApiClientHeaderPattern()
            .matcher(apiClientHeaderKey)
            .matches());
  }

  @Test
  public void listLocationsExceptionTest() throws Exception {
    ApiException exception =
        ApiExceptionFactory.createException(
            new Exception(), FakeStatusCode.of(StatusCode.Code.INVALID_ARGUMENT), false);
    mockService.addException(exception);

    try {
      ListLocationsRequest request =
          ListLocationsRequest.newBuilder()
              .setName("projects/project-3664")
              .setFilter("filter-1274492040")
              .setPageSize(883849137)
              .setPageToken("pageToken873572522")
              .build();
      client.listLocations(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void getLocationTest() throws Exception {
    Location expectedResponse =
        Location.newBuilder()
            .setName("name3373707")
            .setLocationId("locationId1541836720")
            .setDisplayName("displayName1714148973")
            .putAllLabels(new HashMap<String, String>())
            .setMetadata(Any.newBuilder().build())
            .build();
    mockService.addResponse(expectedResponse);

    GetLocationRequest request =
        GetLocationRequest.newBuilder()
            .setName("projects/project-9062/locations/location-9062")
            .build();

    Location actualResponse = client.getLocation(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<String> actualRequests = mockService.getRequestPaths();
    Assert.assertEquals(1, actualRequests.size());

    String apiClientHeaderKey =
        mockService
            .getRequestHeaders()
            .get(ApiClientHeaderProvider.getDefaultApiClientHeaderKey())
            .iterator()
            .next();
    Assert.assertTrue(
        GaxHttpJsonProperties.getDefaultApiClientHeaderPattern()
            .matcher(apiClientHeaderKey)
            .matches());
  }

  @Test
  public void getLocationExceptionTest() throws Exception {
    ApiException exception =
        ApiExceptionFactory.createException(
            new Exception(), FakeStatusCode.of(StatusCode.Code.INVALID_ARGUMENT), false);
    mockService.addException(exception);

    try {
      GetLocationRequest request =
          GetLocationRequest.newBuilder()
              .setName("projects/project-9062/locations/location-9062")
              .build();
      client.getLocation(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }
}
