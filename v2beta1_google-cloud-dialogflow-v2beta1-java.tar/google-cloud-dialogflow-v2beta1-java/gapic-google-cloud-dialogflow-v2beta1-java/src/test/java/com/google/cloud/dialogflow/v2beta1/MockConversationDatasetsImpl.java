/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1;

import com.google.api.core.BetaApi;
import com.google.cloud.dialogflow.v2beta1.ConversationDatasetsGrpc.ConversationDatasetsImplBase;
import com.google.longrunning.Operation;
import com.google.protobuf.AbstractMessage;
import com.google.protobuf.Empty;
import io.grpc.stub.StreamObserver;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import javax.annotation.Generated;

@BetaApi
@Generated("by gapic-generator-java")
public class MockConversationDatasetsImpl extends ConversationDatasetsImplBase {
  private List<AbstractMessage> requests;
  private Queue<Object> responses;

  public MockConversationDatasetsImpl() {
    requests = new ArrayList<>();
    responses = new LinkedList<>();
  }

  public List<AbstractMessage> getRequests() {
    return requests;
  }

  public void addResponse(AbstractMessage response) {
    responses.add(response);
  }

  public void setResponses(List<AbstractMessage> responses) {
    this.responses = new LinkedList<Object>(responses);
  }

  public void addException(Exception exception) {
    responses.add(exception);
  }

  public void reset() {
    requests = new ArrayList<>();
    responses = new LinkedList<>();
  }

  @Override
  public void createConversationDataset(
      CreateConversationDatasetRequest request, StreamObserver<Operation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Operation) {
      requests.add(request);
      responseObserver.onNext(((Operation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method CreateConversationDataset, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Operation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void getConversationDataset(
      GetConversationDatasetRequest request, StreamObserver<ConversationDataset> responseObserver) {
    Object response = responses.poll();
    if (response instanceof ConversationDataset) {
      requests.add(request);
      responseObserver.onNext(((ConversationDataset) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method GetConversationDataset, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  ConversationDataset.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void listConversationDatasets(
      ListConversationDatasetsRequest request,
      StreamObserver<ListConversationDatasetsResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof ListConversationDatasetsResponse) {
      requests.add(request);
      responseObserver.onNext(((ListConversationDatasetsResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ListConversationDatasets, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  ListConversationDatasetsResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void deleteConversationDataset(
      DeleteConversationDatasetRequest request, StreamObserver<Operation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Operation) {
      requests.add(request);
      responseObserver.onNext(((Operation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method DeleteConversationDataset, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Operation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void getAnnotatedConversationDataset(
      GetAnnotatedConversationDatasetRequest request,
      StreamObserver<AnnotatedConversationDataset> responseObserver) {
    Object response = responses.poll();
    if (response instanceof AnnotatedConversationDataset) {
      requests.add(request);
      responseObserver.onNext(((AnnotatedConversationDataset) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method GetAnnotatedConversationDataset, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  AnnotatedConversationDataset.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void listAnnotatedConversationDatasets(
      ListAnnotatedConversationDatasetsRequest request,
      StreamObserver<ListAnnotatedConversationDatasetsResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof ListAnnotatedConversationDatasetsResponse) {
      requests.add(request);
      responseObserver.onNext(((ListAnnotatedConversationDatasetsResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ListAnnotatedConversationDatasets, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  ListAnnotatedConversationDatasetsResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void deleteAnnotatedConversationDataset(
      DeleteAnnotatedConversationDatasetRequest request, StreamObserver<Empty> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Empty) {
      requests.add(request);
      responseObserver.onNext(((Empty) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method DeleteAnnotatedConversationDataset, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Empty.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void importConversationData(
      ImportConversationDataRequest request, StreamObserver<Operation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Operation) {
      requests.add(request);
      responseObserver.onNext(((Operation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ImportConversationData, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Operation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void labelConversation(
      LabelConversationRequest request, StreamObserver<Operation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Operation) {
      requests.add(request);
      responseObserver.onNext(((Operation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method LabelConversation, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Operation.class.getName(),
                  Exception.class.getName())));
    }
  }
}
