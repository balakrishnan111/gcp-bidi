/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1;

import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListHumanAgentAssistantsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListLocationsPagedResponse;

import com.google.api.gax.core.NoCredentialsProvider;
import com.google.api.gax.grpc.GaxGrpcProperties;
import com.google.api.gax.grpc.testing.LocalChannelProvider;
import com.google.api.gax.grpc.testing.MockGrpcService;
import com.google.api.gax.grpc.testing.MockServiceHelper;
import com.google.api.gax.rpc.ApiClientHeaderProvider;
import com.google.api.gax.rpc.InvalidArgumentException;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.common.collect.Lists;
import com.google.protobuf.AbstractMessage;
import com.google.protobuf.Any;
import com.google.protobuf.Empty;
import com.google.protobuf.FieldMask;
import io.grpc.StatusRuntimeException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import javax.annotation.Generated;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

@Generated("by gapic-generator-java")
public class HumanAgentAssistantsClientTest {
  private static MockHumanAgentAssistants mockHumanAgentAssistants;
  private static MockLocations mockLocations;
  private static MockServiceHelper mockServiceHelper;
  private LocalChannelProvider channelProvider;
  private HumanAgentAssistantsClient client;

  @BeforeClass
  public static void startStaticServer() {
    mockHumanAgentAssistants = new MockHumanAgentAssistants();
    mockLocations = new MockLocations();
    mockServiceHelper =
        new MockServiceHelper(
            UUID.randomUUID().toString(),
            Arrays.<MockGrpcService>asList(mockHumanAgentAssistants, mockLocations));
    mockServiceHelper.start();
  }

  @AfterClass
  public static void stopServer() {
    mockServiceHelper.stop();
  }

  @Before
  public void setUp() throws IOException {
    mockServiceHelper.reset();
    channelProvider = mockServiceHelper.createChannelProvider();
    HumanAgentAssistantsSettings settings =
        HumanAgentAssistantsSettings.newBuilder()
            .setTransportChannelProvider(channelProvider)
            .setCredentialsProvider(NoCredentialsProvider.create())
            .build();
    client = HumanAgentAssistantsClient.create(settings);
  }

  @After
  public void tearDown() throws Exception {
    client.close();
  }

  @Test
  public void listHumanAgentAssistantsTest() throws Exception {
    HumanAgentAssistant responsesElement = HumanAgentAssistant.newBuilder().build();
    ListHumanAgentAssistantsResponse expectedResponse =
        ListHumanAgentAssistantsResponse.newBuilder()
            .setNextPageToken("")
            .addAllHumanAgentAssistants(Arrays.asList(responsesElement))
            .build();
    mockHumanAgentAssistants.addResponse(expectedResponse);

    ListHumanAgentAssistantsRequest request =
        ListHumanAgentAssistantsRequest.newBuilder()
            .setParent("parent-995424086")
            .setPageSize(883849137)
            .setPageToken("pageToken873572522")
            .build();

    ListHumanAgentAssistantsPagedResponse pagedListResponse =
        client.listHumanAgentAssistants(request);

    List<HumanAgentAssistant> resources = Lists.newArrayList(pagedListResponse.iterateAll());

    Assert.assertEquals(1, resources.size());
    Assert.assertEquals(expectedResponse.getHumanAgentAssistantsList().get(0), resources.get(0));

    List<AbstractMessage> actualRequests = mockHumanAgentAssistants.getRequests();
    Assert.assertEquals(1, actualRequests.size());
    ListHumanAgentAssistantsRequest actualRequest =
        ((ListHumanAgentAssistantsRequest) actualRequests.get(0));

    Assert.assertEquals(request.getParent(), actualRequest.getParent());
    Assert.assertEquals(request.getPageSize(), actualRequest.getPageSize());
    Assert.assertEquals(request.getPageToken(), actualRequest.getPageToken());
    Assert.assertTrue(
        channelProvider.isHeaderSent(
            ApiClientHeaderProvider.getDefaultApiClientHeaderKey(),
            GaxGrpcProperties.getDefaultApiClientHeaderPattern()));
  }

  @Test
  public void listHumanAgentAssistantsExceptionTest() throws Exception {
    StatusRuntimeException exception = new StatusRuntimeException(io.grpc.Status.INVALID_ARGUMENT);
    mockHumanAgentAssistants.addException(exception);

    try {
      ListHumanAgentAssistantsRequest request =
          ListHumanAgentAssistantsRequest.newBuilder()
              .setParent("parent-995424086")
              .setPageSize(883849137)
              .setPageToken("pageToken873572522")
              .build();
      client.listHumanAgentAssistants(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void getHumanAgentAssistantTest() throws Exception {
    HumanAgentAssistant expectedResponse =
        HumanAgentAssistant.newBuilder()
            .setName("name3373707")
            .setDisplayName("displayName1714148973")
            .setArticleSuggestionConfig(ArticleSuggestionConfig.newBuilder().build())
            .setFaqAnswersConfig(FaqAnswersConfig.newBuilder().build())
            .setSmartReplyConfig(SmartReplyConfig.newBuilder().build())
            .setDialogflowAssistConfig(DialogflowAssistConfig.newBuilder().build())
            .build();
    mockHumanAgentAssistants.addResponse(expectedResponse);

    GetHumanAgentAssistantRequest request =
        GetHumanAgentAssistantRequest.newBuilder().setName("name3373707").build();

    HumanAgentAssistant actualResponse = client.getHumanAgentAssistant(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<AbstractMessage> actualRequests = mockHumanAgentAssistants.getRequests();
    Assert.assertEquals(1, actualRequests.size());
    GetHumanAgentAssistantRequest actualRequest =
        ((GetHumanAgentAssistantRequest) actualRequests.get(0));

    Assert.assertEquals(request.getName(), actualRequest.getName());
    Assert.assertTrue(
        channelProvider.isHeaderSent(
            ApiClientHeaderProvider.getDefaultApiClientHeaderKey(),
            GaxGrpcProperties.getDefaultApiClientHeaderPattern()));
  }

  @Test
  public void getHumanAgentAssistantExceptionTest() throws Exception {
    StatusRuntimeException exception = new StatusRuntimeException(io.grpc.Status.INVALID_ARGUMENT);
    mockHumanAgentAssistants.addException(exception);

    try {
      GetHumanAgentAssistantRequest request =
          GetHumanAgentAssistantRequest.newBuilder().setName("name3373707").build();
      client.getHumanAgentAssistant(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void createHumanAgentAssistantTest() throws Exception {
    HumanAgentAssistant expectedResponse =
        HumanAgentAssistant.newBuilder()
            .setName("name3373707")
            .setDisplayName("displayName1714148973")
            .setArticleSuggestionConfig(ArticleSuggestionConfig.newBuilder().build())
            .setFaqAnswersConfig(FaqAnswersConfig.newBuilder().build())
            .setSmartReplyConfig(SmartReplyConfig.newBuilder().build())
            .setDialogflowAssistConfig(DialogflowAssistConfig.newBuilder().build())
            .build();
    mockHumanAgentAssistants.addResponse(expectedResponse);

    CreateHumanAgentAssistantRequest request =
        CreateHumanAgentAssistantRequest.newBuilder()
            .setParent("parent-995424086")
            .setHumanAgentAssistant(HumanAgentAssistant.newBuilder().build())
            .setBypassDeprecation(true)
            .build();

    HumanAgentAssistant actualResponse = client.createHumanAgentAssistant(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<AbstractMessage> actualRequests = mockHumanAgentAssistants.getRequests();
    Assert.assertEquals(1, actualRequests.size());
    CreateHumanAgentAssistantRequest actualRequest =
        ((CreateHumanAgentAssistantRequest) actualRequests.get(0));

    Assert.assertEquals(request.getParent(), actualRequest.getParent());
    Assert.assertEquals(request.getHumanAgentAssistant(), actualRequest.getHumanAgentAssistant());
    Assert.assertEquals(request.getBypassDeprecation(), actualRequest.getBypassDeprecation());
    Assert.assertTrue(
        channelProvider.isHeaderSent(
            ApiClientHeaderProvider.getDefaultApiClientHeaderKey(),
            GaxGrpcProperties.getDefaultApiClientHeaderPattern()));
  }

  @Test
  public void createHumanAgentAssistantExceptionTest() throws Exception {
    StatusRuntimeException exception = new StatusRuntimeException(io.grpc.Status.INVALID_ARGUMENT);
    mockHumanAgentAssistants.addException(exception);

    try {
      CreateHumanAgentAssistantRequest request =
          CreateHumanAgentAssistantRequest.newBuilder()
              .setParent("parent-995424086")
              .setHumanAgentAssistant(HumanAgentAssistant.newBuilder().build())
              .setBypassDeprecation(true)
              .build();
      client.createHumanAgentAssistant(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void updateHumanAgentAssistantTest() throws Exception {
    HumanAgentAssistant expectedResponse =
        HumanAgentAssistant.newBuilder()
            .setName("name3373707")
            .setDisplayName("displayName1714148973")
            .setArticleSuggestionConfig(ArticleSuggestionConfig.newBuilder().build())
            .setFaqAnswersConfig(FaqAnswersConfig.newBuilder().build())
            .setSmartReplyConfig(SmartReplyConfig.newBuilder().build())
            .setDialogflowAssistConfig(DialogflowAssistConfig.newBuilder().build())
            .build();
    mockHumanAgentAssistants.addResponse(expectedResponse);

    UpdateHumanAgentAssistantRequest request =
        UpdateHumanAgentAssistantRequest.newBuilder()
            .setHumanAgentAssistant(HumanAgentAssistant.newBuilder().build())
            .setUpdateMask(FieldMask.newBuilder().build())
            .build();

    HumanAgentAssistant actualResponse = client.updateHumanAgentAssistant(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<AbstractMessage> actualRequests = mockHumanAgentAssistants.getRequests();
    Assert.assertEquals(1, actualRequests.size());
    UpdateHumanAgentAssistantRequest actualRequest =
        ((UpdateHumanAgentAssistantRequest) actualRequests.get(0));

    Assert.assertEquals(request.getHumanAgentAssistant(), actualRequest.getHumanAgentAssistant());
    Assert.assertEquals(request.getUpdateMask(), actualRequest.getUpdateMask());
    Assert.assertTrue(
        channelProvider.isHeaderSent(
            ApiClientHeaderProvider.getDefaultApiClientHeaderKey(),
            GaxGrpcProperties.getDefaultApiClientHeaderPattern()));
  }

  @Test
  public void updateHumanAgentAssistantExceptionTest() throws Exception {
    StatusRuntimeException exception = new StatusRuntimeException(io.grpc.Status.INVALID_ARGUMENT);
    mockHumanAgentAssistants.addException(exception);

    try {
      UpdateHumanAgentAssistantRequest request =
          UpdateHumanAgentAssistantRequest.newBuilder()
              .setHumanAgentAssistant(HumanAgentAssistant.newBuilder().build())
              .setUpdateMask(FieldMask.newBuilder().build())
              .build();
      client.updateHumanAgentAssistant(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void deleteHumanAgentAssistantTest() throws Exception {
    Empty expectedResponse = Empty.newBuilder().build();
    mockHumanAgentAssistants.addResponse(expectedResponse);

    DeleteHumanAgentAssistantRequest request =
        DeleteHumanAgentAssistantRequest.newBuilder().setName("name3373707").build();

    client.deleteHumanAgentAssistant(request);

    List<AbstractMessage> actualRequests = mockHumanAgentAssistants.getRequests();
    Assert.assertEquals(1, actualRequests.size());
    DeleteHumanAgentAssistantRequest actualRequest =
        ((DeleteHumanAgentAssistantRequest) actualRequests.get(0));

    Assert.assertEquals(request.getName(), actualRequest.getName());
    Assert.assertTrue(
        channelProvider.isHeaderSent(
            ApiClientHeaderProvider.getDefaultApiClientHeaderKey(),
            GaxGrpcProperties.getDefaultApiClientHeaderPattern()));
  }

  @Test
  public void deleteHumanAgentAssistantExceptionTest() throws Exception {
    StatusRuntimeException exception = new StatusRuntimeException(io.grpc.Status.INVALID_ARGUMENT);
    mockHumanAgentAssistants.addException(exception);

    try {
      DeleteHumanAgentAssistantRequest request =
          DeleteHumanAgentAssistantRequest.newBuilder().setName("name3373707").build();
      client.deleteHumanAgentAssistant(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void compileSuggestionsTest() throws Exception {
    CompileSuggestionsResponse expectedResponse =
        CompileSuggestionsResponse.newBuilder()
            .addAllSuggestions(new ArrayList<Suggestion>())
            .build();
    mockHumanAgentAssistants.addResponse(expectedResponse);

    CompileSuggestionsRequest request =
        CompileSuggestionsRequest.newBuilder()
            .setName("name3373707")
            .addAllMessages(new ArrayList<Message>())
            .build();

    CompileSuggestionsResponse actualResponse = client.compileSuggestions(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<AbstractMessage> actualRequests = mockHumanAgentAssistants.getRequests();
    Assert.assertEquals(1, actualRequests.size());
    CompileSuggestionsRequest actualRequest = ((CompileSuggestionsRequest) actualRequests.get(0));

    Assert.assertEquals(request.getName(), actualRequest.getName());
    Assert.assertEquals(request.getMessagesList(), actualRequest.getMessagesList());
    Assert.assertTrue(
        channelProvider.isHeaderSent(
            ApiClientHeaderProvider.getDefaultApiClientHeaderKey(),
            GaxGrpcProperties.getDefaultApiClientHeaderPattern()));
  }

  @Test
  public void compileSuggestionsExceptionTest() throws Exception {
    StatusRuntimeException exception = new StatusRuntimeException(io.grpc.Status.INVALID_ARGUMENT);
    mockHumanAgentAssistants.addException(exception);

    try {
      CompileSuggestionsRequest request =
          CompileSuggestionsRequest.newBuilder()
              .setName("name3373707")
              .addAllMessages(new ArrayList<Message>())
              .build();
      client.compileSuggestions(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void listLocationsTest() throws Exception {
    Location responsesElement = Location.newBuilder().build();
    ListLocationsResponse expectedResponse =
        ListLocationsResponse.newBuilder()
            .setNextPageToken("")
            .addAllLocations(Arrays.asList(responsesElement))
            .build();
    mockLocations.addResponse(expectedResponse);

    ListLocationsRequest request =
        ListLocationsRequest.newBuilder()
            .setName("name3373707")
            .setFilter("filter-1274492040")
            .setPageSize(883849137)
            .setPageToken("pageToken873572522")
            .build();

    ListLocationsPagedResponse pagedListResponse = client.listLocations(request);

    List<Location> resources = Lists.newArrayList(pagedListResponse.iterateAll());

    Assert.assertEquals(1, resources.size());
    Assert.assertEquals(expectedResponse.getLocationsList().get(0), resources.get(0));

    List<AbstractMessage> actualRequests = mockLocations.getRequests();
    Assert.assertEquals(1, actualRequests.size());
    ListLocationsRequest actualRequest = ((ListLocationsRequest) actualRequests.get(0));

    Assert.assertEquals(request.getName(), actualRequest.getName());
    Assert.assertEquals(request.getFilter(), actualRequest.getFilter());
    Assert.assertEquals(request.getPageSize(), actualRequest.getPageSize());
    Assert.assertEquals(request.getPageToken(), actualRequest.getPageToken());
    Assert.assertTrue(
        channelProvider.isHeaderSent(
            ApiClientHeaderProvider.getDefaultApiClientHeaderKey(),
            GaxGrpcProperties.getDefaultApiClientHeaderPattern()));
  }

  @Test
  public void listLocationsExceptionTest() throws Exception {
    StatusRuntimeException exception = new StatusRuntimeException(io.grpc.Status.INVALID_ARGUMENT);
    mockLocations.addException(exception);

    try {
      ListLocationsRequest request =
          ListLocationsRequest.newBuilder()
              .setName("name3373707")
              .setFilter("filter-1274492040")
              .setPageSize(883849137)
              .setPageToken("pageToken873572522")
              .build();
      client.listLocations(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }

  @Test
  public void getLocationTest() throws Exception {
    Location expectedResponse =
        Location.newBuilder()
            .setName("name3373707")
            .setLocationId("locationId1541836720")
            .setDisplayName("displayName1714148973")
            .putAllLabels(new HashMap<String, String>())
            .setMetadata(Any.newBuilder().build())
            .build();
    mockLocations.addResponse(expectedResponse);

    GetLocationRequest request = GetLocationRequest.newBuilder().setName("name3373707").build();

    Location actualResponse = client.getLocation(request);
    Assert.assertEquals(expectedResponse, actualResponse);

    List<AbstractMessage> actualRequests = mockLocations.getRequests();
    Assert.assertEquals(1, actualRequests.size());
    GetLocationRequest actualRequest = ((GetLocationRequest) actualRequests.get(0));

    Assert.assertEquals(request.getName(), actualRequest.getName());
    Assert.assertTrue(
        channelProvider.isHeaderSent(
            ApiClientHeaderProvider.getDefaultApiClientHeaderKey(),
            GaxGrpcProperties.getDefaultApiClientHeaderPattern()));
  }

  @Test
  public void getLocationExceptionTest() throws Exception {
    StatusRuntimeException exception = new StatusRuntimeException(io.grpc.Status.INVALID_ARGUMENT);
    mockLocations.addException(exception);

    try {
      GetLocationRequest request = GetLocationRequest.newBuilder().setName("name3373707").build();
      client.getLocation(request);
      Assert.fail("No exception raised");
    } catch (InvalidArgumentException e) {
      // Expected exception.
    }
  }
}
