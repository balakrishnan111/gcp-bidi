/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1;

import com.google.api.core.BetaApi;
import com.google.cloud.dialogflow.v2beta1.ConversationsGrpc.ConversationsImplBase;
import com.google.longrunning.Operation;
import com.google.protobuf.AbstractMessage;
import com.google.protobuf.Empty;
import io.grpc.stub.StreamObserver;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import javax.annotation.Generated;

@BetaApi
@Generated("by gapic-generator-java")
public class MockConversationsImpl extends ConversationsImplBase {
  private List<AbstractMessage> requests;
  private Queue<Object> responses;

  public MockConversationsImpl() {
    requests = new ArrayList<>();
    responses = new LinkedList<>();
  }

  public List<AbstractMessage> getRequests() {
    return requests;
  }

  public void addResponse(AbstractMessage response) {
    responses.add(response);
  }

  public void setResponses(List<AbstractMessage> responses) {
    this.responses = new LinkedList<Object>(responses);
  }

  public void addException(Exception exception) {
    responses.add(exception);
  }

  public void reset() {
    requests = new ArrayList<>();
    responses = new LinkedList<>();
  }

  @Override
  public void createConversation(
      CreateConversationRequest request, StreamObserver<Conversation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Conversation) {
      requests.add(request);
      responseObserver.onNext(((Conversation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method CreateConversation, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Conversation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void listConversations(
      ListConversationsRequest request,
      StreamObserver<ListConversationsResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof ListConversationsResponse) {
      requests.add(request);
      responseObserver.onNext(((ListConversationsResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ListConversations, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  ListConversationsResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void getConversation(
      GetConversationRequest request, StreamObserver<Conversation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Conversation) {
      requests.add(request);
      responseObserver.onNext(((Conversation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method GetConversation, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Conversation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void addConversationPhoneNumber(
      AddConversationPhoneNumberRequest request,
      StreamObserver<ConversationPhoneNumber> responseObserver) {
    Object response = responses.poll();
    if (response instanceof ConversationPhoneNumber) {
      requests.add(request);
      responseObserver.onNext(((ConversationPhoneNumber) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method AddConversationPhoneNumber, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  ConversationPhoneNumber.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void activateConversation(
      ActivateConversationRequest request, StreamObserver<Conversation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Conversation) {
      requests.add(request);
      responseObserver.onNext(((Conversation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ActivateConversation, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Conversation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void deactivateConversation(
      DeactivateConversationRequest request, StreamObserver<Conversation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Conversation) {
      requests.add(request);
      responseObserver.onNext(((Conversation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method DeactivateConversation, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Conversation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void completeConversation(
      CompleteConversationRequest request, StreamObserver<Conversation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Conversation) {
      requests.add(request);
      responseObserver.onNext(((Conversation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method CompleteConversation, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Conversation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void updateConversation(
      UpdateConversationRequest request, StreamObserver<Conversation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Conversation) {
      requests.add(request);
      responseObserver.onNext(((Conversation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method UpdateConversation, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Conversation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void ingestContextReferences(
      IngestContextReferencesRequest request,
      StreamObserver<IngestContextReferencesResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof IngestContextReferencesResponse) {
      requests.add(request);
      responseObserver.onNext(((IngestContextReferencesResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method IngestContextReferences, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  IngestContextReferencesResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void createCallMatcher(
      CreateCallMatcherRequest request, StreamObserver<CallMatcher> responseObserver) {
    Object response = responses.poll();
    if (response instanceof CallMatcher) {
      requests.add(request);
      responseObserver.onNext(((CallMatcher) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method CreateCallMatcher, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  CallMatcher.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void listCallMatchers(
      ListCallMatchersRequest request, StreamObserver<ListCallMatchersResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof ListCallMatchersResponse) {
      requests.add(request);
      responseObserver.onNext(((ListCallMatchersResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ListCallMatchers, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  ListCallMatchersResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void deleteCallMatcher(
      DeleteCallMatcherRequest request, StreamObserver<Empty> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Empty) {
      requests.add(request);
      responseObserver.onNext(((Empty) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method DeleteCallMatcher, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Empty.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void batchCreateMessages(
      BatchCreateMessagesRequest request,
      StreamObserver<BatchCreateMessagesResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof BatchCreateMessagesResponse) {
      requests.add(request);
      responseObserver.onNext(((BatchCreateMessagesResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method BatchCreateMessages, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  BatchCreateMessagesResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void listMessages(
      ListMessagesRequest request, StreamObserver<ListMessagesResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof ListMessagesResponse) {
      requests.add(request);
      responseObserver.onNext(((ListMessagesResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ListMessages, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  ListMessagesResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void exportMessages(
      ExportMessagesRequest request, StreamObserver<Operation> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Operation) {
      requests.add(request);
      responseObserver.onNext(((Operation) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ExportMessages, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Operation.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void suggestConversationSummary(
      SuggestConversationSummaryRequest request,
      StreamObserver<SuggestConversationSummaryResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof SuggestConversationSummaryResponse) {
      requests.add(request);
      responseObserver.onNext(((SuggestConversationSummaryResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method SuggestConversationSummary, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  SuggestConversationSummaryResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void generateStatelessSummary(
      GenerateStatelessSummaryRequest request,
      StreamObserver<GenerateStatelessSummaryResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof GenerateStatelessSummaryResponse) {
      requests.add(request);
      responseObserver.onNext(((GenerateStatelessSummaryResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method GenerateStatelessSummary, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  GenerateStatelessSummaryResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void generateStatelessSuggestion(
      GenerateStatelessSuggestionRequest request,
      StreamObserver<GenerateStatelessSuggestionResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof GenerateStatelessSuggestionResponse) {
      requests.add(request);
      responseObserver.onNext(((GenerateStatelessSuggestionResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method GenerateStatelessSuggestion, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  GenerateStatelessSuggestionResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void suggestConversationKeyMoments(
      SuggestConversationKeyMomentsRequest request,
      StreamObserver<SuggestConversationKeyMomentsResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof SuggestConversationKeyMomentsResponse) {
      requests.add(request);
      responseObserver.onNext(((SuggestConversationKeyMomentsResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method SuggestConversationKeyMoments, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  SuggestConversationKeyMomentsResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void searchArticles(
      SearchArticlesRequest request, StreamObserver<SearchArticlesResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof SearchArticlesResponse) {
      requests.add(request);
      responseObserver.onNext(((SearchArticlesResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method SearchArticles, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  SearchArticlesResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void listPastCallCompanionEvents(
      ListPastCallCompanionEventsRequest request,
      StreamObserver<ListPastCallCompanionEventsResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof ListPastCallCompanionEventsResponse) {
      requests.add(request);
      responseObserver.onNext(((ListPastCallCompanionEventsResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method ListPastCallCompanionEvents, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  ListPastCallCompanionEventsResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void streamingListUpcomingCallCompanionEvents(
      StreamingListUpcomingCallCompanionEventsRequest request,
      StreamObserver<StreamingListUpcomingCallCompanionEventsResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof StreamingListUpcomingCallCompanionEventsResponse) {
      requests.add(request);
      responseObserver.onNext(((StreamingListUpcomingCallCompanionEventsResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method StreamingListUpcomingCallCompanionEvents, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  StreamingListUpcomingCallCompanionEventsResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void injectCallCompanionUserInput(
      InjectCallCompanionUserInputRequest request,
      StreamObserver<InjectCallCompanionUserInputResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof InjectCallCompanionUserInputResponse) {
      requests.add(request);
      responseObserver.onNext(((InjectCallCompanionUserInputResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method InjectCallCompanionUserInput, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  InjectCallCompanionUserInputResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void streamingListCallCompanionEvents(
      StreamingListCallCompanionEventsRequest request,
      StreamObserver<StreamingListCallCompanionEventsResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof StreamingListCallCompanionEventsResponse) {
      requests.add(request);
      responseObserver.onNext(((StreamingListCallCompanionEventsResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method StreamingListCallCompanionEvents, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  StreamingListCallCompanionEventsResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void injectCallCompanionInput(
      InjectCallCompanionInputRequest request,
      StreamObserver<InjectCallCompanionInputResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof InjectCallCompanionInputResponse) {
      requests.add(request);
      responseObserver.onNext(((InjectCallCompanionInputResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method InjectCallCompanionInput, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  InjectCallCompanionInputResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void initializeCallCompanion(
      InitializeCallCompanionRequest request, StreamObserver<Empty> responseObserver) {
    Object response = responses.poll();
    if (response instanceof Empty) {
      requests.add(request);
      responseObserver.onNext(((Empty) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method InitializeCallCompanion, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  Empty.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void getCallCompanionSettings(
      GetCallCompanionSettingsRequest request,
      StreamObserver<CallCompanionSettings> responseObserver) {
    Object response = responses.poll();
    if (response instanceof CallCompanionSettings) {
      requests.add(request);
      responseObserver.onNext(((CallCompanionSettings) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method GetCallCompanionSettings, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  CallCompanionSettings.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void searchKnowledge(
      SearchKnowledgeRequest request, StreamObserver<SearchKnowledgeResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof SearchKnowledgeResponse) {
      requests.add(request);
      responseObserver.onNext(((SearchKnowledgeResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method SearchKnowledge, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  SearchKnowledgeResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void generateSuggestions(
      GenerateSuggestionsRequest request,
      StreamObserver<GenerateSuggestionsResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof GenerateSuggestionsResponse) {
      requests.add(request);
      responseObserver.onNext(((GenerateSuggestionsResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method GenerateSuggestions, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  GenerateSuggestionsResponse.class.getName(),
                  Exception.class.getName())));
    }
  }

  @Override
  public void initiatePhoneCall(
      InitiatePhoneCallRequest request,
      StreamObserver<InitiatePhoneCallResponse> responseObserver) {
    Object response = responses.poll();
    if (response instanceof InitiatePhoneCallResponse) {
      requests.add(request);
      responseObserver.onNext(((InitiatePhoneCallResponse) response));
      responseObserver.onCompleted();
    } else if (response instanceof Exception) {
      responseObserver.onError(((Exception) response));
    } else {
      responseObserver.onError(
          new IllegalArgumentException(
              String.format(
                  "Unrecognized response type %s for method InitiatePhoneCall, expected %s or %s",
                  response == null ? "null" : response.getClass().getName(),
                  InitiatePhoneCallResponse.class.getName(),
                  Exception.class.getName())));
    }
  }
}
