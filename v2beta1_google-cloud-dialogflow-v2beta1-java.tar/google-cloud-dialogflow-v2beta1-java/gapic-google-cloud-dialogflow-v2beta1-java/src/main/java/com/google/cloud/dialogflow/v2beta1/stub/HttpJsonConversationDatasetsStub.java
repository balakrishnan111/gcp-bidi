/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.ConversationDatasetsClient.ListAnnotatedConversationDatasetsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationDatasetsClient.ListConversationDatasetsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationDatasetsClient.ListLocationsPagedResponse;

import com.google.api.HttpRule;
import com.google.api.core.BetaApi;
import com.google.api.core.InternalApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.core.BackgroundResourceAggregation;
import com.google.api.gax.httpjson.ApiMethodDescriptor;
import com.google.api.gax.httpjson.HttpJsonCallSettings;
import com.google.api.gax.httpjson.HttpJsonOperationSnapshot;
import com.google.api.gax.httpjson.HttpJsonStubCallableFactory;
import com.google.api.gax.httpjson.ProtoMessageRequestFormatter;
import com.google.api.gax.httpjson.ProtoMessageResponseParser;
import com.google.api.gax.httpjson.ProtoRestSerializer;
import com.google.api.gax.httpjson.longrunning.stub.HttpJsonOperationsStub;
import com.google.api.gax.longrunning.OperationSnapshot;
import com.google.api.gax.rpc.ClientContext;
import com.google.api.gax.rpc.OperationCallable;
import com.google.api.gax.rpc.RequestParamsBuilder;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset;
import com.google.cloud.dialogflow.v2beta1.ConversationDataset;
import com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata;
import com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata;
import com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest;
import com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest;
import com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest;
import com.google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata;
import com.google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse;
import com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest;
import com.google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata;
import com.google.cloud.dialogflow.v2beta1.LabelConversationRequest;
import com.google.cloud.dialogflow.v2beta1.LabelConversationResponse;
import com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest;
import com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse;
import com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest;
import com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.common.collect.ImmutableMap;
import com.google.longrunning.Operation;
import com.google.protobuf.Empty;
import com.google.protobuf.TypeRegistry;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * REST stub implementation for the ConversationDatasets service API.
 *
 * <p>This class is for advanced usage and reflects the underlying API directly.
 */
@BetaApi
@Generated("by gapic-generator-java")
public class HttpJsonConversationDatasetsStub extends ConversationDatasetsStub {
  private static final TypeRegistry typeRegistry =
      TypeRegistry.newBuilder()
          .add(Empty.getDescriptor())
          .add(ImportConversationDataOperationMetadata.getDescriptor())
          .add(LabelConversationResponse.getDescriptor())
          .add(DeleteConversationDatasetOperationMetadata.getDescriptor())
          .add(ConversationDataset.getDescriptor())
          .add(LabelConversationOperationMetadata.getDescriptor())
          .add(CreateConversationDatasetOperationMetadata.getDescriptor())
          .add(ImportConversationDataOperationResponse.getDescriptor())
          .build();

  private static final ApiMethodDescriptor<CreateConversationDatasetRequest, Operation>
      createConversationDatasetMethodDescriptor =
          ApiMethodDescriptor.<CreateConversationDatasetRequest, Operation>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/CreateConversationDataset")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<CreateConversationDatasetRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*/locations/*}/conversationDatasets",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<CreateConversationDatasetRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<CreateConversationDatasetRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "conversationDataset",
                                      request.getConversationDataset(),
                                      false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Operation>newBuilder()
                      .setDefaultInstance(Operation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .setOperationSnapshotFactory(
                  (CreateConversationDatasetRequest request, Operation response) ->
                      HttpJsonOperationSnapshot.create(response))
              .build();

  private static final ApiMethodDescriptor<GetConversationDatasetRequest, ConversationDataset>
      getConversationDatasetMethodDescriptor =
          ApiMethodDescriptor.<GetConversationDatasetRequest, ConversationDataset>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/GetConversationDataset")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GetConversationDatasetRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/conversationDatasets/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GetConversationDatasetRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{name=projects/*/locations/*/conversationDatasets/*}")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GetConversationDatasetRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ConversationDataset>newBuilder()
                      .setDefaultInstance(ConversationDataset.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          ListConversationDatasetsRequest, ListConversationDatasetsResponse>
      listConversationDatasetsMethodDescriptor =
          ApiMethodDescriptor
              .<ListConversationDatasetsRequest, ListConversationDatasetsResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/ListConversationDatasets")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListConversationDatasetsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*}/conversationDatasets",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListConversationDatasetsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{parent=projects/*/locations/*}/conversationDatasets")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListConversationDatasetsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "pageSize", request.getPageSize());
                            serializer.putQueryParam(fields, "pageToken", request.getPageToken());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListConversationDatasetsResponse>newBuilder()
                      .setDefaultInstance(ListConversationDatasetsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<DeleteConversationDatasetRequest, Operation>
      deleteConversationDatasetMethodDescriptor =
          ApiMethodDescriptor.<DeleteConversationDatasetRequest, Operation>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/DeleteConversationDataset")
              .setHttpMethod("DELETE")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<DeleteConversationDatasetRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/locations/*/conversationDatasets/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<DeleteConversationDatasetRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<DeleteConversationDatasetRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Operation>newBuilder()
                      .setDefaultInstance(Operation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .setOperationSnapshotFactory(
                  (DeleteConversationDatasetRequest request, Operation response) ->
                      HttpJsonOperationSnapshot.create(response))
              .build();

  private static final ApiMethodDescriptor<
          GetAnnotatedConversationDatasetRequest, AnnotatedConversationDataset>
      getAnnotatedConversationDatasetMethodDescriptor =
          ApiMethodDescriptor
              .<GetAnnotatedConversationDatasetRequest, AnnotatedConversationDataset>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/GetAnnotatedConversationDataset")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GetAnnotatedConversationDatasetRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/conversationDatasets/*/annotatedConversationDatasets/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GetAnnotatedConversationDatasetRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{name=projects/*/locations/*/conversationDatasets/*/annotatedConversationDatasets/*}")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GetAnnotatedConversationDatasetRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<AnnotatedConversationDataset>newBuilder()
                      .setDefaultInstance(AnnotatedConversationDataset.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsResponse>
      listAnnotatedConversationDatasetsMethodDescriptor =
          ApiMethodDescriptor
              .<ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsResponse>
                  newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/ListAnnotatedConversationDatasets")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter
                      .<ListAnnotatedConversationDatasetsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*/conversationDatasets/*}/annotatedConversationDatasets",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListAnnotatedConversationDatasetsRequest>
                                serializer = ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{parent=projects/*/locations/*/conversationDatasets/*}/annotatedConversationDatasets")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListAnnotatedConversationDatasetsRequest>
                                serializer = ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "pageSize", request.getPageSize());
                            serializer.putQueryParam(fields, "pageToken", request.getPageToken());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListAnnotatedConversationDatasetsResponse>newBuilder()
                      .setDefaultInstance(
                          ListAnnotatedConversationDatasetsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<DeleteAnnotatedConversationDatasetRequest, Empty>
      deleteAnnotatedConversationDatasetMethodDescriptor =
          ApiMethodDescriptor.<DeleteAnnotatedConversationDatasetRequest, Empty>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/DeleteAnnotatedConversationDataset")
              .setHttpMethod("DELETE")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter
                      .<DeleteAnnotatedConversationDatasetRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/conversationDatasets/*/annotatedConversationDatasets/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<DeleteAnnotatedConversationDatasetRequest>
                                serializer = ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{name=projects/*/locations/*/conversationDatasets/*/annotatedConversationDatasets/*}")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<DeleteAnnotatedConversationDatasetRequest>
                                serializer = ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Empty>newBuilder()
                      .setDefaultInstance(Empty.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<ImportConversationDataRequest, Operation>
      importConversationDataMethodDescriptor =
          ApiMethodDescriptor.<ImportConversationDataRequest, Operation>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/ImportConversationData")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ImportConversationDataRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/conversationDatasets/*}:importConversationData",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ImportConversationDataRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{name=projects/*/locations/*/conversationDatasets/*}:importConversationData")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ImportConversationDataRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("*", request.toBuilder().clearName().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Operation>newBuilder()
                      .setDefaultInstance(Operation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .setOperationSnapshotFactory(
                  (ImportConversationDataRequest request, Operation response) ->
                      HttpJsonOperationSnapshot.create(response))
              .build();

  private static final ApiMethodDescriptor<LabelConversationRequest, Operation>
      labelConversationMethodDescriptor =
          ApiMethodDescriptor.<LabelConversationRequest, Operation>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.ConversationDatasets/LabelConversation")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<LabelConversationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*/conversationDatasets/*}:labelConversation",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<LabelConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{parent=projects/*/locations/*/conversationDatasets/*}:labelConversation")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<LabelConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("*", request.toBuilder().clearParent().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Operation>newBuilder()
                      .setDefaultInstance(Operation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .setOperationSnapshotFactory(
                  (LabelConversationRequest request, Operation response) ->
                      HttpJsonOperationSnapshot.create(response))
              .build();

  private static final ApiMethodDescriptor<ListLocationsRequest, ListLocationsResponse>
      listLocationsMethodDescriptor =
          ApiMethodDescriptor.<ListLocationsRequest, ListLocationsResponse>newBuilder()
              .setFullMethodName("google.cloud.location.Locations/ListLocations")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListLocationsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*}/locations",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListLocationsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListLocationsRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListLocationsResponse>newBuilder()
                      .setDefaultInstance(ListLocationsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<GetLocationRequest, Location>
      getLocationMethodDescriptor =
          ApiMethodDescriptor.<GetLocationRequest, Location>newBuilder()
              .setFullMethodName("google.cloud.location.Locations/GetLocation")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GetLocationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/locations/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GetLocationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GetLocationRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Location>newBuilder()
                      .setDefaultInstance(Location.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private final UnaryCallable<CreateConversationDatasetRequest, Operation>
      createConversationDatasetCallable;
  private final OperationCallable<
          CreateConversationDatasetRequest,
          ConversationDataset,
          CreateConversationDatasetOperationMetadata>
      createConversationDatasetOperationCallable;
  private final UnaryCallable<GetConversationDatasetRequest, ConversationDataset>
      getConversationDatasetCallable;
  private final UnaryCallable<ListConversationDatasetsRequest, ListConversationDatasetsResponse>
      listConversationDatasetsCallable;
  private final UnaryCallable<
          ListConversationDatasetsRequest, ListConversationDatasetsPagedResponse>
      listConversationDatasetsPagedCallable;
  private final UnaryCallable<DeleteConversationDatasetRequest, Operation>
      deleteConversationDatasetCallable;
  private final OperationCallable<
          DeleteConversationDatasetRequest, Empty, DeleteConversationDatasetOperationMetadata>
      deleteConversationDatasetOperationCallable;
  private final UnaryCallable<GetAnnotatedConversationDatasetRequest, AnnotatedConversationDataset>
      getAnnotatedConversationDatasetCallable;
  private final UnaryCallable<
          ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsResponse>
      listAnnotatedConversationDatasetsCallable;
  private final UnaryCallable<
          ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsPagedResponse>
      listAnnotatedConversationDatasetsPagedCallable;
  private final UnaryCallable<DeleteAnnotatedConversationDatasetRequest, Empty>
      deleteAnnotatedConversationDatasetCallable;
  private final UnaryCallable<ImportConversationDataRequest, Operation>
      importConversationDataCallable;
  private final OperationCallable<
          ImportConversationDataRequest,
          ImportConversationDataOperationResponse,
          ImportConversationDataOperationMetadata>
      importConversationDataOperationCallable;
  private final UnaryCallable<LabelConversationRequest, Operation> labelConversationCallable;
  private final OperationCallable<
          LabelConversationRequest, LabelConversationResponse, LabelConversationOperationMetadata>
      labelConversationOperationCallable;
  private final UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable;
  private final UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable;
  private final UnaryCallable<GetLocationRequest, Location> getLocationCallable;

  private final BackgroundResource backgroundResources;
  private final HttpJsonOperationsStub httpJsonOperationsStub;
  private final HttpJsonStubCallableFactory callableFactory;

  public static final HttpJsonConversationDatasetsStub create(
      ConversationDatasetsStubSettings settings) throws IOException {
    return new HttpJsonConversationDatasetsStub(settings, ClientContext.create(settings));
  }

  public static final HttpJsonConversationDatasetsStub create(ClientContext clientContext)
      throws IOException {
    return new HttpJsonConversationDatasetsStub(
        ConversationDatasetsStubSettings.newHttpJsonBuilder().build(), clientContext);
  }

  public static final HttpJsonConversationDatasetsStub create(
      ClientContext clientContext, HttpJsonStubCallableFactory callableFactory) throws IOException {
    return new HttpJsonConversationDatasetsStub(
        ConversationDatasetsStubSettings.newHttpJsonBuilder().build(),
        clientContext,
        callableFactory);
  }

  /**
   * Constructs an instance of HttpJsonConversationDatasetsStub, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected HttpJsonConversationDatasetsStub(
      ConversationDatasetsStubSettings settings, ClientContext clientContext) throws IOException {
    this(settings, clientContext, new HttpJsonConversationDatasetsCallableFactory());
  }

  /**
   * Constructs an instance of HttpJsonConversationDatasetsStub, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected HttpJsonConversationDatasetsStub(
      ConversationDatasetsStubSettings settings,
      ClientContext clientContext,
      HttpJsonStubCallableFactory callableFactory)
      throws IOException {
    this.callableFactory = callableFactory;
    this.httpJsonOperationsStub =
        HttpJsonOperationsStub.create(
            clientContext,
            callableFactory,
            typeRegistry,
            ImmutableMap.<String, HttpRule>builder()
                .put(
                    "google.longrunning.Operations.CancelOperation",
                    HttpRule.newBuilder()
                        .setPost("/v2beta1/{name=projects/*/operations/*}:cancel")
                        .addAdditionalBindings(
                            HttpRule.newBuilder()
                                .setPost(
                                    "/v2beta1/{name=projects/*/locations/*/operations/*}:cancel")
                                .build())
                        .build())
                .put(
                    "google.longrunning.Operations.GetOperation",
                    HttpRule.newBuilder()
                        .setGet("/v2beta1/{name=projects/*/operations/*}")
                        .addAdditionalBindings(
                            HttpRule.newBuilder()
                                .setGet("/v2beta1/{name=projects/*/locations/*/operations/*}")
                                .build())
                        .build())
                .put(
                    "google.longrunning.Operations.ListOperations",
                    HttpRule.newBuilder()
                        .setGet("/v2beta1/{name=projects/*}/operations")
                        .addAdditionalBindings(
                            HttpRule.newBuilder()
                                .setGet("/v2beta1/{name=projects/*/locations/*}/operations")
                                .build())
                        .build())
                .build());

    HttpJsonCallSettings<CreateConversationDatasetRequest, Operation>
        createConversationDatasetTransportSettings =
            HttpJsonCallSettings.<CreateConversationDatasetRequest, Operation>newBuilder()
                .setMethodDescriptor(createConversationDatasetMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GetConversationDatasetRequest, ConversationDataset>
        getConversationDatasetTransportSettings =
            HttpJsonCallSettings.<GetConversationDatasetRequest, ConversationDataset>newBuilder()
                .setMethodDescriptor(getConversationDatasetMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<ListConversationDatasetsRequest, ListConversationDatasetsResponse>
        listConversationDatasetsTransportSettings =
            HttpJsonCallSettings
                .<ListConversationDatasetsRequest, ListConversationDatasetsResponse>newBuilder()
                .setMethodDescriptor(listConversationDatasetsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<DeleteConversationDatasetRequest, Operation>
        deleteConversationDatasetTransportSettings =
            HttpJsonCallSettings.<DeleteConversationDatasetRequest, Operation>newBuilder()
                .setMethodDescriptor(deleteConversationDatasetMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GetAnnotatedConversationDatasetRequest, AnnotatedConversationDataset>
        getAnnotatedConversationDatasetTransportSettings =
            HttpJsonCallSettings
                .<GetAnnotatedConversationDatasetRequest, AnnotatedConversationDataset>newBuilder()
                .setMethodDescriptor(getAnnotatedConversationDatasetMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<
            ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsResponse>
        listAnnotatedConversationDatasetsTransportSettings =
            HttpJsonCallSettings
                .<ListAnnotatedConversationDatasetsRequest,
                    ListAnnotatedConversationDatasetsResponse>
                    newBuilder()
                .setMethodDescriptor(listAnnotatedConversationDatasetsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<DeleteAnnotatedConversationDatasetRequest, Empty>
        deleteAnnotatedConversationDatasetTransportSettings =
            HttpJsonCallSettings.<DeleteAnnotatedConversationDatasetRequest, Empty>newBuilder()
                .setMethodDescriptor(deleteAnnotatedConversationDatasetMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<ImportConversationDataRequest, Operation>
        importConversationDataTransportSettings =
            HttpJsonCallSettings.<ImportConversationDataRequest, Operation>newBuilder()
                .setMethodDescriptor(importConversationDataMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<LabelConversationRequest, Operation> labelConversationTransportSettings =
        HttpJsonCallSettings.<LabelConversationRequest, Operation>newBuilder()
            .setMethodDescriptor(labelConversationMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("parent", String.valueOf(request.getParent()));
                  return builder.build();
                })
            .build();
    HttpJsonCallSettings<ListLocationsRequest, ListLocationsResponse>
        listLocationsTransportSettings =
            HttpJsonCallSettings.<ListLocationsRequest, ListLocationsResponse>newBuilder()
                .setMethodDescriptor(listLocationsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GetLocationRequest, Location> getLocationTransportSettings =
        HttpJsonCallSettings.<GetLocationRequest, Location>newBuilder()
            .setMethodDescriptor(getLocationMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("name", String.valueOf(request.getName()));
                  return builder.build();
                })
            .build();

    this.createConversationDatasetCallable =
        callableFactory.createUnaryCallable(
            createConversationDatasetTransportSettings,
            settings.createConversationDatasetSettings(),
            clientContext);
    this.createConversationDatasetOperationCallable =
        callableFactory.createOperationCallable(
            createConversationDatasetTransportSettings,
            settings.createConversationDatasetOperationSettings(),
            clientContext,
            httpJsonOperationsStub);
    this.getConversationDatasetCallable =
        callableFactory.createUnaryCallable(
            getConversationDatasetTransportSettings,
            settings.getConversationDatasetSettings(),
            clientContext);
    this.listConversationDatasetsCallable =
        callableFactory.createUnaryCallable(
            listConversationDatasetsTransportSettings,
            settings.listConversationDatasetsSettings(),
            clientContext);
    this.listConversationDatasetsPagedCallable =
        callableFactory.createPagedCallable(
            listConversationDatasetsTransportSettings,
            settings.listConversationDatasetsSettings(),
            clientContext);
    this.deleteConversationDatasetCallable =
        callableFactory.createUnaryCallable(
            deleteConversationDatasetTransportSettings,
            settings.deleteConversationDatasetSettings(),
            clientContext);
    this.deleteConversationDatasetOperationCallable =
        callableFactory.createOperationCallable(
            deleteConversationDatasetTransportSettings,
            settings.deleteConversationDatasetOperationSettings(),
            clientContext,
            httpJsonOperationsStub);
    this.getAnnotatedConversationDatasetCallable =
        callableFactory.createUnaryCallable(
            getAnnotatedConversationDatasetTransportSettings,
            settings.getAnnotatedConversationDatasetSettings(),
            clientContext);
    this.listAnnotatedConversationDatasetsCallable =
        callableFactory.createUnaryCallable(
            listAnnotatedConversationDatasetsTransportSettings,
            settings.listAnnotatedConversationDatasetsSettings(),
            clientContext);
    this.listAnnotatedConversationDatasetsPagedCallable =
        callableFactory.createPagedCallable(
            listAnnotatedConversationDatasetsTransportSettings,
            settings.listAnnotatedConversationDatasetsSettings(),
            clientContext);
    this.deleteAnnotatedConversationDatasetCallable =
        callableFactory.createUnaryCallable(
            deleteAnnotatedConversationDatasetTransportSettings,
            settings.deleteAnnotatedConversationDatasetSettings(),
            clientContext);
    this.importConversationDataCallable =
        callableFactory.createUnaryCallable(
            importConversationDataTransportSettings,
            settings.importConversationDataSettings(),
            clientContext);
    this.importConversationDataOperationCallable =
        callableFactory.createOperationCallable(
            importConversationDataTransportSettings,
            settings.importConversationDataOperationSettings(),
            clientContext,
            httpJsonOperationsStub);
    this.labelConversationCallable =
        callableFactory.createUnaryCallable(
            labelConversationTransportSettings,
            settings.labelConversationSettings(),
            clientContext);
    this.labelConversationOperationCallable =
        callableFactory.createOperationCallable(
            labelConversationTransportSettings,
            settings.labelConversationOperationSettings(),
            clientContext,
            httpJsonOperationsStub);
    this.listLocationsCallable =
        callableFactory.createUnaryCallable(
            listLocationsTransportSettings, settings.listLocationsSettings(), clientContext);
    this.listLocationsPagedCallable =
        callableFactory.createPagedCallable(
            listLocationsTransportSettings, settings.listLocationsSettings(), clientContext);
    this.getLocationCallable =
        callableFactory.createUnaryCallable(
            getLocationTransportSettings, settings.getLocationSettings(), clientContext);

    this.backgroundResources =
        new BackgroundResourceAggregation(clientContext.getBackgroundResources());
  }

  @InternalApi
  public static List<ApiMethodDescriptor> getMethodDescriptors() {
    List<ApiMethodDescriptor> methodDescriptors = new ArrayList<>();
    methodDescriptors.add(createConversationDatasetMethodDescriptor);
    methodDescriptors.add(getConversationDatasetMethodDescriptor);
    methodDescriptors.add(listConversationDatasetsMethodDescriptor);
    methodDescriptors.add(deleteConversationDatasetMethodDescriptor);
    methodDescriptors.add(getAnnotatedConversationDatasetMethodDescriptor);
    methodDescriptors.add(listAnnotatedConversationDatasetsMethodDescriptor);
    methodDescriptors.add(deleteAnnotatedConversationDatasetMethodDescriptor);
    methodDescriptors.add(importConversationDataMethodDescriptor);
    methodDescriptors.add(labelConversationMethodDescriptor);
    methodDescriptors.add(listLocationsMethodDescriptor);
    methodDescriptors.add(getLocationMethodDescriptor);
    return methodDescriptors;
  }

  public HttpJsonOperationsStub getHttpJsonOperationsStub() {
    return httpJsonOperationsStub;
  }

  @Override
  public UnaryCallable<CreateConversationDatasetRequest, Operation>
      createConversationDatasetCallable() {
    return createConversationDatasetCallable;
  }

  @Override
  public OperationCallable<
          CreateConversationDatasetRequest,
          ConversationDataset,
          CreateConversationDatasetOperationMetadata>
      createConversationDatasetOperationCallable() {
    return createConversationDatasetOperationCallable;
  }

  @Override
  public UnaryCallable<GetConversationDatasetRequest, ConversationDataset>
      getConversationDatasetCallable() {
    return getConversationDatasetCallable;
  }

  @Override
  public UnaryCallable<ListConversationDatasetsRequest, ListConversationDatasetsResponse>
      listConversationDatasetsCallable() {
    return listConversationDatasetsCallable;
  }

  @Override
  public UnaryCallable<ListConversationDatasetsRequest, ListConversationDatasetsPagedResponse>
      listConversationDatasetsPagedCallable() {
    return listConversationDatasetsPagedCallable;
  }

  @Override
  public UnaryCallable<DeleteConversationDatasetRequest, Operation>
      deleteConversationDatasetCallable() {
    return deleteConversationDatasetCallable;
  }

  @Override
  public OperationCallable<
          DeleteConversationDatasetRequest, Empty, DeleteConversationDatasetOperationMetadata>
      deleteConversationDatasetOperationCallable() {
    return deleteConversationDatasetOperationCallable;
  }

  @Override
  public UnaryCallable<GetAnnotatedConversationDatasetRequest, AnnotatedConversationDataset>
      getAnnotatedConversationDatasetCallable() {
    return getAnnotatedConversationDatasetCallable;
  }

  @Override
  public UnaryCallable<
          ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsResponse>
      listAnnotatedConversationDatasetsCallable() {
    return listAnnotatedConversationDatasetsCallable;
  }

  @Override
  public UnaryCallable<
          ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsPagedResponse>
      listAnnotatedConversationDatasetsPagedCallable() {
    return listAnnotatedConversationDatasetsPagedCallable;
  }

  @Override
  public UnaryCallable<DeleteAnnotatedConversationDatasetRequest, Empty>
      deleteAnnotatedConversationDatasetCallable() {
    return deleteAnnotatedConversationDatasetCallable;
  }

  @Override
  public UnaryCallable<ImportConversationDataRequest, Operation> importConversationDataCallable() {
    return importConversationDataCallable;
  }

  @Override
  public OperationCallable<
          ImportConversationDataRequest,
          ImportConversationDataOperationResponse,
          ImportConversationDataOperationMetadata>
      importConversationDataOperationCallable() {
    return importConversationDataOperationCallable;
  }

  @Override
  public UnaryCallable<LabelConversationRequest, Operation> labelConversationCallable() {
    return labelConversationCallable;
  }

  @Override
  public OperationCallable<
          LabelConversationRequest, LabelConversationResponse, LabelConversationOperationMetadata>
      labelConversationOperationCallable() {
    return labelConversationOperationCallable;
  }

  @Override
  public UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    return listLocationsCallable;
  }

  @Override
  public UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    return listLocationsPagedCallable;
  }

  @Override
  public UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    return getLocationCallable;
  }

  @Override
  public final void close() {
    try {
      backgroundResources.close();
    } catch (RuntimeException e) {
      throw e;
    } catch (Exception e) {
      throw new IllegalStateException("Failed to close resource", e);
    }
  }

  @Override
  public void shutdown() {
    backgroundResources.shutdown();
  }

  @Override
  public boolean isShutdown() {
    return backgroundResources.isShutdown();
  }

  @Override
  public boolean isTerminated() {
    return backgroundResources.isTerminated();
  }

  @Override
  public void shutdownNow() {
    backgroundResources.shutdownNow();
  }

  @Override
  public boolean awaitTermination(long duration, TimeUnit unit) throws InterruptedException {
    return backgroundResources.awaitTermination(duration, unit);
  }
}
