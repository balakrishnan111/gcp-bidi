/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.ContextsClient.ListContextsByConversationPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ContextsClient.ListContextsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ContextsClient.ListLocationsPagedResponse;

import com.google.api.core.BetaApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.Context;
import com.google.cloud.dialogflow.v2beta1.CreateContextRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteContextRequest;
import com.google.cloud.dialogflow.v2beta1.GetContextRequest;
import com.google.cloud.dialogflow.v2beta1.ListContextsRequest;
import com.google.cloud.dialogflow.v2beta1.ListContextsResponse;
import com.google.cloud.dialogflow.v2beta1.UpdateContextRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.protobuf.Empty;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * Base stub class for the Contexts service API.
 *
 * <p>This class is for advanced usage and reflects the underlying API directly.
 */
@BetaApi
@Generated("by gapic-generator-java")
public abstract class ContextsStub implements BackgroundResource {

  public UnaryCallable<ListContextsRequest, ListContextsPagedResponse> listContextsPagedCallable() {
    throw new UnsupportedOperationException("Not implemented: listContextsPagedCallable()");
  }

  public UnaryCallable<ListContextsRequest, ListContextsResponse> listContextsCallable() {
    throw new UnsupportedOperationException("Not implemented: listContextsCallable()");
  }

  public UnaryCallable<ListContextsRequest, ListContextsByConversationPagedResponse>
      listContextsByConversationPagedCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: listContextsByConversationPagedCallable()");
  }

  public UnaryCallable<ListContextsRequest, ListContextsResponse>
      listContextsByConversationCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: listContextsByConversationCallable()");
  }

  public UnaryCallable<GetContextRequest, Context> getContextCallable() {
    throw new UnsupportedOperationException("Not implemented: getContextCallable()");
  }

  public UnaryCallable<GetContextRequest, Context> getContextByConversationCallable() {
    throw new UnsupportedOperationException("Not implemented: getContextByConversationCallable()");
  }

  public UnaryCallable<CreateContextRequest, Context> createContextCallable() {
    throw new UnsupportedOperationException("Not implemented: createContextCallable()");
  }

  public UnaryCallable<CreateContextRequest, Context> createContextByConversationCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: createContextByConversationCallable()");
  }

  public UnaryCallable<UpdateContextRequest, Context> updateContextCallable() {
    throw new UnsupportedOperationException("Not implemented: updateContextCallable()");
  }

  public UnaryCallable<UpdateContextRequest, Context> updateContextByConversationCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: updateContextByConversationCallable()");
  }

  public UnaryCallable<DeleteContextRequest, Empty> deleteContextCallable() {
    throw new UnsupportedOperationException("Not implemented: deleteContextCallable()");
  }

  public UnaryCallable<DeleteContextRequest, Empty> deleteContextByConversationCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: deleteContextByConversationCallable()");
  }

  public UnaryCallable<DeleteAllContextsRequest, Empty> deleteAllContextsCallable() {
    throw new UnsupportedOperationException("Not implemented: deleteAllContextsCallable()");
  }

  public UnaryCallable<DeleteAllContextsRequest, Empty> deleteAllContextsByConversationCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: deleteAllContextsByConversationCallable()");
  }

  public UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    throw new UnsupportedOperationException("Not implemented: listLocationsPagedCallable()");
  }

  public UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    throw new UnsupportedOperationException("Not implemented: listLocationsCallable()");
  }

  public UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    throw new UnsupportedOperationException("Not implemented: getLocationCallable()");
  }

  @Override
  public abstract void close();
}
