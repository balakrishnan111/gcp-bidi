/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListCallMatchersPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListConversationsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListLocationsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListMessagesPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListPastCallCompanionEventsPagedResponse;

import com.google.api.core.BetaApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.rpc.OperationCallable;
import com.google.api.gax.rpc.ServerStreamingCallable;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest;
import com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.CallCompanionSettings;
import com.google.cloud.dialogflow.v2beta1.CallMatcher;
import com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest;
import com.google.cloud.dialogflow.v2beta1.Conversation;
import com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber;
import com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest;
import com.google.cloud.dialogflow.v2beta1.CreateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest;
import com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.ExportMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse;
import com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest;
import com.google.cloud.dialogflow.v2beta1.GetConversationRequest;
import com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest;
import com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse;
import com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest;
import com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest;
import com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse;
import com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest;
import com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse;
import com.google.cloud.dialogflow.v2beta1.ListConversationsRequest;
import com.google.cloud.dialogflow.v2beta1.ListConversationsResponse;
import com.google.cloud.dialogflow.v2beta1.ListMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.ListMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest;
import com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse;
import com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest;
import com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse;
import com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse;
import com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.longrunning.Operation;
import com.google.longrunning.stub.OperationsStub;
import com.google.protobuf.Empty;
import com.google.protobuf.Struct;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * Base stub class for the Conversations service API.
 *
 * <p>This class is for advanced usage and reflects the underlying API directly.
 */
@BetaApi
@Generated("by gapic-generator-java")
public abstract class ConversationsStub implements BackgroundResource {

  public OperationsStub getOperationsStub() {
    return null;
  }

  public com.google.api.gax.httpjson.longrunning.stub.OperationsStub getHttpJsonOperationsStub() {
    return null;
  }

  public UnaryCallable<CreateConversationRequest, Conversation> createConversationCallable() {
    throw new UnsupportedOperationException("Not implemented: createConversationCallable()");
  }

  public UnaryCallable<ListConversationsRequest, ListConversationsPagedResponse>
      listConversationsPagedCallable() {
    throw new UnsupportedOperationException("Not implemented: listConversationsPagedCallable()");
  }

  public UnaryCallable<ListConversationsRequest, ListConversationsResponse>
      listConversationsCallable() {
    throw new UnsupportedOperationException("Not implemented: listConversationsCallable()");
  }

  public UnaryCallable<GetConversationRequest, Conversation> getConversationCallable() {
    throw new UnsupportedOperationException("Not implemented: getConversationCallable()");
  }

  public UnaryCallable<AddConversationPhoneNumberRequest, ConversationPhoneNumber>
      addConversationPhoneNumberCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: addConversationPhoneNumberCallable()");
  }

  public UnaryCallable<ActivateConversationRequest, Conversation> activateConversationCallable() {
    throw new UnsupportedOperationException("Not implemented: activateConversationCallable()");
  }

  public UnaryCallable<DeactivateConversationRequest, Conversation>
      deactivateConversationCallable() {
    throw new UnsupportedOperationException("Not implemented: deactivateConversationCallable()");
  }

  public UnaryCallable<CompleteConversationRequest, Conversation> completeConversationCallable() {
    throw new UnsupportedOperationException("Not implemented: completeConversationCallable()");
  }

  public UnaryCallable<UpdateConversationRequest, Conversation> updateConversationCallable() {
    throw new UnsupportedOperationException("Not implemented: updateConversationCallable()");
  }

  public UnaryCallable<IngestContextReferencesRequest, IngestContextReferencesResponse>
      ingestContextReferencesCallable() {
    throw new UnsupportedOperationException("Not implemented: ingestContextReferencesCallable()");
  }

  public UnaryCallable<CreateCallMatcherRequest, CallMatcher> createCallMatcherCallable() {
    throw new UnsupportedOperationException("Not implemented: createCallMatcherCallable()");
  }

  public UnaryCallable<ListCallMatchersRequest, ListCallMatchersPagedResponse>
      listCallMatchersPagedCallable() {
    throw new UnsupportedOperationException("Not implemented: listCallMatchersPagedCallable()");
  }

  public UnaryCallable<ListCallMatchersRequest, ListCallMatchersResponse>
      listCallMatchersCallable() {
    throw new UnsupportedOperationException("Not implemented: listCallMatchersCallable()");
  }

  public UnaryCallable<DeleteCallMatcherRequest, Empty> deleteCallMatcherCallable() {
    throw new UnsupportedOperationException("Not implemented: deleteCallMatcherCallable()");
  }

  public UnaryCallable<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
      batchCreateMessagesCallable() {
    throw new UnsupportedOperationException("Not implemented: batchCreateMessagesCallable()");
  }

  public UnaryCallable<ListMessagesRequest, ListMessagesPagedResponse> listMessagesPagedCallable() {
    throw new UnsupportedOperationException("Not implemented: listMessagesPagedCallable()");
  }

  public UnaryCallable<ListMessagesRequest, ListMessagesResponse> listMessagesCallable() {
    throw new UnsupportedOperationException("Not implemented: listMessagesCallable()");
  }

  public OperationCallable<ExportMessagesRequest, ExportMessagesResponse, Struct>
      exportMessagesOperationCallable() {
    throw new UnsupportedOperationException("Not implemented: exportMessagesOperationCallable()");
  }

  public UnaryCallable<ExportMessagesRequest, Operation> exportMessagesCallable() {
    throw new UnsupportedOperationException("Not implemented: exportMessagesCallable()");
  }

  public UnaryCallable<SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
      suggestConversationSummaryCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: suggestConversationSummaryCallable()");
  }

  public UnaryCallable<GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
      generateStatelessSummaryCallable() {
    throw new UnsupportedOperationException("Not implemented: generateStatelessSummaryCallable()");
  }

  public UnaryCallable<GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
      generateStatelessSuggestionCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: generateStatelessSuggestionCallable()");
  }

  public UnaryCallable<SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
      suggestConversationKeyMomentsCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: suggestConversationKeyMomentsCallable()");
  }

  public UnaryCallable<SearchArticlesRequest, SearchArticlesResponse> searchArticlesCallable() {
    throw new UnsupportedOperationException("Not implemented: searchArticlesCallable()");
  }

  public UnaryCallable<ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsPagedResponse>
      listPastCallCompanionEventsPagedCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: listPastCallCompanionEventsPagedCallable()");
  }

  public UnaryCallable<ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsResponse>
      listPastCallCompanionEventsCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: listPastCallCompanionEventsCallable()");
  }

  public ServerStreamingCallable<
          StreamingListUpcomingCallCompanionEventsRequest,
          StreamingListUpcomingCallCompanionEventsResponse>
      streamingListUpcomingCallCompanionEventsCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: streamingListUpcomingCallCompanionEventsCallable()");
  }

  public UnaryCallable<InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
      injectCallCompanionUserInputCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: injectCallCompanionUserInputCallable()");
  }

  public ServerStreamingCallable<
          StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
      streamingListCallCompanionEventsCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: streamingListCallCompanionEventsCallable()");
  }

  public UnaryCallable<InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
      injectCallCompanionInputCallable() {
    throw new UnsupportedOperationException("Not implemented: injectCallCompanionInputCallable()");
  }

  public UnaryCallable<InitializeCallCompanionRequest, Empty> initializeCallCompanionCallable() {
    throw new UnsupportedOperationException("Not implemented: initializeCallCompanionCallable()");
  }

  public UnaryCallable<GetCallCompanionSettingsRequest, CallCompanionSettings>
      getCallCompanionSettingsCallable() {
    throw new UnsupportedOperationException("Not implemented: getCallCompanionSettingsCallable()");
  }

  public UnaryCallable<SearchKnowledgeRequest, SearchKnowledgeResponse> searchKnowledgeCallable() {
    throw new UnsupportedOperationException("Not implemented: searchKnowledgeCallable()");
  }

  public UnaryCallable<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
      generateSuggestionsCallable() {
    throw new UnsupportedOperationException("Not implemented: generateSuggestionsCallable()");
  }

  public UnaryCallable<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
      initiatePhoneCallCallable() {
    throw new UnsupportedOperationException("Not implemented: initiatePhoneCallCallable()");
  }

  public UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    throw new UnsupportedOperationException("Not implemented: listLocationsPagedCallable()");
  }

  public UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    throw new UnsupportedOperationException("Not implemented: listLocationsCallable()");
  }

  public UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    throw new UnsupportedOperationException("Not implemented: getLocationCallable()");
  }

  @Override
  public abstract void close();
}
