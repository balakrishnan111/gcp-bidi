/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListHumanAgentAssistantsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListLocationsPagedResponse;

import com.google.api.core.BetaApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.core.BackgroundResourceAggregation;
import com.google.api.gax.grpc.GrpcCallSettings;
import com.google.api.gax.grpc.GrpcStubCallableFactory;
import com.google.api.gax.rpc.ClientContext;
import com.google.api.gax.rpc.RequestParamsBuilder;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest;
import com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse;
import com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant;
import com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest;
import com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse;
import com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.longrunning.stub.GrpcOperationsStub;
import com.google.protobuf.Empty;
import io.grpc.MethodDescriptor;
import io.grpc.protobuf.ProtoUtils;
import java.io.IOException;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * gRPC stub implementation for the HumanAgentAssistants service API.
 *
 * <p>This class is for advanced usage and reflects the underlying API directly.
 *
 * @deprecated This class is deprecated and will be removed in the next major version update.
 */
@BetaApi
@Deprecated
@Generated("by gapic-generator-java")
public class GrpcHumanAgentAssistantsStub extends HumanAgentAssistantsStub {
  private static final MethodDescriptor<
          ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
      listHumanAgentAssistantsMethodDescriptor =
          MethodDescriptor
              .<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>newBuilder()
              .setType(MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/ListHumanAgentAssistants")
              .setRequestMarshaller(
                  ProtoUtils.marshaller(ListHumanAgentAssistantsRequest.getDefaultInstance()))
              .setResponseMarshaller(
                  ProtoUtils.marshaller(ListHumanAgentAssistantsResponse.getDefaultInstance()))
              .build();

  private static final MethodDescriptor<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantMethodDescriptor =
          MethodDescriptor.<GetHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
              .setType(MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/GetHumanAgentAssistant")
              .setRequestMarshaller(
                  ProtoUtils.marshaller(GetHumanAgentAssistantRequest.getDefaultInstance()))
              .setResponseMarshaller(
                  ProtoUtils.marshaller(HumanAgentAssistant.getDefaultInstance()))
              .build();

  private static final MethodDescriptor<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantMethodDescriptor =
          MethodDescriptor.<CreateHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
              .setType(MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/CreateHumanAgentAssistant")
              .setRequestMarshaller(
                  ProtoUtils.marshaller(CreateHumanAgentAssistantRequest.getDefaultInstance()))
              .setResponseMarshaller(
                  ProtoUtils.marshaller(HumanAgentAssistant.getDefaultInstance()))
              .build();

  private static final MethodDescriptor<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantMethodDescriptor =
          MethodDescriptor.<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
              .setType(MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/UpdateHumanAgentAssistant")
              .setRequestMarshaller(
                  ProtoUtils.marshaller(UpdateHumanAgentAssistantRequest.getDefaultInstance()))
              .setResponseMarshaller(
                  ProtoUtils.marshaller(HumanAgentAssistant.getDefaultInstance()))
              .build();

  private static final MethodDescriptor<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantMethodDescriptor =
          MethodDescriptor.<DeleteHumanAgentAssistantRequest, Empty>newBuilder()
              .setType(MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/DeleteHumanAgentAssistant")
              .setRequestMarshaller(
                  ProtoUtils.marshaller(DeleteHumanAgentAssistantRequest.getDefaultInstance()))
              .setResponseMarshaller(ProtoUtils.marshaller(Empty.getDefaultInstance()))
              .build();

  private static final MethodDescriptor<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsMethodDescriptor =
          MethodDescriptor.<CompileSuggestionsRequest, CompileSuggestionsResponse>newBuilder()
              .setType(MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/CompileSuggestions")
              .setRequestMarshaller(
                  ProtoUtils.marshaller(CompileSuggestionsRequest.getDefaultInstance()))
              .setResponseMarshaller(
                  ProtoUtils.marshaller(CompileSuggestionsResponse.getDefaultInstance()))
              .build();

  private static final MethodDescriptor<ListLocationsRequest, ListLocationsResponse>
      listLocationsMethodDescriptor =
          MethodDescriptor.<ListLocationsRequest, ListLocationsResponse>newBuilder()
              .setType(MethodDescriptor.MethodType.UNARY)
              .setFullMethodName("google.cloud.location.Locations/ListLocations")
              .setRequestMarshaller(
                  ProtoUtils.marshaller(ListLocationsRequest.getDefaultInstance()))
              .setResponseMarshaller(
                  ProtoUtils.marshaller(ListLocationsResponse.getDefaultInstance()))
              .build();

  private static final MethodDescriptor<GetLocationRequest, Location> getLocationMethodDescriptor =
      MethodDescriptor.<GetLocationRequest, Location>newBuilder()
          .setType(MethodDescriptor.MethodType.UNARY)
          .setFullMethodName("google.cloud.location.Locations/GetLocation")
          .setRequestMarshaller(ProtoUtils.marshaller(GetLocationRequest.getDefaultInstance()))
          .setResponseMarshaller(ProtoUtils.marshaller(Location.getDefaultInstance()))
          .build();

  private final UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
      listHumanAgentAssistantsCallable;
  private final UnaryCallable<
          ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsPagedResponse>
      listHumanAgentAssistantsPagedCallable;
  private final UnaryCallable<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantCallable;
  private final UnaryCallable<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantCallable;
  private final UnaryCallable<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantCallable;
  private final UnaryCallable<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantCallable;
  private final UnaryCallable<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsCallable;
  private final UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable;
  private final UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable;
  private final UnaryCallable<GetLocationRequest, Location> getLocationCallable;

  private final BackgroundResource backgroundResources;
  private final GrpcOperationsStub operationsStub;
  private final GrpcStubCallableFactory callableFactory;

  public static final GrpcHumanAgentAssistantsStub create(HumanAgentAssistantsStubSettings settings)
      throws IOException {
    return new GrpcHumanAgentAssistantsStub(settings, ClientContext.create(settings));
  }

  public static final GrpcHumanAgentAssistantsStub create(ClientContext clientContext)
      throws IOException {
    return new GrpcHumanAgentAssistantsStub(
        HumanAgentAssistantsStubSettings.newBuilder().build(), clientContext);
  }

  public static final GrpcHumanAgentAssistantsStub create(
      ClientContext clientContext, GrpcStubCallableFactory callableFactory) throws IOException {
    return new GrpcHumanAgentAssistantsStub(
        HumanAgentAssistantsStubSettings.newBuilder().build(), clientContext, callableFactory);
  }

  /**
   * Constructs an instance of GrpcHumanAgentAssistantsStub, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected GrpcHumanAgentAssistantsStub(
      HumanAgentAssistantsStubSettings settings, ClientContext clientContext) throws IOException {
    this(settings, clientContext, new GrpcHumanAgentAssistantsCallableFactory());
  }

  /**
   * Constructs an instance of GrpcHumanAgentAssistantsStub, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected GrpcHumanAgentAssistantsStub(
      HumanAgentAssistantsStubSettings settings,
      ClientContext clientContext,
      GrpcStubCallableFactory callableFactory)
      throws IOException {
    this.callableFactory = callableFactory;
    this.operationsStub = GrpcOperationsStub.create(clientContext, callableFactory);

    GrpcCallSettings<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
        listHumanAgentAssistantsTransportSettings =
            GrpcCallSettings
                .<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>newBuilder()
                .setMethodDescriptor(listHumanAgentAssistantsMethodDescriptor)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    GrpcCallSettings<GetHumanAgentAssistantRequest, HumanAgentAssistant>
        getHumanAgentAssistantTransportSettings =
            GrpcCallSettings.<GetHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
                .setMethodDescriptor(getHumanAgentAssistantMethodDescriptor)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    GrpcCallSettings<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
        createHumanAgentAssistantTransportSettings =
            GrpcCallSettings.<CreateHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
                .setMethodDescriptor(createHumanAgentAssistantMethodDescriptor)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    GrpcCallSettings<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
        updateHumanAgentAssistantTransportSettings =
            GrpcCallSettings.<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
                .setMethodDescriptor(updateHumanAgentAssistantMethodDescriptor)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add(
                          "human_agent_assistant.name",
                          String.valueOf(request.getHumanAgentAssistant().getName()));
                      return builder.build();
                    })
                .build();
    GrpcCallSettings<DeleteHumanAgentAssistantRequest, Empty>
        deleteHumanAgentAssistantTransportSettings =
            GrpcCallSettings.<DeleteHumanAgentAssistantRequest, Empty>newBuilder()
                .setMethodDescriptor(deleteHumanAgentAssistantMethodDescriptor)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    GrpcCallSettings<CompileSuggestionsRequest, CompileSuggestionsResponse>
        compileSuggestionsTransportSettings =
            GrpcCallSettings.<CompileSuggestionsRequest, CompileSuggestionsResponse>newBuilder()
                .setMethodDescriptor(compileSuggestionsMethodDescriptor)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    GrpcCallSettings<ListLocationsRequest, ListLocationsResponse> listLocationsTransportSettings =
        GrpcCallSettings.<ListLocationsRequest, ListLocationsResponse>newBuilder()
            .setMethodDescriptor(listLocationsMethodDescriptor)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("name", String.valueOf(request.getName()));
                  return builder.build();
                })
            .build();
    GrpcCallSettings<GetLocationRequest, Location> getLocationTransportSettings =
        GrpcCallSettings.<GetLocationRequest, Location>newBuilder()
            .setMethodDescriptor(getLocationMethodDescriptor)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("name", String.valueOf(request.getName()));
                  return builder.build();
                })
            .build();

    this.listHumanAgentAssistantsCallable =
        callableFactory.createUnaryCallable(
            listHumanAgentAssistantsTransportSettings,
            settings.listHumanAgentAssistantsSettings(),
            clientContext);
    this.listHumanAgentAssistantsPagedCallable =
        callableFactory.createPagedCallable(
            listHumanAgentAssistantsTransportSettings,
            settings.listHumanAgentAssistantsSettings(),
            clientContext);
    this.getHumanAgentAssistantCallable =
        callableFactory.createUnaryCallable(
            getHumanAgentAssistantTransportSettings,
            settings.getHumanAgentAssistantSettings(),
            clientContext);
    this.createHumanAgentAssistantCallable =
        callableFactory.createUnaryCallable(
            createHumanAgentAssistantTransportSettings,
            settings.createHumanAgentAssistantSettings(),
            clientContext);
    this.updateHumanAgentAssistantCallable =
        callableFactory.createUnaryCallable(
            updateHumanAgentAssistantTransportSettings,
            settings.updateHumanAgentAssistantSettings(),
            clientContext);
    this.deleteHumanAgentAssistantCallable =
        callableFactory.createUnaryCallable(
            deleteHumanAgentAssistantTransportSettings,
            settings.deleteHumanAgentAssistantSettings(),
            clientContext);
    this.compileSuggestionsCallable =
        callableFactory.createUnaryCallable(
            compileSuggestionsTransportSettings,
            settings.compileSuggestionsSettings(),
            clientContext);
    this.listLocationsCallable =
        callableFactory.createUnaryCallable(
            listLocationsTransportSettings, settings.listLocationsSettings(), clientContext);
    this.listLocationsPagedCallable =
        callableFactory.createPagedCallable(
            listLocationsTransportSettings, settings.listLocationsSettings(), clientContext);
    this.getLocationCallable =
        callableFactory.createUnaryCallable(
            getLocationTransportSettings, settings.getLocationSettings(), clientContext);

    this.backgroundResources =
        new BackgroundResourceAggregation(clientContext.getBackgroundResources());
  }

  public GrpcOperationsStub getOperationsStub() {
    return operationsStub;
  }

  @Override
  public UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
      listHumanAgentAssistantsCallable() {
    return listHumanAgentAssistantsCallable;
  }

  @Override
  public UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsPagedResponse>
      listHumanAgentAssistantsPagedCallable() {
    return listHumanAgentAssistantsPagedCallable;
  }

  @Override
  public UnaryCallable<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantCallable() {
    return getHumanAgentAssistantCallable;
  }

  @Override
  public UnaryCallable<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantCallable() {
    return createHumanAgentAssistantCallable;
  }

  @Override
  public UnaryCallable<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantCallable() {
    return updateHumanAgentAssistantCallable;
  }

  @Override
  public UnaryCallable<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantCallable() {
    return deleteHumanAgentAssistantCallable;
  }

  @Override
  public UnaryCallable<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsCallable() {
    return compileSuggestionsCallable;
  }

  @Override
  public UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    return listLocationsCallable;
  }

  @Override
  public UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    return listLocationsPagedCallable;
  }

  @Override
  public UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    return getLocationCallable;
  }

  @Override
  public final void close() {
    try {
      backgroundResources.close();
    } catch (RuntimeException e) {
      throw e;
    } catch (Exception e) {
      throw new IllegalStateException("Failed to close resource", e);
    }
  }

  @Override
  public void shutdown() {
    backgroundResources.shutdown();
  }

  @Override
  public boolean isShutdown() {
    return backgroundResources.isShutdown();
  }

  @Override
  public boolean isTerminated() {
    return backgroundResources.isTerminated();
  }

  @Override
  public void shutdownNow() {
    backgroundResources.shutdownNow();
  }

  @Override
  public boolean awaitTermination(long duration, TimeUnit unit) throws InterruptedException {
    return backgroundResources.awaitTermination(duration, unit);
  }
}
