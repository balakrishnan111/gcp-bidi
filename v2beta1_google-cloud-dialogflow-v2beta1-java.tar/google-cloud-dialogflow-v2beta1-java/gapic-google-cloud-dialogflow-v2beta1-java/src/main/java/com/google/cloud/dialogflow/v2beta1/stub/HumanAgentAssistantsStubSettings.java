/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListHumanAgentAssistantsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListLocationsPagedResponse;

import com.google.api.core.ApiFunction;
import com.google.api.core.ApiFuture;
import com.google.api.core.BetaApi;
import com.google.api.core.ObsoleteApi;
import com.google.api.gax.core.GaxProperties;
import com.google.api.gax.core.GoogleCredentialsProvider;
import com.google.api.gax.core.InstantiatingExecutorProvider;
import com.google.api.gax.grpc.GaxGrpcProperties;
import com.google.api.gax.grpc.GrpcTransportChannel;
import com.google.api.gax.grpc.InstantiatingGrpcChannelProvider;
import com.google.api.gax.httpjson.GaxHttpJsonProperties;
import com.google.api.gax.httpjson.HttpJsonTransportChannel;
import com.google.api.gax.httpjson.InstantiatingHttpJsonChannelProvider;
import com.google.api.gax.retrying.RetrySettings;
import com.google.api.gax.rpc.ApiCallContext;
import com.google.api.gax.rpc.ApiClientHeaderProvider;
import com.google.api.gax.rpc.ClientContext;
import com.google.api.gax.rpc.PageContext;
import com.google.api.gax.rpc.PagedCallSettings;
import com.google.api.gax.rpc.PagedListDescriptor;
import com.google.api.gax.rpc.PagedListResponseFactory;
import com.google.api.gax.rpc.StatusCode;
import com.google.api.gax.rpc.StubSettings;
import com.google.api.gax.rpc.TransportChannelProvider;
import com.google.api.gax.rpc.UnaryCallSettings;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest;
import com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse;
import com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant;
import com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest;
import com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse;
import com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.protobuf.Empty;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * Settings class to configure an instance of {@link HumanAgentAssistantsStub}.
 *
 * <p>The default instance has everything set to sensible defaults:
 *
 * <ul>
 *   <li>The default service address (dialogflow.googleapis.com) and default port (443) are used.
 *   <li>Credentials are acquired automatically through Application Default Credentials.
 *   <li>Retries are configured for idempotent methods but not for non-idempotent methods.
 * </ul>
 *
 * <p>The builder of this class is recursive, so contained classes are themselves builders. When
 * build() is called, the tree of builders is called to create the complete settings object.
 *
 * <p>For example, to set the
 * [RetrySettings](https://cloud.google.com/java/docs/reference/gax/latest/com.google.api.gax.retrying.RetrySettings)
 * of getHumanAgentAssistant:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * HumanAgentAssistantsStubSettings.Builder humanAgentAssistantsSettingsBuilder =
 *     HumanAgentAssistantsStubSettings.newBuilder();
 * humanAgentAssistantsSettingsBuilder
 *     .getHumanAgentAssistantSettings()
 *     .setRetrySettings(
 *         humanAgentAssistantsSettingsBuilder
 *             .getHumanAgentAssistantSettings()
 *             .getRetrySettings()
 *             .toBuilder()
 *             .setInitialRetryDelayDuration(Duration.ofSeconds(1))
 *             .setInitialRpcTimeoutDuration(Duration.ofSeconds(5))
 *             .setMaxAttempts(5)
 *             .setMaxRetryDelayDuration(Duration.ofSeconds(30))
 *             .setMaxRpcTimeoutDuration(Duration.ofSeconds(60))
 *             .setRetryDelayMultiplier(1.3)
 *             .setRpcTimeoutMultiplier(1.5)
 *             .setTotalTimeoutDuration(Duration.ofSeconds(300))
 *             .build());
 * HumanAgentAssistantsStubSettings humanAgentAssistantsSettings =
 *     humanAgentAssistantsSettingsBuilder.build();
 * }</pre>
 *
 * Please refer to the [Client Side Retry
 * Guide](https://github.com/googleapis/google-cloud-java/blob/main/docs/client_retries.md) for
 * additional support in setting retries.
 *
 * @deprecated This class is deprecated and will be removed in the next major version update.
 */
@BetaApi
@Deprecated
@Generated("by gapic-generator-java")
public class HumanAgentAssistantsStubSettings
    extends StubSettings<HumanAgentAssistantsStubSettings> {
  /** The default scopes of the service. */
  private static final ImmutableList<String> DEFAULT_SERVICE_SCOPES =
      ImmutableList.<String>builder()
          .add("https://www.googleapis.com/auth/cloud-platform")
          .add("https://www.googleapis.com/auth/dialogflow")
          .build();

  private final PagedCallSettings<
          ListHumanAgentAssistantsRequest,
          ListHumanAgentAssistantsResponse,
          ListHumanAgentAssistantsPagedResponse>
      listHumanAgentAssistantsSettings;
  private final UnaryCallSettings<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantSettings;
  private final UnaryCallSettings<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantSettings;
  private final UnaryCallSettings<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantSettings;
  private final UnaryCallSettings<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantSettings;
  private final UnaryCallSettings<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsSettings;
  private final PagedCallSettings<
          ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
      listLocationsSettings;
  private final UnaryCallSettings<GetLocationRequest, Location> getLocationSettings;

  private static final PagedListDescriptor<
          ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse, HumanAgentAssistant>
      LIST_HUMAN_AGENT_ASSISTANTS_PAGE_STR_DESC =
          new PagedListDescriptor<
              ListHumanAgentAssistantsRequest,
              ListHumanAgentAssistantsResponse,
              HumanAgentAssistant>() {
            @Override
            public String emptyToken() {
              return "";
            }

            @Override
            public ListHumanAgentAssistantsRequest injectToken(
                ListHumanAgentAssistantsRequest payload, String token) {
              return ListHumanAgentAssistantsRequest.newBuilder(payload)
                  .setPageToken(token)
                  .build();
            }

            @Override
            public ListHumanAgentAssistantsRequest injectPageSize(
                ListHumanAgentAssistantsRequest payload, int pageSize) {
              return ListHumanAgentAssistantsRequest.newBuilder(payload)
                  .setPageSize(pageSize)
                  .build();
            }

            @Override
            public Integer extractPageSize(ListHumanAgentAssistantsRequest payload) {
              return payload.getPageSize();
            }

            @Override
            public String extractNextToken(ListHumanAgentAssistantsResponse payload) {
              return payload.getNextPageToken();
            }

            @Override
            public Iterable<HumanAgentAssistant> extractResources(
                ListHumanAgentAssistantsResponse payload) {
              return payload.getHumanAgentAssistantsList();
            }
          };

  private static final PagedListDescriptor<ListLocationsRequest, ListLocationsResponse, Location>
      LIST_LOCATIONS_PAGE_STR_DESC =
          new PagedListDescriptor<ListLocationsRequest, ListLocationsResponse, Location>() {
            @Override
            public String emptyToken() {
              return "";
            }

            @Override
            public ListLocationsRequest injectToken(ListLocationsRequest payload, String token) {
              return ListLocationsRequest.newBuilder(payload).setPageToken(token).build();
            }

            @Override
            public ListLocationsRequest injectPageSize(ListLocationsRequest payload, int pageSize) {
              return ListLocationsRequest.newBuilder(payload).setPageSize(pageSize).build();
            }

            @Override
            public Integer extractPageSize(ListLocationsRequest payload) {
              return payload.getPageSize();
            }

            @Override
            public String extractNextToken(ListLocationsResponse payload) {
              return payload.getNextPageToken();
            }

            @Override
            public Iterable<Location> extractResources(ListLocationsResponse payload) {
              return payload.getLocationsList();
            }
          };

  private static final PagedListResponseFactory<
          ListHumanAgentAssistantsRequest,
          ListHumanAgentAssistantsResponse,
          ListHumanAgentAssistantsPagedResponse>
      LIST_HUMAN_AGENT_ASSISTANTS_PAGE_STR_FACT =
          new PagedListResponseFactory<
              ListHumanAgentAssistantsRequest,
              ListHumanAgentAssistantsResponse,
              ListHumanAgentAssistantsPagedResponse>() {
            @Override
            public ApiFuture<ListHumanAgentAssistantsPagedResponse> getFuturePagedResponse(
                UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
                    callable,
                ListHumanAgentAssistantsRequest request,
                ApiCallContext context,
                ApiFuture<ListHumanAgentAssistantsResponse> futureResponse) {
              PageContext<
                      ListHumanAgentAssistantsRequest,
                      ListHumanAgentAssistantsResponse,
                      HumanAgentAssistant>
                  pageContext =
                      PageContext.create(
                          callable, LIST_HUMAN_AGENT_ASSISTANTS_PAGE_STR_DESC, request, context);
              return ListHumanAgentAssistantsPagedResponse.createAsync(pageContext, futureResponse);
            }
          };

  private static final PagedListResponseFactory<
          ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
      LIST_LOCATIONS_PAGE_STR_FACT =
          new PagedListResponseFactory<
              ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>() {
            @Override
            public ApiFuture<ListLocationsPagedResponse> getFuturePagedResponse(
                UnaryCallable<ListLocationsRequest, ListLocationsResponse> callable,
                ListLocationsRequest request,
                ApiCallContext context,
                ApiFuture<ListLocationsResponse> futureResponse) {
              PageContext<ListLocationsRequest, ListLocationsResponse, Location> pageContext =
                  PageContext.create(callable, LIST_LOCATIONS_PAGE_STR_DESC, request, context);
              return ListLocationsPagedResponse.createAsync(pageContext, futureResponse);
            }
          };

  /**
   * Returns the object with the settings used for calls to listHumanAgentAssistants.
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public PagedCallSettings<
          ListHumanAgentAssistantsRequest,
          ListHumanAgentAssistantsResponse,
          ListHumanAgentAssistantsPagedResponse>
      listHumanAgentAssistantsSettings() {
    return listHumanAgentAssistantsSettings;
  }

  /**
   * Returns the object with the settings used for calls to getHumanAgentAssistant.
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public UnaryCallSettings<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantSettings() {
    return getHumanAgentAssistantSettings;
  }

  /**
   * Returns the object with the settings used for calls to createHumanAgentAssistant.
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public UnaryCallSettings<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantSettings() {
    return createHumanAgentAssistantSettings;
  }

  /**
   * Returns the object with the settings used for calls to updateHumanAgentAssistant.
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public UnaryCallSettings<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantSettings() {
    return updateHumanAgentAssistantSettings;
  }

  /**
   * Returns the object with the settings used for calls to deleteHumanAgentAssistant.
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public UnaryCallSettings<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantSettings() {
    return deleteHumanAgentAssistantSettings;
  }

  /**
   * Returns the object with the settings used for calls to compileSuggestions.
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public UnaryCallSettings<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsSettings() {
    return compileSuggestionsSettings;
  }

  /** Returns the object with the settings used for calls to listLocations. */
  public PagedCallSettings<ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
      listLocationsSettings() {
    return listLocationsSettings;
  }

  /** Returns the object with the settings used for calls to getLocation. */
  public UnaryCallSettings<GetLocationRequest, Location> getLocationSettings() {
    return getLocationSettings;
  }

  public HumanAgentAssistantsStub createStub() throws IOException {
    if (getTransportChannelProvider()
        .getTransportName()
        .equals(GrpcTransportChannel.getGrpcTransportName())) {
      return GrpcHumanAgentAssistantsStub.create(this);
    }
    if (getTransportChannelProvider()
        .getTransportName()
        .equals(HttpJsonTransportChannel.getHttpJsonTransportName())) {
      return HttpJsonHumanAgentAssistantsStub.create(this);
    }
    throw new UnsupportedOperationException(
        String.format(
            "Transport not supported: %s", getTransportChannelProvider().getTransportName()));
  }

  /** Returns the default service name. */
  @Override
  public String getServiceName() {
    return "dialogflow";
  }

  /** Returns a builder for the default ExecutorProvider for this service. */
  public static InstantiatingExecutorProvider.Builder defaultExecutorProviderBuilder() {
    return InstantiatingExecutorProvider.newBuilder();
  }

  /** Returns the default service endpoint. */
  @ObsoleteApi("Use getEndpoint() instead")
  public static String getDefaultEndpoint() {
    return "dialogflow.googleapis.com:443";
  }

  /** Returns the default mTLS service endpoint. */
  public static String getDefaultMtlsEndpoint() {
    return "dialogflow.mtls.googleapis.com:443";
  }

  /** Returns the default service scopes. */
  public static List<String> getDefaultServiceScopes() {
    return DEFAULT_SERVICE_SCOPES;
  }

  /** Returns a builder for the default credentials for this service. */
  public static GoogleCredentialsProvider.Builder defaultCredentialsProviderBuilder() {
    return GoogleCredentialsProvider.newBuilder()
        .setScopesToApply(DEFAULT_SERVICE_SCOPES)
        .setUseJwtAccessWithScope(true);
  }

  /** Returns a builder for the default gRPC ChannelProvider for this service. */
  public static InstantiatingGrpcChannelProvider.Builder defaultGrpcTransportProviderBuilder() {
    return InstantiatingGrpcChannelProvider.newBuilder()
        .setMaxInboundMessageSize(Integer.MAX_VALUE);
  }

  /** Returns a builder for the default REST ChannelProvider for this service. */
  @BetaApi
  public static InstantiatingHttpJsonChannelProvider.Builder
      defaultHttpJsonTransportProviderBuilder() {
    return InstantiatingHttpJsonChannelProvider.newBuilder();
  }

  public static TransportChannelProvider defaultTransportChannelProvider() {
    return defaultGrpcTransportProviderBuilder().build();
  }

  public static ApiClientHeaderProvider.Builder defaultGrpcApiClientHeaderProviderBuilder() {
    return ApiClientHeaderProvider.newBuilder()
        .setGeneratedLibToken(
            "gapic", GaxProperties.getLibraryVersion(HumanAgentAssistantsStubSettings.class))
        .setTransportToken(
            GaxGrpcProperties.getGrpcTokenName(), GaxGrpcProperties.getGrpcVersion());
  }

  public static ApiClientHeaderProvider.Builder defaultHttpJsonApiClientHeaderProviderBuilder() {
    return ApiClientHeaderProvider.newBuilder()
        .setGeneratedLibToken(
            "gapic", GaxProperties.getLibraryVersion(HumanAgentAssistantsStubSettings.class))
        .setTransportToken(
            GaxHttpJsonProperties.getHttpJsonTokenName(),
            GaxHttpJsonProperties.getHttpJsonVersion());
  }

  public static ApiClientHeaderProvider.Builder defaultApiClientHeaderProviderBuilder() {
    return HumanAgentAssistantsStubSettings.defaultGrpcApiClientHeaderProviderBuilder();
  }

  /** Returns a new gRPC builder for this class. */
  public static Builder newBuilder() {
    return Builder.createDefault();
  }

  /** Returns a new REST builder for this class. */
  public static Builder newHttpJsonBuilder() {
    return Builder.createHttpJsonDefault();
  }

  /** Returns a new builder for this class. */
  public static Builder newBuilder(ClientContext clientContext) {
    return new Builder(clientContext);
  }

  /** Returns a builder containing all the values of this settings class. */
  public Builder toBuilder() {
    return new Builder(this);
  }

  protected HumanAgentAssistantsStubSettings(Builder settingsBuilder) throws IOException {
    super(settingsBuilder);

    listHumanAgentAssistantsSettings = settingsBuilder.listHumanAgentAssistantsSettings().build();
    getHumanAgentAssistantSettings = settingsBuilder.getHumanAgentAssistantSettings().build();
    createHumanAgentAssistantSettings = settingsBuilder.createHumanAgentAssistantSettings().build();
    updateHumanAgentAssistantSettings = settingsBuilder.updateHumanAgentAssistantSettings().build();
    deleteHumanAgentAssistantSettings = settingsBuilder.deleteHumanAgentAssistantSettings().build();
    compileSuggestionsSettings = settingsBuilder.compileSuggestionsSettings().build();
    listLocationsSettings = settingsBuilder.listLocationsSettings().build();
    getLocationSettings = settingsBuilder.getLocationSettings().build();
  }

  /** Builder for HumanAgentAssistantsStubSettings. */
  public static class Builder
      extends StubSettings.Builder<HumanAgentAssistantsStubSettings, Builder> {
    private final ImmutableList<UnaryCallSettings.Builder<?, ?>> unaryMethodSettingsBuilders;
    private final PagedCallSettings.Builder<
            ListHumanAgentAssistantsRequest,
            ListHumanAgentAssistantsResponse,
            ListHumanAgentAssistantsPagedResponse>
        listHumanAgentAssistantsSettings;
    private final UnaryCallSettings.Builder<GetHumanAgentAssistantRequest, HumanAgentAssistant>
        getHumanAgentAssistantSettings;
    private final UnaryCallSettings.Builder<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
        createHumanAgentAssistantSettings;
    private final UnaryCallSettings.Builder<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
        updateHumanAgentAssistantSettings;
    private final UnaryCallSettings.Builder<DeleteHumanAgentAssistantRequest, Empty>
        deleteHumanAgentAssistantSettings;
    private final UnaryCallSettings.Builder<CompileSuggestionsRequest, CompileSuggestionsResponse>
        compileSuggestionsSettings;
    private final PagedCallSettings.Builder<
            ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
        listLocationsSettings;
    private final UnaryCallSettings.Builder<GetLocationRequest, Location> getLocationSettings;
    private static final ImmutableMap<String, ImmutableSet<StatusCode.Code>>
        RETRYABLE_CODE_DEFINITIONS;

    static {
      ImmutableMap.Builder<String, ImmutableSet<StatusCode.Code>> definitions =
          ImmutableMap.builder();
      definitions.put(
          "retry_policy_0_codes",
          ImmutableSet.copyOf(Lists.<StatusCode.Code>newArrayList(StatusCode.Code.UNAVAILABLE)));
      RETRYABLE_CODE_DEFINITIONS = definitions.build();
    }

    private static final ImmutableMap<String, RetrySettings> RETRY_PARAM_DEFINITIONS;

    static {
      ImmutableMap.Builder<String, RetrySettings> definitions = ImmutableMap.builder();
      RetrySettings settings = null;
      settings =
          RetrySettings.newBuilder()
              .setInitialRetryDelayDuration(Duration.ofMillis(100L))
              .setRetryDelayMultiplier(1.3)
              .setMaxRetryDelayDuration(Duration.ofMillis(60000L))
              .setInitialRpcTimeoutDuration(Duration.ofMillis(60000L))
              .setRpcTimeoutMultiplier(1.0)
              .setMaxRpcTimeoutDuration(Duration.ofMillis(60000L))
              .setTotalTimeoutDuration(Duration.ofMillis(60000L))
              .build();
      definitions.put("retry_policy_0_params", settings);
      RETRY_PARAM_DEFINITIONS = definitions.build();
    }

    protected Builder() {
      this(((ClientContext) null));
    }

    protected Builder(ClientContext clientContext) {
      super(clientContext);

      listHumanAgentAssistantsSettings =
          PagedCallSettings.newBuilder(LIST_HUMAN_AGENT_ASSISTANTS_PAGE_STR_FACT);
      getHumanAgentAssistantSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      createHumanAgentAssistantSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      updateHumanAgentAssistantSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      deleteHumanAgentAssistantSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      compileSuggestionsSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      listLocationsSettings = PagedCallSettings.newBuilder(LIST_LOCATIONS_PAGE_STR_FACT);
      getLocationSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();

      unaryMethodSettingsBuilders =
          ImmutableList.<UnaryCallSettings.Builder<?, ?>>of(
              listHumanAgentAssistantsSettings,
              getHumanAgentAssistantSettings,
              createHumanAgentAssistantSettings,
              updateHumanAgentAssistantSettings,
              deleteHumanAgentAssistantSettings,
              compileSuggestionsSettings,
              listLocationsSettings,
              getLocationSettings);
      initDefaults(this);
    }

    protected Builder(HumanAgentAssistantsStubSettings settings) {
      super(settings);

      listHumanAgentAssistantsSettings = settings.listHumanAgentAssistantsSettings.toBuilder();
      getHumanAgentAssistantSettings = settings.getHumanAgentAssistantSettings.toBuilder();
      createHumanAgentAssistantSettings = settings.createHumanAgentAssistantSettings.toBuilder();
      updateHumanAgentAssistantSettings = settings.updateHumanAgentAssistantSettings.toBuilder();
      deleteHumanAgentAssistantSettings = settings.deleteHumanAgentAssistantSettings.toBuilder();
      compileSuggestionsSettings = settings.compileSuggestionsSettings.toBuilder();
      listLocationsSettings = settings.listLocationsSettings.toBuilder();
      getLocationSettings = settings.getLocationSettings.toBuilder();

      unaryMethodSettingsBuilders =
          ImmutableList.<UnaryCallSettings.Builder<?, ?>>of(
              listHumanAgentAssistantsSettings,
              getHumanAgentAssistantSettings,
              createHumanAgentAssistantSettings,
              updateHumanAgentAssistantSettings,
              deleteHumanAgentAssistantSettings,
              compileSuggestionsSettings,
              listLocationsSettings,
              getLocationSettings);
    }

    private static Builder createDefault() {
      Builder builder = new Builder(((ClientContext) null));

      builder.setTransportChannelProvider(defaultTransportChannelProvider());
      builder.setCredentialsProvider(defaultCredentialsProviderBuilder().build());
      builder.setInternalHeaderProvider(defaultApiClientHeaderProviderBuilder().build());
      builder.setMtlsEndpoint(getDefaultMtlsEndpoint());
      builder.setSwitchToMtlsEndpointAllowed(true);

      return initDefaults(builder);
    }

    private static Builder createHttpJsonDefault() {
      Builder builder = new Builder(((ClientContext) null));

      builder.setTransportChannelProvider(defaultHttpJsonTransportProviderBuilder().build());
      builder.setCredentialsProvider(defaultCredentialsProviderBuilder().build());
      builder.setInternalHeaderProvider(defaultHttpJsonApiClientHeaderProviderBuilder().build());
      builder.setMtlsEndpoint(getDefaultMtlsEndpoint());
      builder.setSwitchToMtlsEndpointAllowed(true);

      return initDefaults(builder);
    }

    private static Builder initDefaults(Builder builder) {
      builder
          .listHumanAgentAssistantsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .getHumanAgentAssistantSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .createHumanAgentAssistantSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .updateHumanAgentAssistantSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .deleteHumanAgentAssistantSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .compileSuggestionsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .listLocationsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .getLocationSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      return builder;
    }

    /**
     * Applies the given settings updater function to all of the unary API methods in this service.
     *
     * <p>Note: This method does not support applying settings to streaming methods.
     */
    public Builder applyToAllUnaryMethods(
        ApiFunction<UnaryCallSettings.Builder<?, ?>, Void> settingsUpdater) {
      super.applyToAllUnaryMethods(unaryMethodSettingsBuilders, settingsUpdater);
      return this;
    }

    public ImmutableList<UnaryCallSettings.Builder<?, ?>> unaryMethodSettingsBuilders() {
      return unaryMethodSettingsBuilders;
    }

    /**
     * Returns the builder for the settings used for calls to listHumanAgentAssistants.
     *
     * @deprecated This method is deprecated and will be removed in the next major version update.
     */
    @Deprecated
    public PagedCallSettings.Builder<
            ListHumanAgentAssistantsRequest,
            ListHumanAgentAssistantsResponse,
            ListHumanAgentAssistantsPagedResponse>
        listHumanAgentAssistantsSettings() {
      return listHumanAgentAssistantsSettings;
    }

    /**
     * Returns the builder for the settings used for calls to getHumanAgentAssistant.
     *
     * @deprecated This method is deprecated and will be removed in the next major version update.
     */
    @Deprecated
    public UnaryCallSettings.Builder<GetHumanAgentAssistantRequest, HumanAgentAssistant>
        getHumanAgentAssistantSettings() {
      return getHumanAgentAssistantSettings;
    }

    /**
     * Returns the builder for the settings used for calls to createHumanAgentAssistant.
     *
     * @deprecated This method is deprecated and will be removed in the next major version update.
     */
    @Deprecated
    public UnaryCallSettings.Builder<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
        createHumanAgentAssistantSettings() {
      return createHumanAgentAssistantSettings;
    }

    /**
     * Returns the builder for the settings used for calls to updateHumanAgentAssistant.
     *
     * @deprecated This method is deprecated and will be removed in the next major version update.
     */
    @Deprecated
    public UnaryCallSettings.Builder<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
        updateHumanAgentAssistantSettings() {
      return updateHumanAgentAssistantSettings;
    }

    /**
     * Returns the builder for the settings used for calls to deleteHumanAgentAssistant.
     *
     * @deprecated This method is deprecated and will be removed in the next major version update.
     */
    @Deprecated
    public UnaryCallSettings.Builder<DeleteHumanAgentAssistantRequest, Empty>
        deleteHumanAgentAssistantSettings() {
      return deleteHumanAgentAssistantSettings;
    }

    /**
     * Returns the builder for the settings used for calls to compileSuggestions.
     *
     * @deprecated This method is deprecated and will be removed in the next major version update.
     */
    @Deprecated
    public UnaryCallSettings.Builder<CompileSuggestionsRequest, CompileSuggestionsResponse>
        compileSuggestionsSettings() {
      return compileSuggestionsSettings;
    }

    /** Returns the builder for the settings used for calls to listLocations. */
    public PagedCallSettings.Builder<
            ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
        listLocationsSettings() {
      return listLocationsSettings;
    }

    /** Returns the builder for the settings used for calls to getLocation. */
    public UnaryCallSettings.Builder<GetLocationRequest, Location> getLocationSettings() {
      return getLocationSettings;
    }

    @Override
    public HumanAgentAssistantsStubSettings build() throws IOException {
      return new HumanAgentAssistantsStubSettings(this);
    }
  }
}
