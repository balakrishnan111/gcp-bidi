/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListCallMatchersPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListConversationsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListLocationsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListMessagesPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListPastCallCompanionEventsPagedResponse;

import com.google.api.core.ApiFunction;
import com.google.api.core.ApiFuture;
import com.google.api.core.BetaApi;
import com.google.api.core.ObsoleteApi;
import com.google.api.gax.core.GaxProperties;
import com.google.api.gax.core.GoogleCredentialsProvider;
import com.google.api.gax.core.InstantiatingExecutorProvider;
import com.google.api.gax.grpc.GaxGrpcProperties;
import com.google.api.gax.grpc.GrpcTransportChannel;
import com.google.api.gax.grpc.InstantiatingGrpcChannelProvider;
import com.google.api.gax.grpc.ProtoOperationTransformers;
import com.google.api.gax.httpjson.GaxHttpJsonProperties;
import com.google.api.gax.httpjson.HttpJsonTransportChannel;
import com.google.api.gax.httpjson.InstantiatingHttpJsonChannelProvider;
import com.google.api.gax.longrunning.OperationSnapshot;
import com.google.api.gax.longrunning.OperationTimedPollAlgorithm;
import com.google.api.gax.retrying.RetrySettings;
import com.google.api.gax.rpc.ApiCallContext;
import com.google.api.gax.rpc.ApiClientHeaderProvider;
import com.google.api.gax.rpc.ClientContext;
import com.google.api.gax.rpc.OperationCallSettings;
import com.google.api.gax.rpc.PageContext;
import com.google.api.gax.rpc.PagedCallSettings;
import com.google.api.gax.rpc.PagedListDescriptor;
import com.google.api.gax.rpc.PagedListResponseFactory;
import com.google.api.gax.rpc.ServerStreamingCallSettings;
import com.google.api.gax.rpc.StatusCode;
import com.google.api.gax.rpc.StubSettings;
import com.google.api.gax.rpc.TransportChannelProvider;
import com.google.api.gax.rpc.UnaryCallSettings;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest;
import com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.CallCompanionConversationEvent;
import com.google.cloud.dialogflow.v2beta1.CallCompanionSettings;
import com.google.cloud.dialogflow.v2beta1.CallMatcher;
import com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest;
import com.google.cloud.dialogflow.v2beta1.Conversation;
import com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber;
import com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest;
import com.google.cloud.dialogflow.v2beta1.CreateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest;
import com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.ExportMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse;
import com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest;
import com.google.cloud.dialogflow.v2beta1.GetConversationRequest;
import com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest;
import com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse;
import com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest;
import com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest;
import com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse;
import com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest;
import com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse;
import com.google.cloud.dialogflow.v2beta1.ListConversationsRequest;
import com.google.cloud.dialogflow.v2beta1.ListConversationsResponse;
import com.google.cloud.dialogflow.v2beta1.ListMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.ListMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.Message;
import com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest;
import com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse;
import com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest;
import com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse;
import com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse;
import com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.ImmutableSet;
import com.google.common.collect.Lists;
import com.google.longrunning.Operation;
import com.google.protobuf.Empty;
import com.google.protobuf.Struct;
import java.io.IOException;
import java.time.Duration;
import java.util.List;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * Settings class to configure an instance of {@link ConversationsStub}.
 *
 * <p>The default instance has everything set to sensible defaults:
 *
 * <ul>
 *   <li>The default service address (dialogflow.googleapis.com) and default port (443) are used.
 *   <li>Credentials are acquired automatically through Application Default Credentials.
 *   <li>Retries are configured for idempotent methods but not for non-idempotent methods.
 * </ul>
 *
 * <p>The builder of this class is recursive, so contained classes are themselves builders. When
 * build() is called, the tree of builders is called to create the complete settings object.
 *
 * <p>For example, to set the
 * [RetrySettings](https://cloud.google.com/java/docs/reference/gax/latest/com.google.api.gax.retrying.RetrySettings)
 * of createConversation:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * ConversationsStubSettings.Builder conversationsSettingsBuilder =
 *     ConversationsStubSettings.newBuilder();
 * conversationsSettingsBuilder
 *     .createConversationSettings()
 *     .setRetrySettings(
 *         conversationsSettingsBuilder
 *             .createConversationSettings()
 *             .getRetrySettings()
 *             .toBuilder()
 *             .setInitialRetryDelayDuration(Duration.ofSeconds(1))
 *             .setInitialRpcTimeoutDuration(Duration.ofSeconds(5))
 *             .setMaxAttempts(5)
 *             .setMaxRetryDelayDuration(Duration.ofSeconds(30))
 *             .setMaxRpcTimeoutDuration(Duration.ofSeconds(60))
 *             .setRetryDelayMultiplier(1.3)
 *             .setRpcTimeoutMultiplier(1.5)
 *             .setTotalTimeoutDuration(Duration.ofSeconds(300))
 *             .build());
 * ConversationsStubSettings conversationsSettings = conversationsSettingsBuilder.build();
 * }</pre>
 *
 * Please refer to the [Client Side Retry
 * Guide](https://github.com/googleapis/google-cloud-java/blob/main/docs/client_retries.md) for
 * additional support in setting retries.
 *
 * <p>To configure the RetrySettings of a Long Running Operation method, create an
 * OperationTimedPollAlgorithm object and update the RPC's polling algorithm. For example, to
 * configure the RetrySettings for exportMessages:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * ConversationsStubSettings.Builder conversationsSettingsBuilder =
 *     ConversationsStubSettings.newBuilder();
 * TimedRetryAlgorithm timedRetryAlgorithm =
 *     OperationalTimedPollAlgorithm.create(
 *         RetrySettings.newBuilder()
 *             .setInitialRetryDelayDuration(Duration.ofMillis(500))
 *             .setRetryDelayMultiplier(1.5)
 *             .setMaxRetryDelayDuration(Duration.ofMillis(5000))
 *             .setTotalTimeoutDuration(Duration.ofHours(24))
 *             .build());
 * conversationsSettingsBuilder
 *     .createClusterOperationSettings()
 *     .setPollingAlgorithm(timedRetryAlgorithm)
 *     .build();
 * }</pre>
 */
@BetaApi
@Generated("by gapic-generator-java")
public class ConversationsStubSettings extends StubSettings<ConversationsStubSettings> {
  /** The default scopes of the service. */
  private static final ImmutableList<String> DEFAULT_SERVICE_SCOPES =
      ImmutableList.<String>builder()
          .add("https://www.googleapis.com/auth/cloud-platform")
          .add("https://www.googleapis.com/auth/dialogflow")
          .build();

  private final UnaryCallSettings<CreateConversationRequest, Conversation>
      createConversationSettings;
  private final PagedCallSettings<
          ListConversationsRequest, ListConversationsResponse, ListConversationsPagedResponse>
      listConversationsSettings;
  private final UnaryCallSettings<GetConversationRequest, Conversation> getConversationSettings;
  private final UnaryCallSettings<AddConversationPhoneNumberRequest, ConversationPhoneNumber>
      addConversationPhoneNumberSettings;
  private final UnaryCallSettings<ActivateConversationRequest, Conversation>
      activateConversationSettings;
  private final UnaryCallSettings<DeactivateConversationRequest, Conversation>
      deactivateConversationSettings;
  private final UnaryCallSettings<CompleteConversationRequest, Conversation>
      completeConversationSettings;
  private final UnaryCallSettings<UpdateConversationRequest, Conversation>
      updateConversationSettings;
  private final UnaryCallSettings<IngestContextReferencesRequest, IngestContextReferencesResponse>
      ingestContextReferencesSettings;
  private final UnaryCallSettings<CreateCallMatcherRequest, CallMatcher> createCallMatcherSettings;
  private final PagedCallSettings<
          ListCallMatchersRequest, ListCallMatchersResponse, ListCallMatchersPagedResponse>
      listCallMatchersSettings;
  private final UnaryCallSettings<DeleteCallMatcherRequest, Empty> deleteCallMatcherSettings;
  private final UnaryCallSettings<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
      batchCreateMessagesSettings;
  private final PagedCallSettings<
          ListMessagesRequest, ListMessagesResponse, ListMessagesPagedResponse>
      listMessagesSettings;
  private final UnaryCallSettings<ExportMessagesRequest, Operation> exportMessagesSettings;
  private final OperationCallSettings<ExportMessagesRequest, ExportMessagesResponse, Struct>
      exportMessagesOperationSettings;
  private final UnaryCallSettings<
          SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
      suggestConversationSummarySettings;
  private final UnaryCallSettings<GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
      generateStatelessSummarySettings;
  private final UnaryCallSettings<
          GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
      generateStatelessSuggestionSettings;
  private final UnaryCallSettings<
          SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
      suggestConversationKeyMomentsSettings;
  private final UnaryCallSettings<SearchArticlesRequest, SearchArticlesResponse>
      searchArticlesSettings;
  private final PagedCallSettings<
          ListPastCallCompanionEventsRequest,
          ListPastCallCompanionEventsResponse,
          ListPastCallCompanionEventsPagedResponse>
      listPastCallCompanionEventsSettings;
  private final ServerStreamingCallSettings<
          StreamingListUpcomingCallCompanionEventsRequest,
          StreamingListUpcomingCallCompanionEventsResponse>
      streamingListUpcomingCallCompanionEventsSettings;
  private final UnaryCallSettings<
          InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
      injectCallCompanionUserInputSettings;
  private final ServerStreamingCallSettings<
          StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
      streamingListCallCompanionEventsSettings;
  private final UnaryCallSettings<InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
      injectCallCompanionInputSettings;
  private final UnaryCallSettings<InitializeCallCompanionRequest, Empty>
      initializeCallCompanionSettings;
  private final UnaryCallSettings<GetCallCompanionSettingsRequest, CallCompanionSettings>
      getCallCompanionSettingsSettings;
  private final UnaryCallSettings<SearchKnowledgeRequest, SearchKnowledgeResponse>
      searchKnowledgeSettings;
  private final UnaryCallSettings<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
      generateSuggestionsSettings;
  private final UnaryCallSettings<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
      initiatePhoneCallSettings;
  private final PagedCallSettings<
          ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
      listLocationsSettings;
  private final UnaryCallSettings<GetLocationRequest, Location> getLocationSettings;

  private static final PagedListDescriptor<
          ListConversationsRequest, ListConversationsResponse, Conversation>
      LIST_CONVERSATIONS_PAGE_STR_DESC =
          new PagedListDescriptor<
              ListConversationsRequest, ListConversationsResponse, Conversation>() {
            @Override
            public String emptyToken() {
              return "";
            }

            @Override
            public ListConversationsRequest injectToken(
                ListConversationsRequest payload, String token) {
              return ListConversationsRequest.newBuilder(payload).setPageToken(token).build();
            }

            @Override
            public ListConversationsRequest injectPageSize(
                ListConversationsRequest payload, int pageSize) {
              return ListConversationsRequest.newBuilder(payload).setPageSize(pageSize).build();
            }

            @Override
            public Integer extractPageSize(ListConversationsRequest payload) {
              return payload.getPageSize();
            }

            @Override
            public String extractNextToken(ListConversationsResponse payload) {
              return payload.getNextPageToken();
            }

            @Override
            public Iterable<Conversation> extractResources(ListConversationsResponse payload) {
              return payload.getConversationsList();
            }
          };

  private static final PagedListDescriptor<
          ListCallMatchersRequest, ListCallMatchersResponse, CallMatcher>
      LIST_CALL_MATCHERS_PAGE_STR_DESC =
          new PagedListDescriptor<
              ListCallMatchersRequest, ListCallMatchersResponse, CallMatcher>() {
            @Override
            public String emptyToken() {
              return "";
            }

            @Override
            public ListCallMatchersRequest injectToken(
                ListCallMatchersRequest payload, String token) {
              return ListCallMatchersRequest.newBuilder(payload).setPageToken(token).build();
            }

            @Override
            public ListCallMatchersRequest injectPageSize(
                ListCallMatchersRequest payload, int pageSize) {
              return ListCallMatchersRequest.newBuilder(payload).setPageSize(pageSize).build();
            }

            @Override
            public Integer extractPageSize(ListCallMatchersRequest payload) {
              return payload.getPageSize();
            }

            @Override
            public String extractNextToken(ListCallMatchersResponse payload) {
              return payload.getNextPageToken();
            }

            @Override
            public Iterable<CallMatcher> extractResources(ListCallMatchersResponse payload) {
              return payload.getCallMatchersList();
            }
          };

  private static final PagedListDescriptor<ListMessagesRequest, ListMessagesResponse, Message>
      LIST_MESSAGES_PAGE_STR_DESC =
          new PagedListDescriptor<ListMessagesRequest, ListMessagesResponse, Message>() {
            @Override
            public String emptyToken() {
              return "";
            }

            @Override
            public ListMessagesRequest injectToken(ListMessagesRequest payload, String token) {
              return ListMessagesRequest.newBuilder(payload).setPageToken(token).build();
            }

            @Override
            public ListMessagesRequest injectPageSize(ListMessagesRequest payload, int pageSize) {
              return ListMessagesRequest.newBuilder(payload).setPageSize(pageSize).build();
            }

            @Override
            public Integer extractPageSize(ListMessagesRequest payload) {
              return payload.getPageSize();
            }

            @Override
            public String extractNextToken(ListMessagesResponse payload) {
              return payload.getNextPageToken();
            }

            @Override
            public Iterable<Message> extractResources(ListMessagesResponse payload) {
              return payload.getMessagesList();
            }
          };

  private static final PagedListDescriptor<
          ListPastCallCompanionEventsRequest,
          ListPastCallCompanionEventsResponse,
          CallCompanionConversationEvent>
      LIST_PAST_CALL_COMPANION_EVENTS_PAGE_STR_DESC =
          new PagedListDescriptor<
              ListPastCallCompanionEventsRequest,
              ListPastCallCompanionEventsResponse,
              CallCompanionConversationEvent>() {
            @Override
            public String emptyToken() {
              return "";
            }

            @Override
            public ListPastCallCompanionEventsRequest injectToken(
                ListPastCallCompanionEventsRequest payload, String token) {
              return ListPastCallCompanionEventsRequest.newBuilder(payload)
                  .setPageToken(token)
                  .build();
            }

            @Override
            public ListPastCallCompanionEventsRequest injectPageSize(
                ListPastCallCompanionEventsRequest payload, int pageSize) {
              return ListPastCallCompanionEventsRequest.newBuilder(payload)
                  .setPageSize(pageSize)
                  .build();
            }

            @Override
            public Integer extractPageSize(ListPastCallCompanionEventsRequest payload) {
              return payload.getPageSize();
            }

            @Override
            public String extractNextToken(ListPastCallCompanionEventsResponse payload) {
              return payload.getNextPageToken();
            }

            @Override
            public Iterable<CallCompanionConversationEvent> extractResources(
                ListPastCallCompanionEventsResponse payload) {
              return payload.getCallCompanionConversationEventsList();
            }
          };

  private static final PagedListDescriptor<ListLocationsRequest, ListLocationsResponse, Location>
      LIST_LOCATIONS_PAGE_STR_DESC =
          new PagedListDescriptor<ListLocationsRequest, ListLocationsResponse, Location>() {
            @Override
            public String emptyToken() {
              return "";
            }

            @Override
            public ListLocationsRequest injectToken(ListLocationsRequest payload, String token) {
              return ListLocationsRequest.newBuilder(payload).setPageToken(token).build();
            }

            @Override
            public ListLocationsRequest injectPageSize(ListLocationsRequest payload, int pageSize) {
              return ListLocationsRequest.newBuilder(payload).setPageSize(pageSize).build();
            }

            @Override
            public Integer extractPageSize(ListLocationsRequest payload) {
              return payload.getPageSize();
            }

            @Override
            public String extractNextToken(ListLocationsResponse payload) {
              return payload.getNextPageToken();
            }

            @Override
            public Iterable<Location> extractResources(ListLocationsResponse payload) {
              return payload.getLocationsList();
            }
          };

  private static final PagedListResponseFactory<
          ListConversationsRequest, ListConversationsResponse, ListConversationsPagedResponse>
      LIST_CONVERSATIONS_PAGE_STR_FACT =
          new PagedListResponseFactory<
              ListConversationsRequest,
              ListConversationsResponse,
              ListConversationsPagedResponse>() {
            @Override
            public ApiFuture<ListConversationsPagedResponse> getFuturePagedResponse(
                UnaryCallable<ListConversationsRequest, ListConversationsResponse> callable,
                ListConversationsRequest request,
                ApiCallContext context,
                ApiFuture<ListConversationsResponse> futureResponse) {
              PageContext<ListConversationsRequest, ListConversationsResponse, Conversation>
                  pageContext =
                      PageContext.create(
                          callable, LIST_CONVERSATIONS_PAGE_STR_DESC, request, context);
              return ListConversationsPagedResponse.createAsync(pageContext, futureResponse);
            }
          };

  private static final PagedListResponseFactory<
          ListCallMatchersRequest, ListCallMatchersResponse, ListCallMatchersPagedResponse>
      LIST_CALL_MATCHERS_PAGE_STR_FACT =
          new PagedListResponseFactory<
              ListCallMatchersRequest, ListCallMatchersResponse, ListCallMatchersPagedResponse>() {
            @Override
            public ApiFuture<ListCallMatchersPagedResponse> getFuturePagedResponse(
                UnaryCallable<ListCallMatchersRequest, ListCallMatchersResponse> callable,
                ListCallMatchersRequest request,
                ApiCallContext context,
                ApiFuture<ListCallMatchersResponse> futureResponse) {
              PageContext<ListCallMatchersRequest, ListCallMatchersResponse, CallMatcher>
                  pageContext =
                      PageContext.create(
                          callable, LIST_CALL_MATCHERS_PAGE_STR_DESC, request, context);
              return ListCallMatchersPagedResponse.createAsync(pageContext, futureResponse);
            }
          };

  private static final PagedListResponseFactory<
          ListMessagesRequest, ListMessagesResponse, ListMessagesPagedResponse>
      LIST_MESSAGES_PAGE_STR_FACT =
          new PagedListResponseFactory<
              ListMessagesRequest, ListMessagesResponse, ListMessagesPagedResponse>() {
            @Override
            public ApiFuture<ListMessagesPagedResponse> getFuturePagedResponse(
                UnaryCallable<ListMessagesRequest, ListMessagesResponse> callable,
                ListMessagesRequest request,
                ApiCallContext context,
                ApiFuture<ListMessagesResponse> futureResponse) {
              PageContext<ListMessagesRequest, ListMessagesResponse, Message> pageContext =
                  PageContext.create(callable, LIST_MESSAGES_PAGE_STR_DESC, request, context);
              return ListMessagesPagedResponse.createAsync(pageContext, futureResponse);
            }
          };

  private static final PagedListResponseFactory<
          ListPastCallCompanionEventsRequest,
          ListPastCallCompanionEventsResponse,
          ListPastCallCompanionEventsPagedResponse>
      LIST_PAST_CALL_COMPANION_EVENTS_PAGE_STR_FACT =
          new PagedListResponseFactory<
              ListPastCallCompanionEventsRequest,
              ListPastCallCompanionEventsResponse,
              ListPastCallCompanionEventsPagedResponse>() {
            @Override
            public ApiFuture<ListPastCallCompanionEventsPagedResponse> getFuturePagedResponse(
                UnaryCallable<
                        ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsResponse>
                    callable,
                ListPastCallCompanionEventsRequest request,
                ApiCallContext context,
                ApiFuture<ListPastCallCompanionEventsResponse> futureResponse) {
              PageContext<
                      ListPastCallCompanionEventsRequest,
                      ListPastCallCompanionEventsResponse,
                      CallCompanionConversationEvent>
                  pageContext =
                      PageContext.create(
                          callable,
                          LIST_PAST_CALL_COMPANION_EVENTS_PAGE_STR_DESC,
                          request,
                          context);
              return ListPastCallCompanionEventsPagedResponse.createAsync(
                  pageContext, futureResponse);
            }
          };

  private static final PagedListResponseFactory<
          ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
      LIST_LOCATIONS_PAGE_STR_FACT =
          new PagedListResponseFactory<
              ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>() {
            @Override
            public ApiFuture<ListLocationsPagedResponse> getFuturePagedResponse(
                UnaryCallable<ListLocationsRequest, ListLocationsResponse> callable,
                ListLocationsRequest request,
                ApiCallContext context,
                ApiFuture<ListLocationsResponse> futureResponse) {
              PageContext<ListLocationsRequest, ListLocationsResponse, Location> pageContext =
                  PageContext.create(callable, LIST_LOCATIONS_PAGE_STR_DESC, request, context);
              return ListLocationsPagedResponse.createAsync(pageContext, futureResponse);
            }
          };

  /** Returns the object with the settings used for calls to createConversation. */
  public UnaryCallSettings<CreateConversationRequest, Conversation> createConversationSettings() {
    return createConversationSettings;
  }

  /** Returns the object with the settings used for calls to listConversations. */
  public PagedCallSettings<
          ListConversationsRequest, ListConversationsResponse, ListConversationsPagedResponse>
      listConversationsSettings() {
    return listConversationsSettings;
  }

  /** Returns the object with the settings used for calls to getConversation. */
  public UnaryCallSettings<GetConversationRequest, Conversation> getConversationSettings() {
    return getConversationSettings;
  }

  /** Returns the object with the settings used for calls to addConversationPhoneNumber. */
  public UnaryCallSettings<AddConversationPhoneNumberRequest, ConversationPhoneNumber>
      addConversationPhoneNumberSettings() {
    return addConversationPhoneNumberSettings;
  }

  /** Returns the object with the settings used for calls to activateConversation. */
  public UnaryCallSettings<ActivateConversationRequest, Conversation>
      activateConversationSettings() {
    return activateConversationSettings;
  }

  /** Returns the object with the settings used for calls to deactivateConversation. */
  public UnaryCallSettings<DeactivateConversationRequest, Conversation>
      deactivateConversationSettings() {
    return deactivateConversationSettings;
  }

  /** Returns the object with the settings used for calls to completeConversation. */
  public UnaryCallSettings<CompleteConversationRequest, Conversation>
      completeConversationSettings() {
    return completeConversationSettings;
  }

  /** Returns the object with the settings used for calls to updateConversation. */
  public UnaryCallSettings<UpdateConversationRequest, Conversation> updateConversationSettings() {
    return updateConversationSettings;
  }

  /** Returns the object with the settings used for calls to ingestContextReferences. */
  public UnaryCallSettings<IngestContextReferencesRequest, IngestContextReferencesResponse>
      ingestContextReferencesSettings() {
    return ingestContextReferencesSettings;
  }

  /** Returns the object with the settings used for calls to createCallMatcher. */
  public UnaryCallSettings<CreateCallMatcherRequest, CallMatcher> createCallMatcherSettings() {
    return createCallMatcherSettings;
  }

  /** Returns the object with the settings used for calls to listCallMatchers. */
  public PagedCallSettings<
          ListCallMatchersRequest, ListCallMatchersResponse, ListCallMatchersPagedResponse>
      listCallMatchersSettings() {
    return listCallMatchersSettings;
  }

  /** Returns the object with the settings used for calls to deleteCallMatcher. */
  public UnaryCallSettings<DeleteCallMatcherRequest, Empty> deleteCallMatcherSettings() {
    return deleteCallMatcherSettings;
  }

  /** Returns the object with the settings used for calls to batchCreateMessages. */
  public UnaryCallSettings<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
      batchCreateMessagesSettings() {
    return batchCreateMessagesSettings;
  }

  /** Returns the object with the settings used for calls to listMessages. */
  public PagedCallSettings<ListMessagesRequest, ListMessagesResponse, ListMessagesPagedResponse>
      listMessagesSettings() {
    return listMessagesSettings;
  }

  /** Returns the object with the settings used for calls to exportMessages. */
  public UnaryCallSettings<ExportMessagesRequest, Operation> exportMessagesSettings() {
    return exportMessagesSettings;
  }

  /** Returns the object with the settings used for calls to exportMessages. */
  public OperationCallSettings<ExportMessagesRequest, ExportMessagesResponse, Struct>
      exportMessagesOperationSettings() {
    return exportMessagesOperationSettings;
  }

  /** Returns the object with the settings used for calls to suggestConversationSummary. */
  public UnaryCallSettings<SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
      suggestConversationSummarySettings() {
    return suggestConversationSummarySettings;
  }

  /** Returns the object with the settings used for calls to generateStatelessSummary. */
  public UnaryCallSettings<GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
      generateStatelessSummarySettings() {
    return generateStatelessSummarySettings;
  }

  /** Returns the object with the settings used for calls to generateStatelessSuggestion. */
  public UnaryCallSettings<GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
      generateStatelessSuggestionSettings() {
    return generateStatelessSuggestionSettings;
  }

  /** Returns the object with the settings used for calls to suggestConversationKeyMoments. */
  public UnaryCallSettings<
          SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
      suggestConversationKeyMomentsSettings() {
    return suggestConversationKeyMomentsSettings;
  }

  /** Returns the object with the settings used for calls to searchArticles. */
  public UnaryCallSettings<SearchArticlesRequest, SearchArticlesResponse> searchArticlesSettings() {
    return searchArticlesSettings;
  }

  /** Returns the object with the settings used for calls to listPastCallCompanionEvents. */
  public PagedCallSettings<
          ListPastCallCompanionEventsRequest,
          ListPastCallCompanionEventsResponse,
          ListPastCallCompanionEventsPagedResponse>
      listPastCallCompanionEventsSettings() {
    return listPastCallCompanionEventsSettings;
  }

  /**
   * Returns the object with the settings used for calls to
   * streamingListUpcomingCallCompanionEvents.
   */
  public ServerStreamingCallSettings<
          StreamingListUpcomingCallCompanionEventsRequest,
          StreamingListUpcomingCallCompanionEventsResponse>
      streamingListUpcomingCallCompanionEventsSettings() {
    return streamingListUpcomingCallCompanionEventsSettings;
  }

  /** Returns the object with the settings used for calls to injectCallCompanionUserInput. */
  public UnaryCallSettings<
          InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
      injectCallCompanionUserInputSettings() {
    return injectCallCompanionUserInputSettings;
  }

  /** Returns the object with the settings used for calls to streamingListCallCompanionEvents. */
  public ServerStreamingCallSettings<
          StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
      streamingListCallCompanionEventsSettings() {
    return streamingListCallCompanionEventsSettings;
  }

  /** Returns the object with the settings used for calls to injectCallCompanionInput. */
  public UnaryCallSettings<InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
      injectCallCompanionInputSettings() {
    return injectCallCompanionInputSettings;
  }

  /** Returns the object with the settings used for calls to initializeCallCompanion. */
  public UnaryCallSettings<InitializeCallCompanionRequest, Empty>
      initializeCallCompanionSettings() {
    return initializeCallCompanionSettings;
  }

  /** Returns the object with the settings used for calls to getCallCompanionSettings. */
  public UnaryCallSettings<GetCallCompanionSettingsRequest, CallCompanionSettings>
      getCallCompanionSettingsSettings() {
    return getCallCompanionSettingsSettings;
  }

  /** Returns the object with the settings used for calls to searchKnowledge. */
  public UnaryCallSettings<SearchKnowledgeRequest, SearchKnowledgeResponse>
      searchKnowledgeSettings() {
    return searchKnowledgeSettings;
  }

  /** Returns the object with the settings used for calls to generateSuggestions. */
  public UnaryCallSettings<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
      generateSuggestionsSettings() {
    return generateSuggestionsSettings;
  }

  /** Returns the object with the settings used for calls to initiatePhoneCall. */
  public UnaryCallSettings<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
      initiatePhoneCallSettings() {
    return initiatePhoneCallSettings;
  }

  /** Returns the object with the settings used for calls to listLocations. */
  public PagedCallSettings<ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
      listLocationsSettings() {
    return listLocationsSettings;
  }

  /** Returns the object with the settings used for calls to getLocation. */
  public UnaryCallSettings<GetLocationRequest, Location> getLocationSettings() {
    return getLocationSettings;
  }

  public ConversationsStub createStub() throws IOException {
    if (getTransportChannelProvider()
        .getTransportName()
        .equals(GrpcTransportChannel.getGrpcTransportName())) {
      return GrpcConversationsStub.create(this);
    }
    if (getTransportChannelProvider()
        .getTransportName()
        .equals(HttpJsonTransportChannel.getHttpJsonTransportName())) {
      return HttpJsonConversationsStub.create(this);
    }
    throw new UnsupportedOperationException(
        String.format(
            "Transport not supported: %s", getTransportChannelProvider().getTransportName()));
  }

  /** Returns the default service name. */
  @Override
  public String getServiceName() {
    return "dialogflow";
  }

  /** Returns a builder for the default ExecutorProvider for this service. */
  public static InstantiatingExecutorProvider.Builder defaultExecutorProviderBuilder() {
    return InstantiatingExecutorProvider.newBuilder();
  }

  /** Returns the default service endpoint. */
  @ObsoleteApi("Use getEndpoint() instead")
  public static String getDefaultEndpoint() {
    return "dialogflow.googleapis.com:443";
  }

  /** Returns the default mTLS service endpoint. */
  public static String getDefaultMtlsEndpoint() {
    return "dialogflow.mtls.googleapis.com:443";
  }

  /** Returns the default service scopes. */
  public static List<String> getDefaultServiceScopes() {
    return DEFAULT_SERVICE_SCOPES;
  }

  /** Returns a builder for the default credentials for this service. */
  public static GoogleCredentialsProvider.Builder defaultCredentialsProviderBuilder() {
    return GoogleCredentialsProvider.newBuilder()
        .setScopesToApply(DEFAULT_SERVICE_SCOPES)
        .setUseJwtAccessWithScope(true);
  }

  /** Returns a builder for the default gRPC ChannelProvider for this service. */
  public static InstantiatingGrpcChannelProvider.Builder defaultGrpcTransportProviderBuilder() {
    return InstantiatingGrpcChannelProvider.newBuilder()
        .setMaxInboundMessageSize(Integer.MAX_VALUE);
  }

  /** Returns a builder for the default REST ChannelProvider for this service. */
  @BetaApi
  public static InstantiatingHttpJsonChannelProvider.Builder
      defaultHttpJsonTransportProviderBuilder() {
    return InstantiatingHttpJsonChannelProvider.newBuilder();
  }

  public static TransportChannelProvider defaultTransportChannelProvider() {
    return defaultGrpcTransportProviderBuilder().build();
  }

  public static ApiClientHeaderProvider.Builder defaultGrpcApiClientHeaderProviderBuilder() {
    return ApiClientHeaderProvider.newBuilder()
        .setGeneratedLibToken(
            "gapic", GaxProperties.getLibraryVersion(ConversationsStubSettings.class))
        .setTransportToken(
            GaxGrpcProperties.getGrpcTokenName(), GaxGrpcProperties.getGrpcVersion());
  }

  public static ApiClientHeaderProvider.Builder defaultHttpJsonApiClientHeaderProviderBuilder() {
    return ApiClientHeaderProvider.newBuilder()
        .setGeneratedLibToken(
            "gapic", GaxProperties.getLibraryVersion(ConversationsStubSettings.class))
        .setTransportToken(
            GaxHttpJsonProperties.getHttpJsonTokenName(),
            GaxHttpJsonProperties.getHttpJsonVersion());
  }

  public static ApiClientHeaderProvider.Builder defaultApiClientHeaderProviderBuilder() {
    return ConversationsStubSettings.defaultGrpcApiClientHeaderProviderBuilder();
  }

  /** Returns a new gRPC builder for this class. */
  public static Builder newBuilder() {
    return Builder.createDefault();
  }

  /** Returns a new REST builder for this class. */
  public static Builder newHttpJsonBuilder() {
    return Builder.createHttpJsonDefault();
  }

  /** Returns a new builder for this class. */
  public static Builder newBuilder(ClientContext clientContext) {
    return new Builder(clientContext);
  }

  /** Returns a builder containing all the values of this settings class. */
  public Builder toBuilder() {
    return new Builder(this);
  }

  protected ConversationsStubSettings(Builder settingsBuilder) throws IOException {
    super(settingsBuilder);

    createConversationSettings = settingsBuilder.createConversationSettings().build();
    listConversationsSettings = settingsBuilder.listConversationsSettings().build();
    getConversationSettings = settingsBuilder.getConversationSettings().build();
    addConversationPhoneNumberSettings =
        settingsBuilder.addConversationPhoneNumberSettings().build();
    activateConversationSettings = settingsBuilder.activateConversationSettings().build();
    deactivateConversationSettings = settingsBuilder.deactivateConversationSettings().build();
    completeConversationSettings = settingsBuilder.completeConversationSettings().build();
    updateConversationSettings = settingsBuilder.updateConversationSettings().build();
    ingestContextReferencesSettings = settingsBuilder.ingestContextReferencesSettings().build();
    createCallMatcherSettings = settingsBuilder.createCallMatcherSettings().build();
    listCallMatchersSettings = settingsBuilder.listCallMatchersSettings().build();
    deleteCallMatcherSettings = settingsBuilder.deleteCallMatcherSettings().build();
    batchCreateMessagesSettings = settingsBuilder.batchCreateMessagesSettings().build();
    listMessagesSettings = settingsBuilder.listMessagesSettings().build();
    exportMessagesSettings = settingsBuilder.exportMessagesSettings().build();
    exportMessagesOperationSettings = settingsBuilder.exportMessagesOperationSettings().build();
    suggestConversationSummarySettings =
        settingsBuilder.suggestConversationSummarySettings().build();
    generateStatelessSummarySettings = settingsBuilder.generateStatelessSummarySettings().build();
    generateStatelessSuggestionSettings =
        settingsBuilder.generateStatelessSuggestionSettings().build();
    suggestConversationKeyMomentsSettings =
        settingsBuilder.suggestConversationKeyMomentsSettings().build();
    searchArticlesSettings = settingsBuilder.searchArticlesSettings().build();
    listPastCallCompanionEventsSettings =
        settingsBuilder.listPastCallCompanionEventsSettings().build();
    streamingListUpcomingCallCompanionEventsSettings =
        settingsBuilder.streamingListUpcomingCallCompanionEventsSettings().build();
    injectCallCompanionUserInputSettings =
        settingsBuilder.injectCallCompanionUserInputSettings().build();
    streamingListCallCompanionEventsSettings =
        settingsBuilder.streamingListCallCompanionEventsSettings().build();
    injectCallCompanionInputSettings = settingsBuilder.injectCallCompanionInputSettings().build();
    initializeCallCompanionSettings = settingsBuilder.initializeCallCompanionSettings().build();
    getCallCompanionSettingsSettings = settingsBuilder.getCallCompanionSettingsSettings().build();
    searchKnowledgeSettings = settingsBuilder.searchKnowledgeSettings().build();
    generateSuggestionsSettings = settingsBuilder.generateSuggestionsSettings().build();
    initiatePhoneCallSettings = settingsBuilder.initiatePhoneCallSettings().build();
    listLocationsSettings = settingsBuilder.listLocationsSettings().build();
    getLocationSettings = settingsBuilder.getLocationSettings().build();
  }

  /** Builder for ConversationsStubSettings. */
  public static class Builder extends StubSettings.Builder<ConversationsStubSettings, Builder> {
    private final ImmutableList<UnaryCallSettings.Builder<?, ?>> unaryMethodSettingsBuilders;
    private final UnaryCallSettings.Builder<CreateConversationRequest, Conversation>
        createConversationSettings;
    private final PagedCallSettings.Builder<
            ListConversationsRequest, ListConversationsResponse, ListConversationsPagedResponse>
        listConversationsSettings;
    private final UnaryCallSettings.Builder<GetConversationRequest, Conversation>
        getConversationSettings;
    private final UnaryCallSettings.Builder<
            AddConversationPhoneNumberRequest, ConversationPhoneNumber>
        addConversationPhoneNumberSettings;
    private final UnaryCallSettings.Builder<ActivateConversationRequest, Conversation>
        activateConversationSettings;
    private final UnaryCallSettings.Builder<DeactivateConversationRequest, Conversation>
        deactivateConversationSettings;
    private final UnaryCallSettings.Builder<CompleteConversationRequest, Conversation>
        completeConversationSettings;
    private final UnaryCallSettings.Builder<UpdateConversationRequest, Conversation>
        updateConversationSettings;
    private final UnaryCallSettings.Builder<
            IngestContextReferencesRequest, IngestContextReferencesResponse>
        ingestContextReferencesSettings;
    private final UnaryCallSettings.Builder<CreateCallMatcherRequest, CallMatcher>
        createCallMatcherSettings;
    private final PagedCallSettings.Builder<
            ListCallMatchersRequest, ListCallMatchersResponse, ListCallMatchersPagedResponse>
        listCallMatchersSettings;
    private final UnaryCallSettings.Builder<DeleteCallMatcherRequest, Empty>
        deleteCallMatcherSettings;
    private final UnaryCallSettings.Builder<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
        batchCreateMessagesSettings;
    private final PagedCallSettings.Builder<
            ListMessagesRequest, ListMessagesResponse, ListMessagesPagedResponse>
        listMessagesSettings;
    private final UnaryCallSettings.Builder<ExportMessagesRequest, Operation>
        exportMessagesSettings;
    private final OperationCallSettings.Builder<
            ExportMessagesRequest, ExportMessagesResponse, Struct>
        exportMessagesOperationSettings;
    private final UnaryCallSettings.Builder<
            SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
        suggestConversationSummarySettings;
    private final UnaryCallSettings.Builder<
            GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
        generateStatelessSummarySettings;
    private final UnaryCallSettings.Builder<
            GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
        generateStatelessSuggestionSettings;
    private final UnaryCallSettings.Builder<
            SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
        suggestConversationKeyMomentsSettings;
    private final UnaryCallSettings.Builder<SearchArticlesRequest, SearchArticlesResponse>
        searchArticlesSettings;
    private final PagedCallSettings.Builder<
            ListPastCallCompanionEventsRequest,
            ListPastCallCompanionEventsResponse,
            ListPastCallCompanionEventsPagedResponse>
        listPastCallCompanionEventsSettings;
    private final ServerStreamingCallSettings.Builder<
            StreamingListUpcomingCallCompanionEventsRequest,
            StreamingListUpcomingCallCompanionEventsResponse>
        streamingListUpcomingCallCompanionEventsSettings;
    private final UnaryCallSettings.Builder<
            InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
        injectCallCompanionUserInputSettings;
    private final ServerStreamingCallSettings.Builder<
            StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
        streamingListCallCompanionEventsSettings;
    private final UnaryCallSettings.Builder<
            InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
        injectCallCompanionInputSettings;
    private final UnaryCallSettings.Builder<InitializeCallCompanionRequest, Empty>
        initializeCallCompanionSettings;
    private final UnaryCallSettings.Builder<GetCallCompanionSettingsRequest, CallCompanionSettings>
        getCallCompanionSettingsSettings;
    private final UnaryCallSettings.Builder<SearchKnowledgeRequest, SearchKnowledgeResponse>
        searchKnowledgeSettings;
    private final UnaryCallSettings.Builder<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
        generateSuggestionsSettings;
    private final UnaryCallSettings.Builder<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
        initiatePhoneCallSettings;
    private final PagedCallSettings.Builder<
            ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
        listLocationsSettings;
    private final UnaryCallSettings.Builder<GetLocationRequest, Location> getLocationSettings;
    private static final ImmutableMap<String, ImmutableSet<StatusCode.Code>>
        RETRYABLE_CODE_DEFINITIONS;

    static {
      ImmutableMap.Builder<String, ImmutableSet<StatusCode.Code>> definitions =
          ImmutableMap.builder();
      definitions.put(
          "retry_policy_0_codes",
          ImmutableSet.copyOf(Lists.<StatusCode.Code>newArrayList(StatusCode.Code.UNAVAILABLE)));
      definitions.put(
          "no_retry_4_codes", ImmutableSet.copyOf(Lists.<StatusCode.Code>newArrayList()));
      definitions.put(
          "no_retry_5_codes", ImmutableSet.copyOf(Lists.<StatusCode.Code>newArrayList()));
      RETRYABLE_CODE_DEFINITIONS = definitions.build();
    }

    private static final ImmutableMap<String, RetrySettings> RETRY_PARAM_DEFINITIONS;

    static {
      ImmutableMap.Builder<String, RetrySettings> definitions = ImmutableMap.builder();
      RetrySettings settings = null;
      settings =
          RetrySettings.newBuilder()
              .setInitialRetryDelayDuration(Duration.ofMillis(100L))
              .setRetryDelayMultiplier(1.3)
              .setMaxRetryDelayDuration(Duration.ofMillis(60000L))
              .setInitialRpcTimeoutDuration(Duration.ofMillis(60000L))
              .setRpcTimeoutMultiplier(1.0)
              .setMaxRpcTimeoutDuration(Duration.ofMillis(60000L))
              .setTotalTimeoutDuration(Duration.ofMillis(60000L))
              .build();
      definitions.put("retry_policy_0_params", settings);
      settings =
          RetrySettings.newBuilder()
              .setInitialRpcTimeoutDuration(Duration.ofMillis(600000L))
              .setRpcTimeoutMultiplier(1.0)
              .setMaxRpcTimeoutDuration(Duration.ofMillis(600000L))
              .setTotalTimeoutDuration(Duration.ofMillis(600000L))
              .build();
      definitions.put("no_retry_4_params", settings);
      settings =
          RetrySettings.newBuilder()
              .setInitialRpcTimeoutDuration(Duration.ofMillis(600000L))
              .setRpcTimeoutMultiplier(1.0)
              .setMaxRpcTimeoutDuration(Duration.ofMillis(600000L))
              .setTotalTimeoutDuration(Duration.ofMillis(600000L))
              .build();
      definitions.put("no_retry_5_params", settings);
      RETRY_PARAM_DEFINITIONS = definitions.build();
    }

    protected Builder() {
      this(((ClientContext) null));
    }

    protected Builder(ClientContext clientContext) {
      super(clientContext);

      createConversationSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      listConversationsSettings = PagedCallSettings.newBuilder(LIST_CONVERSATIONS_PAGE_STR_FACT);
      getConversationSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      addConversationPhoneNumberSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      activateConversationSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      deactivateConversationSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      completeConversationSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      updateConversationSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      ingestContextReferencesSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      createCallMatcherSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      listCallMatchersSettings = PagedCallSettings.newBuilder(LIST_CALL_MATCHERS_PAGE_STR_FACT);
      deleteCallMatcherSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      batchCreateMessagesSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      listMessagesSettings = PagedCallSettings.newBuilder(LIST_MESSAGES_PAGE_STR_FACT);
      exportMessagesSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      exportMessagesOperationSettings = OperationCallSettings.newBuilder();
      suggestConversationSummarySettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      generateStatelessSummarySettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      generateStatelessSuggestionSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      suggestConversationKeyMomentsSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      searchArticlesSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      listPastCallCompanionEventsSettings =
          PagedCallSettings.newBuilder(LIST_PAST_CALL_COMPANION_EVENTS_PAGE_STR_FACT);
      streamingListUpcomingCallCompanionEventsSettings = ServerStreamingCallSettings.newBuilder();
      injectCallCompanionUserInputSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      streamingListCallCompanionEventsSettings = ServerStreamingCallSettings.newBuilder();
      injectCallCompanionInputSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      initializeCallCompanionSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      getCallCompanionSettingsSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      searchKnowledgeSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      generateSuggestionsSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      initiatePhoneCallSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();
      listLocationsSettings = PagedCallSettings.newBuilder(LIST_LOCATIONS_PAGE_STR_FACT);
      getLocationSettings = UnaryCallSettings.newUnaryCallSettingsBuilder();

      unaryMethodSettingsBuilders =
          ImmutableList.<UnaryCallSettings.Builder<?, ?>>of(
              createConversationSettings,
              listConversationsSettings,
              getConversationSettings,
              addConversationPhoneNumberSettings,
              activateConversationSettings,
              deactivateConversationSettings,
              completeConversationSettings,
              updateConversationSettings,
              ingestContextReferencesSettings,
              createCallMatcherSettings,
              listCallMatchersSettings,
              deleteCallMatcherSettings,
              batchCreateMessagesSettings,
              listMessagesSettings,
              exportMessagesSettings,
              suggestConversationSummarySettings,
              generateStatelessSummarySettings,
              generateStatelessSuggestionSettings,
              suggestConversationKeyMomentsSettings,
              searchArticlesSettings,
              listPastCallCompanionEventsSettings,
              injectCallCompanionUserInputSettings,
              injectCallCompanionInputSettings,
              initializeCallCompanionSettings,
              getCallCompanionSettingsSettings,
              searchKnowledgeSettings,
              generateSuggestionsSettings,
              initiatePhoneCallSettings,
              listLocationsSettings,
              getLocationSettings);
      initDefaults(this);
    }

    protected Builder(ConversationsStubSettings settings) {
      super(settings);

      createConversationSettings = settings.createConversationSettings.toBuilder();
      listConversationsSettings = settings.listConversationsSettings.toBuilder();
      getConversationSettings = settings.getConversationSettings.toBuilder();
      addConversationPhoneNumberSettings = settings.addConversationPhoneNumberSettings.toBuilder();
      activateConversationSettings = settings.activateConversationSettings.toBuilder();
      deactivateConversationSettings = settings.deactivateConversationSettings.toBuilder();
      completeConversationSettings = settings.completeConversationSettings.toBuilder();
      updateConversationSettings = settings.updateConversationSettings.toBuilder();
      ingestContextReferencesSettings = settings.ingestContextReferencesSettings.toBuilder();
      createCallMatcherSettings = settings.createCallMatcherSettings.toBuilder();
      listCallMatchersSettings = settings.listCallMatchersSettings.toBuilder();
      deleteCallMatcherSettings = settings.deleteCallMatcherSettings.toBuilder();
      batchCreateMessagesSettings = settings.batchCreateMessagesSettings.toBuilder();
      listMessagesSettings = settings.listMessagesSettings.toBuilder();
      exportMessagesSettings = settings.exportMessagesSettings.toBuilder();
      exportMessagesOperationSettings = settings.exportMessagesOperationSettings.toBuilder();
      suggestConversationSummarySettings = settings.suggestConversationSummarySettings.toBuilder();
      generateStatelessSummarySettings = settings.generateStatelessSummarySettings.toBuilder();
      generateStatelessSuggestionSettings =
          settings.generateStatelessSuggestionSettings.toBuilder();
      suggestConversationKeyMomentsSettings =
          settings.suggestConversationKeyMomentsSettings.toBuilder();
      searchArticlesSettings = settings.searchArticlesSettings.toBuilder();
      listPastCallCompanionEventsSettings =
          settings.listPastCallCompanionEventsSettings.toBuilder();
      streamingListUpcomingCallCompanionEventsSettings =
          settings.streamingListUpcomingCallCompanionEventsSettings.toBuilder();
      injectCallCompanionUserInputSettings =
          settings.injectCallCompanionUserInputSettings.toBuilder();
      streamingListCallCompanionEventsSettings =
          settings.streamingListCallCompanionEventsSettings.toBuilder();
      injectCallCompanionInputSettings = settings.injectCallCompanionInputSettings.toBuilder();
      initializeCallCompanionSettings = settings.initializeCallCompanionSettings.toBuilder();
      getCallCompanionSettingsSettings = settings.getCallCompanionSettingsSettings.toBuilder();
      searchKnowledgeSettings = settings.searchKnowledgeSettings.toBuilder();
      generateSuggestionsSettings = settings.generateSuggestionsSettings.toBuilder();
      initiatePhoneCallSettings = settings.initiatePhoneCallSettings.toBuilder();
      listLocationsSettings = settings.listLocationsSettings.toBuilder();
      getLocationSettings = settings.getLocationSettings.toBuilder();

      unaryMethodSettingsBuilders =
          ImmutableList.<UnaryCallSettings.Builder<?, ?>>of(
              createConversationSettings,
              listConversationsSettings,
              getConversationSettings,
              addConversationPhoneNumberSettings,
              activateConversationSettings,
              deactivateConversationSettings,
              completeConversationSettings,
              updateConversationSettings,
              ingestContextReferencesSettings,
              createCallMatcherSettings,
              listCallMatchersSettings,
              deleteCallMatcherSettings,
              batchCreateMessagesSettings,
              listMessagesSettings,
              exportMessagesSettings,
              suggestConversationSummarySettings,
              generateStatelessSummarySettings,
              generateStatelessSuggestionSettings,
              suggestConversationKeyMomentsSettings,
              searchArticlesSettings,
              listPastCallCompanionEventsSettings,
              injectCallCompanionUserInputSettings,
              injectCallCompanionInputSettings,
              initializeCallCompanionSettings,
              getCallCompanionSettingsSettings,
              searchKnowledgeSettings,
              generateSuggestionsSettings,
              initiatePhoneCallSettings,
              listLocationsSettings,
              getLocationSettings);
    }

    private static Builder createDefault() {
      Builder builder = new Builder(((ClientContext) null));

      builder.setTransportChannelProvider(defaultTransportChannelProvider());
      builder.setCredentialsProvider(defaultCredentialsProviderBuilder().build());
      builder.setInternalHeaderProvider(defaultApiClientHeaderProviderBuilder().build());
      builder.setMtlsEndpoint(getDefaultMtlsEndpoint());
      builder.setSwitchToMtlsEndpointAllowed(true);

      return initDefaults(builder);
    }

    private static Builder createHttpJsonDefault() {
      Builder builder = new Builder(((ClientContext) null));

      builder.setTransportChannelProvider(defaultHttpJsonTransportProviderBuilder().build());
      builder.setCredentialsProvider(defaultCredentialsProviderBuilder().build());
      builder.setInternalHeaderProvider(defaultHttpJsonApiClientHeaderProviderBuilder().build());
      builder.setMtlsEndpoint(getDefaultMtlsEndpoint());
      builder.setSwitchToMtlsEndpointAllowed(true);

      return initDefaults(builder);
    }

    private static Builder initDefaults(Builder builder) {
      builder
          .createConversationSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .listConversationsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .getConversationSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .addConversationPhoneNumberSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .activateConversationSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .deactivateConversationSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .completeConversationSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .updateConversationSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .ingestContextReferencesSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .createCallMatcherSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .listCallMatchersSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .deleteCallMatcherSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .batchCreateMessagesSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .listMessagesSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .exportMessagesSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .suggestConversationSummarySettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .generateStatelessSummarySettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .generateStatelessSuggestionSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .suggestConversationKeyMomentsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .searchArticlesSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .listPastCallCompanionEventsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .streamingListUpcomingCallCompanionEventsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("no_retry_4_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("no_retry_4_params"));

      builder
          .injectCallCompanionUserInputSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .streamingListCallCompanionEventsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("no_retry_5_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("no_retry_5_params"));

      builder
          .injectCallCompanionInputSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .initializeCallCompanionSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .getCallCompanionSettingsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .searchKnowledgeSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .generateSuggestionsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .initiatePhoneCallSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .listLocationsSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .getLocationSettings()
          .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
          .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"));

      builder
          .exportMessagesOperationSettings()
          .setInitialCallSettings(
              UnaryCallSettings
                  .<ExportMessagesRequest, OperationSnapshot>newUnaryCallSettingsBuilder()
                  .setRetryableCodes(RETRYABLE_CODE_DEFINITIONS.get("retry_policy_0_codes"))
                  .setRetrySettings(RETRY_PARAM_DEFINITIONS.get("retry_policy_0_params"))
                  .build())
          .setResponseTransformer(
              ProtoOperationTransformers.ResponseTransformer.create(ExportMessagesResponse.class))
          .setMetadataTransformer(
              ProtoOperationTransformers.MetadataTransformer.create(Struct.class))
          .setPollingAlgorithm(
              OperationTimedPollAlgorithm.create(
                  RetrySettings.newBuilder()
                      .setInitialRetryDelayDuration(Duration.ofMillis(5000L))
                      .setRetryDelayMultiplier(1.5)
                      .setMaxRetryDelayDuration(Duration.ofMillis(45000L))
                      .setInitialRpcTimeoutDuration(Duration.ZERO)
                      .setRpcTimeoutMultiplier(1.0)
                      .setMaxRpcTimeoutDuration(Duration.ZERO)
                      .setTotalTimeoutDuration(Duration.ofMillis(300000L))
                      .build()));

      return builder;
    }

    /**
     * Applies the given settings updater function to all of the unary API methods in this service.
     *
     * <p>Note: This method does not support applying settings to streaming methods.
     */
    public Builder applyToAllUnaryMethods(
        ApiFunction<UnaryCallSettings.Builder<?, ?>, Void> settingsUpdater) {
      super.applyToAllUnaryMethods(unaryMethodSettingsBuilders, settingsUpdater);
      return this;
    }

    public ImmutableList<UnaryCallSettings.Builder<?, ?>> unaryMethodSettingsBuilders() {
      return unaryMethodSettingsBuilders;
    }

    /** Returns the builder for the settings used for calls to createConversation. */
    public UnaryCallSettings.Builder<CreateConversationRequest, Conversation>
        createConversationSettings() {
      return createConversationSettings;
    }

    /** Returns the builder for the settings used for calls to listConversations. */
    public PagedCallSettings.Builder<
            ListConversationsRequest, ListConversationsResponse, ListConversationsPagedResponse>
        listConversationsSettings() {
      return listConversationsSettings;
    }

    /** Returns the builder for the settings used for calls to getConversation. */
    public UnaryCallSettings.Builder<GetConversationRequest, Conversation>
        getConversationSettings() {
      return getConversationSettings;
    }

    /** Returns the builder for the settings used for calls to addConversationPhoneNumber. */
    public UnaryCallSettings.Builder<AddConversationPhoneNumberRequest, ConversationPhoneNumber>
        addConversationPhoneNumberSettings() {
      return addConversationPhoneNumberSettings;
    }

    /** Returns the builder for the settings used for calls to activateConversation. */
    public UnaryCallSettings.Builder<ActivateConversationRequest, Conversation>
        activateConversationSettings() {
      return activateConversationSettings;
    }

    /** Returns the builder for the settings used for calls to deactivateConversation. */
    public UnaryCallSettings.Builder<DeactivateConversationRequest, Conversation>
        deactivateConversationSettings() {
      return deactivateConversationSettings;
    }

    /** Returns the builder for the settings used for calls to completeConversation. */
    public UnaryCallSettings.Builder<CompleteConversationRequest, Conversation>
        completeConversationSettings() {
      return completeConversationSettings;
    }

    /** Returns the builder for the settings used for calls to updateConversation. */
    public UnaryCallSettings.Builder<UpdateConversationRequest, Conversation>
        updateConversationSettings() {
      return updateConversationSettings;
    }

    /** Returns the builder for the settings used for calls to ingestContextReferences. */
    public UnaryCallSettings.Builder<
            IngestContextReferencesRequest, IngestContextReferencesResponse>
        ingestContextReferencesSettings() {
      return ingestContextReferencesSettings;
    }

    /** Returns the builder for the settings used for calls to createCallMatcher. */
    public UnaryCallSettings.Builder<CreateCallMatcherRequest, CallMatcher>
        createCallMatcherSettings() {
      return createCallMatcherSettings;
    }

    /** Returns the builder for the settings used for calls to listCallMatchers. */
    public PagedCallSettings.Builder<
            ListCallMatchersRequest, ListCallMatchersResponse, ListCallMatchersPagedResponse>
        listCallMatchersSettings() {
      return listCallMatchersSettings;
    }

    /** Returns the builder for the settings used for calls to deleteCallMatcher. */
    public UnaryCallSettings.Builder<DeleteCallMatcherRequest, Empty> deleteCallMatcherSettings() {
      return deleteCallMatcherSettings;
    }

    /** Returns the builder for the settings used for calls to batchCreateMessages. */
    public UnaryCallSettings.Builder<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
        batchCreateMessagesSettings() {
      return batchCreateMessagesSettings;
    }

    /** Returns the builder for the settings used for calls to listMessages. */
    public PagedCallSettings.Builder<
            ListMessagesRequest, ListMessagesResponse, ListMessagesPagedResponse>
        listMessagesSettings() {
      return listMessagesSettings;
    }

    /** Returns the builder for the settings used for calls to exportMessages. */
    public UnaryCallSettings.Builder<ExportMessagesRequest, Operation> exportMessagesSettings() {
      return exportMessagesSettings;
    }

    /** Returns the builder for the settings used for calls to exportMessages. */
    public OperationCallSettings.Builder<ExportMessagesRequest, ExportMessagesResponse, Struct>
        exportMessagesOperationSettings() {
      return exportMessagesOperationSettings;
    }

    /** Returns the builder for the settings used for calls to suggestConversationSummary. */
    public UnaryCallSettings.Builder<
            SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
        suggestConversationSummarySettings() {
      return suggestConversationSummarySettings;
    }

    /** Returns the builder for the settings used for calls to generateStatelessSummary. */
    public UnaryCallSettings.Builder<
            GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
        generateStatelessSummarySettings() {
      return generateStatelessSummarySettings;
    }

    /** Returns the builder for the settings used for calls to generateStatelessSuggestion. */
    public UnaryCallSettings.Builder<
            GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
        generateStatelessSuggestionSettings() {
      return generateStatelessSuggestionSettings;
    }

    /** Returns the builder for the settings used for calls to suggestConversationKeyMoments. */
    public UnaryCallSettings.Builder<
            SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
        suggestConversationKeyMomentsSettings() {
      return suggestConversationKeyMomentsSettings;
    }

    /** Returns the builder for the settings used for calls to searchArticles. */
    public UnaryCallSettings.Builder<SearchArticlesRequest, SearchArticlesResponse>
        searchArticlesSettings() {
      return searchArticlesSettings;
    }

    /** Returns the builder for the settings used for calls to listPastCallCompanionEvents. */
    public PagedCallSettings.Builder<
            ListPastCallCompanionEventsRequest,
            ListPastCallCompanionEventsResponse,
            ListPastCallCompanionEventsPagedResponse>
        listPastCallCompanionEventsSettings() {
      return listPastCallCompanionEventsSettings;
    }

    /**
     * Returns the builder for the settings used for calls to
     * streamingListUpcomingCallCompanionEvents.
     */
    public ServerStreamingCallSettings.Builder<
            StreamingListUpcomingCallCompanionEventsRequest,
            StreamingListUpcomingCallCompanionEventsResponse>
        streamingListUpcomingCallCompanionEventsSettings() {
      return streamingListUpcomingCallCompanionEventsSettings;
    }

    /** Returns the builder for the settings used for calls to injectCallCompanionUserInput. */
    public UnaryCallSettings.Builder<
            InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
        injectCallCompanionUserInputSettings() {
      return injectCallCompanionUserInputSettings;
    }

    /** Returns the builder for the settings used for calls to streamingListCallCompanionEvents. */
    public ServerStreamingCallSettings.Builder<
            StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
        streamingListCallCompanionEventsSettings() {
      return streamingListCallCompanionEventsSettings;
    }

    /** Returns the builder for the settings used for calls to injectCallCompanionInput. */
    public UnaryCallSettings.Builder<
            InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
        injectCallCompanionInputSettings() {
      return injectCallCompanionInputSettings;
    }

    /** Returns the builder for the settings used for calls to initializeCallCompanion. */
    public UnaryCallSettings.Builder<InitializeCallCompanionRequest, Empty>
        initializeCallCompanionSettings() {
      return initializeCallCompanionSettings;
    }

    /** Returns the builder for the settings used for calls to getCallCompanionSettings. */
    public UnaryCallSettings.Builder<GetCallCompanionSettingsRequest, CallCompanionSettings>
        getCallCompanionSettingsSettings() {
      return getCallCompanionSettingsSettings;
    }

    /** Returns the builder for the settings used for calls to searchKnowledge. */
    public UnaryCallSettings.Builder<SearchKnowledgeRequest, SearchKnowledgeResponse>
        searchKnowledgeSettings() {
      return searchKnowledgeSettings;
    }

    /** Returns the builder for the settings used for calls to generateSuggestions. */
    public UnaryCallSettings.Builder<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
        generateSuggestionsSettings() {
      return generateSuggestionsSettings;
    }

    /** Returns the builder for the settings used for calls to initiatePhoneCall. */
    public UnaryCallSettings.Builder<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
        initiatePhoneCallSettings() {
      return initiatePhoneCallSettings;
    }

    /** Returns the builder for the settings used for calls to listLocations. */
    public PagedCallSettings.Builder<
            ListLocationsRequest, ListLocationsResponse, ListLocationsPagedResponse>
        listLocationsSettings() {
      return listLocationsSettings;
    }

    /** Returns the builder for the settings used for calls to getLocation. */
    public UnaryCallSettings.Builder<GetLocationRequest, Location> getLocationSettings() {
      return getLocationSettings;
    }

    @Override
    public ConversationsStubSettings build() throws IOException {
      return new ConversationsStubSettings(this);
    }
  }
}
