/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListHumanAgentAssistantsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListLocationsPagedResponse;

import com.google.api.core.BetaApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest;
import com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse;
import com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant;
import com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest;
import com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse;
import com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.protobuf.Empty;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * Base stub class for the HumanAgentAssistants service API.
 *
 * <p>This class is for advanced usage and reflects the underlying API directly.
 *
 * @deprecated This class is deprecated and will be removed in the next major version update.
 */
@BetaApi
@Deprecated
@Generated("by gapic-generator-java")
public abstract class HumanAgentAssistantsStub implements BackgroundResource {

  @Deprecated
  public UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsPagedResponse>
      listHumanAgentAssistantsPagedCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: listHumanAgentAssistantsPagedCallable()");
  }

  @Deprecated
  public UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
      listHumanAgentAssistantsCallable() {
    throw new UnsupportedOperationException("Not implemented: listHumanAgentAssistantsCallable()");
  }

  @Deprecated
  public UnaryCallable<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantCallable() {
    throw new UnsupportedOperationException("Not implemented: getHumanAgentAssistantCallable()");
  }

  @Deprecated
  public UnaryCallable<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantCallable() {
    throw new UnsupportedOperationException("Not implemented: createHumanAgentAssistantCallable()");
  }

  @Deprecated
  public UnaryCallable<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantCallable() {
    throw new UnsupportedOperationException("Not implemented: updateHumanAgentAssistantCallable()");
  }

  @Deprecated
  public UnaryCallable<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantCallable() {
    throw new UnsupportedOperationException("Not implemented: deleteHumanAgentAssistantCallable()");
  }

  @Deprecated
  public UnaryCallable<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsCallable() {
    throw new UnsupportedOperationException("Not implemented: compileSuggestionsCallable()");
  }

  public UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    throw new UnsupportedOperationException("Not implemented: listLocationsPagedCallable()");
  }

  public UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    throw new UnsupportedOperationException("Not implemented: listLocationsCallable()");
  }

  public UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    throw new UnsupportedOperationException("Not implemented: getLocationCallable()");
  }

  @Override
  public abstract void close();
}
