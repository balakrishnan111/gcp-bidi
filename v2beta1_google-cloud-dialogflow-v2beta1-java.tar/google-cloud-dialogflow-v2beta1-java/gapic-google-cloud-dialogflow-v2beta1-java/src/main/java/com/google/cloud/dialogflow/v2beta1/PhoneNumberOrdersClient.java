/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1;

import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutures;
import com.google.api.core.BetaApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.paging.AbstractFixedSizeCollection;
import com.google.api.gax.paging.AbstractPage;
import com.google.api.gax.paging.AbstractPagedListResponse;
import com.google.api.gax.rpc.PageContext;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.stub.PhoneNumberOrdersStub;
import com.google.cloud.dialogflow.v2beta1.stub.PhoneNumberOrdersStubSettings;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.protobuf.Empty;
import com.google.protobuf.FieldMask;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * Service Description: Service for managing
 * [PhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrder].
 *
 * <p>This class provides the ability to make remote calls to the backing service through method
 * calls that map to API methods. Sample code to get started:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
 *   LocationName parent = LocationName.of("[PROJECT]", "[LOCATION]");
 *   PhoneNumberOrder phoneNumberOrder = PhoneNumberOrder.newBuilder().build();
 *   PhoneNumberOrder response =
 *       phoneNumberOrdersClient.createPhoneNumberOrder(parent, phoneNumberOrder);
 * }
 * }</pre>
 *
 * <p>Note: close() needs to be called on the PhoneNumberOrdersClient object to clean up resources
 * such as threads. In the example above, try-with-resources is used, which automatically calls
 * close().
 *
 * <table>
 *    <caption>Methods</caption>
 *    <tr>
 *      <th>Method</th>
 *      <th>Description</th>
 *      <th>Method Variants</th>
 *    </tr>
 *    <tr>
 *      <td><p> CreatePhoneNumberOrder</td>
 *      <td><p> Creates an order to request phone numbers be added to a project. The initial `LifecycleState` of a newly created order is [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> createPhoneNumberOrder(CreatePhoneNumberOrderRequest request)
 *      </ul>
 *      <p>"Flattened" method variants have converted the fields of the request object into function parameters to enable multiple ways to call the same method.</p>
 *      <ul>
 *           <li><p> createPhoneNumberOrder(LocationName parent, PhoneNumberOrder phoneNumberOrder)
 *           <li><p> createPhoneNumberOrder(ProjectName parent, PhoneNumberOrder phoneNumberOrder)
 *           <li><p> createPhoneNumberOrder(String parent, PhoneNumberOrder phoneNumberOrder)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> createPhoneNumberOrderCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> GetPhoneNumberOrder</td>
 *      <td><p> Returns a specific `PhoneNumberOrder`.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> getPhoneNumberOrder(GetPhoneNumberOrderRequest request)
 *      </ul>
 *      <p>"Flattened" method variants have converted the fields of the request object into function parameters to enable multiple ways to call the same method.</p>
 *      <ul>
 *           <li><p> getPhoneNumberOrder(PhoneNumberOrderName name)
 *           <li><p> getPhoneNumberOrder(String name)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> getPhoneNumberOrderCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> ListPhoneNumberOrders</td>
 *      <td><p> Lists of all `PhoneNumberOrder` resources in the specified project.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> listPhoneNumberOrders(ListPhoneNumberOrdersRequest request)
 *      </ul>
 *      <p>"Flattened" method variants have converted the fields of the request object into function parameters to enable multiple ways to call the same method.</p>
 *      <ul>
 *           <li><p> listPhoneNumberOrders(LocationName parent)
 *           <li><p> listPhoneNumberOrders(ProjectName parent)
 *           <li><p> listPhoneNumberOrders(String parent)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> listPhoneNumberOrdersPagedCallable()
 *           <li><p> listPhoneNumberOrdersCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> UpdatePhoneNumberOrder</td>
 *      <td><p> Updates the specified `PhoneNumberOrder` resource. Returns an error if the order is in state [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> updatePhoneNumberOrder(UpdatePhoneNumberOrderRequest request)
 *      </ul>
 *      <p>"Flattened" method variants have converted the fields of the request object into function parameters to enable multiple ways to call the same method.</p>
 *      <ul>
 *           <li><p> updatePhoneNumberOrder(PhoneNumberOrder phoneNumberOrder, FieldMask updateMask)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> updatePhoneNumberOrderCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> CancelPhoneNumberOrder</td>
 *      <td><p> Cancels an `PhoneNumberOrder`. Returns an error if the order is in state [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> cancelPhoneNumberOrder(CancelPhoneNumberOrderRequest request)
 *      </ul>
 *      <p>"Flattened" method variants have converted the fields of the request object into function parameters to enable multiple ways to call the same method.</p>
 *      <ul>
 *           <li><p> cancelPhoneNumberOrder(PhoneNumberOrderName name)
 *           <li><p> cancelPhoneNumberOrder(String name)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> cancelPhoneNumberOrderCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> ListLocations</td>
 *      <td><p> Lists information about the supported locations for this service.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> listLocations(ListLocationsRequest request)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> listLocationsPagedCallable()
 *           <li><p> listLocationsCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> GetLocation</td>
 *      <td><p> Gets information about a location.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> getLocation(GetLocationRequest request)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> getLocationCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *  </table>
 *
 * <p>See the individual methods for example code.
 *
 * <p>Many parameters require resource names to be formatted in a particular way. To assist with
 * these names, this class includes a format method for each type of name, and additionally a parse
 * method to extract the individual identifiers contained within names that are returned.
 *
 * <p>This class can be customized by passing in a custom instance of PhoneNumberOrdersSettings to
 * create(). For example:
 *
 * <p>To customize credentials:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * PhoneNumberOrdersSettings phoneNumberOrdersSettings =
 *     PhoneNumberOrdersSettings.newBuilder()
 *         .setCredentialsProvider(FixedCredentialsProvider.create(myCredentials))
 *         .build();
 * PhoneNumberOrdersClient phoneNumberOrdersClient =
 *     PhoneNumberOrdersClient.create(phoneNumberOrdersSettings);
 * }</pre>
 *
 * <p>To customize the endpoint:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * PhoneNumberOrdersSettings phoneNumberOrdersSettings =
 *     PhoneNumberOrdersSettings.newBuilder().setEndpoint(myEndpoint).build();
 * PhoneNumberOrdersClient phoneNumberOrdersClient =
 *     PhoneNumberOrdersClient.create(phoneNumberOrdersSettings);
 * }</pre>
 *
 * <p>To use REST (HTTP1.1/JSON) transport (instead of gRPC) for sending and receiving requests over
 * the wire:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * PhoneNumberOrdersSettings phoneNumberOrdersSettings =
 *     PhoneNumberOrdersSettings.newHttpJsonBuilder().build();
 * PhoneNumberOrdersClient phoneNumberOrdersClient =
 *     PhoneNumberOrdersClient.create(phoneNumberOrdersSettings);
 * }</pre>
 *
 * <p>Please refer to the GitHub repository's samples for more quickstart code snippets.
 */
@BetaApi
@Generated("by gapic-generator-java")
public class PhoneNumberOrdersClient implements BackgroundResource {
  private final PhoneNumberOrdersSettings settings;
  private final PhoneNumberOrdersStub stub;

  /** Constructs an instance of PhoneNumberOrdersClient with default settings. */
  public static final PhoneNumberOrdersClient create() throws IOException {
    return create(PhoneNumberOrdersSettings.newBuilder().build());
  }

  /**
   * Constructs an instance of PhoneNumberOrdersClient, using the given settings. The channels are
   * created based on the settings passed in, or defaults for any settings that are not set.
   */
  public static final PhoneNumberOrdersClient create(PhoneNumberOrdersSettings settings)
      throws IOException {
    return new PhoneNumberOrdersClient(settings);
  }

  /**
   * Constructs an instance of PhoneNumberOrdersClient, using the given stub for making calls. This
   * is for advanced usage - prefer using create(PhoneNumberOrdersSettings).
   */
  public static final PhoneNumberOrdersClient create(PhoneNumberOrdersStub stub) {
    return new PhoneNumberOrdersClient(stub);
  }

  /**
   * Constructs an instance of PhoneNumberOrdersClient, using the given settings. This is protected
   * so that it is easy to make a subclass, but otherwise, the static factory methods should be
   * preferred.
   */
  protected PhoneNumberOrdersClient(PhoneNumberOrdersSettings settings) throws IOException {
    this.settings = settings;
    this.stub = ((PhoneNumberOrdersStubSettings) settings.getStubSettings()).createStub();
  }

  protected PhoneNumberOrdersClient(PhoneNumberOrdersStub stub) {
    this.settings = null;
    this.stub = stub;
  }

  public final PhoneNumberOrdersSettings getSettings() {
    return settings;
  }

  public PhoneNumberOrdersStub getStub() {
    return stub;
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates an order to request phone numbers be added to a project. The initial `LifecycleState`
   * of a newly created order is
   * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   LocationName parent = LocationName.of("[PROJECT]", "[LOCATION]");
   *   PhoneNumberOrder phoneNumberOrder = PhoneNumberOrder.newBuilder().build();
   *   PhoneNumberOrder response =
   *       phoneNumberOrdersClient.createPhoneNumberOrder(parent, phoneNumberOrder);
   * }
   * }</pre>
   *
   * @param parent Required. Resource identifier of the project requesting the orders. Format:
   *     `projects/&lt;Project ID&gt;`. Format: `projects/&lt;Project ID&gt;/locations/&lt;Location
   *     ID&gt;`.
   * @param phoneNumberOrder Required. The order to create.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder createPhoneNumberOrder(
      LocationName parent, PhoneNumberOrder phoneNumberOrder) {
    CreatePhoneNumberOrderRequest request =
        CreatePhoneNumberOrderRequest.newBuilder()
            .setParent(parent == null ? null : parent.toString())
            .setPhoneNumberOrder(phoneNumberOrder)
            .build();
    return createPhoneNumberOrder(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates an order to request phone numbers be added to a project. The initial `LifecycleState`
   * of a newly created order is
   * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   ProjectName parent = ProjectName.of("[PROJECT]");
   *   PhoneNumberOrder phoneNumberOrder = PhoneNumberOrder.newBuilder().build();
   *   PhoneNumberOrder response =
   *       phoneNumberOrdersClient.createPhoneNumberOrder(parent, phoneNumberOrder);
   * }
   * }</pre>
   *
   * @param parent Required. Resource identifier of the project requesting the orders. Format:
   *     `projects/&lt;Project ID&gt;`. Format: `projects/&lt;Project ID&gt;/locations/&lt;Location
   *     ID&gt;`.
   * @param phoneNumberOrder Required. The order to create.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder createPhoneNumberOrder(
      ProjectName parent, PhoneNumberOrder phoneNumberOrder) {
    CreatePhoneNumberOrderRequest request =
        CreatePhoneNumberOrderRequest.newBuilder()
            .setParent(parent == null ? null : parent.toString())
            .setPhoneNumberOrder(phoneNumberOrder)
            .build();
    return createPhoneNumberOrder(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates an order to request phone numbers be added to a project. The initial `LifecycleState`
   * of a newly created order is
   * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   String parent = ProjectName.of("[PROJECT]").toString();
   *   PhoneNumberOrder phoneNumberOrder = PhoneNumberOrder.newBuilder().build();
   *   PhoneNumberOrder response =
   *       phoneNumberOrdersClient.createPhoneNumberOrder(parent, phoneNumberOrder);
   * }
   * }</pre>
   *
   * @param parent Required. Resource identifier of the project requesting the orders. Format:
   *     `projects/&lt;Project ID&gt;`. Format: `projects/&lt;Project ID&gt;/locations/&lt;Location
   *     ID&gt;`.
   * @param phoneNumberOrder Required. The order to create.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder createPhoneNumberOrder(
      String parent, PhoneNumberOrder phoneNumberOrder) {
    CreatePhoneNumberOrderRequest request =
        CreatePhoneNumberOrderRequest.newBuilder()
            .setParent(parent)
            .setPhoneNumberOrder(phoneNumberOrder)
            .build();
    return createPhoneNumberOrder(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates an order to request phone numbers be added to a project. The initial `LifecycleState`
   * of a newly created order is
   * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   CreatePhoneNumberOrderRequest request =
   *       CreatePhoneNumberOrderRequest.newBuilder()
   *           .setParent(ProjectName.of("[PROJECT]").toString())
   *           .setPhoneNumberOrder(PhoneNumberOrder.newBuilder().build())
   *           .build();
   *   PhoneNumberOrder response = phoneNumberOrdersClient.createPhoneNumberOrder(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder createPhoneNumberOrder(CreatePhoneNumberOrderRequest request) {
    return createPhoneNumberOrderCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates an order to request phone numbers be added to a project. The initial `LifecycleState`
   * of a newly created order is
   * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   CreatePhoneNumberOrderRequest request =
   *       CreatePhoneNumberOrderRequest.newBuilder()
   *           .setParent(ProjectName.of("[PROJECT]").toString())
   *           .setPhoneNumberOrder(PhoneNumberOrder.newBuilder().build())
   *           .build();
   *   ApiFuture<PhoneNumberOrder> future =
   *       phoneNumberOrdersClient.createPhoneNumberOrderCallable().futureCall(request);
   *   // Do something.
   *   PhoneNumberOrder response = future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<CreatePhoneNumberOrderRequest, PhoneNumberOrder>
      createPhoneNumberOrderCallable() {
    return stub.createPhoneNumberOrderCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns a specific `PhoneNumberOrder`.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   PhoneNumberOrderName name =
   *       PhoneNumberOrderName.ofProjectPhoneNumberOrderName("[PROJECT]", "[PHONE_NUMBER_ORDER]");
   *   PhoneNumberOrder response = phoneNumberOrdersClient.getPhoneNumberOrder(name);
   * }
   * }</pre>
   *
   * @param name Required. The unique identifier of the order to retrieve. Format:
   *     `projects/&lt;Project ID&gt;/phoneNumberOrders/&lt;Order ID&gt;`. Format:
   *     `projects/&lt;Project ID&gt;/locations/&lt;Location ID&gt;/phoneNumberOrders/&lt;Order
   *     ID&gt;`.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder getPhoneNumberOrder(PhoneNumberOrderName name) {
    GetPhoneNumberOrderRequest request =
        GetPhoneNumberOrderRequest.newBuilder()
            .setName(name == null ? null : name.toString())
            .build();
    return getPhoneNumberOrder(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns a specific `PhoneNumberOrder`.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   String name =
   *       PhoneNumberOrderName.ofProjectPhoneNumberOrderName("[PROJECT]", "[PHONE_NUMBER_ORDER]")
   *           .toString();
   *   PhoneNumberOrder response = phoneNumberOrdersClient.getPhoneNumberOrder(name);
   * }
   * }</pre>
   *
   * @param name Required. The unique identifier of the order to retrieve. Format:
   *     `projects/&lt;Project ID&gt;/phoneNumberOrders/&lt;Order ID&gt;`. Format:
   *     `projects/&lt;Project ID&gt;/locations/&lt;Location ID&gt;/phoneNumberOrders/&lt;Order
   *     ID&gt;`.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder getPhoneNumberOrder(String name) {
    GetPhoneNumberOrderRequest request =
        GetPhoneNumberOrderRequest.newBuilder().setName(name).build();
    return getPhoneNumberOrder(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns a specific `PhoneNumberOrder`.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   GetPhoneNumberOrderRequest request =
   *       GetPhoneNumberOrderRequest.newBuilder()
   *           .setName(
   *               PhoneNumberOrderName.ofProjectPhoneNumberOrderName(
   *                       "[PROJECT]", "[PHONE_NUMBER_ORDER]")
   *                   .toString())
   *           .build();
   *   PhoneNumberOrder response = phoneNumberOrdersClient.getPhoneNumberOrder(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder getPhoneNumberOrder(GetPhoneNumberOrderRequest request) {
    return getPhoneNumberOrderCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns a specific `PhoneNumberOrder`.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   GetPhoneNumberOrderRequest request =
   *       GetPhoneNumberOrderRequest.newBuilder()
   *           .setName(
   *               PhoneNumberOrderName.ofProjectPhoneNumberOrderName(
   *                       "[PROJECT]", "[PHONE_NUMBER_ORDER]")
   *                   .toString())
   *           .build();
   *   ApiFuture<PhoneNumberOrder> future =
   *       phoneNumberOrdersClient.getPhoneNumberOrderCallable().futureCall(request);
   *   // Do something.
   *   PhoneNumberOrder response = future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<GetPhoneNumberOrderRequest, PhoneNumberOrder>
      getPhoneNumberOrderCallable() {
    return stub.getPhoneNumberOrderCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists of all `PhoneNumberOrder` resources in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   LocationName parent = LocationName.of("[PROJECT]", "[LOCATION]");
   *   for (PhoneNumberOrder element :
   *       phoneNumberOrdersClient.listPhoneNumberOrders(parent).iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @param parent Required. The project to list all orders from. Format: `projects/&lt;Project
   *     ID&gt;`. Format: `projects/&lt;Project ID&gt;/locations/&lt;Location ID&gt;`.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ListPhoneNumberOrdersPagedResponse listPhoneNumberOrders(LocationName parent) {
    ListPhoneNumberOrdersRequest request =
        ListPhoneNumberOrdersRequest.newBuilder()
            .setParent(parent == null ? null : parent.toString())
            .build();
    return listPhoneNumberOrders(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists of all `PhoneNumberOrder` resources in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   ProjectName parent = ProjectName.of("[PROJECT]");
   *   for (PhoneNumberOrder element :
   *       phoneNumberOrdersClient.listPhoneNumberOrders(parent).iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @param parent Required. The project to list all orders from. Format: `projects/&lt;Project
   *     ID&gt;`. Format: `projects/&lt;Project ID&gt;/locations/&lt;Location ID&gt;`.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ListPhoneNumberOrdersPagedResponse listPhoneNumberOrders(ProjectName parent) {
    ListPhoneNumberOrdersRequest request =
        ListPhoneNumberOrdersRequest.newBuilder()
            .setParent(parent == null ? null : parent.toString())
            .build();
    return listPhoneNumberOrders(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists of all `PhoneNumberOrder` resources in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   String parent = ProjectName.of("[PROJECT]").toString();
   *   for (PhoneNumberOrder element :
   *       phoneNumberOrdersClient.listPhoneNumberOrders(parent).iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @param parent Required. The project to list all orders from. Format: `projects/&lt;Project
   *     ID&gt;`. Format: `projects/&lt;Project ID&gt;/locations/&lt;Location ID&gt;`.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ListPhoneNumberOrdersPagedResponse listPhoneNumberOrders(String parent) {
    ListPhoneNumberOrdersRequest request =
        ListPhoneNumberOrdersRequest.newBuilder().setParent(parent).build();
    return listPhoneNumberOrders(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists of all `PhoneNumberOrder` resources in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   ListPhoneNumberOrdersRequest request =
   *       ListPhoneNumberOrdersRequest.newBuilder()
   *           .setParent(ProjectName.of("[PROJECT]").toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   for (PhoneNumberOrder element :
   *       phoneNumberOrdersClient.listPhoneNumberOrders(request).iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ListPhoneNumberOrdersPagedResponse listPhoneNumberOrders(
      ListPhoneNumberOrdersRequest request) {
    return listPhoneNumberOrdersPagedCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists of all `PhoneNumberOrder` resources in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   ListPhoneNumberOrdersRequest request =
   *       ListPhoneNumberOrdersRequest.newBuilder()
   *           .setParent(ProjectName.of("[PROJECT]").toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   ApiFuture<PhoneNumberOrder> future =
   *       phoneNumberOrdersClient.listPhoneNumberOrdersPagedCallable().futureCall(request);
   *   // Do something.
   *   for (PhoneNumberOrder element : future.get().iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   */
  public final UnaryCallable<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersPagedResponse>
      listPhoneNumberOrdersPagedCallable() {
    return stub.listPhoneNumberOrdersPagedCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists of all `PhoneNumberOrder` resources in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   ListPhoneNumberOrdersRequest request =
   *       ListPhoneNumberOrdersRequest.newBuilder()
   *           .setParent(ProjectName.of("[PROJECT]").toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   while (true) {
   *     ListPhoneNumberOrdersResponse response =
   *         phoneNumberOrdersClient.listPhoneNumberOrdersCallable().call(request);
   *     for (PhoneNumberOrder element : response.getPhoneNumberOrdersList()) {
   *       // doThingsWith(element);
   *     }
   *     String nextPageToken = response.getNextPageToken();
   *     if (!Strings.isNullOrEmpty(nextPageToken)) {
   *       request = request.toBuilder().setPageToken(nextPageToken).build();
   *     } else {
   *       break;
   *     }
   *   }
   * }
   * }</pre>
   */
  public final UnaryCallable<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse>
      listPhoneNumberOrdersCallable() {
    return stub.listPhoneNumberOrdersCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Updates the specified `PhoneNumberOrder` resource. Returns an error if the order is in state
   * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or
   * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   PhoneNumberOrder phoneNumberOrder = PhoneNumberOrder.newBuilder().build();
   *   FieldMask updateMask = FieldMask.newBuilder().build();
   *   PhoneNumberOrder response =
   *       phoneNumberOrdersClient.updatePhoneNumberOrder(phoneNumberOrder, updateMask);
   * }
   * }</pre>
   *
   * @param phoneNumberOrder Required. The order to update.
   * @param updateMask Optional. The mask to control which fields get updated.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder updatePhoneNumberOrder(
      PhoneNumberOrder phoneNumberOrder, FieldMask updateMask) {
    UpdatePhoneNumberOrderRequest request =
        UpdatePhoneNumberOrderRequest.newBuilder()
            .setPhoneNumberOrder(phoneNumberOrder)
            .setUpdateMask(updateMask)
            .build();
    return updatePhoneNumberOrder(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Updates the specified `PhoneNumberOrder` resource. Returns an error if the order is in state
   * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or
   * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   UpdatePhoneNumberOrderRequest request =
   *       UpdatePhoneNumberOrderRequest.newBuilder()
   *           .setPhoneNumberOrder(PhoneNumberOrder.newBuilder().build())
   *           .setUpdateMask(FieldMask.newBuilder().build())
   *           .build();
   *   PhoneNumberOrder response = phoneNumberOrdersClient.updatePhoneNumberOrder(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final PhoneNumberOrder updatePhoneNumberOrder(UpdatePhoneNumberOrderRequest request) {
    return updatePhoneNumberOrderCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Updates the specified `PhoneNumberOrder` resource. Returns an error if the order is in state
   * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or
   * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   UpdatePhoneNumberOrderRequest request =
   *       UpdatePhoneNumberOrderRequest.newBuilder()
   *           .setPhoneNumberOrder(PhoneNumberOrder.newBuilder().build())
   *           .setUpdateMask(FieldMask.newBuilder().build())
   *           .build();
   *   ApiFuture<PhoneNumberOrder> future =
   *       phoneNumberOrdersClient.updatePhoneNumberOrderCallable().futureCall(request);
   *   // Do something.
   *   PhoneNumberOrder response = future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<UpdatePhoneNumberOrderRequest, PhoneNumberOrder>
      updatePhoneNumberOrderCallable() {
    return stub.updatePhoneNumberOrderCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Cancels an `PhoneNumberOrder`. Returns an error if the order is in state
   * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or
   * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   PhoneNumberOrderName name =
   *       PhoneNumberOrderName.ofProjectPhoneNumberOrderName("[PROJECT]", "[PHONE_NUMBER_ORDER]");
   *   phoneNumberOrdersClient.cancelPhoneNumberOrder(name);
   * }
   * }</pre>
   *
   * @param name Required. The unique identifier of the order to delete. Format:
   *     `projects/&lt;Project ID&gt;/phoneNumberOrders/&lt;Order ID&gt;`. Format:
   *     `projects/&lt;Project ID&gt;/locations/&lt;Location ID&gt;/phoneNumberOrders/&lt;Order
   *     ID&gt;`.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final void cancelPhoneNumberOrder(PhoneNumberOrderName name) {
    CancelPhoneNumberOrderRequest request =
        CancelPhoneNumberOrderRequest.newBuilder()
            .setName(name == null ? null : name.toString())
            .build();
    cancelPhoneNumberOrder(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Cancels an `PhoneNumberOrder`. Returns an error if the order is in state
   * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or
   * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   String name =
   *       PhoneNumberOrderName.ofProjectPhoneNumberOrderName("[PROJECT]", "[PHONE_NUMBER_ORDER]")
   *           .toString();
   *   phoneNumberOrdersClient.cancelPhoneNumberOrder(name);
   * }
   * }</pre>
   *
   * @param name Required. The unique identifier of the order to delete. Format:
   *     `projects/&lt;Project ID&gt;/phoneNumberOrders/&lt;Order ID&gt;`. Format:
   *     `projects/&lt;Project ID&gt;/locations/&lt;Location ID&gt;/phoneNumberOrders/&lt;Order
   *     ID&gt;`.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final void cancelPhoneNumberOrder(String name) {
    CancelPhoneNumberOrderRequest request =
        CancelPhoneNumberOrderRequest.newBuilder().setName(name).build();
    cancelPhoneNumberOrder(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Cancels an `PhoneNumberOrder`. Returns an error if the order is in state
   * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or
   * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   CancelPhoneNumberOrderRequest request =
   *       CancelPhoneNumberOrderRequest.newBuilder()
   *           .setName(
   *               PhoneNumberOrderName.ofProjectPhoneNumberOrderName(
   *                       "[PROJECT]", "[PHONE_NUMBER_ORDER]")
   *                   .toString())
   *           .build();
   *   phoneNumberOrdersClient.cancelPhoneNumberOrder(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final void cancelPhoneNumberOrder(CancelPhoneNumberOrderRequest request) {
    cancelPhoneNumberOrderCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Cancels an `PhoneNumberOrder`. Returns an error if the order is in state
   * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS] or
   * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   CancelPhoneNumberOrderRequest request =
   *       CancelPhoneNumberOrderRequest.newBuilder()
   *           .setName(
   *               PhoneNumberOrderName.ofProjectPhoneNumberOrderName(
   *                       "[PROJECT]", "[PHONE_NUMBER_ORDER]")
   *                   .toString())
   *           .build();
   *   ApiFuture<Empty> future =
   *       phoneNumberOrdersClient.cancelPhoneNumberOrderCallable().futureCall(request);
   *   // Do something.
   *   future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<CancelPhoneNumberOrderRequest, Empty>
      cancelPhoneNumberOrderCallable() {
    return stub.cancelPhoneNumberOrderCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists information about the supported locations for this service.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   ListLocationsRequest request =
   *       ListLocationsRequest.newBuilder()
   *           .setName("name3373707")
   *           .setFilter("filter-1274492040")
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   for (Location element : phoneNumberOrdersClient.listLocations(request).iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ListLocationsPagedResponse listLocations(ListLocationsRequest request) {
    return listLocationsPagedCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists information about the supported locations for this service.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   ListLocationsRequest request =
   *       ListLocationsRequest.newBuilder()
   *           .setName("name3373707")
   *           .setFilter("filter-1274492040")
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   ApiFuture<Location> future =
   *       phoneNumberOrdersClient.listLocationsPagedCallable().futureCall(request);
   *   // Do something.
   *   for (Location element : future.get().iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   */
  public final UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    return stub.listLocationsPagedCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists information about the supported locations for this service.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   ListLocationsRequest request =
   *       ListLocationsRequest.newBuilder()
   *           .setName("name3373707")
   *           .setFilter("filter-1274492040")
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   while (true) {
   *     ListLocationsResponse response =
   *         phoneNumberOrdersClient.listLocationsCallable().call(request);
   *     for (Location element : response.getLocationsList()) {
   *       // doThingsWith(element);
   *     }
   *     String nextPageToken = response.getNextPageToken();
   *     if (!Strings.isNullOrEmpty(nextPageToken)) {
   *       request = request.toBuilder().setPageToken(nextPageToken).build();
   *     } else {
   *       break;
   *     }
   *   }
   * }
   * }</pre>
   */
  public final UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    return stub.listLocationsCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Gets information about a location.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   GetLocationRequest request = GetLocationRequest.newBuilder().setName("name3373707").build();
   *   Location response = phoneNumberOrdersClient.getLocation(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final Location getLocation(GetLocationRequest request) {
    return getLocationCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Gets information about a location.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (PhoneNumberOrdersClient phoneNumberOrdersClient = PhoneNumberOrdersClient.create()) {
   *   GetLocationRequest request = GetLocationRequest.newBuilder().setName("name3373707").build();
   *   ApiFuture<Location> future =
   *       phoneNumberOrdersClient.getLocationCallable().futureCall(request);
   *   // Do something.
   *   Location response = future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    return stub.getLocationCallable();
  }

  @Override
  public final void close() {
    stub.close();
  }

  @Override
  public void shutdown() {
    stub.shutdown();
  }

  @Override
  public boolean isShutdown() {
    return stub.isShutdown();
  }

  @Override
  public boolean isTerminated() {
    return stub.isTerminated();
  }

  @Override
  public void shutdownNow() {
    stub.shutdownNow();
  }

  @Override
  public boolean awaitTermination(long duration, TimeUnit unit) throws InterruptedException {
    return stub.awaitTermination(duration, unit);
  }

  public static class ListPhoneNumberOrdersPagedResponse
      extends AbstractPagedListResponse<
          ListPhoneNumberOrdersRequest,
          ListPhoneNumberOrdersResponse,
          PhoneNumberOrder,
          ListPhoneNumberOrdersPage,
          ListPhoneNumberOrdersFixedSizeCollection> {

    public static ApiFuture<ListPhoneNumberOrdersPagedResponse> createAsync(
        PageContext<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse, PhoneNumberOrder>
            context,
        ApiFuture<ListPhoneNumberOrdersResponse> futureResponse) {
      ApiFuture<ListPhoneNumberOrdersPage> futurePage =
          ListPhoneNumberOrdersPage.createEmptyPage().createPageAsync(context, futureResponse);
      return ApiFutures.transform(
          futurePage,
          input -> new ListPhoneNumberOrdersPagedResponse(input),
          MoreExecutors.directExecutor());
    }

    private ListPhoneNumberOrdersPagedResponse(ListPhoneNumberOrdersPage page) {
      super(page, ListPhoneNumberOrdersFixedSizeCollection.createEmptyCollection());
    }
  }

  public static class ListPhoneNumberOrdersPage
      extends AbstractPage<
          ListPhoneNumberOrdersRequest,
          ListPhoneNumberOrdersResponse,
          PhoneNumberOrder,
          ListPhoneNumberOrdersPage> {

    private ListPhoneNumberOrdersPage(
        PageContext<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse, PhoneNumberOrder>
            context,
        ListPhoneNumberOrdersResponse response) {
      super(context, response);
    }

    private static ListPhoneNumberOrdersPage createEmptyPage() {
      return new ListPhoneNumberOrdersPage(null, null);
    }

    @Override
    protected ListPhoneNumberOrdersPage createPage(
        PageContext<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse, PhoneNumberOrder>
            context,
        ListPhoneNumberOrdersResponse response) {
      return new ListPhoneNumberOrdersPage(context, response);
    }

    @Override
    public ApiFuture<ListPhoneNumberOrdersPage> createPageAsync(
        PageContext<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse, PhoneNumberOrder>
            context,
        ApiFuture<ListPhoneNumberOrdersResponse> futureResponse) {
      return super.createPageAsync(context, futureResponse);
    }
  }

  public static class ListPhoneNumberOrdersFixedSizeCollection
      extends AbstractFixedSizeCollection<
          ListPhoneNumberOrdersRequest,
          ListPhoneNumberOrdersResponse,
          PhoneNumberOrder,
          ListPhoneNumberOrdersPage,
          ListPhoneNumberOrdersFixedSizeCollection> {

    private ListPhoneNumberOrdersFixedSizeCollection(
        List<ListPhoneNumberOrdersPage> pages, int collectionSize) {
      super(pages, collectionSize);
    }

    private static ListPhoneNumberOrdersFixedSizeCollection createEmptyCollection() {
      return new ListPhoneNumberOrdersFixedSizeCollection(null, 0);
    }

    @Override
    protected ListPhoneNumberOrdersFixedSizeCollection createCollection(
        List<ListPhoneNumberOrdersPage> pages, int collectionSize) {
      return new ListPhoneNumberOrdersFixedSizeCollection(pages, collectionSize);
    }
  }

  public static class ListLocationsPagedResponse
      extends AbstractPagedListResponse<
          ListLocationsRequest,
          ListLocationsResponse,
          Location,
          ListLocationsPage,
          ListLocationsFixedSizeCollection> {

    public static ApiFuture<ListLocationsPagedResponse> createAsync(
        PageContext<ListLocationsRequest, ListLocationsResponse, Location> context,
        ApiFuture<ListLocationsResponse> futureResponse) {
      ApiFuture<ListLocationsPage> futurePage =
          ListLocationsPage.createEmptyPage().createPageAsync(context, futureResponse);
      return ApiFutures.transform(
          futurePage,
          input -> new ListLocationsPagedResponse(input),
          MoreExecutors.directExecutor());
    }

    private ListLocationsPagedResponse(ListLocationsPage page) {
      super(page, ListLocationsFixedSizeCollection.createEmptyCollection());
    }
  }

  public static class ListLocationsPage
      extends AbstractPage<
          ListLocationsRequest, ListLocationsResponse, Location, ListLocationsPage> {

    private ListLocationsPage(
        PageContext<ListLocationsRequest, ListLocationsResponse, Location> context,
        ListLocationsResponse response) {
      super(context, response);
    }

    private static ListLocationsPage createEmptyPage() {
      return new ListLocationsPage(null, null);
    }

    @Override
    protected ListLocationsPage createPage(
        PageContext<ListLocationsRequest, ListLocationsResponse, Location> context,
        ListLocationsResponse response) {
      return new ListLocationsPage(context, response);
    }

    @Override
    public ApiFuture<ListLocationsPage> createPageAsync(
        PageContext<ListLocationsRequest, ListLocationsResponse, Location> context,
        ApiFuture<ListLocationsResponse> futureResponse) {
      return super.createPageAsync(context, futureResponse);
    }
  }

  public static class ListLocationsFixedSizeCollection
      extends AbstractFixedSizeCollection<
          ListLocationsRequest,
          ListLocationsResponse,
          Location,
          ListLocationsPage,
          ListLocationsFixedSizeCollection> {

    private ListLocationsFixedSizeCollection(List<ListLocationsPage> pages, int collectionSize) {
      super(pages, collectionSize);
    }

    private static ListLocationsFixedSizeCollection createEmptyCollection() {
      return new ListLocationsFixedSizeCollection(null, 0);
    }

    @Override
    protected ListLocationsFixedSizeCollection createCollection(
        List<ListLocationsPage> pages, int collectionSize) {
      return new ListLocationsFixedSizeCollection(pages, collectionSize);
    }
  }
}
