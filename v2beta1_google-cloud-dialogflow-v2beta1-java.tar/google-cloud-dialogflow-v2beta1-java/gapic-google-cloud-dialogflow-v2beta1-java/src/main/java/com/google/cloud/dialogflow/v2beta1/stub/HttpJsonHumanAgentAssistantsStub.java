/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListHumanAgentAssistantsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantsClient.ListLocationsPagedResponse;

import com.google.api.core.BetaApi;
import com.google.api.core.InternalApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.core.BackgroundResourceAggregation;
import com.google.api.gax.httpjson.ApiMethodDescriptor;
import com.google.api.gax.httpjson.HttpJsonCallSettings;
import com.google.api.gax.httpjson.HttpJsonStubCallableFactory;
import com.google.api.gax.httpjson.ProtoMessageRequestFormatter;
import com.google.api.gax.httpjson.ProtoMessageResponseParser;
import com.google.api.gax.httpjson.ProtoRestSerializer;
import com.google.api.gax.rpc.ClientContext;
import com.google.api.gax.rpc.RequestParamsBuilder;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest;
import com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse;
import com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest;
import com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant;
import com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest;
import com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse;
import com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.protobuf.Empty;
import com.google.protobuf.TypeRegistry;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * REST stub implementation for the HumanAgentAssistants service API.
 *
 * <p>This class is for advanced usage and reflects the underlying API directly.
 *
 * @deprecated This class is deprecated and will be removed in the next major version update.
 */
@BetaApi
@Deprecated
@Generated("by gapic-generator-java")
public class HttpJsonHumanAgentAssistantsStub extends HumanAgentAssistantsStub {
  private static final TypeRegistry typeRegistry = TypeRegistry.newBuilder().build();

  private static final ApiMethodDescriptor<
          ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
      listHumanAgentAssistantsMethodDescriptor =
          ApiMethodDescriptor
              .<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/ListHumanAgentAssistants")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListHumanAgentAssistantsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*}/humanAgentAssistants",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListHumanAgentAssistantsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListHumanAgentAssistantsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "pageSize", request.getPageSize());
                            serializer.putQueryParam(fields, "pageToken", request.getPageToken());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListHumanAgentAssistantsResponse>newBuilder()
                      .setDefaultInstance(ListHumanAgentAssistantsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantMethodDescriptor =
          ApiMethodDescriptor.<GetHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/GetHumanAgentAssistant")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GetHumanAgentAssistantRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/humanAgentAssistants/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GetHumanAgentAssistantRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GetHumanAgentAssistantRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<HumanAgentAssistant>newBuilder()
                      .setDefaultInstance(HumanAgentAssistant.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantMethodDescriptor =
          ApiMethodDescriptor.<CreateHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/CreateHumanAgentAssistant")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<CreateHumanAgentAssistantRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*}/humanAgentAssistants",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<CreateHumanAgentAssistantRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<CreateHumanAgentAssistantRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(
                                fields, "bypassDeprecation", request.getBypassDeprecation());
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "humanAgentAssistant",
                                      request.getHumanAgentAssistant(),
                                      false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<HumanAgentAssistant>newBuilder()
                      .setDefaultInstance(HumanAgentAssistant.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantMethodDescriptor =
          ApiMethodDescriptor.<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/UpdateHumanAgentAssistant")
              .setHttpMethod("PATCH")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<UpdateHumanAgentAssistantRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{humanAgentAssistant.name=projects/*/humanAgentAssistants/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<UpdateHumanAgentAssistantRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields,
                                "humanAgentAssistant.name",
                                request.getHumanAgentAssistant().getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<UpdateHumanAgentAssistantRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "updateMask", request.getUpdateMask());
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "humanAgentAssistant",
                                      request.getHumanAgentAssistant(),
                                      false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<HumanAgentAssistant>newBuilder()
                      .setDefaultInstance(HumanAgentAssistant.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantMethodDescriptor =
          ApiMethodDescriptor.<DeleteHumanAgentAssistantRequest, Empty>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/DeleteHumanAgentAssistant")
              .setHttpMethod("DELETE")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<DeleteHumanAgentAssistantRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/humanAgentAssistants/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<DeleteHumanAgentAssistantRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<DeleteHumanAgentAssistantRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Empty>newBuilder()
                      .setDefaultInstance(Empty.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsMethodDescriptor =
          ApiMethodDescriptor.<CompileSuggestionsRequest, CompileSuggestionsResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.HumanAgentAssistants/CompileSuggestions")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<CompileSuggestionsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/humanAgentAssistants/*}:compileSuggestions",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<CompileSuggestionsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<CompileSuggestionsRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("*", request.toBuilder().clearName().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<CompileSuggestionsResponse>newBuilder()
                      .setDefaultInstance(CompileSuggestionsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<ListLocationsRequest, ListLocationsResponse>
      listLocationsMethodDescriptor =
          ApiMethodDescriptor.<ListLocationsRequest, ListLocationsResponse>newBuilder()
              .setFullMethodName("google.cloud.location.Locations/ListLocations")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListLocationsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*}/locations",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListLocationsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListLocationsRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListLocationsResponse>newBuilder()
                      .setDefaultInstance(ListLocationsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<GetLocationRequest, Location>
      getLocationMethodDescriptor =
          ApiMethodDescriptor.<GetLocationRequest, Location>newBuilder()
              .setFullMethodName("google.cloud.location.Locations/GetLocation")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GetLocationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/locations/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GetLocationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GetLocationRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Location>newBuilder()
                      .setDefaultInstance(Location.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private final UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
      listHumanAgentAssistantsCallable;
  private final UnaryCallable<
          ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsPagedResponse>
      listHumanAgentAssistantsPagedCallable;
  private final UnaryCallable<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantCallable;
  private final UnaryCallable<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantCallable;
  private final UnaryCallable<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantCallable;
  private final UnaryCallable<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantCallable;
  private final UnaryCallable<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsCallable;
  private final UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable;
  private final UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable;
  private final UnaryCallable<GetLocationRequest, Location> getLocationCallable;

  private final BackgroundResource backgroundResources;
  private final HttpJsonStubCallableFactory callableFactory;

  public static final HttpJsonHumanAgentAssistantsStub create(
      HumanAgentAssistantsStubSettings settings) throws IOException {
    return new HttpJsonHumanAgentAssistantsStub(settings, ClientContext.create(settings));
  }

  public static final HttpJsonHumanAgentAssistantsStub create(ClientContext clientContext)
      throws IOException {
    return new HttpJsonHumanAgentAssistantsStub(
        HumanAgentAssistantsStubSettings.newHttpJsonBuilder().build(), clientContext);
  }

  public static final HttpJsonHumanAgentAssistantsStub create(
      ClientContext clientContext, HttpJsonStubCallableFactory callableFactory) throws IOException {
    return new HttpJsonHumanAgentAssistantsStub(
        HumanAgentAssistantsStubSettings.newHttpJsonBuilder().build(),
        clientContext,
        callableFactory);
  }

  /**
   * Constructs an instance of HttpJsonHumanAgentAssistantsStub, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected HttpJsonHumanAgentAssistantsStub(
      HumanAgentAssistantsStubSettings settings, ClientContext clientContext) throws IOException {
    this(settings, clientContext, new HttpJsonHumanAgentAssistantsCallableFactory());
  }

  /**
   * Constructs an instance of HttpJsonHumanAgentAssistantsStub, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected HttpJsonHumanAgentAssistantsStub(
      HumanAgentAssistantsStubSettings settings,
      ClientContext clientContext,
      HttpJsonStubCallableFactory callableFactory)
      throws IOException {
    this.callableFactory = callableFactory;

    HttpJsonCallSettings<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
        listHumanAgentAssistantsTransportSettings =
            HttpJsonCallSettings
                .<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>newBuilder()
                .setMethodDescriptor(listHumanAgentAssistantsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GetHumanAgentAssistantRequest, HumanAgentAssistant>
        getHumanAgentAssistantTransportSettings =
            HttpJsonCallSettings.<GetHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
                .setMethodDescriptor(getHumanAgentAssistantMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
        createHumanAgentAssistantTransportSettings =
            HttpJsonCallSettings.<CreateHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
                .setMethodDescriptor(createHumanAgentAssistantMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
        updateHumanAgentAssistantTransportSettings =
            HttpJsonCallSettings.<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>newBuilder()
                .setMethodDescriptor(updateHumanAgentAssistantMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add(
                          "human_agent_assistant.name",
                          String.valueOf(request.getHumanAgentAssistant().getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<DeleteHumanAgentAssistantRequest, Empty>
        deleteHumanAgentAssistantTransportSettings =
            HttpJsonCallSettings.<DeleteHumanAgentAssistantRequest, Empty>newBuilder()
                .setMethodDescriptor(deleteHumanAgentAssistantMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<CompileSuggestionsRequest, CompileSuggestionsResponse>
        compileSuggestionsTransportSettings =
            HttpJsonCallSettings.<CompileSuggestionsRequest, CompileSuggestionsResponse>newBuilder()
                .setMethodDescriptor(compileSuggestionsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<ListLocationsRequest, ListLocationsResponse>
        listLocationsTransportSettings =
            HttpJsonCallSettings.<ListLocationsRequest, ListLocationsResponse>newBuilder()
                .setMethodDescriptor(listLocationsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GetLocationRequest, Location> getLocationTransportSettings =
        HttpJsonCallSettings.<GetLocationRequest, Location>newBuilder()
            .setMethodDescriptor(getLocationMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("name", String.valueOf(request.getName()));
                  return builder.build();
                })
            .build();

    this.listHumanAgentAssistantsCallable =
        callableFactory.createUnaryCallable(
            listHumanAgentAssistantsTransportSettings,
            settings.listHumanAgentAssistantsSettings(),
            clientContext);
    this.listHumanAgentAssistantsPagedCallable =
        callableFactory.createPagedCallable(
            listHumanAgentAssistantsTransportSettings,
            settings.listHumanAgentAssistantsSettings(),
            clientContext);
    this.getHumanAgentAssistantCallable =
        callableFactory.createUnaryCallable(
            getHumanAgentAssistantTransportSettings,
            settings.getHumanAgentAssistantSettings(),
            clientContext);
    this.createHumanAgentAssistantCallable =
        callableFactory.createUnaryCallable(
            createHumanAgentAssistantTransportSettings,
            settings.createHumanAgentAssistantSettings(),
            clientContext);
    this.updateHumanAgentAssistantCallable =
        callableFactory.createUnaryCallable(
            updateHumanAgentAssistantTransportSettings,
            settings.updateHumanAgentAssistantSettings(),
            clientContext);
    this.deleteHumanAgentAssistantCallable =
        callableFactory.createUnaryCallable(
            deleteHumanAgentAssistantTransportSettings,
            settings.deleteHumanAgentAssistantSettings(),
            clientContext);
    this.compileSuggestionsCallable =
        callableFactory.createUnaryCallable(
            compileSuggestionsTransportSettings,
            settings.compileSuggestionsSettings(),
            clientContext);
    this.listLocationsCallable =
        callableFactory.createUnaryCallable(
            listLocationsTransportSettings, settings.listLocationsSettings(), clientContext);
    this.listLocationsPagedCallable =
        callableFactory.createPagedCallable(
            listLocationsTransportSettings, settings.listLocationsSettings(), clientContext);
    this.getLocationCallable =
        callableFactory.createUnaryCallable(
            getLocationTransportSettings, settings.getLocationSettings(), clientContext);

    this.backgroundResources =
        new BackgroundResourceAggregation(clientContext.getBackgroundResources());
  }

  @InternalApi
  public static List<ApiMethodDescriptor> getMethodDescriptors() {
    List<ApiMethodDescriptor> methodDescriptors = new ArrayList<>();
    methodDescriptors.add(listHumanAgentAssistantsMethodDescriptor);
    methodDescriptors.add(getHumanAgentAssistantMethodDescriptor);
    methodDescriptors.add(createHumanAgentAssistantMethodDescriptor);
    methodDescriptors.add(updateHumanAgentAssistantMethodDescriptor);
    methodDescriptors.add(deleteHumanAgentAssistantMethodDescriptor);
    methodDescriptors.add(compileSuggestionsMethodDescriptor);
    methodDescriptors.add(listLocationsMethodDescriptor);
    methodDescriptors.add(getLocationMethodDescriptor);
    return methodDescriptors;
  }

  @Override
  public UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsResponse>
      listHumanAgentAssistantsCallable() {
    return listHumanAgentAssistantsCallable;
  }

  @Override
  public UnaryCallable<ListHumanAgentAssistantsRequest, ListHumanAgentAssistantsPagedResponse>
      listHumanAgentAssistantsPagedCallable() {
    return listHumanAgentAssistantsPagedCallable;
  }

  @Override
  public UnaryCallable<GetHumanAgentAssistantRequest, HumanAgentAssistant>
      getHumanAgentAssistantCallable() {
    return getHumanAgentAssistantCallable;
  }

  @Override
  public UnaryCallable<CreateHumanAgentAssistantRequest, HumanAgentAssistant>
      createHumanAgentAssistantCallable() {
    return createHumanAgentAssistantCallable;
  }

  @Override
  public UnaryCallable<UpdateHumanAgentAssistantRequest, HumanAgentAssistant>
      updateHumanAgentAssistantCallable() {
    return updateHumanAgentAssistantCallable;
  }

  @Override
  public UnaryCallable<DeleteHumanAgentAssistantRequest, Empty>
      deleteHumanAgentAssistantCallable() {
    return deleteHumanAgentAssistantCallable;
  }

  @Override
  public UnaryCallable<CompileSuggestionsRequest, CompileSuggestionsResponse>
      compileSuggestionsCallable() {
    return compileSuggestionsCallable;
  }

  @Override
  public UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    return listLocationsCallable;
  }

  @Override
  public UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    return listLocationsPagedCallable;
  }

  @Override
  public UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    return getLocationCallable;
  }

  @Override
  public final void close() {
    try {
      backgroundResources.close();
    } catch (RuntimeException e) {
      throw e;
    } catch (Exception e) {
      throw new IllegalStateException("Failed to close resource", e);
    }
  }

  @Override
  public void shutdown() {
    backgroundResources.shutdown();
  }

  @Override
  public boolean isShutdown() {
    return backgroundResources.isShutdown();
  }

  @Override
  public boolean isTerminated() {
    return backgroundResources.isTerminated();
  }

  @Override
  public void shutdownNow() {
    backgroundResources.shutdownNow();
  }

  @Override
  public boolean awaitTermination(long duration, TimeUnit unit) throws InterruptedException {
    return backgroundResources.awaitTermination(duration, unit);
  }
}
