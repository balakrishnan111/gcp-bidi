/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListCallMatchersPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListConversationsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListLocationsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListMessagesPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListPastCallCompanionEventsPagedResponse;

import com.google.api.HttpRule;
import com.google.api.core.BetaApi;
import com.google.api.core.InternalApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.core.BackgroundResourceAggregation;
import com.google.api.gax.httpjson.ApiMethodDescriptor;
import com.google.api.gax.httpjson.HttpJsonCallSettings;
import com.google.api.gax.httpjson.HttpJsonOperationSnapshot;
import com.google.api.gax.httpjson.HttpJsonStubCallableFactory;
import com.google.api.gax.httpjson.ProtoMessageRequestFormatter;
import com.google.api.gax.httpjson.ProtoMessageResponseParser;
import com.google.api.gax.httpjson.ProtoRestSerializer;
import com.google.api.gax.httpjson.longrunning.stub.HttpJsonOperationsStub;
import com.google.api.gax.longrunning.OperationSnapshot;
import com.google.api.gax.rpc.ClientContext;
import com.google.api.gax.rpc.OperationCallable;
import com.google.api.gax.rpc.RequestParamsBuilder;
import com.google.api.gax.rpc.ServerStreamingCallable;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest;
import com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.CallCompanionSettings;
import com.google.cloud.dialogflow.v2beta1.CallMatcher;
import com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest;
import com.google.cloud.dialogflow.v2beta1.Conversation;
import com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber;
import com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest;
import com.google.cloud.dialogflow.v2beta1.CreateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest;
import com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest;
import com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.ExportMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse;
import com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest;
import com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse;
import com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest;
import com.google.cloud.dialogflow.v2beta1.GetConversationRequest;
import com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest;
import com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse;
import com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest;
import com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest;
import com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest;
import com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse;
import com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest;
import com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse;
import com.google.cloud.dialogflow.v2beta1.ListConversationsRequest;
import com.google.cloud.dialogflow.v2beta1.ListConversationsResponse;
import com.google.cloud.dialogflow.v2beta1.ListMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.ListMessagesResponse;
import com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest;
import com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse;
import com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest;
import com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse;
import com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest;
import com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest;
import com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse;
import com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.common.collect.ImmutableMap;
import com.google.longrunning.Operation;
import com.google.protobuf.Empty;
import com.google.protobuf.Struct;
import com.google.protobuf.TypeRegistry;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * REST stub implementation for the Conversations service API.
 *
 * <p>This class is for advanced usage and reflects the underlying API directly.
 */
@BetaApi
@Generated("by gapic-generator-java")
public class HttpJsonConversationsStub extends ConversationsStub {
  private static final TypeRegistry typeRegistry =
      TypeRegistry.newBuilder()
          .add(ExportMessagesResponse.getDescriptor())
          .add(Struct.getDescriptor())
          .build();

  private static final ApiMethodDescriptor<CreateConversationRequest, Conversation>
      createConversationMethodDescriptor =
          ApiMethodDescriptor.<CreateConversationRequest, Conversation>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/CreateConversation")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<CreateConversationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*}/conversations",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<CreateConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths("/v2beta1/{parent=projects/*/locations/*}/conversations")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<CreateConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(
                                fields, "conversationId", request.getConversationId());
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("conversation", request.getConversation(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Conversation>newBuilder()
                      .setDefaultInstance(Conversation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<ListConversationsRequest, ListConversationsResponse>
      listConversationsMethodDescriptor =
          ApiMethodDescriptor.<ListConversationsRequest, ListConversationsResponse>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/ListConversations")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListConversationsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*}/conversations",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListConversationsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths("/v2beta1/{parent=projects/*/locations/*}/conversations")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListConversationsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "filter", request.getFilter());
                            serializer.putQueryParam(fields, "pageSize", request.getPageSize());
                            serializer.putQueryParam(fields, "pageToken", request.getPageToken());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListConversationsResponse>newBuilder()
                      .setDefaultInstance(ListConversationsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<GetConversationRequest, Conversation>
      getConversationMethodDescriptor =
          ApiMethodDescriptor.<GetConversationRequest, Conversation>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/GetConversation")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GetConversationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/conversations/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GetConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setAdditionalPaths("/v2beta1/{name=projects/*/locations/*/conversations/*}")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GetConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Conversation>newBuilder()
                      .setDefaultInstance(Conversation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          AddConversationPhoneNumberRequest, ConversationPhoneNumber>
      addConversationPhoneNumberMethodDescriptor =
          ApiMethodDescriptor
              .<AddConversationPhoneNumberRequest, ConversationPhoneNumber>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/AddConversationPhoneNumber")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<AddConversationPhoneNumberRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/conversations/*}:addConversationPhoneNumber",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<AddConversationPhoneNumberRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{name=projects/*/locations/*/conversations/*}:addConversationPhoneNumber")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<AddConversationPhoneNumberRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("*", request.toBuilder().clearName().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ConversationPhoneNumber>newBuilder()
                      .setDefaultInstance(ConversationPhoneNumber.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<ActivateConversationRequest, Conversation>
      activateConversationMethodDescriptor =
          ApiMethodDescriptor.<ActivateConversationRequest, Conversation>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/ActivateConversation")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ActivateConversationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/conversations/*}:activateConversation",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ActivateConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:activateConversation")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ActivateConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Conversation>newBuilder()
                      .setDefaultInstance(Conversation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<DeactivateConversationRequest, Conversation>
      deactivateConversationMethodDescriptor =
          ApiMethodDescriptor.<DeactivateConversationRequest, Conversation>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/DeactivateConversation")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<DeactivateConversationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/conversations/*}:deactivateConversation",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<DeactivateConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:deactivateConversation")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<DeactivateConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Conversation>newBuilder()
                      .setDefaultInstance(Conversation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<CompleteConversationRequest, Conversation>
      completeConversationMethodDescriptor =
          ApiMethodDescriptor.<CompleteConversationRequest, Conversation>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/CompleteConversation")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<CompleteConversationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/conversations/*}:complete",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<CompleteConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{name=projects/*/locations/*/conversations/*}:complete")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<CompleteConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("*", request.toBuilder().clearName().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Conversation>newBuilder()
                      .setDefaultInstance(Conversation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<UpdateConversationRequest, Conversation>
      updateConversationMethodDescriptor =
          ApiMethodDescriptor.<UpdateConversationRequest, Conversation>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/UpdateConversation")
              .setHttpMethod("PATCH")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<UpdateConversationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation.name=projects/*/conversations/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<UpdateConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation.name", request.getConversation().getName());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{conversation.name=projects/*/locations/*/conversations/*}")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<UpdateConversationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "updateMask", request.getUpdateMask());
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("conversation", request.getConversation(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Conversation>newBuilder()
                      .setDefaultInstance(Conversation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          IngestContextReferencesRequest, IngestContextReferencesResponse>
      ingestContextReferencesMethodDescriptor =
          ApiMethodDescriptor
              .<IngestContextReferencesRequest, IngestContextReferencesResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/IngestContextReferences")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<IngestContextReferencesRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:ingestContextReferences",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<IngestContextReferencesRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<IngestContextReferencesRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<IngestContextReferencesResponse>newBuilder()
                      .setDefaultInstance(IngestContextReferencesResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<CreateCallMatcherRequest, CallMatcher>
      createCallMatcherMethodDescriptor =
          ApiMethodDescriptor.<CreateCallMatcherRequest, CallMatcher>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/CreateCallMatcher")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<CreateCallMatcherRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*/conversations/*}/callMatchers",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<CreateCallMatcherRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{parent=projects/*/locations/*/conversations/*}/callMatchers")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<CreateCallMatcherRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("callMatcher", request.getCallMatcher(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<CallMatcher>newBuilder()
                      .setDefaultInstance(CallMatcher.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<ListCallMatchersRequest, ListCallMatchersResponse>
      listCallMatchersMethodDescriptor =
          ApiMethodDescriptor.<ListCallMatchersRequest, ListCallMatchersResponse>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/ListCallMatchers")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListCallMatchersRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*/conversations/*}/callMatchers",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListCallMatchersRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{parent=projects/*/locations/*/conversations/*}/callMatchers")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListCallMatchersRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "pageSize", request.getPageSize());
                            serializer.putQueryParam(fields, "pageToken", request.getPageToken());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListCallMatchersResponse>newBuilder()
                      .setDefaultInstance(ListCallMatchersResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<DeleteCallMatcherRequest, Empty>
      deleteCallMatcherMethodDescriptor =
          ApiMethodDescriptor.<DeleteCallMatcherRequest, Empty>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/DeleteCallMatcher")
              .setHttpMethod("DELETE")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<DeleteCallMatcherRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/conversations/*/callMatchers/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<DeleteCallMatcherRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{name=projects/*/locations/*/conversations/*/callMatchers/*}")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<DeleteCallMatcherRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Empty>newBuilder()
                      .setDefaultInstance(Empty.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
      batchCreateMessagesMethodDescriptor =
          ApiMethodDescriptor.<BatchCreateMessagesRequest, BatchCreateMessagesResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/BatchCreateMessages")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<BatchCreateMessagesRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*/conversations/*}/messages:batchCreate",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<BatchCreateMessagesRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{parent=projects/*/locations/*/conversations/*}/messages:batchCreate")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<BatchCreateMessagesRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("*", request.toBuilder().clearParent().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<BatchCreateMessagesResponse>newBuilder()
                      .setDefaultInstance(BatchCreateMessagesResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<ListMessagesRequest, ListMessagesResponse>
      listMessagesMethodDescriptor =
          ApiMethodDescriptor.<ListMessagesRequest, ListMessagesResponse>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/ListMessages")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListMessagesRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*/conversations/*}/messages",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListMessagesRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{parent=projects/*/locations/*/conversations/*}/messages")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListMessagesRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "filter", request.getFilter());
                            serializer.putQueryParam(fields, "pageSize", request.getPageSize());
                            serializer.putQueryParam(fields, "pageToken", request.getPageToken());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListMessagesResponse>newBuilder()
                      .setDefaultInstance(ListMessagesResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<ExportMessagesRequest, Operation>
      exportMessagesMethodDescriptor =
          ApiMethodDescriptor.<ExportMessagesRequest, Operation>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/ExportMessages")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ExportMessagesRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*}:exportMessages",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ExportMessagesRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths("/v2beta1/{parent=projects/*/locations/*}:exportMessages")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ExportMessagesRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "filter", request.getFilter());
                            serializer.putQueryParam(
                                fields, "gcsDestination", request.getGcsDestination());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Operation>newBuilder()
                      .setDefaultInstance(Operation.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .setOperationSnapshotFactory(
                  (ExportMessagesRequest request, Operation response) ->
                      HttpJsonOperationSnapshot.create(response))
              .build();

  private static final ApiMethodDescriptor<
          SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
      suggestConversationSummaryMethodDescriptor =
          ApiMethodDescriptor
              .<SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/SuggestConversationSummary")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<SuggestConversationSummaryRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/conversations/*}/suggestions:suggestConversationSummary",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<SuggestConversationSummaryRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}/suggestions:suggestConversationSummary")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<SuggestConversationSummaryRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<SuggestConversationSummaryResponse>newBuilder()
                      .setDefaultInstance(SuggestConversationSummaryResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
      generateStatelessSummaryMethodDescriptor =
          ApiMethodDescriptor
              .<GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/GenerateStatelessSummary")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GenerateStatelessSummaryRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{statelessConversation.parent=projects/*}/suggestions:generateStatelessSummary",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GenerateStatelessSummaryRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields,
                                "statelessConversation.parent",
                                request.getStatelessConversation().getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{statelessConversation.parent=projects/*/locations/*}/suggestions:generateStatelessSummary")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GenerateStatelessSummaryRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("*", request.toBuilder().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<GenerateStatelessSummaryResponse>newBuilder()
                      .setDefaultInstance(GenerateStatelessSummaryResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
      generateStatelessSuggestionMethodDescriptor =
          ApiMethodDescriptor
              .<GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/GenerateStatelessSuggestion")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GenerateStatelessSuggestionRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*/locations/*}/statelessSuggestion:generate",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GenerateStatelessSuggestionRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GenerateStatelessSuggestionRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody("*", request.toBuilder().clearParent().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<GenerateStatelessSuggestionResponse>newBuilder()
                      .setDefaultInstance(GenerateStatelessSuggestionResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
      suggestConversationKeyMomentsMethodDescriptor =
          ApiMethodDescriptor
              .<SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
                  newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/SuggestConversationKeyMoments")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<SuggestConversationKeyMomentsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/conversations/*}/suggestions:suggestConversationKeyMoments",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<SuggestConversationKeyMomentsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}/suggestions:suggestConversationKeyMoments")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<SuggestConversationKeyMomentsRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<SuggestConversationKeyMomentsResponse>newBuilder()
                      .setDefaultInstance(
                          SuggestConversationKeyMomentsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<SearchArticlesRequest, SearchArticlesResponse>
      searchArticlesMethodDescriptor =
          ApiMethodDescriptor.<SearchArticlesRequest, SearchArticlesResponse>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/SearchArticles")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<SearchArticlesRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}/suggestions:searchArticles",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<SearchArticlesRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<SearchArticlesRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "query", request.getQuery());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<SearchArticlesResponse>newBuilder()
                      .setDefaultInstance(SearchArticlesResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsResponse>
      listPastCallCompanionEventsMethodDescriptor =
          ApiMethodDescriptor
              .<ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/ListPastCallCompanionEvents")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListPastCallCompanionEventsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:listPastCallCompanionEvents",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListPastCallCompanionEventsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListPastCallCompanionEventsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putQueryParam(fields, "pageSize", request.getPageSize());
                            serializer.putQueryParam(fields, "pageToken", request.getPageToken());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListPastCallCompanionEventsResponse>newBuilder()
                      .setDefaultInstance(ListPastCallCompanionEventsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          StreamingListUpcomingCallCompanionEventsRequest,
          StreamingListUpcomingCallCompanionEventsResponse>
      streamingListUpcomingCallCompanionEventsMethodDescriptor =
          ApiMethodDescriptor
              .<StreamingListUpcomingCallCompanionEventsRequest,
                  StreamingListUpcomingCallCompanionEventsResponse>
                  newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/StreamingListUpcomingCallCompanionEvents")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.SERVER_STREAMING)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter
                      .<StreamingListUpcomingCallCompanionEventsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:streamingListUpcomingCallCompanionEvents",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<StreamingListUpcomingCallCompanionEventsRequest>
                                serializer = ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<StreamingListUpcomingCallCompanionEventsRequest>
                                serializer = ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser
                      .<StreamingListUpcomingCallCompanionEventsResponse>newBuilder()
                      .setDefaultInstance(
                          StreamingListUpcomingCallCompanionEventsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
      injectCallCompanionUserInputMethodDescriptor =
          ApiMethodDescriptor
              .<InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
                  newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/InjectCallCompanionUserInput")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<InjectCallCompanionUserInputRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:injectCallCompanionUserInput",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<InjectCallCompanionUserInputRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<InjectCallCompanionUserInputRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<InjectCallCompanionUserInputResponse>newBuilder()
                      .setDefaultInstance(InjectCallCompanionUserInputResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
      streamingListCallCompanionEventsMethodDescriptor =
          ApiMethodDescriptor
              .<StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
                  newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/StreamingListCallCompanionEvents")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.SERVER_STREAMING)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<StreamingListCallCompanionEventsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:streamingListCallCompanionEvents",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<StreamingListCallCompanionEventsRequest>
                                serializer = ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<StreamingListCallCompanionEventsRequest>
                                serializer = ProtoRestSerializer.create();
                            serializer.putQueryParam(
                                fields, "authenticationCode", request.getAuthenticationCode());
                            serializer.putQueryParam(
                                fields, "includePastEvents", request.getIncludePastEvents());
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<StreamingListCallCompanionEventsResponse>newBuilder()
                      .setDefaultInstance(
                          StreamingListCallCompanionEventsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<
          InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
      injectCallCompanionInputMethodDescriptor =
          ApiMethodDescriptor
              .<InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/InjectCallCompanionInput")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<InjectCallCompanionInputRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:injectCallCompanionInput",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<InjectCallCompanionInputRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<InjectCallCompanionInputRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<InjectCallCompanionInputResponse>newBuilder()
                      .setDefaultInstance(InjectCallCompanionInputResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<InitializeCallCompanionRequest, Empty>
      initializeCallCompanionMethodDescriptor =
          ApiMethodDescriptor.<InitializeCallCompanionRequest, Empty>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/InitializeCallCompanion")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<InitializeCallCompanionRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:initializeCallCompanion",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<InitializeCallCompanionRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<InitializeCallCompanionRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Empty>newBuilder()
                      .setDefaultInstance(Empty.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<GetCallCompanionSettingsRequest, CallCompanionSettings>
      getCallCompanionSettingsMethodDescriptor =
          ApiMethodDescriptor.<GetCallCompanionSettingsRequest, CallCompanionSettings>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/GetCallCompanionSettings")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GetCallCompanionSettingsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:getCallCompanionSettings",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GetCallCompanionSettingsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GetCallCompanionSettingsRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<CallCompanionSettings>newBuilder()
                      .setDefaultInstance(CallCompanionSettings.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<SearchKnowledgeRequest, SearchKnowledgeResponse>
      searchKnowledgeMethodDescriptor =
          ApiMethodDescriptor.<SearchKnowledgeRequest, SearchKnowledgeResponse>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/SearchKnowledge")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<SearchKnowledgeRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{parent=projects/*}/suggestions:searchKnowledge",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<SearchKnowledgeRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            serializer.putPathParam(fields, "parent", request.getParent());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{parent=projects/*/locations/*}/suggestions:searchKnowledge",
                          "/v2beta1/{conversation=projects/*/conversations/*}/suggestions:searchKnowledge",
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}/suggestions:searchKnowledge")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<SearchKnowledgeRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*",
                                      request.toBuilder().clearConversation().clearParent().build(),
                                      false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<SearchKnowledgeResponse>newBuilder()
                      .setDefaultInstance(SearchKnowledgeResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
      generateSuggestionsMethodDescriptor =
          ApiMethodDescriptor.<GenerateSuggestionsRequest, GenerateSuggestionsResponse>newBuilder()
              .setFullMethodName(
                  "google.cloud.dialogflow.v2beta1.Conversations/GenerateSuggestions")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GenerateSuggestionsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/conversations/*}/suggestions:generate",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GenerateSuggestionsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setAdditionalPaths(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}/suggestions:generate")
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GenerateSuggestionsRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<GenerateSuggestionsResponse>newBuilder()
                      .setDefaultInstance(GenerateSuggestionsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
      initiatePhoneCallMethodDescriptor =
          ApiMethodDescriptor.<InitiatePhoneCallRequest, InitiatePhoneCallResponse>newBuilder()
              .setFullMethodName("google.cloud.dialogflow.v2beta1.Conversations/InitiatePhoneCall")
              .setHttpMethod("POST")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<InitiatePhoneCallRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{conversation=projects/*/locations/*/conversations/*}:initiatePhoneCall",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<InitiatePhoneCallRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(
                                fields, "conversation", request.getConversation());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<InitiatePhoneCallRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(
                          request ->
                              ProtoRestSerializer.create()
                                  .toBody(
                                      "*", request.toBuilder().clearConversation().build(), false))
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<InitiatePhoneCallResponse>newBuilder()
                      .setDefaultInstance(InitiatePhoneCallResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<ListLocationsRequest, ListLocationsResponse>
      listLocationsMethodDescriptor =
          ApiMethodDescriptor.<ListLocationsRequest, ListLocationsResponse>newBuilder()
              .setFullMethodName("google.cloud.location.Locations/ListLocations")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<ListLocationsRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*}/locations",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<ListLocationsRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<ListLocationsRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<ListLocationsResponse>newBuilder()
                      .setDefaultInstance(ListLocationsResponse.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private static final ApiMethodDescriptor<GetLocationRequest, Location>
      getLocationMethodDescriptor =
          ApiMethodDescriptor.<GetLocationRequest, Location>newBuilder()
              .setFullMethodName("google.cloud.location.Locations/GetLocation")
              .setHttpMethod("GET")
              .setType(ApiMethodDescriptor.MethodType.UNARY)
              .setRequestFormatter(
                  ProtoMessageRequestFormatter.<GetLocationRequest>newBuilder()
                      .setPath(
                          "/v2beta1/{name=projects/*/locations/*}",
                          request -> {
                            Map<String, String> fields = new HashMap<>();
                            ProtoRestSerializer<GetLocationRequest> serializer =
                                ProtoRestSerializer.create();
                            serializer.putPathParam(fields, "name", request.getName());
                            return fields;
                          })
                      .setQueryParamsExtractor(
                          request -> {
                            Map<String, List<String>> fields = new HashMap<>();
                            ProtoRestSerializer<GetLocationRequest> serializer =
                                ProtoRestSerializer.create();
                            return fields;
                          })
                      .setRequestBodyExtractor(request -> null)
                      .build())
              .setResponseParser(
                  ProtoMessageResponseParser.<Location>newBuilder()
                      .setDefaultInstance(Location.getDefaultInstance())
                      .setDefaultTypeRegistry(typeRegistry)
                      .build())
              .build();

  private final UnaryCallable<CreateConversationRequest, Conversation> createConversationCallable;
  private final UnaryCallable<ListConversationsRequest, ListConversationsResponse>
      listConversationsCallable;
  private final UnaryCallable<ListConversationsRequest, ListConversationsPagedResponse>
      listConversationsPagedCallable;
  private final UnaryCallable<GetConversationRequest, Conversation> getConversationCallable;
  private final UnaryCallable<AddConversationPhoneNumberRequest, ConversationPhoneNumber>
      addConversationPhoneNumberCallable;
  private final UnaryCallable<ActivateConversationRequest, Conversation>
      activateConversationCallable;
  private final UnaryCallable<DeactivateConversationRequest, Conversation>
      deactivateConversationCallable;
  private final UnaryCallable<CompleteConversationRequest, Conversation>
      completeConversationCallable;
  private final UnaryCallable<UpdateConversationRequest, Conversation> updateConversationCallable;
  private final UnaryCallable<IngestContextReferencesRequest, IngestContextReferencesResponse>
      ingestContextReferencesCallable;
  private final UnaryCallable<CreateCallMatcherRequest, CallMatcher> createCallMatcherCallable;
  private final UnaryCallable<ListCallMatchersRequest, ListCallMatchersResponse>
      listCallMatchersCallable;
  private final UnaryCallable<ListCallMatchersRequest, ListCallMatchersPagedResponse>
      listCallMatchersPagedCallable;
  private final UnaryCallable<DeleteCallMatcherRequest, Empty> deleteCallMatcherCallable;
  private final UnaryCallable<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
      batchCreateMessagesCallable;
  private final UnaryCallable<ListMessagesRequest, ListMessagesResponse> listMessagesCallable;
  private final UnaryCallable<ListMessagesRequest, ListMessagesPagedResponse>
      listMessagesPagedCallable;
  private final UnaryCallable<ExportMessagesRequest, Operation> exportMessagesCallable;
  private final OperationCallable<ExportMessagesRequest, ExportMessagesResponse, Struct>
      exportMessagesOperationCallable;
  private final UnaryCallable<SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
      suggestConversationSummaryCallable;
  private final UnaryCallable<GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
      generateStatelessSummaryCallable;
  private final UnaryCallable<
          GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
      generateStatelessSuggestionCallable;
  private final UnaryCallable<
          SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
      suggestConversationKeyMomentsCallable;
  private final UnaryCallable<SearchArticlesRequest, SearchArticlesResponse> searchArticlesCallable;
  private final UnaryCallable<
          ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsResponse>
      listPastCallCompanionEventsCallable;
  private final UnaryCallable<
          ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsPagedResponse>
      listPastCallCompanionEventsPagedCallable;
  private final ServerStreamingCallable<
          StreamingListUpcomingCallCompanionEventsRequest,
          StreamingListUpcomingCallCompanionEventsResponse>
      streamingListUpcomingCallCompanionEventsCallable;
  private final UnaryCallable<
          InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
      injectCallCompanionUserInputCallable;
  private final ServerStreamingCallable<
          StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
      streamingListCallCompanionEventsCallable;
  private final UnaryCallable<InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
      injectCallCompanionInputCallable;
  private final UnaryCallable<InitializeCallCompanionRequest, Empty>
      initializeCallCompanionCallable;
  private final UnaryCallable<GetCallCompanionSettingsRequest, CallCompanionSettings>
      getCallCompanionSettingsCallable;
  private final UnaryCallable<SearchKnowledgeRequest, SearchKnowledgeResponse>
      searchKnowledgeCallable;
  private final UnaryCallable<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
      generateSuggestionsCallable;
  private final UnaryCallable<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
      initiatePhoneCallCallable;
  private final UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable;
  private final UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable;
  private final UnaryCallable<GetLocationRequest, Location> getLocationCallable;

  private final BackgroundResource backgroundResources;
  private final HttpJsonOperationsStub httpJsonOperationsStub;
  private final HttpJsonStubCallableFactory callableFactory;

  public static final HttpJsonConversationsStub create(ConversationsStubSettings settings)
      throws IOException {
    return new HttpJsonConversationsStub(settings, ClientContext.create(settings));
  }

  public static final HttpJsonConversationsStub create(ClientContext clientContext)
      throws IOException {
    return new HttpJsonConversationsStub(
        ConversationsStubSettings.newHttpJsonBuilder().build(), clientContext);
  }

  public static final HttpJsonConversationsStub create(
      ClientContext clientContext, HttpJsonStubCallableFactory callableFactory) throws IOException {
    return new HttpJsonConversationsStub(
        ConversationsStubSettings.newHttpJsonBuilder().build(), clientContext, callableFactory);
  }

  /**
   * Constructs an instance of HttpJsonConversationsStub, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected HttpJsonConversationsStub(
      ConversationsStubSettings settings, ClientContext clientContext) throws IOException {
    this(settings, clientContext, new HttpJsonConversationsCallableFactory());
  }

  /**
   * Constructs an instance of HttpJsonConversationsStub, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected HttpJsonConversationsStub(
      ConversationsStubSettings settings,
      ClientContext clientContext,
      HttpJsonStubCallableFactory callableFactory)
      throws IOException {
    this.callableFactory = callableFactory;
    this.httpJsonOperationsStub =
        HttpJsonOperationsStub.create(
            clientContext,
            callableFactory,
            typeRegistry,
            ImmutableMap.<String, HttpRule>builder()
                .put(
                    "google.longrunning.Operations.CancelOperation",
                    HttpRule.newBuilder()
                        .setPost("/v2beta1/{name=projects/*/operations/*}:cancel")
                        .addAdditionalBindings(
                            HttpRule.newBuilder()
                                .setPost(
                                    "/v2beta1/{name=projects/*/locations/*/operations/*}:cancel")
                                .build())
                        .build())
                .put(
                    "google.longrunning.Operations.GetOperation",
                    HttpRule.newBuilder()
                        .setGet("/v2beta1/{name=projects/*/operations/*}")
                        .addAdditionalBindings(
                            HttpRule.newBuilder()
                                .setGet("/v2beta1/{name=projects/*/locations/*/operations/*}")
                                .build())
                        .build())
                .put(
                    "google.longrunning.Operations.ListOperations",
                    HttpRule.newBuilder()
                        .setGet("/v2beta1/{name=projects/*}/operations")
                        .addAdditionalBindings(
                            HttpRule.newBuilder()
                                .setGet("/v2beta1/{name=projects/*/locations/*}/operations")
                                .build())
                        .build())
                .build());

    HttpJsonCallSettings<CreateConversationRequest, Conversation>
        createConversationTransportSettings =
            HttpJsonCallSettings.<CreateConversationRequest, Conversation>newBuilder()
                .setMethodDescriptor(createConversationMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<ListConversationsRequest, ListConversationsResponse>
        listConversationsTransportSettings =
            HttpJsonCallSettings.<ListConversationsRequest, ListConversationsResponse>newBuilder()
                .setMethodDescriptor(listConversationsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GetConversationRequest, Conversation> getConversationTransportSettings =
        HttpJsonCallSettings.<GetConversationRequest, Conversation>newBuilder()
            .setMethodDescriptor(getConversationMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("name", String.valueOf(request.getName()));
                  return builder.build();
                })
            .build();
    HttpJsonCallSettings<AddConversationPhoneNumberRequest, ConversationPhoneNumber>
        addConversationPhoneNumberTransportSettings =
            HttpJsonCallSettings
                .<AddConversationPhoneNumberRequest, ConversationPhoneNumber>newBuilder()
                .setMethodDescriptor(addConversationPhoneNumberMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<ActivateConversationRequest, Conversation>
        activateConversationTransportSettings =
            HttpJsonCallSettings.<ActivateConversationRequest, Conversation>newBuilder()
                .setMethodDescriptor(activateConversationMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<DeactivateConversationRequest, Conversation>
        deactivateConversationTransportSettings =
            HttpJsonCallSettings.<DeactivateConversationRequest, Conversation>newBuilder()
                .setMethodDescriptor(deactivateConversationMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<CompleteConversationRequest, Conversation>
        completeConversationTransportSettings =
            HttpJsonCallSettings.<CompleteConversationRequest, Conversation>newBuilder()
                .setMethodDescriptor(completeConversationMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<UpdateConversationRequest, Conversation>
        updateConversationTransportSettings =
            HttpJsonCallSettings.<UpdateConversationRequest, Conversation>newBuilder()
                .setMethodDescriptor(updateConversationMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add(
                          "conversation.name", String.valueOf(request.getConversation().getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<IngestContextReferencesRequest, IngestContextReferencesResponse>
        ingestContextReferencesTransportSettings =
            HttpJsonCallSettings
                .<IngestContextReferencesRequest, IngestContextReferencesResponse>newBuilder()
                .setMethodDescriptor(ingestContextReferencesMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<CreateCallMatcherRequest, CallMatcher> createCallMatcherTransportSettings =
        HttpJsonCallSettings.<CreateCallMatcherRequest, CallMatcher>newBuilder()
            .setMethodDescriptor(createCallMatcherMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("parent", String.valueOf(request.getParent()));
                  return builder.build();
                })
            .build();
    HttpJsonCallSettings<ListCallMatchersRequest, ListCallMatchersResponse>
        listCallMatchersTransportSettings =
            HttpJsonCallSettings.<ListCallMatchersRequest, ListCallMatchersResponse>newBuilder()
                .setMethodDescriptor(listCallMatchersMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<DeleteCallMatcherRequest, Empty> deleteCallMatcherTransportSettings =
        HttpJsonCallSettings.<DeleteCallMatcherRequest, Empty>newBuilder()
            .setMethodDescriptor(deleteCallMatcherMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("name", String.valueOf(request.getName()));
                  return builder.build();
                })
            .build();
    HttpJsonCallSettings<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
        batchCreateMessagesTransportSettings =
            HttpJsonCallSettings
                .<BatchCreateMessagesRequest, BatchCreateMessagesResponse>newBuilder()
                .setMethodDescriptor(batchCreateMessagesMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<ListMessagesRequest, ListMessagesResponse> listMessagesTransportSettings =
        HttpJsonCallSettings.<ListMessagesRequest, ListMessagesResponse>newBuilder()
            .setMethodDescriptor(listMessagesMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("parent", String.valueOf(request.getParent()));
                  return builder.build();
                })
            .build();
    HttpJsonCallSettings<ExportMessagesRequest, Operation> exportMessagesTransportSettings =
        HttpJsonCallSettings.<ExportMessagesRequest, Operation>newBuilder()
            .setMethodDescriptor(exportMessagesMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("parent", String.valueOf(request.getParent()));
                  return builder.build();
                })
            .build();
    HttpJsonCallSettings<SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
        suggestConversationSummaryTransportSettings =
            HttpJsonCallSettings
                .<SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>newBuilder()
                .setMethodDescriptor(suggestConversationSummaryMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
        generateStatelessSummaryTransportSettings =
            HttpJsonCallSettings
                .<GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>newBuilder()
                .setMethodDescriptor(generateStatelessSummaryMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add(
                          "stateless_conversation.parent",
                          String.valueOf(request.getStatelessConversation().getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
        generateStatelessSuggestionTransportSettings =
            HttpJsonCallSettings
                .<GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
                    newBuilder()
                .setMethodDescriptor(generateStatelessSuggestionMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<
            SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
        suggestConversationKeyMomentsTransportSettings =
            HttpJsonCallSettings
                .<SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
                    newBuilder()
                .setMethodDescriptor(suggestConversationKeyMomentsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<SearchArticlesRequest, SearchArticlesResponse>
        searchArticlesTransportSettings =
            HttpJsonCallSettings.<SearchArticlesRequest, SearchArticlesResponse>newBuilder()
                .setMethodDescriptor(searchArticlesMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsResponse>
        listPastCallCompanionEventsTransportSettings =
            HttpJsonCallSettings
                .<ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsResponse>
                    newBuilder()
                .setMethodDescriptor(listPastCallCompanionEventsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<
            StreamingListUpcomingCallCompanionEventsRequest,
            StreamingListUpcomingCallCompanionEventsResponse>
        streamingListUpcomingCallCompanionEventsTransportSettings =
            HttpJsonCallSettings
                .<StreamingListUpcomingCallCompanionEventsRequest,
                    StreamingListUpcomingCallCompanionEventsResponse>
                    newBuilder()
                .setMethodDescriptor(streamingListUpcomingCallCompanionEventsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
        injectCallCompanionUserInputTransportSettings =
            HttpJsonCallSettings
                .<InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
                    newBuilder()
                .setMethodDescriptor(injectCallCompanionUserInputMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<
            StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
        streamingListCallCompanionEventsTransportSettings =
            HttpJsonCallSettings
                .<StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
                    newBuilder()
                .setMethodDescriptor(streamingListCallCompanionEventsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
        injectCallCompanionInputTransportSettings =
            HttpJsonCallSettings
                .<InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>newBuilder()
                .setMethodDescriptor(injectCallCompanionInputMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<InitializeCallCompanionRequest, Empty>
        initializeCallCompanionTransportSettings =
            HttpJsonCallSettings.<InitializeCallCompanionRequest, Empty>newBuilder()
                .setMethodDescriptor(initializeCallCompanionMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GetCallCompanionSettingsRequest, CallCompanionSettings>
        getCallCompanionSettingsTransportSettings =
            HttpJsonCallSettings
                .<GetCallCompanionSettingsRequest, CallCompanionSettings>newBuilder()
                .setMethodDescriptor(getCallCompanionSettingsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<SearchKnowledgeRequest, SearchKnowledgeResponse>
        searchKnowledgeTransportSettings =
            HttpJsonCallSettings.<SearchKnowledgeRequest, SearchKnowledgeResponse>newBuilder()
                .setMethodDescriptor(searchKnowledgeMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      builder.add("parent", String.valueOf(request.getParent()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
        generateSuggestionsTransportSettings =
            HttpJsonCallSettings
                .<GenerateSuggestionsRequest, GenerateSuggestionsResponse>newBuilder()
                .setMethodDescriptor(generateSuggestionsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
        initiatePhoneCallTransportSettings =
            HttpJsonCallSettings.<InitiatePhoneCallRequest, InitiatePhoneCallResponse>newBuilder()
                .setMethodDescriptor(initiatePhoneCallMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("conversation", String.valueOf(request.getConversation()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<ListLocationsRequest, ListLocationsResponse>
        listLocationsTransportSettings =
            HttpJsonCallSettings.<ListLocationsRequest, ListLocationsResponse>newBuilder()
                .setMethodDescriptor(listLocationsMethodDescriptor)
                .setTypeRegistry(typeRegistry)
                .setParamsExtractor(
                    request -> {
                      RequestParamsBuilder builder = RequestParamsBuilder.create();
                      builder.add("name", String.valueOf(request.getName()));
                      return builder.build();
                    })
                .build();
    HttpJsonCallSettings<GetLocationRequest, Location> getLocationTransportSettings =
        HttpJsonCallSettings.<GetLocationRequest, Location>newBuilder()
            .setMethodDescriptor(getLocationMethodDescriptor)
            .setTypeRegistry(typeRegistry)
            .setParamsExtractor(
                request -> {
                  RequestParamsBuilder builder = RequestParamsBuilder.create();
                  builder.add("name", String.valueOf(request.getName()));
                  return builder.build();
                })
            .build();

    this.createConversationCallable =
        callableFactory.createUnaryCallable(
            createConversationTransportSettings,
            settings.createConversationSettings(),
            clientContext);
    this.listConversationsCallable =
        callableFactory.createUnaryCallable(
            listConversationsTransportSettings,
            settings.listConversationsSettings(),
            clientContext);
    this.listConversationsPagedCallable =
        callableFactory.createPagedCallable(
            listConversationsTransportSettings,
            settings.listConversationsSettings(),
            clientContext);
    this.getConversationCallable =
        callableFactory.createUnaryCallable(
            getConversationTransportSettings, settings.getConversationSettings(), clientContext);
    this.addConversationPhoneNumberCallable =
        callableFactory.createUnaryCallable(
            addConversationPhoneNumberTransportSettings,
            settings.addConversationPhoneNumberSettings(),
            clientContext);
    this.activateConversationCallable =
        callableFactory.createUnaryCallable(
            activateConversationTransportSettings,
            settings.activateConversationSettings(),
            clientContext);
    this.deactivateConversationCallable =
        callableFactory.createUnaryCallable(
            deactivateConversationTransportSettings,
            settings.deactivateConversationSettings(),
            clientContext);
    this.completeConversationCallable =
        callableFactory.createUnaryCallable(
            completeConversationTransportSettings,
            settings.completeConversationSettings(),
            clientContext);
    this.updateConversationCallable =
        callableFactory.createUnaryCallable(
            updateConversationTransportSettings,
            settings.updateConversationSettings(),
            clientContext);
    this.ingestContextReferencesCallable =
        callableFactory.createUnaryCallable(
            ingestContextReferencesTransportSettings,
            settings.ingestContextReferencesSettings(),
            clientContext);
    this.createCallMatcherCallable =
        callableFactory.createUnaryCallable(
            createCallMatcherTransportSettings,
            settings.createCallMatcherSettings(),
            clientContext);
    this.listCallMatchersCallable =
        callableFactory.createUnaryCallable(
            listCallMatchersTransportSettings, settings.listCallMatchersSettings(), clientContext);
    this.listCallMatchersPagedCallable =
        callableFactory.createPagedCallable(
            listCallMatchersTransportSettings, settings.listCallMatchersSettings(), clientContext);
    this.deleteCallMatcherCallable =
        callableFactory.createUnaryCallable(
            deleteCallMatcherTransportSettings,
            settings.deleteCallMatcherSettings(),
            clientContext);
    this.batchCreateMessagesCallable =
        callableFactory.createUnaryCallable(
            batchCreateMessagesTransportSettings,
            settings.batchCreateMessagesSettings(),
            clientContext);
    this.listMessagesCallable =
        callableFactory.createUnaryCallable(
            listMessagesTransportSettings, settings.listMessagesSettings(), clientContext);
    this.listMessagesPagedCallable =
        callableFactory.createPagedCallable(
            listMessagesTransportSettings, settings.listMessagesSettings(), clientContext);
    this.exportMessagesCallable =
        callableFactory.createUnaryCallable(
            exportMessagesTransportSettings, settings.exportMessagesSettings(), clientContext);
    this.exportMessagesOperationCallable =
        callableFactory.createOperationCallable(
            exportMessagesTransportSettings,
            settings.exportMessagesOperationSettings(),
            clientContext,
            httpJsonOperationsStub);
    this.suggestConversationSummaryCallable =
        callableFactory.createUnaryCallable(
            suggestConversationSummaryTransportSettings,
            settings.suggestConversationSummarySettings(),
            clientContext);
    this.generateStatelessSummaryCallable =
        callableFactory.createUnaryCallable(
            generateStatelessSummaryTransportSettings,
            settings.generateStatelessSummarySettings(),
            clientContext);
    this.generateStatelessSuggestionCallable =
        callableFactory.createUnaryCallable(
            generateStatelessSuggestionTransportSettings,
            settings.generateStatelessSuggestionSettings(),
            clientContext);
    this.suggestConversationKeyMomentsCallable =
        callableFactory.createUnaryCallable(
            suggestConversationKeyMomentsTransportSettings,
            settings.suggestConversationKeyMomentsSettings(),
            clientContext);
    this.searchArticlesCallable =
        callableFactory.createUnaryCallable(
            searchArticlesTransportSettings, settings.searchArticlesSettings(), clientContext);
    this.listPastCallCompanionEventsCallable =
        callableFactory.createUnaryCallable(
            listPastCallCompanionEventsTransportSettings,
            settings.listPastCallCompanionEventsSettings(),
            clientContext);
    this.listPastCallCompanionEventsPagedCallable =
        callableFactory.createPagedCallable(
            listPastCallCompanionEventsTransportSettings,
            settings.listPastCallCompanionEventsSettings(),
            clientContext);
    this.streamingListUpcomingCallCompanionEventsCallable =
        callableFactory.createServerStreamingCallable(
            streamingListUpcomingCallCompanionEventsTransportSettings,
            settings.streamingListUpcomingCallCompanionEventsSettings(),
            clientContext);
    this.injectCallCompanionUserInputCallable =
        callableFactory.createUnaryCallable(
            injectCallCompanionUserInputTransportSettings,
            settings.injectCallCompanionUserInputSettings(),
            clientContext);
    this.streamingListCallCompanionEventsCallable =
        callableFactory.createServerStreamingCallable(
            streamingListCallCompanionEventsTransportSettings,
            settings.streamingListCallCompanionEventsSettings(),
            clientContext);
    this.injectCallCompanionInputCallable =
        callableFactory.createUnaryCallable(
            injectCallCompanionInputTransportSettings,
            settings.injectCallCompanionInputSettings(),
            clientContext);
    this.initializeCallCompanionCallable =
        callableFactory.createUnaryCallable(
            initializeCallCompanionTransportSettings,
            settings.initializeCallCompanionSettings(),
            clientContext);
    this.getCallCompanionSettingsCallable =
        callableFactory.createUnaryCallable(
            getCallCompanionSettingsTransportSettings,
            settings.getCallCompanionSettingsSettings(),
            clientContext);
    this.searchKnowledgeCallable =
        callableFactory.createUnaryCallable(
            searchKnowledgeTransportSettings, settings.searchKnowledgeSettings(), clientContext);
    this.generateSuggestionsCallable =
        callableFactory.createUnaryCallable(
            generateSuggestionsTransportSettings,
            settings.generateSuggestionsSettings(),
            clientContext);
    this.initiatePhoneCallCallable =
        callableFactory.createUnaryCallable(
            initiatePhoneCallTransportSettings,
            settings.initiatePhoneCallSettings(),
            clientContext);
    this.listLocationsCallable =
        callableFactory.createUnaryCallable(
            listLocationsTransportSettings, settings.listLocationsSettings(), clientContext);
    this.listLocationsPagedCallable =
        callableFactory.createPagedCallable(
            listLocationsTransportSettings, settings.listLocationsSettings(), clientContext);
    this.getLocationCallable =
        callableFactory.createUnaryCallable(
            getLocationTransportSettings, settings.getLocationSettings(), clientContext);

    this.backgroundResources =
        new BackgroundResourceAggregation(clientContext.getBackgroundResources());
  }

  @InternalApi
  public static List<ApiMethodDescriptor> getMethodDescriptors() {
    List<ApiMethodDescriptor> methodDescriptors = new ArrayList<>();
    methodDescriptors.add(createConversationMethodDescriptor);
    methodDescriptors.add(listConversationsMethodDescriptor);
    methodDescriptors.add(getConversationMethodDescriptor);
    methodDescriptors.add(addConversationPhoneNumberMethodDescriptor);
    methodDescriptors.add(activateConversationMethodDescriptor);
    methodDescriptors.add(deactivateConversationMethodDescriptor);
    methodDescriptors.add(completeConversationMethodDescriptor);
    methodDescriptors.add(updateConversationMethodDescriptor);
    methodDescriptors.add(ingestContextReferencesMethodDescriptor);
    methodDescriptors.add(createCallMatcherMethodDescriptor);
    methodDescriptors.add(listCallMatchersMethodDescriptor);
    methodDescriptors.add(deleteCallMatcherMethodDescriptor);
    methodDescriptors.add(batchCreateMessagesMethodDescriptor);
    methodDescriptors.add(listMessagesMethodDescriptor);
    methodDescriptors.add(exportMessagesMethodDescriptor);
    methodDescriptors.add(suggestConversationSummaryMethodDescriptor);
    methodDescriptors.add(generateStatelessSummaryMethodDescriptor);
    methodDescriptors.add(generateStatelessSuggestionMethodDescriptor);
    methodDescriptors.add(suggestConversationKeyMomentsMethodDescriptor);
    methodDescriptors.add(searchArticlesMethodDescriptor);
    methodDescriptors.add(listPastCallCompanionEventsMethodDescriptor);
    methodDescriptors.add(streamingListUpcomingCallCompanionEventsMethodDescriptor);
    methodDescriptors.add(injectCallCompanionUserInputMethodDescriptor);
    methodDescriptors.add(streamingListCallCompanionEventsMethodDescriptor);
    methodDescriptors.add(injectCallCompanionInputMethodDescriptor);
    methodDescriptors.add(initializeCallCompanionMethodDescriptor);
    methodDescriptors.add(getCallCompanionSettingsMethodDescriptor);
    methodDescriptors.add(searchKnowledgeMethodDescriptor);
    methodDescriptors.add(generateSuggestionsMethodDescriptor);
    methodDescriptors.add(initiatePhoneCallMethodDescriptor);
    methodDescriptors.add(listLocationsMethodDescriptor);
    methodDescriptors.add(getLocationMethodDescriptor);
    return methodDescriptors;
  }

  public HttpJsonOperationsStub getHttpJsonOperationsStub() {
    return httpJsonOperationsStub;
  }

  @Override
  public UnaryCallable<CreateConversationRequest, Conversation> createConversationCallable() {
    return createConversationCallable;
  }

  @Override
  public UnaryCallable<ListConversationsRequest, ListConversationsResponse>
      listConversationsCallable() {
    return listConversationsCallable;
  }

  @Override
  public UnaryCallable<ListConversationsRequest, ListConversationsPagedResponse>
      listConversationsPagedCallable() {
    return listConversationsPagedCallable;
  }

  @Override
  public UnaryCallable<GetConversationRequest, Conversation> getConversationCallable() {
    return getConversationCallable;
  }

  @Override
  public UnaryCallable<AddConversationPhoneNumberRequest, ConversationPhoneNumber>
      addConversationPhoneNumberCallable() {
    return addConversationPhoneNumberCallable;
  }

  @Override
  public UnaryCallable<ActivateConversationRequest, Conversation> activateConversationCallable() {
    return activateConversationCallable;
  }

  @Override
  public UnaryCallable<DeactivateConversationRequest, Conversation>
      deactivateConversationCallable() {
    return deactivateConversationCallable;
  }

  @Override
  public UnaryCallable<CompleteConversationRequest, Conversation> completeConversationCallable() {
    return completeConversationCallable;
  }

  @Override
  public UnaryCallable<UpdateConversationRequest, Conversation> updateConversationCallable() {
    return updateConversationCallable;
  }

  @Override
  public UnaryCallable<IngestContextReferencesRequest, IngestContextReferencesResponse>
      ingestContextReferencesCallable() {
    return ingestContextReferencesCallable;
  }

  @Override
  public UnaryCallable<CreateCallMatcherRequest, CallMatcher> createCallMatcherCallable() {
    return createCallMatcherCallable;
  }

  @Override
  public UnaryCallable<ListCallMatchersRequest, ListCallMatchersResponse>
      listCallMatchersCallable() {
    return listCallMatchersCallable;
  }

  @Override
  public UnaryCallable<ListCallMatchersRequest, ListCallMatchersPagedResponse>
      listCallMatchersPagedCallable() {
    return listCallMatchersPagedCallable;
  }

  @Override
  public UnaryCallable<DeleteCallMatcherRequest, Empty> deleteCallMatcherCallable() {
    return deleteCallMatcherCallable;
  }

  @Override
  public UnaryCallable<BatchCreateMessagesRequest, BatchCreateMessagesResponse>
      batchCreateMessagesCallable() {
    return batchCreateMessagesCallable;
  }

  @Override
  public UnaryCallable<ListMessagesRequest, ListMessagesResponse> listMessagesCallable() {
    return listMessagesCallable;
  }

  @Override
  public UnaryCallable<ListMessagesRequest, ListMessagesPagedResponse> listMessagesPagedCallable() {
    return listMessagesPagedCallable;
  }

  @Override
  public UnaryCallable<ExportMessagesRequest, Operation> exportMessagesCallable() {
    return exportMessagesCallable;
  }

  @Override
  public OperationCallable<ExportMessagesRequest, ExportMessagesResponse, Struct>
      exportMessagesOperationCallable() {
    return exportMessagesOperationCallable;
  }

  @Override
  public UnaryCallable<SuggestConversationSummaryRequest, SuggestConversationSummaryResponse>
      suggestConversationSummaryCallable() {
    return suggestConversationSummaryCallable;
  }

  @Override
  public UnaryCallable<GenerateStatelessSummaryRequest, GenerateStatelessSummaryResponse>
      generateStatelessSummaryCallable() {
    return generateStatelessSummaryCallable;
  }

  @Override
  public UnaryCallable<GenerateStatelessSuggestionRequest, GenerateStatelessSuggestionResponse>
      generateStatelessSuggestionCallable() {
    return generateStatelessSuggestionCallable;
  }

  @Override
  public UnaryCallable<SuggestConversationKeyMomentsRequest, SuggestConversationKeyMomentsResponse>
      suggestConversationKeyMomentsCallable() {
    return suggestConversationKeyMomentsCallable;
  }

  @Override
  public UnaryCallable<SearchArticlesRequest, SearchArticlesResponse> searchArticlesCallable() {
    return searchArticlesCallable;
  }

  @Override
  public UnaryCallable<ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsResponse>
      listPastCallCompanionEventsCallable() {
    return listPastCallCompanionEventsCallable;
  }

  @Override
  public UnaryCallable<ListPastCallCompanionEventsRequest, ListPastCallCompanionEventsPagedResponse>
      listPastCallCompanionEventsPagedCallable() {
    return listPastCallCompanionEventsPagedCallable;
  }

  @Override
  public ServerStreamingCallable<
          StreamingListUpcomingCallCompanionEventsRequest,
          StreamingListUpcomingCallCompanionEventsResponse>
      streamingListUpcomingCallCompanionEventsCallable() {
    return streamingListUpcomingCallCompanionEventsCallable;
  }

  @Override
  public UnaryCallable<InjectCallCompanionUserInputRequest, InjectCallCompanionUserInputResponse>
      injectCallCompanionUserInputCallable() {
    return injectCallCompanionUserInputCallable;
  }

  @Override
  public ServerStreamingCallable<
          StreamingListCallCompanionEventsRequest, StreamingListCallCompanionEventsResponse>
      streamingListCallCompanionEventsCallable() {
    return streamingListCallCompanionEventsCallable;
  }

  @Override
  public UnaryCallable<InjectCallCompanionInputRequest, InjectCallCompanionInputResponse>
      injectCallCompanionInputCallable() {
    return injectCallCompanionInputCallable;
  }

  @Override
  public UnaryCallable<InitializeCallCompanionRequest, Empty> initializeCallCompanionCallable() {
    return initializeCallCompanionCallable;
  }

  @Override
  public UnaryCallable<GetCallCompanionSettingsRequest, CallCompanionSettings>
      getCallCompanionSettingsCallable() {
    return getCallCompanionSettingsCallable;
  }

  @Override
  public UnaryCallable<SearchKnowledgeRequest, SearchKnowledgeResponse> searchKnowledgeCallable() {
    return searchKnowledgeCallable;
  }

  @Override
  public UnaryCallable<GenerateSuggestionsRequest, GenerateSuggestionsResponse>
      generateSuggestionsCallable() {
    return generateSuggestionsCallable;
  }

  @Override
  public UnaryCallable<InitiatePhoneCallRequest, InitiatePhoneCallResponse>
      initiatePhoneCallCallable() {
    return initiatePhoneCallCallable;
  }

  @Override
  public UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    return listLocationsCallable;
  }

  @Override
  public UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    return listLocationsPagedCallable;
  }

  @Override
  public UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    return getLocationCallable;
  }

  @Override
  public final void close() {
    try {
      backgroundResources.close();
    } catch (RuntimeException e) {
      throw e;
    } catch (Exception e) {
      throw new IllegalStateException("Failed to close resource", e);
    }
  }

  @Override
  public void shutdown() {
    backgroundResources.shutdown();
  }

  @Override
  public boolean isShutdown() {
    return backgroundResources.isShutdown();
  }

  @Override
  public boolean isTerminated() {
    return backgroundResources.isTerminated();
  }

  @Override
  public void shutdownNow() {
    backgroundResources.shutdownNow();
  }

  @Override
  public boolean awaitTermination(long duration, TimeUnit unit) throws InterruptedException {
    return backgroundResources.awaitTermination(duration, unit);
  }
}
