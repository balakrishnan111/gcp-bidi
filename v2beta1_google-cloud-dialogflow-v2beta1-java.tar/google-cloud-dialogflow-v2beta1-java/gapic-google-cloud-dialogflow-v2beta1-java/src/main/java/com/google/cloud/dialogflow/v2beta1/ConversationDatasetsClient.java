/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1;

import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutures;
import com.google.api.core.BetaApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.httpjson.longrunning.OperationsClient;
import com.google.api.gax.longrunning.OperationFuture;
import com.google.api.gax.paging.AbstractFixedSizeCollection;
import com.google.api.gax.paging.AbstractPage;
import com.google.api.gax.paging.AbstractPagedListResponse;
import com.google.api.gax.rpc.OperationCallable;
import com.google.api.gax.rpc.PageContext;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.stub.ConversationDatasetsStub;
import com.google.cloud.dialogflow.v2beta1.stub.ConversationDatasetsStubSettings;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.common.util.concurrent.MoreExecutors;
import com.google.longrunning.Operation;
import com.google.protobuf.Empty;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * Service Description: Conversation datasets.
 *
 * <p>Conversation datasets contain raw conversation files along with their customizable metadata
 * that can be used to train custom human agent assistant models, evaluate models in regression
 * tests and other stuff.
 *
 * <p>This class provides the ability to make remote calls to the backing service through method
 * calls that map to API methods. Sample code to get started:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * try (ConversationDatasetsClient conversationDatasetsClient =
 *     ConversationDatasetsClient.create()) {
 *   ConversationDatasetName name =
 *       ConversationDatasetName.ofProjectConversationDatasetName(
 *           "[PROJECT]", "[CONVERSATION_DATASET]");
 *   ConversationDataset response = conversationDatasetsClient.getConversationDataset(name);
 * }
 * }</pre>
 *
 * <p>Note: close() needs to be called on the ConversationDatasetsClient object to clean up
 * resources such as threads. In the example above, try-with-resources is used, which automatically
 * calls close().
 *
 * <table>
 *    <caption>Methods</caption>
 *    <tr>
 *      <th>Method</th>
 *      <th>Description</th>
 *      <th>Method Variants</th>
 *    </tr>
 *    <tr>
 *      <td><p> CreateConversationDataset</td>
 *      <td><p> Creates a new conversation dataset.
 * <p>  This method is a [long-running operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The returned `Operation` type has the following method-specific fields:
 * <p>  - `metadata`: [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata] - `response`: [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> createConversationDatasetAsync(CreateConversationDatasetRequest request)
 *      </ul>
 *      <p>Methods that return long-running operations have "Async" method variants that return `OperationFuture`, which is used to track polling of the service.</p>
 *      <ul>
 *           <li><p> createConversationDatasetAsync(String parent, ConversationDataset conversationDataset)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> createConversationDatasetOperationCallable()
 *           <li><p> createConversationDatasetCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> GetConversationDataset</td>
 *      <td><p> Retrieves the specified conversation dataset.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> getConversationDataset(GetConversationDatasetRequest request)
 *      </ul>
 *      <p>"Flattened" method variants have converted the fields of the request object into function parameters to enable multiple ways to call the same method.</p>
 *      <ul>
 *           <li><p> getConversationDataset(ConversationDatasetName name)
 *           <li><p> getConversationDataset(String name)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> getConversationDatasetCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> ListConversationDatasets</td>
 *      <td><p> Returns the list of all conversation datasets in the specified project.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> listConversationDatasets(ListConversationDatasetsRequest request)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> listConversationDatasetsPagedCallable()
 *           <li><p> listConversationDatasetsCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> DeleteConversationDataset</td>
 *      <td><p> Deletes the specified conversation dataset and all annotated conversation datasets that belong to it.
 * <p>  This method is a [long-running operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The returned `Operation` type has the following method-specific fields:
 * <p>  - `metadata`: [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata] - `response`: An [Empty   message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> deleteConversationDatasetAsync(DeleteConversationDatasetRequest request)
 *      </ul>
 *      <p>Methods that return long-running operations have "Async" method variants that return `OperationFuture`, which is used to track polling of the service.</p>
 *      <ul>
 *           <li><p> deleteConversationDatasetAsync(ConversationDatasetName name)
 *           <li><p> deleteConversationDatasetAsync(String name)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> deleteConversationDatasetOperationCallable()
 *           <li><p> deleteConversationDatasetCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> GetAnnotatedConversationDataset</td>
 *      <td><p> Retrieves the specified annotated conversation dataset.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> getAnnotatedConversationDataset(GetAnnotatedConversationDatasetRequest request)
 *      </ul>
 *      <p>"Flattened" method variants have converted the fields of the request object into function parameters to enable multiple ways to call the same method.</p>
 *      <ul>
 *           <li><p> getAnnotatedConversationDataset(AnnotatedConversationDatasetName name)
 *           <li><p> getAnnotatedConversationDataset(String name)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> getAnnotatedConversationDatasetCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> ListAnnotatedConversationDatasets</td>
 *      <td><p> Returns the list of all annotated conversation datasets that belong to a given conversation dataset.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> listAnnotatedConversationDatasets(ListAnnotatedConversationDatasetsRequest request)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> listAnnotatedConversationDatasetsPagedCallable()
 *           <li><p> listAnnotatedConversationDatasetsCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> DeleteAnnotatedConversationDataset</td>
 *      <td><p> Deletes the specified annotated conversation dataset and annotations that belongs to it.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> deleteAnnotatedConversationDataset(DeleteAnnotatedConversationDatasetRequest request)
 *      </ul>
 *      <p>"Flattened" method variants have converted the fields of the request object into function parameters to enable multiple ways to call the same method.</p>
 *      <ul>
 *           <li><p> deleteAnnotatedConversationDataset(AnnotatedConversationDatasetName name)
 *           <li><p> deleteAnnotatedConversationDataset(String name)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> deleteAnnotatedConversationDatasetCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> ImportConversationData</td>
 *      <td><p> Import data into the specified conversation dataset. Note that it is not allowed to import data to a conversation dataset that already has data in it.
 * <p>  This method is a [long-running operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The returned `Operation` type has the following method-specific fields:
 * <p>  - `metadata`: [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata] - `response`: [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> importConversationDataAsync(ImportConversationDataRequest request)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> importConversationDataOperationCallable()
 *           <li><p> importConversationDataCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> LabelConversation</td>
 *      <td><p> [DEPRECATED]. Creates and starts a conversation dataset annotation task.
 * <p>  This method is a [long-running operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The returned `Operation` type has the following method-specific fields:
 * <p>  - `metadata`: [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata] - `response`: [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> labelConversationAsync(LabelConversationRequest request)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> labelConversationOperationCallable()
 *           <li><p> labelConversationCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> ListLocations</td>
 *      <td><p> Lists information about the supported locations for this service.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> listLocations(ListLocationsRequest request)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> listLocationsPagedCallable()
 *           <li><p> listLocationsCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *    <tr>
 *      <td><p> GetLocation</td>
 *      <td><p> Gets information about a location.</td>
 *      <td>
 *      <p>Request object method variants only take one parameter, a request object, which must be constructed before the call.</p>
 *      <ul>
 *           <li><p> getLocation(GetLocationRequest request)
 *      </ul>
 *      <p>Callable method variants take no parameters and return an immutable API callable object, which can be used to initiate calls to the service.</p>
 *      <ul>
 *           <li><p> getLocationCallable()
 *      </ul>
 *       </td>
 *    </tr>
 *  </table>
 *
 * <p>See the individual methods for example code.
 *
 * <p>Many parameters require resource names to be formatted in a particular way. To assist with
 * these names, this class includes a format method for each type of name, and additionally a parse
 * method to extract the individual identifiers contained within names that are returned.
 *
 * <p>This class can be customized by passing in a custom instance of ConversationDatasetsSettings
 * to create(). For example:
 *
 * <p>To customize credentials:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * ConversationDatasetsSettings conversationDatasetsSettings =
 *     ConversationDatasetsSettings.newBuilder()
 *         .setCredentialsProvider(FixedCredentialsProvider.create(myCredentials))
 *         .build();
 * ConversationDatasetsClient conversationDatasetsClient =
 *     ConversationDatasetsClient.create(conversationDatasetsSettings);
 * }</pre>
 *
 * <p>To customize the endpoint:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * ConversationDatasetsSettings conversationDatasetsSettings =
 *     ConversationDatasetsSettings.newBuilder().setEndpoint(myEndpoint).build();
 * ConversationDatasetsClient conversationDatasetsClient =
 *     ConversationDatasetsClient.create(conversationDatasetsSettings);
 * }</pre>
 *
 * <p>To use REST (HTTP1.1/JSON) transport (instead of gRPC) for sending and receiving requests over
 * the wire:
 *
 * <pre>{@code
 * // This snippet has been automatically generated and should be regarded as a code template only.
 * // It will require modifications to work:
 * // - It may require correct/in-range values for request initialization.
 * // - It may require specifying regional endpoints when creating the service client as shown in
 * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
 * ConversationDatasetsSettings conversationDatasetsSettings =
 *     ConversationDatasetsSettings.newHttpJsonBuilder().build();
 * ConversationDatasetsClient conversationDatasetsClient =
 *     ConversationDatasetsClient.create(conversationDatasetsSettings);
 * }</pre>
 *
 * <p>Please refer to the GitHub repository's samples for more quickstart code snippets.
 */
@BetaApi
@Generated("by gapic-generator-java")
public class ConversationDatasetsClient implements BackgroundResource {
  private final ConversationDatasetsSettings settings;
  private final ConversationDatasetsStub stub;
  private final OperationsClient httpJsonOperationsClient;
  private final com.google.longrunning.OperationsClient operationsClient;

  /** Constructs an instance of ConversationDatasetsClient with default settings. */
  public static final ConversationDatasetsClient create() throws IOException {
    return create(ConversationDatasetsSettings.newBuilder().build());
  }

  /**
   * Constructs an instance of ConversationDatasetsClient, using the given settings. The channels
   * are created based on the settings passed in, or defaults for any settings that are not set.
   */
  public static final ConversationDatasetsClient create(ConversationDatasetsSettings settings)
      throws IOException {
    return new ConversationDatasetsClient(settings);
  }

  /**
   * Constructs an instance of ConversationDatasetsClient, using the given stub for making calls.
   * This is for advanced usage - prefer using create(ConversationDatasetsSettings).
   */
  public static final ConversationDatasetsClient create(ConversationDatasetsStub stub) {
    return new ConversationDatasetsClient(stub);
  }

  /**
   * Constructs an instance of ConversationDatasetsClient, using the given settings. This is
   * protected so that it is easy to make a subclass, but otherwise, the static factory methods
   * should be preferred.
   */
  protected ConversationDatasetsClient(ConversationDatasetsSettings settings) throws IOException {
    this.settings = settings;
    this.stub = ((ConversationDatasetsStubSettings) settings.getStubSettings()).createStub();
    this.operationsClient =
        com.google.longrunning.OperationsClient.create(this.stub.getOperationsStub());
    this.httpJsonOperationsClient = OperationsClient.create(this.stub.getHttpJsonOperationsStub());
  }

  protected ConversationDatasetsClient(ConversationDatasetsStub stub) {
    this.settings = null;
    this.stub = stub;
    this.operationsClient =
        com.google.longrunning.OperationsClient.create(this.stub.getOperationsStub());
    this.httpJsonOperationsClient = OperationsClient.create(this.stub.getHttpJsonOperationsStub());
  }

  public final ConversationDatasetsSettings getSettings() {
    return settings;
  }

  public ConversationDatasetsStub getStub() {
    return stub;
  }

  /**
   * Returns the OperationsClient that can be used to query the status of a long-running operation
   * returned by another API method call.
   */
  public final com.google.longrunning.OperationsClient getOperationsClient() {
    return operationsClient;
  }

  /**
   * Returns the OperationsClient that can be used to query the status of a long-running operation
   * returned by another API method call.
   */
  @BetaApi
  public final OperationsClient getHttpJsonOperationsClient() {
    return httpJsonOperationsClient;
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates a new conversation dataset.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
   * - `response`: [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   String parent = "parent-995424086";
   *   ConversationDataset conversationDataset = ConversationDataset.newBuilder().build();
   *   ConversationDataset response =
   *       conversationDatasetsClient
   *           .createConversationDatasetAsync(parent, conversationDataset)
   *           .get();
   * }
   * }</pre>
   *
   * @param parent Required. The project to create conversation dataset for. Format:
   *     `projects/&lt;Project ID&gt;`
   * @param conversationDataset Required. The conversation dataset to create.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final OperationFuture<ConversationDataset, CreateConversationDatasetOperationMetadata>
      createConversationDatasetAsync(String parent, ConversationDataset conversationDataset) {
    CreateConversationDatasetRequest request =
        CreateConversationDatasetRequest.newBuilder()
            .setParent(parent)
            .setConversationDataset(conversationDataset)
            .build();
    return createConversationDatasetAsync(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates a new conversation dataset.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
   * - `response`: [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   CreateConversationDatasetRequest request =
   *       CreateConversationDatasetRequest.newBuilder()
   *           .setParent("parent-995424086")
   *           .setConversationDataset(ConversationDataset.newBuilder().build())
   *           .build();
   *   ConversationDataset response =
   *       conversationDatasetsClient.createConversationDatasetAsync(request).get();
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final OperationFuture<ConversationDataset, CreateConversationDatasetOperationMetadata>
      createConversationDatasetAsync(CreateConversationDatasetRequest request) {
    return createConversationDatasetOperationCallable().futureCall(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates a new conversation dataset.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
   * - `response`: [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   CreateConversationDatasetRequest request =
   *       CreateConversationDatasetRequest.newBuilder()
   *           .setParent("parent-995424086")
   *           .setConversationDataset(ConversationDataset.newBuilder().build())
   *           .build();
   *   OperationFuture<ConversationDataset, CreateConversationDatasetOperationMetadata> future =
   *       conversationDatasetsClient
   *           .createConversationDatasetOperationCallable()
   *           .futureCall(request);
   *   // Do something.
   *   ConversationDataset response = future.get();
   * }
   * }</pre>
   */
  public final OperationCallable<
          CreateConversationDatasetRequest,
          ConversationDataset,
          CreateConversationDatasetOperationMetadata>
      createConversationDatasetOperationCallable() {
    return stub.createConversationDatasetOperationCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Creates a new conversation dataset.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
   * - `response`: [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   CreateConversationDatasetRequest request =
   *       CreateConversationDatasetRequest.newBuilder()
   *           .setParent("parent-995424086")
   *           .setConversationDataset(ConversationDataset.newBuilder().build())
   *           .build();
   *   ApiFuture<Operation> future =
   *       conversationDatasetsClient.createConversationDatasetCallable().futureCall(request);
   *   // Do something.
   *   Operation response = future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<CreateConversationDatasetRequest, Operation>
      createConversationDatasetCallable() {
    return stub.createConversationDatasetCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Retrieves the specified conversation dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ConversationDatasetName name =
   *       ConversationDatasetName.ofProjectConversationDatasetName(
   *           "[PROJECT]", "[CONVERSATION_DATASET]");
   *   ConversationDataset response = conversationDatasetsClient.getConversationDataset(name);
   * }
   * }</pre>
   *
   * @param name Required. The conversation dataset to retrieve. Format: `projects/&lt;Project
   *     ID&gt;/conversationDatasets/&lt;Conversation Dataset ID&gt;`
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ConversationDataset getConversationDataset(ConversationDatasetName name) {
    GetConversationDatasetRequest request =
        GetConversationDatasetRequest.newBuilder()
            .setName(name == null ? null : name.toString())
            .build();
    return getConversationDataset(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Retrieves the specified conversation dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   String name =
   *       ConversationDatasetName.ofProjectConversationDatasetName(
   *               "[PROJECT]", "[CONVERSATION_DATASET]")
   *           .toString();
   *   ConversationDataset response = conversationDatasetsClient.getConversationDataset(name);
   * }
   * }</pre>
   *
   * @param name Required. The conversation dataset to retrieve. Format: `projects/&lt;Project
   *     ID&gt;/conversationDatasets/&lt;Conversation Dataset ID&gt;`
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ConversationDataset getConversationDataset(String name) {
    GetConversationDatasetRequest request =
        GetConversationDatasetRequest.newBuilder().setName(name).build();
    return getConversationDataset(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Retrieves the specified conversation dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   GetConversationDatasetRequest request =
   *       GetConversationDatasetRequest.newBuilder()
   *           .setName(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   ConversationDataset response = conversationDatasetsClient.getConversationDataset(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ConversationDataset getConversationDataset(GetConversationDatasetRequest request) {
    return getConversationDatasetCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Retrieves the specified conversation dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   GetConversationDatasetRequest request =
   *       GetConversationDatasetRequest.newBuilder()
   *           .setName(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   ApiFuture<ConversationDataset> future =
   *       conversationDatasetsClient.getConversationDatasetCallable().futureCall(request);
   *   // Do something.
   *   ConversationDataset response = future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<GetConversationDatasetRequest, ConversationDataset>
      getConversationDatasetCallable() {
    return stub.getConversationDatasetCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns the list of all conversation datasets in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListConversationDatasetsRequest request =
   *       ListConversationDatasetsRequest.newBuilder()
   *           .setParent(ProjectName.of("[PROJECT]").toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   for (ConversationDataset element :
   *       conversationDatasetsClient.listConversationDatasets(request).iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ListConversationDatasetsPagedResponse listConversationDatasets(
      ListConversationDatasetsRequest request) {
    return listConversationDatasetsPagedCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns the list of all conversation datasets in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListConversationDatasetsRequest request =
   *       ListConversationDatasetsRequest.newBuilder()
   *           .setParent(ProjectName.of("[PROJECT]").toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   ApiFuture<ConversationDataset> future =
   *       conversationDatasetsClient.listConversationDatasetsPagedCallable().futureCall(request);
   *   // Do something.
   *   for (ConversationDataset element : future.get().iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   */
  public final UnaryCallable<ListConversationDatasetsRequest, ListConversationDatasetsPagedResponse>
      listConversationDatasetsPagedCallable() {
    return stub.listConversationDatasetsPagedCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns the list of all conversation datasets in the specified project.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListConversationDatasetsRequest request =
   *       ListConversationDatasetsRequest.newBuilder()
   *           .setParent(ProjectName.of("[PROJECT]").toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   while (true) {
   *     ListConversationDatasetsResponse response =
   *         conversationDatasetsClient.listConversationDatasetsCallable().call(request);
   *     for (ConversationDataset element : response.getConversationDatasetsList()) {
   *       // doThingsWith(element);
   *     }
   *     String nextPageToken = response.getNextPageToken();
   *     if (!Strings.isNullOrEmpty(nextPageToken)) {
   *       request = request.toBuilder().setPageToken(nextPageToken).build();
   *     } else {
   *       break;
   *     }
   *   }
   * }
   * }</pre>
   */
  public final UnaryCallable<ListConversationDatasetsRequest, ListConversationDatasetsResponse>
      listConversationDatasetsCallable() {
    return stub.listConversationDatasetsCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified conversation dataset and all annotated conversation datasets that belong
   * to it.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
   * - `response`: An [Empty
   * message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ConversationDatasetName name =
   *       ConversationDatasetName.ofProjectLocationConversationDatasetName(
   *           "[PROJECT]", "[LOCATION]", "[CONVERSATION_DATASET]");
   *   conversationDatasetsClient.deleteConversationDatasetAsync(name).get();
   * }
   * }</pre>
   *
   * @param name Required. The conversation dataset to delete. Format: `projects/&lt;Project
   *     ID&gt;/conversationDatasets/&lt;Conversation Dataset ID&gt;`
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final OperationFuture<Empty, DeleteConversationDatasetOperationMetadata>
      deleteConversationDatasetAsync(ConversationDatasetName name) {
    DeleteConversationDatasetRequest request =
        DeleteConversationDatasetRequest.newBuilder()
            .setName(name == null ? null : name.toString())
            .build();
    return deleteConversationDatasetAsync(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified conversation dataset and all annotated conversation datasets that belong
   * to it.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
   * - `response`: An [Empty
   * message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   String name =
   *       ConversationDatasetName.ofProjectConversationDatasetName(
   *               "[PROJECT]", "[CONVERSATION_DATASET]")
   *           .toString();
   *   conversationDatasetsClient.deleteConversationDatasetAsync(name).get();
   * }
   * }</pre>
   *
   * @param name Required. The conversation dataset to delete. Format: `projects/&lt;Project
   *     ID&gt;/conversationDatasets/&lt;Conversation Dataset ID&gt;`
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final OperationFuture<Empty, DeleteConversationDatasetOperationMetadata>
      deleteConversationDatasetAsync(String name) {
    DeleteConversationDatasetRequest request =
        DeleteConversationDatasetRequest.newBuilder().setName(name).build();
    return deleteConversationDatasetAsync(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified conversation dataset and all annotated conversation datasets that belong
   * to it.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
   * - `response`: An [Empty
   * message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   DeleteConversationDatasetRequest request =
   *       DeleteConversationDatasetRequest.newBuilder()
   *           .setName(
   *               ConversationDatasetName.ofProjectLocationConversationDatasetName(
   *                       "[PROJECT]", "[LOCATION]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   conversationDatasetsClient.deleteConversationDatasetAsync(request).get();
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final OperationFuture<Empty, DeleteConversationDatasetOperationMetadata>
      deleteConversationDatasetAsync(DeleteConversationDatasetRequest request) {
    return deleteConversationDatasetOperationCallable().futureCall(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified conversation dataset and all annotated conversation datasets that belong
   * to it.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
   * - `response`: An [Empty
   * message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   DeleteConversationDatasetRequest request =
   *       DeleteConversationDatasetRequest.newBuilder()
   *           .setName(
   *               ConversationDatasetName.ofProjectLocationConversationDatasetName(
   *                       "[PROJECT]", "[LOCATION]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   OperationFuture<Empty, DeleteConversationDatasetOperationMetadata> future =
   *       conversationDatasetsClient
   *           .deleteConversationDatasetOperationCallable()
   *           .futureCall(request);
   *   // Do something.
   *   future.get();
   * }
   * }</pre>
   */
  public final OperationCallable<
          DeleteConversationDatasetRequest, Empty, DeleteConversationDatasetOperationMetadata>
      deleteConversationDatasetOperationCallable() {
    return stub.deleteConversationDatasetOperationCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified conversation dataset and all annotated conversation datasets that belong
   * to it.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
   * - `response`: An [Empty
   * message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   DeleteConversationDatasetRequest request =
   *       DeleteConversationDatasetRequest.newBuilder()
   *           .setName(
   *               ConversationDatasetName.ofProjectLocationConversationDatasetName(
   *                       "[PROJECT]", "[LOCATION]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   ApiFuture<Operation> future =
   *       conversationDatasetsClient.deleteConversationDatasetCallable().futureCall(request);
   *   // Do something.
   *   future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<DeleteConversationDatasetRequest, Operation>
      deleteConversationDatasetCallable() {
    return stub.deleteConversationDatasetCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Retrieves the specified annotated conversation dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   AnnotatedConversationDatasetName name =
   *       AnnotatedConversationDatasetName
   *           .ofProjectConversationDatasetAnnotatedConversationDatasetName(
   *               "[PROJECT]", "[CONVERSATION_DATASET]", "[ANNOTATED_CONVERSATION_DATASET]");
   *   AnnotatedConversationDataset response =
   *       conversationDatasetsClient.getAnnotatedConversationDataset(name);
   * }
   * }</pre>
   *
   * @param name Required. The annotated conversation dataset to retrieve. Format:
   *     `projects/&lt;Project ID&gt;/conversationDatasets/&lt;Conversation Dataset
   *     ID&gt;/annotatedConversationDatasets/&lt;Annotated Conversation Dataset ID&gt;`
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final AnnotatedConversationDataset getAnnotatedConversationDataset(
      AnnotatedConversationDatasetName name) {
    GetAnnotatedConversationDatasetRequest request =
        GetAnnotatedConversationDatasetRequest.newBuilder()
            .setName(name == null ? null : name.toString())
            .build();
    return getAnnotatedConversationDataset(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Retrieves the specified annotated conversation dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   String name =
   *       AnnotatedConversationDatasetName
   *           .ofProjectConversationDatasetAnnotatedConversationDatasetName(
   *               "[PROJECT]", "[CONVERSATION_DATASET]", "[ANNOTATED_CONVERSATION_DATASET]")
   *           .toString();
   *   AnnotatedConversationDataset response =
   *       conversationDatasetsClient.getAnnotatedConversationDataset(name);
   * }
   * }</pre>
   *
   * @param name Required. The annotated conversation dataset to retrieve. Format:
   *     `projects/&lt;Project ID&gt;/conversationDatasets/&lt;Conversation Dataset
   *     ID&gt;/annotatedConversationDatasets/&lt;Annotated Conversation Dataset ID&gt;`
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final AnnotatedConversationDataset getAnnotatedConversationDataset(String name) {
    GetAnnotatedConversationDatasetRequest request =
        GetAnnotatedConversationDatasetRequest.newBuilder().setName(name).build();
    return getAnnotatedConversationDataset(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Retrieves the specified annotated conversation dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   GetAnnotatedConversationDatasetRequest request =
   *       GetAnnotatedConversationDatasetRequest.newBuilder()
   *           .setName(
   *               AnnotatedConversationDatasetName
   *                   .ofProjectConversationDatasetAnnotatedConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]", "[ANNOTATED_CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   AnnotatedConversationDataset response =
   *       conversationDatasetsClient.getAnnotatedConversationDataset(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final AnnotatedConversationDataset getAnnotatedConversationDataset(
      GetAnnotatedConversationDatasetRequest request) {
    return getAnnotatedConversationDatasetCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Retrieves the specified annotated conversation dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   GetAnnotatedConversationDatasetRequest request =
   *       GetAnnotatedConversationDatasetRequest.newBuilder()
   *           .setName(
   *               AnnotatedConversationDatasetName
   *                   .ofProjectConversationDatasetAnnotatedConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]", "[ANNOTATED_CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   ApiFuture<AnnotatedConversationDataset> future =
   *       conversationDatasetsClient.getAnnotatedConversationDatasetCallable().futureCall(request);
   *   // Do something.
   *   AnnotatedConversationDataset response = future.get();
   * }
   * }</pre>
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final UnaryCallable<GetAnnotatedConversationDatasetRequest, AnnotatedConversationDataset>
      getAnnotatedConversationDatasetCallable() {
    return stub.getAnnotatedConversationDatasetCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns the list of all annotated conversation datasets that belong to a given conversation
   * dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListAnnotatedConversationDatasetsRequest request =
   *       ListAnnotatedConversationDatasetsRequest.newBuilder()
   *           .setParent(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   for (AnnotatedConversationDataset element :
   *       conversationDatasetsClient.listAnnotatedConversationDatasets(request).iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final ListAnnotatedConversationDatasetsPagedResponse listAnnotatedConversationDatasets(
      ListAnnotatedConversationDatasetsRequest request) {
    return listAnnotatedConversationDatasetsPagedCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns the list of all annotated conversation datasets that belong to a given conversation
   * dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListAnnotatedConversationDatasetsRequest request =
   *       ListAnnotatedConversationDatasetsRequest.newBuilder()
   *           .setParent(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   ApiFuture<AnnotatedConversationDataset> future =
   *       conversationDatasetsClient
   *           .listAnnotatedConversationDatasetsPagedCallable()
   *           .futureCall(request);
   *   // Do something.
   *   for (AnnotatedConversationDataset element : future.get().iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final UnaryCallable<
          ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsPagedResponse>
      listAnnotatedConversationDatasetsPagedCallable() {
    return stub.listAnnotatedConversationDatasetsPagedCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Returns the list of all annotated conversation datasets that belong to a given conversation
   * dataset.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListAnnotatedConversationDatasetsRequest request =
   *       ListAnnotatedConversationDatasetsRequest.newBuilder()
   *           .setParent(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   while (true) {
   *     ListAnnotatedConversationDatasetsResponse response =
   *         conversationDatasetsClient.listAnnotatedConversationDatasetsCallable().call(request);
   *     for (AnnotatedConversationDataset element :
   *         response.getAnnotatedConversationDatasetsList()) {
   *       // doThingsWith(element);
   *     }
   *     String nextPageToken = response.getNextPageToken();
   *     if (!Strings.isNullOrEmpty(nextPageToken)) {
   *       request = request.toBuilder().setPageToken(nextPageToken).build();
   *     } else {
   *       break;
   *     }
   *   }
   * }
   * }</pre>
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final UnaryCallable<
          ListAnnotatedConversationDatasetsRequest, ListAnnotatedConversationDatasetsResponse>
      listAnnotatedConversationDatasetsCallable() {
    return stub.listAnnotatedConversationDatasetsCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified annotated conversation dataset and annotations that belongs to it.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   AnnotatedConversationDatasetName name =
   *       AnnotatedConversationDatasetName
   *           .ofProjectConversationDatasetAnnotatedConversationDatasetName(
   *               "[PROJECT]", "[CONVERSATION_DATASET]", "[ANNOTATED_CONVERSATION_DATASET]");
   *   conversationDatasetsClient.deleteAnnotatedConversationDataset(name);
   * }
   * }</pre>
   *
   * @param name Required. The annotated conversation dataset to delete. Format:
   *     `projects/&lt;Project ID&gt;/conversationDatasets/&lt;Conversation Dataset
   *     ID&gt;/annotatedConversationDatasets/&lt;Annotated Conversation Dataset ID&gt;`
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final void deleteAnnotatedConversationDataset(AnnotatedConversationDatasetName name) {
    DeleteAnnotatedConversationDatasetRequest request =
        DeleteAnnotatedConversationDatasetRequest.newBuilder()
            .setName(name == null ? null : name.toString())
            .build();
    deleteAnnotatedConversationDataset(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified annotated conversation dataset and annotations that belongs to it.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   String name =
   *       AnnotatedConversationDatasetName
   *           .ofProjectConversationDatasetAnnotatedConversationDatasetName(
   *               "[PROJECT]", "[CONVERSATION_DATASET]", "[ANNOTATED_CONVERSATION_DATASET]")
   *           .toString();
   *   conversationDatasetsClient.deleteAnnotatedConversationDataset(name);
   * }
   * }</pre>
   *
   * @param name Required. The annotated conversation dataset to delete. Format:
   *     `projects/&lt;Project ID&gt;/conversationDatasets/&lt;Conversation Dataset
   *     ID&gt;/annotatedConversationDatasets/&lt;Annotated Conversation Dataset ID&gt;`
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final void deleteAnnotatedConversationDataset(String name) {
    DeleteAnnotatedConversationDatasetRequest request =
        DeleteAnnotatedConversationDatasetRequest.newBuilder().setName(name).build();
    deleteAnnotatedConversationDataset(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified annotated conversation dataset and annotations that belongs to it.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   DeleteAnnotatedConversationDatasetRequest request =
   *       DeleteAnnotatedConversationDatasetRequest.newBuilder()
   *           .setName(
   *               AnnotatedConversationDatasetName
   *                   .ofProjectConversationDatasetAnnotatedConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]", "[ANNOTATED_CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   conversationDatasetsClient.deleteAnnotatedConversationDataset(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final void deleteAnnotatedConversationDataset(
      DeleteAnnotatedConversationDatasetRequest request) {
    deleteAnnotatedConversationDatasetCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Deletes the specified annotated conversation dataset and annotations that belongs to it.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   DeleteAnnotatedConversationDatasetRequest request =
   *       DeleteAnnotatedConversationDatasetRequest.newBuilder()
   *           .setName(
   *               AnnotatedConversationDatasetName
   *                   .ofProjectConversationDatasetAnnotatedConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]", "[ANNOTATED_CONVERSATION_DATASET]")
   *                   .toString())
   *           .build();
   *   ApiFuture<Empty> future =
   *       conversationDatasetsClient
   *           .deleteAnnotatedConversationDatasetCallable()
   *           .futureCall(request);
   *   // Do something.
   *   future.get();
   * }
   * }</pre>
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final UnaryCallable<DeleteAnnotatedConversationDatasetRequest, Empty>
      deleteAnnotatedConversationDatasetCallable() {
    return stub.deleteAnnotatedConversationDatasetCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Import data into the specified conversation dataset. Note that it is not allowed to import data
   * to a conversation dataset that already has data in it.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
   * - `response`:
   * [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ImportConversationDataRequest request =
   *       ImportConversationDataRequest.newBuilder()
   *           .setName(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setInputConfig(InputConfig.newBuilder().build())
   *           .setConversationInfo(ConversationInfo.newBuilder().build())
   *           .build();
   *   ImportConversationDataOperationResponse response =
   *       conversationDatasetsClient.importConversationDataAsync(request).get();
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final OperationFuture<
          ImportConversationDataOperationResponse, ImportConversationDataOperationMetadata>
      importConversationDataAsync(ImportConversationDataRequest request) {
    return importConversationDataOperationCallable().futureCall(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Import data into the specified conversation dataset. Note that it is not allowed to import data
   * to a conversation dataset that already has data in it.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
   * - `response`:
   * [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ImportConversationDataRequest request =
   *       ImportConversationDataRequest.newBuilder()
   *           .setName(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setInputConfig(InputConfig.newBuilder().build())
   *           .setConversationInfo(ConversationInfo.newBuilder().build())
   *           .build();
   *   OperationFuture<
   *           ImportConversationDataOperationResponse, ImportConversationDataOperationMetadata>
   *       future =
   *           conversationDatasetsClient
   *               .importConversationDataOperationCallable()
   *               .futureCall(request);
   *   // Do something.
   *   ImportConversationDataOperationResponse response = future.get();
   * }
   * }</pre>
   */
  public final OperationCallable<
          ImportConversationDataRequest,
          ImportConversationDataOperationResponse,
          ImportConversationDataOperationMetadata>
      importConversationDataOperationCallable() {
    return stub.importConversationDataOperationCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Import data into the specified conversation dataset. Note that it is not allowed to import data
   * to a conversation dataset that already has data in it.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
   * - `response`:
   * [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ImportConversationDataRequest request =
   *       ImportConversationDataRequest.newBuilder()
   *           .setName(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setInputConfig(InputConfig.newBuilder().build())
   *           .setConversationInfo(ConversationInfo.newBuilder().build())
   *           .build();
   *   ApiFuture<Operation> future =
   *       conversationDatasetsClient.importConversationDataCallable().futureCall(request);
   *   // Do something.
   *   Operation response = future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<ImportConversationDataRequest, Operation>
      importConversationDataCallable() {
    return stub.importConversationDataCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * [DEPRECATED]. Creates and starts a conversation dataset annotation task.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
   * - `response`:
   * [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   LabelConversationRequest request =
   *       LabelConversationRequest.newBuilder()
   *           .setParent(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setAnnotationTaskConfig(AnnotationTaskConfig.newBuilder().build())
   *           .build();
   *   LabelConversationResponse response =
   *       conversationDatasetsClient.labelConversationAsync(request).get();
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final OperationFuture<LabelConversationResponse, LabelConversationOperationMetadata>
      labelConversationAsync(LabelConversationRequest request) {
    return labelConversationOperationCallable().futureCall(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * [DEPRECATED]. Creates and starts a conversation dataset annotation task.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
   * - `response`:
   * [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   LabelConversationRequest request =
   *       LabelConversationRequest.newBuilder()
   *           .setParent(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setAnnotationTaskConfig(AnnotationTaskConfig.newBuilder().build())
   *           .build();
   *   OperationFuture<LabelConversationResponse, LabelConversationOperationMetadata> future =
   *       conversationDatasetsClient.labelConversationOperationCallable().futureCall(request);
   *   // Do something.
   *   LabelConversationResponse response = future.get();
   * }
   * }</pre>
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final OperationCallable<
          LabelConversationRequest, LabelConversationResponse, LabelConversationOperationMetadata>
      labelConversationOperationCallable() {
    return stub.labelConversationOperationCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * [DEPRECATED]. Creates and starts a conversation dataset annotation task.
   *
   * <p>This method is a [long-running
   * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations). The
   * returned `Operation` type has the following method-specific fields:
   *
   * <p>- `metadata`:
   * [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
   * - `response`:
   * [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   LabelConversationRequest request =
   *       LabelConversationRequest.newBuilder()
   *           .setParent(
   *               ConversationDatasetName.ofProjectConversationDatasetName(
   *                       "[PROJECT]", "[CONVERSATION_DATASET]")
   *                   .toString())
   *           .setAnnotationTaskConfig(AnnotationTaskConfig.newBuilder().build())
   *           .build();
   *   ApiFuture<Operation> future =
   *       conversationDatasetsClient.labelConversationCallable().futureCall(request);
   *   // Do something.
   *   Operation response = future.get();
   * }
   * }</pre>
   *
   * @deprecated This method is deprecated and will be removed in the next major version update.
   */
  @Deprecated
  public final UnaryCallable<LabelConversationRequest, Operation> labelConversationCallable() {
    return stub.labelConversationCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists information about the supported locations for this service.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListLocationsRequest request =
   *       ListLocationsRequest.newBuilder()
   *           .setName("name3373707")
   *           .setFilter("filter-1274492040")
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   for (Location element : conversationDatasetsClient.listLocations(request).iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final ListLocationsPagedResponse listLocations(ListLocationsRequest request) {
    return listLocationsPagedCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists information about the supported locations for this service.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListLocationsRequest request =
   *       ListLocationsRequest.newBuilder()
   *           .setName("name3373707")
   *           .setFilter("filter-1274492040")
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   ApiFuture<Location> future =
   *       conversationDatasetsClient.listLocationsPagedCallable().futureCall(request);
   *   // Do something.
   *   for (Location element : future.get().iterateAll()) {
   *     // doThingsWith(element);
   *   }
   * }
   * }</pre>
   */
  public final UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    return stub.listLocationsPagedCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Lists information about the supported locations for this service.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   ListLocationsRequest request =
   *       ListLocationsRequest.newBuilder()
   *           .setName("name3373707")
   *           .setFilter("filter-1274492040")
   *           .setPageSize(883849137)
   *           .setPageToken("pageToken873572522")
   *           .build();
   *   while (true) {
   *     ListLocationsResponse response =
   *         conversationDatasetsClient.listLocationsCallable().call(request);
   *     for (Location element : response.getLocationsList()) {
   *       // doThingsWith(element);
   *     }
   *     String nextPageToken = response.getNextPageToken();
   *     if (!Strings.isNullOrEmpty(nextPageToken)) {
   *       request = request.toBuilder().setPageToken(nextPageToken).build();
   *     } else {
   *       break;
   *     }
   *   }
   * }
   * }</pre>
   */
  public final UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    return stub.listLocationsCallable();
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Gets information about a location.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   GetLocationRequest request = GetLocationRequest.newBuilder().setName("name3373707").build();
   *   Location response = conversationDatasetsClient.getLocation(request);
   * }
   * }</pre>
   *
   * @param request The request object containing all of the parameters for the API call.
   * @throws com.google.api.gax.rpc.ApiException if the remote call fails
   */
  public final Location getLocation(GetLocationRequest request) {
    return getLocationCallable().call(request);
  }

  // AUTO-GENERATED DOCUMENTATION AND METHOD.
  /**
   * Gets information about a location.
   *
   * <p>Sample code:
   *
   * <pre>{@code
   * // This snippet has been automatically generated and should be regarded as a code template only.
   * // It will require modifications to work:
   * // - It may require correct/in-range values for request initialization.
   * // - It may require specifying regional endpoints when creating the service client as shown in
   * // https://cloud.google.com/java/docs/setup#configure_endpoints_for_the_client_library
   * try (ConversationDatasetsClient conversationDatasetsClient =
   *     ConversationDatasetsClient.create()) {
   *   GetLocationRequest request = GetLocationRequest.newBuilder().setName("name3373707").build();
   *   ApiFuture<Location> future =
   *       conversationDatasetsClient.getLocationCallable().futureCall(request);
   *   // Do something.
   *   Location response = future.get();
   * }
   * }</pre>
   */
  public final UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    return stub.getLocationCallable();
  }

  @Override
  public final void close() {
    stub.close();
  }

  @Override
  public void shutdown() {
    stub.shutdown();
  }

  @Override
  public boolean isShutdown() {
    return stub.isShutdown();
  }

  @Override
  public boolean isTerminated() {
    return stub.isTerminated();
  }

  @Override
  public void shutdownNow() {
    stub.shutdownNow();
  }

  @Override
  public boolean awaitTermination(long duration, TimeUnit unit) throws InterruptedException {
    return stub.awaitTermination(duration, unit);
  }

  public static class ListConversationDatasetsPagedResponse
      extends AbstractPagedListResponse<
          ListConversationDatasetsRequest,
          ListConversationDatasetsResponse,
          ConversationDataset,
          ListConversationDatasetsPage,
          ListConversationDatasetsFixedSizeCollection> {

    public static ApiFuture<ListConversationDatasetsPagedResponse> createAsync(
        PageContext<
                ListConversationDatasetsRequest,
                ListConversationDatasetsResponse,
                ConversationDataset>
            context,
        ApiFuture<ListConversationDatasetsResponse> futureResponse) {
      ApiFuture<ListConversationDatasetsPage> futurePage =
          ListConversationDatasetsPage.createEmptyPage().createPageAsync(context, futureResponse);
      return ApiFutures.transform(
          futurePage,
          input -> new ListConversationDatasetsPagedResponse(input),
          MoreExecutors.directExecutor());
    }

    private ListConversationDatasetsPagedResponse(ListConversationDatasetsPage page) {
      super(page, ListConversationDatasetsFixedSizeCollection.createEmptyCollection());
    }
  }

  public static class ListConversationDatasetsPage
      extends AbstractPage<
          ListConversationDatasetsRequest,
          ListConversationDatasetsResponse,
          ConversationDataset,
          ListConversationDatasetsPage> {

    private ListConversationDatasetsPage(
        PageContext<
                ListConversationDatasetsRequest,
                ListConversationDatasetsResponse,
                ConversationDataset>
            context,
        ListConversationDatasetsResponse response) {
      super(context, response);
    }

    private static ListConversationDatasetsPage createEmptyPage() {
      return new ListConversationDatasetsPage(null, null);
    }

    @Override
    protected ListConversationDatasetsPage createPage(
        PageContext<
                ListConversationDatasetsRequest,
                ListConversationDatasetsResponse,
                ConversationDataset>
            context,
        ListConversationDatasetsResponse response) {
      return new ListConversationDatasetsPage(context, response);
    }

    @Override
    public ApiFuture<ListConversationDatasetsPage> createPageAsync(
        PageContext<
                ListConversationDatasetsRequest,
                ListConversationDatasetsResponse,
                ConversationDataset>
            context,
        ApiFuture<ListConversationDatasetsResponse> futureResponse) {
      return super.createPageAsync(context, futureResponse);
    }
  }

  public static class ListConversationDatasetsFixedSizeCollection
      extends AbstractFixedSizeCollection<
          ListConversationDatasetsRequest,
          ListConversationDatasetsResponse,
          ConversationDataset,
          ListConversationDatasetsPage,
          ListConversationDatasetsFixedSizeCollection> {

    private ListConversationDatasetsFixedSizeCollection(
        List<ListConversationDatasetsPage> pages, int collectionSize) {
      super(pages, collectionSize);
    }

    private static ListConversationDatasetsFixedSizeCollection createEmptyCollection() {
      return new ListConversationDatasetsFixedSizeCollection(null, 0);
    }

    @Override
    protected ListConversationDatasetsFixedSizeCollection createCollection(
        List<ListConversationDatasetsPage> pages, int collectionSize) {
      return new ListConversationDatasetsFixedSizeCollection(pages, collectionSize);
    }
  }

  public static class ListAnnotatedConversationDatasetsPagedResponse
      extends AbstractPagedListResponse<
          ListAnnotatedConversationDatasetsRequest,
          ListAnnotatedConversationDatasetsResponse,
          AnnotatedConversationDataset,
          ListAnnotatedConversationDatasetsPage,
          ListAnnotatedConversationDatasetsFixedSizeCollection> {

    public static ApiFuture<ListAnnotatedConversationDatasetsPagedResponse> createAsync(
        PageContext<
                ListAnnotatedConversationDatasetsRequest,
                ListAnnotatedConversationDatasetsResponse,
                AnnotatedConversationDataset>
            context,
        ApiFuture<ListAnnotatedConversationDatasetsResponse> futureResponse) {
      ApiFuture<ListAnnotatedConversationDatasetsPage> futurePage =
          ListAnnotatedConversationDatasetsPage.createEmptyPage()
              .createPageAsync(context, futureResponse);
      return ApiFutures.transform(
          futurePage,
          input -> new ListAnnotatedConversationDatasetsPagedResponse(input),
          MoreExecutors.directExecutor());
    }

    private ListAnnotatedConversationDatasetsPagedResponse(
        ListAnnotatedConversationDatasetsPage page) {
      super(page, ListAnnotatedConversationDatasetsFixedSizeCollection.createEmptyCollection());
    }
  }

  public static class ListAnnotatedConversationDatasetsPage
      extends AbstractPage<
          ListAnnotatedConversationDatasetsRequest,
          ListAnnotatedConversationDatasetsResponse,
          AnnotatedConversationDataset,
          ListAnnotatedConversationDatasetsPage> {

    private ListAnnotatedConversationDatasetsPage(
        PageContext<
                ListAnnotatedConversationDatasetsRequest,
                ListAnnotatedConversationDatasetsResponse,
                AnnotatedConversationDataset>
            context,
        ListAnnotatedConversationDatasetsResponse response) {
      super(context, response);
    }

    private static ListAnnotatedConversationDatasetsPage createEmptyPage() {
      return new ListAnnotatedConversationDatasetsPage(null, null);
    }

    @Override
    protected ListAnnotatedConversationDatasetsPage createPage(
        PageContext<
                ListAnnotatedConversationDatasetsRequest,
                ListAnnotatedConversationDatasetsResponse,
                AnnotatedConversationDataset>
            context,
        ListAnnotatedConversationDatasetsResponse response) {
      return new ListAnnotatedConversationDatasetsPage(context, response);
    }

    @Override
    public ApiFuture<ListAnnotatedConversationDatasetsPage> createPageAsync(
        PageContext<
                ListAnnotatedConversationDatasetsRequest,
                ListAnnotatedConversationDatasetsResponse,
                AnnotatedConversationDataset>
            context,
        ApiFuture<ListAnnotatedConversationDatasetsResponse> futureResponse) {
      return super.createPageAsync(context, futureResponse);
    }
  }

  public static class ListAnnotatedConversationDatasetsFixedSizeCollection
      extends AbstractFixedSizeCollection<
          ListAnnotatedConversationDatasetsRequest,
          ListAnnotatedConversationDatasetsResponse,
          AnnotatedConversationDataset,
          ListAnnotatedConversationDatasetsPage,
          ListAnnotatedConversationDatasetsFixedSizeCollection> {

    private ListAnnotatedConversationDatasetsFixedSizeCollection(
        List<ListAnnotatedConversationDatasetsPage> pages, int collectionSize) {
      super(pages, collectionSize);
    }

    private static ListAnnotatedConversationDatasetsFixedSizeCollection createEmptyCollection() {
      return new ListAnnotatedConversationDatasetsFixedSizeCollection(null, 0);
    }

    @Override
    protected ListAnnotatedConversationDatasetsFixedSizeCollection createCollection(
        List<ListAnnotatedConversationDatasetsPage> pages, int collectionSize) {
      return new ListAnnotatedConversationDatasetsFixedSizeCollection(pages, collectionSize);
    }
  }

  public static class ListLocationsPagedResponse
      extends AbstractPagedListResponse<
          ListLocationsRequest,
          ListLocationsResponse,
          Location,
          ListLocationsPage,
          ListLocationsFixedSizeCollection> {

    public static ApiFuture<ListLocationsPagedResponse> createAsync(
        PageContext<ListLocationsRequest, ListLocationsResponse, Location> context,
        ApiFuture<ListLocationsResponse> futureResponse) {
      ApiFuture<ListLocationsPage> futurePage =
          ListLocationsPage.createEmptyPage().createPageAsync(context, futureResponse);
      return ApiFutures.transform(
          futurePage,
          input -> new ListLocationsPagedResponse(input),
          MoreExecutors.directExecutor());
    }

    private ListLocationsPagedResponse(ListLocationsPage page) {
      super(page, ListLocationsFixedSizeCollection.createEmptyCollection());
    }
  }

  public static class ListLocationsPage
      extends AbstractPage<
          ListLocationsRequest, ListLocationsResponse, Location, ListLocationsPage> {

    private ListLocationsPage(
        PageContext<ListLocationsRequest, ListLocationsResponse, Location> context,
        ListLocationsResponse response) {
      super(context, response);
    }

    private static ListLocationsPage createEmptyPage() {
      return new ListLocationsPage(null, null);
    }

    @Override
    protected ListLocationsPage createPage(
        PageContext<ListLocationsRequest, ListLocationsResponse, Location> context,
        ListLocationsResponse response) {
      return new ListLocationsPage(context, response);
    }

    @Override
    public ApiFuture<ListLocationsPage> createPageAsync(
        PageContext<ListLocationsRequest, ListLocationsResponse, Location> context,
        ApiFuture<ListLocationsResponse> futureResponse) {
      return super.createPageAsync(context, futureResponse);
    }
  }

  public static class ListLocationsFixedSizeCollection
      extends AbstractFixedSizeCollection<
          ListLocationsRequest,
          ListLocationsResponse,
          Location,
          ListLocationsPage,
          ListLocationsFixedSizeCollection> {

    private ListLocationsFixedSizeCollection(List<ListLocationsPage> pages, int collectionSize) {
      super(pages, collectionSize);
    }

    private static ListLocationsFixedSizeCollection createEmptyCollection() {
      return new ListLocationsFixedSizeCollection(null, 0);
    }

    @Override
    protected ListLocationsFixedSizeCollection createCollection(
        List<ListLocationsPage> pages, int collectionSize) {
      return new ListLocationsFixedSizeCollection(pages, collectionSize);
    }
  }
}
