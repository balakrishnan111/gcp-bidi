/*
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.google.cloud.dialogflow.v2beta1.stub;

import static com.google.cloud.dialogflow.v2beta1.PhoneNumberOrdersClient.ListLocationsPagedResponse;
import static com.google.cloud.dialogflow.v2beta1.PhoneNumberOrdersClient.ListPhoneNumberOrdersPagedResponse;

import com.google.api.core.BetaApi;
import com.google.api.gax.core.BackgroundResource;
import com.google.api.gax.rpc.UnaryCallable;
import com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest;
import com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest;
import com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest;
import com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest;
import com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse;
import com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder;
import com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest;
import com.google.cloud.location.GetLocationRequest;
import com.google.cloud.location.ListLocationsRequest;
import com.google.cloud.location.ListLocationsResponse;
import com.google.cloud.location.Location;
import com.google.protobuf.Empty;
import javax.annotation.Generated;

// AUTO-GENERATED DOCUMENTATION AND CLASS.
/**
 * Base stub class for the PhoneNumberOrders service API.
 *
 * <p>This class is for advanced usage and reflects the underlying API directly.
 */
@BetaApi
@Generated("by gapic-generator-java")
public abstract class PhoneNumberOrdersStub implements BackgroundResource {

  public UnaryCallable<CreatePhoneNumberOrderRequest, PhoneNumberOrder>
      createPhoneNumberOrderCallable() {
    throw new UnsupportedOperationException("Not implemented: createPhoneNumberOrderCallable()");
  }

  public UnaryCallable<GetPhoneNumberOrderRequest, PhoneNumberOrder> getPhoneNumberOrderCallable() {
    throw new UnsupportedOperationException("Not implemented: getPhoneNumberOrderCallable()");
  }

  public UnaryCallable<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersPagedResponse>
      listPhoneNumberOrdersPagedCallable() {
    throw new UnsupportedOperationException(
        "Not implemented: listPhoneNumberOrdersPagedCallable()");
  }

  public UnaryCallable<ListPhoneNumberOrdersRequest, ListPhoneNumberOrdersResponse>
      listPhoneNumberOrdersCallable() {
    throw new UnsupportedOperationException("Not implemented: listPhoneNumberOrdersCallable()");
  }

  public UnaryCallable<UpdatePhoneNumberOrderRequest, PhoneNumberOrder>
      updatePhoneNumberOrderCallable() {
    throw new UnsupportedOperationException("Not implemented: updatePhoneNumberOrderCallable()");
  }

  public UnaryCallable<CancelPhoneNumberOrderRequest, Empty> cancelPhoneNumberOrderCallable() {
    throw new UnsupportedOperationException("Not implemented: cancelPhoneNumberOrderCallable()");
  }

  public UnaryCallable<ListLocationsRequest, ListLocationsPagedResponse>
      listLocationsPagedCallable() {
    throw new UnsupportedOperationException("Not implemented: listLocationsPagedCallable()");
  }

  public UnaryCallable<ListLocationsRequest, ListLocationsResponse> listLocationsCallable() {
    throw new UnsupportedOperationException("Not implemented: listLocationsCallable()");
  }

  public UnaryCallable<GetLocationRequest, Location> getLocationCallable() {
    throw new UnsupportedOperationException("Not implemented: getLocationCallable()");
  }

  @Override
  public abstract void close();
}
