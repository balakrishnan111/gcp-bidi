package com.google.cloud.dialogflow.v2beta1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Deprecated: use configs in
 * [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
 * of [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
 * Removal Date: 2020-09-01. From 2020-06-08, we will disable
 * [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
 * After 2020-09-01, all configuration will be migrated into
 * [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
 * automatically.
 * Manages a collection of human agent assistants.
 * A human agent assistant provides prompts and information to a live, human
 * agent to use with end users. Each human agent participating in a conversation
 * can use a different human agent assistant.
 * The life cycle of human agent assistant resources is independent of the
 * lifecycle of conversations.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler",
    comments = "Source: google/cloud/dialogflow/v2beta1/human_agent_assistant.proto")
@io.grpc.stub.annotations.GrpcGenerated
@java.lang.Deprecated
public final class HumanAgentAssistantsGrpc {

  private HumanAgentAssistantsGrpc() {}

  public static final java.lang.String SERVICE_NAME = "google.cloud.dialogflow.v2beta1.HumanAgentAssistants";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest,
      com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse> getListHumanAgentAssistantsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListHumanAgentAssistants",
      requestType = com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest,
      com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse> getListHumanAgentAssistantsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest, com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse> getListHumanAgentAssistantsMethod;
    if ((getListHumanAgentAssistantsMethod = HumanAgentAssistantsGrpc.getListHumanAgentAssistantsMethod) == null) {
      synchronized (HumanAgentAssistantsGrpc.class) {
        if ((getListHumanAgentAssistantsMethod = HumanAgentAssistantsGrpc.getListHumanAgentAssistantsMethod) == null) {
          HumanAgentAssistantsGrpc.getListHumanAgentAssistantsMethod = getListHumanAgentAssistantsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest, com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListHumanAgentAssistants"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new HumanAgentAssistantsMethodDescriptorSupplier("ListHumanAgentAssistants"))
              .build();
        }
      }
    }
    return getListHumanAgentAssistantsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest,
      com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getGetHumanAgentAssistantMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetHumanAgentAssistant",
      requestType = com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest,
      com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getGetHumanAgentAssistantMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest, com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getGetHumanAgentAssistantMethod;
    if ((getGetHumanAgentAssistantMethod = HumanAgentAssistantsGrpc.getGetHumanAgentAssistantMethod) == null) {
      synchronized (HumanAgentAssistantsGrpc.class) {
        if ((getGetHumanAgentAssistantMethod = HumanAgentAssistantsGrpc.getGetHumanAgentAssistantMethod) == null) {
          HumanAgentAssistantsGrpc.getGetHumanAgentAssistantMethod = getGetHumanAgentAssistantMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest, com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetHumanAgentAssistant"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant.getDefaultInstance()))
              .setSchemaDescriptor(new HumanAgentAssistantsMethodDescriptorSupplier("GetHumanAgentAssistant"))
              .build();
        }
      }
    }
    return getGetHumanAgentAssistantMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest,
      com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getCreateHumanAgentAssistantMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateHumanAgentAssistant",
      requestType = com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest,
      com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getCreateHumanAgentAssistantMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest, com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getCreateHumanAgentAssistantMethod;
    if ((getCreateHumanAgentAssistantMethod = HumanAgentAssistantsGrpc.getCreateHumanAgentAssistantMethod) == null) {
      synchronized (HumanAgentAssistantsGrpc.class) {
        if ((getCreateHumanAgentAssistantMethod = HumanAgentAssistantsGrpc.getCreateHumanAgentAssistantMethod) == null) {
          HumanAgentAssistantsGrpc.getCreateHumanAgentAssistantMethod = getCreateHumanAgentAssistantMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest, com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateHumanAgentAssistant"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant.getDefaultInstance()))
              .setSchemaDescriptor(new HumanAgentAssistantsMethodDescriptorSupplier("CreateHumanAgentAssistant"))
              .build();
        }
      }
    }
    return getCreateHumanAgentAssistantMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest,
      com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getUpdateHumanAgentAssistantMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateHumanAgentAssistant",
      requestType = com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest,
      com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getUpdateHumanAgentAssistantMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest, com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getUpdateHumanAgentAssistantMethod;
    if ((getUpdateHumanAgentAssistantMethod = HumanAgentAssistantsGrpc.getUpdateHumanAgentAssistantMethod) == null) {
      synchronized (HumanAgentAssistantsGrpc.class) {
        if ((getUpdateHumanAgentAssistantMethod = HumanAgentAssistantsGrpc.getUpdateHumanAgentAssistantMethod) == null) {
          HumanAgentAssistantsGrpc.getUpdateHumanAgentAssistantMethod = getUpdateHumanAgentAssistantMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest, com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateHumanAgentAssistant"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant.getDefaultInstance()))
              .setSchemaDescriptor(new HumanAgentAssistantsMethodDescriptorSupplier("UpdateHumanAgentAssistant"))
              .build();
        }
      }
    }
    return getUpdateHumanAgentAssistantMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest,
      com.google.protobuf.Empty> getDeleteHumanAgentAssistantMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteHumanAgentAssistant",
      requestType = com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest,
      com.google.protobuf.Empty> getDeleteHumanAgentAssistantMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest, com.google.protobuf.Empty> getDeleteHumanAgentAssistantMethod;
    if ((getDeleteHumanAgentAssistantMethod = HumanAgentAssistantsGrpc.getDeleteHumanAgentAssistantMethod) == null) {
      synchronized (HumanAgentAssistantsGrpc.class) {
        if ((getDeleteHumanAgentAssistantMethod = HumanAgentAssistantsGrpc.getDeleteHumanAgentAssistantMethod) == null) {
          HumanAgentAssistantsGrpc.getDeleteHumanAgentAssistantMethod = getDeleteHumanAgentAssistantMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteHumanAgentAssistant"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new HumanAgentAssistantsMethodDescriptorSupplier("DeleteHumanAgentAssistant"))
              .build();
        }
      }
    }
    return getDeleteHumanAgentAssistantMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest,
      com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse> getCompileSuggestionsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CompileSuggestions",
      requestType = com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest,
      com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse> getCompileSuggestionsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest, com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse> getCompileSuggestionsMethod;
    if ((getCompileSuggestionsMethod = HumanAgentAssistantsGrpc.getCompileSuggestionsMethod) == null) {
      synchronized (HumanAgentAssistantsGrpc.class) {
        if ((getCompileSuggestionsMethod = HumanAgentAssistantsGrpc.getCompileSuggestionsMethod) == null) {
          HumanAgentAssistantsGrpc.getCompileSuggestionsMethod = getCompileSuggestionsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest, com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CompileSuggestions"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new HumanAgentAssistantsMethodDescriptorSupplier("CompileSuggestions"))
              .build();
        }
      }
    }
    return getCompileSuggestionsMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static HumanAgentAssistantsStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<HumanAgentAssistantsStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<HumanAgentAssistantsStub>() {
        @java.lang.Override
        public HumanAgentAssistantsStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new HumanAgentAssistantsStub(channel, callOptions);
        }
      };
    return HumanAgentAssistantsStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static HumanAgentAssistantsBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<HumanAgentAssistantsBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<HumanAgentAssistantsBlockingV2Stub>() {
        @java.lang.Override
        public HumanAgentAssistantsBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new HumanAgentAssistantsBlockingV2Stub(channel, callOptions);
        }
      };
    return HumanAgentAssistantsBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static HumanAgentAssistantsBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<HumanAgentAssistantsBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<HumanAgentAssistantsBlockingStub>() {
        @java.lang.Override
        public HumanAgentAssistantsBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new HumanAgentAssistantsBlockingStub(channel, callOptions);
        }
      };
    return HumanAgentAssistantsBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static HumanAgentAssistantsFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<HumanAgentAssistantsFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<HumanAgentAssistantsFutureStub>() {
        @java.lang.Override
        public HumanAgentAssistantsFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new HumanAgentAssistantsFutureStub(channel, callOptions);
        }
      };
    return HumanAgentAssistantsFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Deprecated: use configs in
   * [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
   * of [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * Removal Date: 2020-09-01. From 2020-06-08, we will disable
   * [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
   * After 2020-09-01, all configuration will be migrated into
   * [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * automatically.
   * Manages a collection of human agent assistants.
   * A human agent assistant provides prompts and information to a live, human
   * agent to use with end users. Each human agent participating in a conversation
   * can use a different human agent assistant.
   * The life cycle of human agent assistant resources is independent of the
   * lifecycle of conversations.
   * </pre>
   */
  @java.lang.Deprecated
  public interface AsyncService {

    /**
     * <pre>
     * Returns the list of all human agent assistants.
     * </pre>
     */
    @java.lang.Deprecated
    default void listHumanAgentAssistants(com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListHumanAgentAssistantsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Retrieves a human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    default void getHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetHumanAgentAssistantMethod(), responseObserver);
    }

    /**
     * <pre>
     * Creates a human agent assistant.
     * Deprecated. Use
     * [ConversationProfiles.CreateConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfiles.CreateConversationProfile]
     * instead.
     * Starting 2020-06-08, this method will always return INVALID_ARGUMENT. If
     * you need to continue using this method, you can set
     * [CreateHumanAgentAssistantRequest.bypass_deprecation][google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest.bypass_deprecation]
     * to true. The bypass flag will be removed after 2020-09-01, so you will need
     * to stop using this method by that date.
     * .
     * </pre>
     */
    @java.lang.Deprecated
    default void createHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateHumanAgentAssistantMethod(), responseObserver);
    }

    /**
     * <pre>
     * Updates the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    default void updateHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateHumanAgentAssistantMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    default void deleteHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteHumanAgentAssistantMethod(), responseObserver);
    }

    /**
     * <pre>
     * Uses the specified human agent assistant to come up with suggestions
     * (relevant articles and FAQs) on how to respond to a given conversation.
     * </pre>
     */
    @java.lang.Deprecated
    default void compileSuggestions(com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCompileSuggestionsMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service HumanAgentAssistants.
   * <pre>
   * Deprecated: use configs in
   * [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
   * of [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * Removal Date: 2020-09-01. From 2020-06-08, we will disable
   * [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
   * After 2020-09-01, all configuration will be migrated into
   * [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * automatically.
   * Manages a collection of human agent assistants.
   * A human agent assistant provides prompts and information to a live, human
   * agent to use with end users. Each human agent participating in a conversation
   * can use a different human agent assistant.
   * The life cycle of human agent assistant resources is independent of the
   * lifecycle of conversations.
   * </pre>
   */
  @java.lang.Deprecated
  public static abstract class HumanAgentAssistantsImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return HumanAgentAssistantsGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service HumanAgentAssistants.
   * <pre>
   * Deprecated: use configs in
   * [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
   * of [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * Removal Date: 2020-09-01. From 2020-06-08, we will disable
   * [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
   * After 2020-09-01, all configuration will be migrated into
   * [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * automatically.
   * Manages a collection of human agent assistants.
   * A human agent assistant provides prompts and information to a live, human
   * agent to use with end users. Each human agent participating in a conversation
   * can use a different human agent assistant.
   * The life cycle of human agent assistant resources is independent of the
   * lifecycle of conversations.
   * </pre>
   */
  @java.lang.Deprecated
  public static final class HumanAgentAssistantsStub
      extends io.grpc.stub.AbstractAsyncStub<HumanAgentAssistantsStub> {
    private HumanAgentAssistantsStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected HumanAgentAssistantsStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new HumanAgentAssistantsStub(channel, callOptions);
    }

    /**
     * <pre>
     * Returns the list of all human agent assistants.
     * </pre>
     */
    @java.lang.Deprecated
    public void listHumanAgentAssistants(com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListHumanAgentAssistantsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Retrieves a human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public void getHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetHumanAgentAssistantMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Creates a human agent assistant.
     * Deprecated. Use
     * [ConversationProfiles.CreateConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfiles.CreateConversationProfile]
     * instead.
     * Starting 2020-06-08, this method will always return INVALID_ARGUMENT. If
     * you need to continue using this method, you can set
     * [CreateHumanAgentAssistantRequest.bypass_deprecation][google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest.bypass_deprecation]
     * to true. The bypass flag will be removed after 2020-09-01, so you will need
     * to stop using this method by that date.
     * .
     * </pre>
     */
    @java.lang.Deprecated
    public void createHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateHumanAgentAssistantMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Updates the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public void updateHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateHumanAgentAssistantMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public void deleteHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteHumanAgentAssistantMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Uses the specified human agent assistant to come up with suggestions
     * (relevant articles and FAQs) on how to respond to a given conversation.
     * </pre>
     */
    @java.lang.Deprecated
    public void compileSuggestions(com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCompileSuggestionsMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service HumanAgentAssistants.
   * <pre>
   * Deprecated: use configs in
   * [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
   * of [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * Removal Date: 2020-09-01. From 2020-06-08, we will disable
   * [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
   * After 2020-09-01, all configuration will be migrated into
   * [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * automatically.
   * Manages a collection of human agent assistants.
   * A human agent assistant provides prompts and information to a live, human
   * agent to use with end users. Each human agent participating in a conversation
   * can use a different human agent assistant.
   * The life cycle of human agent assistant resources is independent of the
   * lifecycle of conversations.
   * </pre>
   */
  @java.lang.Deprecated
  public static final class HumanAgentAssistantsBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<HumanAgentAssistantsBlockingV2Stub> {
    private HumanAgentAssistantsBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected HumanAgentAssistantsBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new HumanAgentAssistantsBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Returns the list of all human agent assistants.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse listHumanAgentAssistants(com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListHumanAgentAssistantsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves a human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant getHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetHumanAgentAssistantMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates a human agent assistant.
     * Deprecated. Use
     * [ConversationProfiles.CreateConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfiles.CreateConversationProfile]
     * instead.
     * Starting 2020-06-08, this method will always return INVALID_ARGUMENT. If
     * you need to continue using this method, you can set
     * [CreateHumanAgentAssistantRequest.bypass_deprecation][google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest.bypass_deprecation]
     * to true. The bypass flag will be removed after 2020-09-01, so you will need
     * to stop using this method by that date.
     * .
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant createHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateHumanAgentAssistantMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant updateHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateHumanAgentAssistantMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.protobuf.Empty deleteHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteHumanAgentAssistantMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Uses the specified human agent assistant to come up with suggestions
     * (relevant articles and FAQs) on how to respond to a given conversation.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse compileSuggestions(com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCompileSuggestionsMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service HumanAgentAssistants.
   * <pre>
   * Deprecated: use configs in
   * [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
   * of [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * Removal Date: 2020-09-01. From 2020-06-08, we will disable
   * [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
   * After 2020-09-01, all configuration will be migrated into
   * [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * automatically.
   * Manages a collection of human agent assistants.
   * A human agent assistant provides prompts and information to a live, human
   * agent to use with end users. Each human agent participating in a conversation
   * can use a different human agent assistant.
   * The life cycle of human agent assistant resources is independent of the
   * lifecycle of conversations.
   * </pre>
   */
  @java.lang.Deprecated
  public static final class HumanAgentAssistantsBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<HumanAgentAssistantsBlockingStub> {
    private HumanAgentAssistantsBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected HumanAgentAssistantsBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new HumanAgentAssistantsBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Returns the list of all human agent assistants.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse listHumanAgentAssistants(com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListHumanAgentAssistantsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves a human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant getHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetHumanAgentAssistantMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates a human agent assistant.
     * Deprecated. Use
     * [ConversationProfiles.CreateConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfiles.CreateConversationProfile]
     * instead.
     * Starting 2020-06-08, this method will always return INVALID_ARGUMENT. If
     * you need to continue using this method, you can set
     * [CreateHumanAgentAssistantRequest.bypass_deprecation][google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest.bypass_deprecation]
     * to true. The bypass flag will be removed after 2020-09-01, so you will need
     * to stop using this method by that date.
     * .
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant createHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateHumanAgentAssistantMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant updateHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateHumanAgentAssistantMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.protobuf.Empty deleteHumanAgentAssistant(com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteHumanAgentAssistantMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Uses the specified human agent assistant to come up with suggestions
     * (relevant articles and FAQs) on how to respond to a given conversation.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse compileSuggestions(com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCompileSuggestionsMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service HumanAgentAssistants.
   * <pre>
   * Deprecated: use configs in
   * [HumanAgentAssistantConfig.SuggestionFeatureConfig][google.cloud.dialogflow.v2beta1.HumanAgentAssistantConfig.SuggestionFeatureConfig]
   * of [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * Removal Date: 2020-09-01. From 2020-06-08, we will disable
   * [HumanAgentAssistants.CreateHumanAgentAssistant][google.cloud.dialogflow.v2beta1.HumanAgentAssistants.CreateHumanAgentAssistant].
   * After 2020-09-01, all configuration will be migrated into
   * [ConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfile]
   * automatically.
   * Manages a collection of human agent assistants.
   * A human agent assistant provides prompts and information to a live, human
   * agent to use with end users. Each human agent participating in a conversation
   * can use a different human agent assistant.
   * The life cycle of human agent assistant resources is independent of the
   * lifecycle of conversations.
   * </pre>
   */
  @java.lang.Deprecated
  public static final class HumanAgentAssistantsFutureStub
      extends io.grpc.stub.AbstractFutureStub<HumanAgentAssistantsFutureStub> {
    private HumanAgentAssistantsFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected HumanAgentAssistantsFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new HumanAgentAssistantsFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Returns the list of all human agent assistants.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse> listHumanAgentAssistants(
        com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListHumanAgentAssistantsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Retrieves a human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> getHumanAgentAssistant(
        com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetHumanAgentAssistantMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Creates a human agent assistant.
     * Deprecated. Use
     * [ConversationProfiles.CreateConversationProfile][google.cloud.dialogflow.v2beta1.ConversationProfiles.CreateConversationProfile]
     * instead.
     * Starting 2020-06-08, this method will always return INVALID_ARGUMENT. If
     * you need to continue using this method, you can set
     * [CreateHumanAgentAssistantRequest.bypass_deprecation][google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest.bypass_deprecation]
     * to true. The bypass flag will be removed after 2020-09-01, so you will need
     * to stop using this method by that date.
     * .
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> createHumanAgentAssistant(
        com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateHumanAgentAssistantMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Updates the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant> updateHumanAgentAssistant(
        com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateHumanAgentAssistantMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Deletes the specified human agent assistant.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteHumanAgentAssistant(
        com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteHumanAgentAssistantMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Uses the specified human agent assistant to come up with suggestions
     * (relevant articles and FAQs) on how to respond to a given conversation.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse> compileSuggestions(
        com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCompileSuggestionsMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_LIST_HUMAN_AGENT_ASSISTANTS = 0;
  private static final int METHODID_GET_HUMAN_AGENT_ASSISTANT = 1;
  private static final int METHODID_CREATE_HUMAN_AGENT_ASSISTANT = 2;
  private static final int METHODID_UPDATE_HUMAN_AGENT_ASSISTANT = 3;
  private static final int METHODID_DELETE_HUMAN_AGENT_ASSISTANT = 4;
  private static final int METHODID_COMPILE_SUGGESTIONS = 5;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_LIST_HUMAN_AGENT_ASSISTANTS:
          serviceImpl.listHumanAgentAssistants((com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse>) responseObserver);
          break;
        case METHODID_GET_HUMAN_AGENT_ASSISTANT:
          serviceImpl.getHumanAgentAssistant((com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>) responseObserver);
          break;
        case METHODID_CREATE_HUMAN_AGENT_ASSISTANT:
          serviceImpl.createHumanAgentAssistant((com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>) responseObserver);
          break;
        case METHODID_UPDATE_HUMAN_AGENT_ASSISTANT:
          serviceImpl.updateHumanAgentAssistant((com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>) responseObserver);
          break;
        case METHODID_DELETE_HUMAN_AGENT_ASSISTANT:
          serviceImpl.deleteHumanAgentAssistant((com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_COMPILE_SUGGESTIONS:
          serviceImpl.compileSuggestions((com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getListHumanAgentAssistantsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsRequest,
              com.google.cloud.dialogflow.v2beta1.ListHumanAgentAssistantsResponse>(
                service, METHODID_LIST_HUMAN_AGENT_ASSISTANTS)))
        .addMethod(
          getGetHumanAgentAssistantMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GetHumanAgentAssistantRequest,
              com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>(
                service, METHODID_GET_HUMAN_AGENT_ASSISTANT)))
        .addMethod(
          getCreateHumanAgentAssistantMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CreateHumanAgentAssistantRequest,
              com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>(
                service, METHODID_CREATE_HUMAN_AGENT_ASSISTANT)))
        .addMethod(
          getUpdateHumanAgentAssistantMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.UpdateHumanAgentAssistantRequest,
              com.google.cloud.dialogflow.v2beta1.HumanAgentAssistant>(
                service, METHODID_UPDATE_HUMAN_AGENT_ASSISTANT)))
        .addMethod(
          getDeleteHumanAgentAssistantMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeleteHumanAgentAssistantRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_HUMAN_AGENT_ASSISTANT)))
        .addMethod(
          getCompileSuggestionsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CompileSuggestionsRequest,
              com.google.cloud.dialogflow.v2beta1.CompileSuggestionsResponse>(
                service, METHODID_COMPILE_SUGGESTIONS)))
        .build();
  }

  private static abstract class HumanAgentAssistantsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    HumanAgentAssistantsBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.google.cloud.dialogflow.v2beta1.HumanAgentAssistantProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("HumanAgentAssistants");
    }
  }

  private static final class HumanAgentAssistantsFileDescriptorSupplier
      extends HumanAgentAssistantsBaseDescriptorSupplier {
    HumanAgentAssistantsFileDescriptorSupplier() {}
  }

  private static final class HumanAgentAssistantsMethodDescriptorSupplier
      extends HumanAgentAssistantsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    HumanAgentAssistantsMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (HumanAgentAssistantsGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new HumanAgentAssistantsFileDescriptorSupplier())
              .addMethod(getListHumanAgentAssistantsMethod())
              .addMethod(getGetHumanAgentAssistantMethod())
              .addMethod(getCreateHumanAgentAssistantMethod())
              .addMethod(getUpdateHumanAgentAssistantMethod())
              .addMethod(getDeleteHumanAgentAssistantMethod())
              .addMethod(getCompileSuggestionsMethod())
              .build();
        }
      }
    }
    return result;
  }
}
