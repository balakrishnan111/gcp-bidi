package com.google.cloud.dialogflow.v2beta1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Service for managing
 * [PhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrder].
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler",
    comments = "Source: google/cloud/dialogflow/v2beta1/phone_number_order.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class PhoneNumberOrdersGrpc {

  private PhoneNumberOrdersGrpc() {}

  public static final java.lang.String SERVICE_NAME = "google.cloud.dialogflow.v2beta1.PhoneNumberOrders";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest,
      com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getCreatePhoneNumberOrderMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreatePhoneNumberOrder",
      requestType = com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest,
      com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getCreatePhoneNumberOrderMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest, com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getCreatePhoneNumberOrderMethod;
    if ((getCreatePhoneNumberOrderMethod = PhoneNumberOrdersGrpc.getCreatePhoneNumberOrderMethod) == null) {
      synchronized (PhoneNumberOrdersGrpc.class) {
        if ((getCreatePhoneNumberOrderMethod = PhoneNumberOrdersGrpc.getCreatePhoneNumberOrderMethod) == null) {
          PhoneNumberOrdersGrpc.getCreatePhoneNumberOrderMethod = getCreatePhoneNumberOrderMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest, com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreatePhoneNumberOrder"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder.getDefaultInstance()))
              .setSchemaDescriptor(new PhoneNumberOrdersMethodDescriptorSupplier("CreatePhoneNumberOrder"))
              .build();
        }
      }
    }
    return getCreatePhoneNumberOrderMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest,
      com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getGetPhoneNumberOrderMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetPhoneNumberOrder",
      requestType = com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest,
      com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getGetPhoneNumberOrderMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest, com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getGetPhoneNumberOrderMethod;
    if ((getGetPhoneNumberOrderMethod = PhoneNumberOrdersGrpc.getGetPhoneNumberOrderMethod) == null) {
      synchronized (PhoneNumberOrdersGrpc.class) {
        if ((getGetPhoneNumberOrderMethod = PhoneNumberOrdersGrpc.getGetPhoneNumberOrderMethod) == null) {
          PhoneNumberOrdersGrpc.getGetPhoneNumberOrderMethod = getGetPhoneNumberOrderMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest, com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetPhoneNumberOrder"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder.getDefaultInstance()))
              .setSchemaDescriptor(new PhoneNumberOrdersMethodDescriptorSupplier("GetPhoneNumberOrder"))
              .build();
        }
      }
    }
    return getGetPhoneNumberOrderMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest,
      com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse> getListPhoneNumberOrdersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListPhoneNumberOrders",
      requestType = com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest,
      com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse> getListPhoneNumberOrdersMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest, com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse> getListPhoneNumberOrdersMethod;
    if ((getListPhoneNumberOrdersMethod = PhoneNumberOrdersGrpc.getListPhoneNumberOrdersMethod) == null) {
      synchronized (PhoneNumberOrdersGrpc.class) {
        if ((getListPhoneNumberOrdersMethod = PhoneNumberOrdersGrpc.getListPhoneNumberOrdersMethod) == null) {
          PhoneNumberOrdersGrpc.getListPhoneNumberOrdersMethod = getListPhoneNumberOrdersMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest, com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListPhoneNumberOrders"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse.getDefaultInstance()))
              .setSchemaDescriptor(new PhoneNumberOrdersMethodDescriptorSupplier("ListPhoneNumberOrders"))
              .build();
        }
      }
    }
    return getListPhoneNumberOrdersMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest,
      com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getUpdatePhoneNumberOrderMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdatePhoneNumberOrder",
      requestType = com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest,
      com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getUpdatePhoneNumberOrderMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest, com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getUpdatePhoneNumberOrderMethod;
    if ((getUpdatePhoneNumberOrderMethod = PhoneNumberOrdersGrpc.getUpdatePhoneNumberOrderMethod) == null) {
      synchronized (PhoneNumberOrdersGrpc.class) {
        if ((getUpdatePhoneNumberOrderMethod = PhoneNumberOrdersGrpc.getUpdatePhoneNumberOrderMethod) == null) {
          PhoneNumberOrdersGrpc.getUpdatePhoneNumberOrderMethod = getUpdatePhoneNumberOrderMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest, com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdatePhoneNumberOrder"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder.getDefaultInstance()))
              .setSchemaDescriptor(new PhoneNumberOrdersMethodDescriptorSupplier("UpdatePhoneNumberOrder"))
              .build();
        }
      }
    }
    return getUpdatePhoneNumberOrderMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest,
      com.google.protobuf.Empty> getCancelPhoneNumberOrderMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CancelPhoneNumberOrder",
      requestType = com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest,
      com.google.protobuf.Empty> getCancelPhoneNumberOrderMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest, com.google.protobuf.Empty> getCancelPhoneNumberOrderMethod;
    if ((getCancelPhoneNumberOrderMethod = PhoneNumberOrdersGrpc.getCancelPhoneNumberOrderMethod) == null) {
      synchronized (PhoneNumberOrdersGrpc.class) {
        if ((getCancelPhoneNumberOrderMethod = PhoneNumberOrdersGrpc.getCancelPhoneNumberOrderMethod) == null) {
          PhoneNumberOrdersGrpc.getCancelPhoneNumberOrderMethod = getCancelPhoneNumberOrderMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CancelPhoneNumberOrder"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new PhoneNumberOrdersMethodDescriptorSupplier("CancelPhoneNumberOrder"))
              .build();
        }
      }
    }
    return getCancelPhoneNumberOrderMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static PhoneNumberOrdersStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<PhoneNumberOrdersStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<PhoneNumberOrdersStub>() {
        @java.lang.Override
        public PhoneNumberOrdersStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new PhoneNumberOrdersStub(channel, callOptions);
        }
      };
    return PhoneNumberOrdersStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static PhoneNumberOrdersBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<PhoneNumberOrdersBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<PhoneNumberOrdersBlockingV2Stub>() {
        @java.lang.Override
        public PhoneNumberOrdersBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new PhoneNumberOrdersBlockingV2Stub(channel, callOptions);
        }
      };
    return PhoneNumberOrdersBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static PhoneNumberOrdersBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<PhoneNumberOrdersBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<PhoneNumberOrdersBlockingStub>() {
        @java.lang.Override
        public PhoneNumberOrdersBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new PhoneNumberOrdersBlockingStub(channel, callOptions);
        }
      };
    return PhoneNumberOrdersBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static PhoneNumberOrdersFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<PhoneNumberOrdersFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<PhoneNumberOrdersFutureStub>() {
        @java.lang.Override
        public PhoneNumberOrdersFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new PhoneNumberOrdersFutureStub(channel, callOptions);
        }
      };
    return PhoneNumberOrdersFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Service for managing
   * [PhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrder].
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Creates an order to request phone numbers be added to a project.
     * The initial `LifecycleState` of a newly created order is
     * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
     * </pre>
     */
    default void createPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreatePhoneNumberOrderMethod(), responseObserver);
    }

    /**
     * <pre>
     * Returns a specific `PhoneNumberOrder`.
     * </pre>
     */
    default void getPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetPhoneNumberOrderMethod(), responseObserver);
    }

    /**
     * <pre>
     * Lists of all `PhoneNumberOrder` resources in the specified project.
     * </pre>
     */
    default void listPhoneNumberOrders(com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListPhoneNumberOrdersMethod(), responseObserver);
    }

    /**
     * <pre>
     * Updates the specified `PhoneNumberOrder` resource.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    default void updatePhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdatePhoneNumberOrderMethod(), responseObserver);
    }

    /**
     * <pre>
     * Cancels an `PhoneNumberOrder`.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    default void cancelPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCancelPhoneNumberOrderMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service PhoneNumberOrders.
   * <pre>
   * Service for managing
   * [PhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrder].
   * </pre>
   */
  public static abstract class PhoneNumberOrdersImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return PhoneNumberOrdersGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service PhoneNumberOrders.
   * <pre>
   * Service for managing
   * [PhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrder].
   * </pre>
   */
  public static final class PhoneNumberOrdersStub
      extends io.grpc.stub.AbstractAsyncStub<PhoneNumberOrdersStub> {
    private PhoneNumberOrdersStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PhoneNumberOrdersStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new PhoneNumberOrdersStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates an order to request phone numbers be added to a project.
     * The initial `LifecycleState` of a newly created order is
     * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
     * </pre>
     */
    public void createPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreatePhoneNumberOrderMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Returns a specific `PhoneNumberOrder`.
     * </pre>
     */
    public void getPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetPhoneNumberOrderMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Lists of all `PhoneNumberOrder` resources in the specified project.
     * </pre>
     */
    public void listPhoneNumberOrders(com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListPhoneNumberOrdersMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Updates the specified `PhoneNumberOrder` resource.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    public void updatePhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdatePhoneNumberOrderMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Cancels an `PhoneNumberOrder`.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    public void cancelPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCancelPhoneNumberOrderMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service PhoneNumberOrders.
   * <pre>
   * Service for managing
   * [PhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrder].
   * </pre>
   */
  public static final class PhoneNumberOrdersBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<PhoneNumberOrdersBlockingV2Stub> {
    private PhoneNumberOrdersBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PhoneNumberOrdersBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new PhoneNumberOrdersBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates an order to request phone numbers be added to a project.
     * The initial `LifecycleState` of a newly created order is
     * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder createPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreatePhoneNumberOrderMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns a specific `PhoneNumberOrder`.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder getPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetPhoneNumberOrderMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Lists of all `PhoneNumberOrder` resources in the specified project.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse listPhoneNumberOrders(com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListPhoneNumberOrdersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified `PhoneNumberOrder` resource.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder updatePhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdatePhoneNumberOrderMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Cancels an `PhoneNumberOrder`.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    public com.google.protobuf.Empty cancelPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCancelPhoneNumberOrderMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service PhoneNumberOrders.
   * <pre>
   * Service for managing
   * [PhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrder].
   * </pre>
   */
  public static final class PhoneNumberOrdersBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<PhoneNumberOrdersBlockingStub> {
    private PhoneNumberOrdersBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PhoneNumberOrdersBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new PhoneNumberOrdersBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates an order to request phone numbers be added to a project.
     * The initial `LifecycleState` of a newly created order is
     * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder createPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreatePhoneNumberOrderMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns a specific `PhoneNumberOrder`.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder getPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetPhoneNumberOrderMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Lists of all `PhoneNumberOrder` resources in the specified project.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse listPhoneNumberOrders(com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListPhoneNumberOrdersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified `PhoneNumberOrder` resource.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder updatePhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdatePhoneNumberOrderMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Cancels an `PhoneNumberOrder`.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    public com.google.protobuf.Empty cancelPhoneNumberOrder(com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCancelPhoneNumberOrderMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service PhoneNumberOrders.
   * <pre>
   * Service for managing
   * [PhoneNumberOrders][google.cloud.dialogflow.v2beta1.PhoneNumberOrder].
   * </pre>
   */
  public static final class PhoneNumberOrdersFutureStub
      extends io.grpc.stub.AbstractFutureStub<PhoneNumberOrdersFutureStub> {
    private PhoneNumberOrdersFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected PhoneNumberOrdersFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new PhoneNumberOrdersFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates an order to request phone numbers be added to a project.
     * The initial `LifecycleState` of a newly created order is
     * [PENDING][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.PENDING].
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> createPhoneNumberOrder(
        com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreatePhoneNumberOrderMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Returns a specific `PhoneNumberOrder`.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> getPhoneNumberOrder(
        com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetPhoneNumberOrderMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Lists of all `PhoneNumberOrder` resources in the specified project.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse> listPhoneNumberOrders(
        com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListPhoneNumberOrdersMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Updates the specified `PhoneNumberOrder` resource.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder> updatePhoneNumberOrder(
        com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdatePhoneNumberOrderMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Cancels an `PhoneNumberOrder`.
     * Returns an error if the order is in state
     * [IN_PROGRESS][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.IN_PROGRESS]
     * or
     * [COMPLETED][google.cloud.dialogflow.v2beta1.PhoneNumberOrder.LifecycleState.COMPLETED].
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> cancelPhoneNumberOrder(
        com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCancelPhoneNumberOrderMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_PHONE_NUMBER_ORDER = 0;
  private static final int METHODID_GET_PHONE_NUMBER_ORDER = 1;
  private static final int METHODID_LIST_PHONE_NUMBER_ORDERS = 2;
  private static final int METHODID_UPDATE_PHONE_NUMBER_ORDER = 3;
  private static final int METHODID_CANCEL_PHONE_NUMBER_ORDER = 4;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_PHONE_NUMBER_ORDER:
          serviceImpl.createPhoneNumberOrder((com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>) responseObserver);
          break;
        case METHODID_GET_PHONE_NUMBER_ORDER:
          serviceImpl.getPhoneNumberOrder((com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>) responseObserver);
          break;
        case METHODID_LIST_PHONE_NUMBER_ORDERS:
          serviceImpl.listPhoneNumberOrders((com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse>) responseObserver);
          break;
        case METHODID_UPDATE_PHONE_NUMBER_ORDER:
          serviceImpl.updatePhoneNumberOrder((com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>) responseObserver);
          break;
        case METHODID_CANCEL_PHONE_NUMBER_ORDER:
          serviceImpl.cancelPhoneNumberOrder((com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getCreatePhoneNumberOrderMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CreatePhoneNumberOrderRequest,
              com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>(
                service, METHODID_CREATE_PHONE_NUMBER_ORDER)))
        .addMethod(
          getGetPhoneNumberOrderMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GetPhoneNumberOrderRequest,
              com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>(
                service, METHODID_GET_PHONE_NUMBER_ORDER)))
        .addMethod(
          getListPhoneNumberOrdersMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersRequest,
              com.google.cloud.dialogflow.v2beta1.ListPhoneNumberOrdersResponse>(
                service, METHODID_LIST_PHONE_NUMBER_ORDERS)))
        .addMethod(
          getUpdatePhoneNumberOrderMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.UpdatePhoneNumberOrderRequest,
              com.google.cloud.dialogflow.v2beta1.PhoneNumberOrder>(
                service, METHODID_UPDATE_PHONE_NUMBER_ORDER)))
        .addMethod(
          getCancelPhoneNumberOrderMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CancelPhoneNumberOrderRequest,
              com.google.protobuf.Empty>(
                service, METHODID_CANCEL_PHONE_NUMBER_ORDER)))
        .build();
  }

  private static abstract class PhoneNumberOrdersBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    PhoneNumberOrdersBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.google.cloud.dialogflow.v2beta1.PhoneNumberOrderProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("PhoneNumberOrders");
    }
  }

  private static final class PhoneNumberOrdersFileDescriptorSupplier
      extends PhoneNumberOrdersBaseDescriptorSupplier {
    PhoneNumberOrdersFileDescriptorSupplier() {}
  }

  private static final class PhoneNumberOrdersMethodDescriptorSupplier
      extends PhoneNumberOrdersBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    PhoneNumberOrdersMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (PhoneNumberOrdersGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new PhoneNumberOrdersFileDescriptorSupplier())
              .addMethod(getCreatePhoneNumberOrderMethod())
              .addMethod(getGetPhoneNumberOrderMethod())
              .addMethod(getListPhoneNumberOrdersMethod())
              .addMethod(getUpdatePhoneNumberOrderMethod())
              .addMethod(getCancelPhoneNumberOrderMethod())
              .build();
        }
      }
    }
    return result;
  }
}
