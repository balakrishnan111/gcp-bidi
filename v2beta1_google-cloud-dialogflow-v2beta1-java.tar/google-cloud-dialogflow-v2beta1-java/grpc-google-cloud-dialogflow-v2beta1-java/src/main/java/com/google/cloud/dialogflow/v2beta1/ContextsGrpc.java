package com.google.cloud.dialogflow.v2beta1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Service for managing [Contexts][google.cloud.dialogflow.v2beta1.Context].
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler",
    comments = "Source: google/cloud/dialogflow/v2beta1/context.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ContextsGrpc {

  private ContextsGrpc() {}

  public static final java.lang.String SERVICE_NAME = "google.cloud.dialogflow.v2beta1.Contexts";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListContextsRequest,
      com.google.cloud.dialogflow.v2beta1.ListContextsResponse> getListContextsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListContexts",
      requestType = com.google.cloud.dialogflow.v2beta1.ListContextsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListContextsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListContextsRequest,
      com.google.cloud.dialogflow.v2beta1.ListContextsResponse> getListContextsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListContextsRequest, com.google.cloud.dialogflow.v2beta1.ListContextsResponse> getListContextsMethod;
    if ((getListContextsMethod = ContextsGrpc.getListContextsMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getListContextsMethod = ContextsGrpc.getListContextsMethod) == null) {
          ContextsGrpc.getListContextsMethod = getListContextsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListContextsRequest, com.google.cloud.dialogflow.v2beta1.ListContextsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListContexts"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListContextsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListContextsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("ListContexts"))
              .build();
        }
      }
    }
    return getListContextsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListContextsRequest,
      com.google.cloud.dialogflow.v2beta1.ListContextsResponse> getListContextsByConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListContextsByConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.ListContextsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListContextsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListContextsRequest,
      com.google.cloud.dialogflow.v2beta1.ListContextsResponse> getListContextsByConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListContextsRequest, com.google.cloud.dialogflow.v2beta1.ListContextsResponse> getListContextsByConversationMethod;
    if ((getListContextsByConversationMethod = ContextsGrpc.getListContextsByConversationMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getListContextsByConversationMethod = ContextsGrpc.getListContextsByConversationMethod) == null) {
          ContextsGrpc.getListContextsByConversationMethod = getListContextsByConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListContextsRequest, com.google.cloud.dialogflow.v2beta1.ListContextsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListContextsByConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListContextsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListContextsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("ListContextsByConversation"))
              .build();
        }
      }
    }
    return getListContextsByConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getGetContextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetContext",
      requestType = com.google.cloud.dialogflow.v2beta1.GetContextRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Context.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getGetContextMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetContextRequest, com.google.cloud.dialogflow.v2beta1.Context> getGetContextMethod;
    if ((getGetContextMethod = ContextsGrpc.getGetContextMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getGetContextMethod = ContextsGrpc.getGetContextMethod) == null) {
          ContextsGrpc.getGetContextMethod = getGetContextMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GetContextRequest, com.google.cloud.dialogflow.v2beta1.Context>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetContext"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GetContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Context.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("GetContext"))
              .build();
        }
      }
    }
    return getGetContextMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getGetContextByConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetContextByConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.GetContextRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Context.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getGetContextByConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetContextRequest, com.google.cloud.dialogflow.v2beta1.Context> getGetContextByConversationMethod;
    if ((getGetContextByConversationMethod = ContextsGrpc.getGetContextByConversationMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getGetContextByConversationMethod = ContextsGrpc.getGetContextByConversationMethod) == null) {
          ContextsGrpc.getGetContextByConversationMethod = getGetContextByConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GetContextRequest, com.google.cloud.dialogflow.v2beta1.Context>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetContextByConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GetContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Context.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("GetContextByConversation"))
              .build();
        }
      }
    }
    return getGetContextByConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getCreateContextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateContext",
      requestType = com.google.cloud.dialogflow.v2beta1.CreateContextRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Context.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getCreateContextMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateContextRequest, com.google.cloud.dialogflow.v2beta1.Context> getCreateContextMethod;
    if ((getCreateContextMethod = ContextsGrpc.getCreateContextMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getCreateContextMethod = ContextsGrpc.getCreateContextMethod) == null) {
          ContextsGrpc.getCreateContextMethod = getCreateContextMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CreateContextRequest, com.google.cloud.dialogflow.v2beta1.Context>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateContext"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CreateContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Context.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("CreateContext"))
              .build();
        }
      }
    }
    return getCreateContextMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getCreateContextByConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateContextByConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.CreateContextRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Context.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getCreateContextByConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateContextRequest, com.google.cloud.dialogflow.v2beta1.Context> getCreateContextByConversationMethod;
    if ((getCreateContextByConversationMethod = ContextsGrpc.getCreateContextByConversationMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getCreateContextByConversationMethod = ContextsGrpc.getCreateContextByConversationMethod) == null) {
          ContextsGrpc.getCreateContextByConversationMethod = getCreateContextByConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CreateContextRequest, com.google.cloud.dialogflow.v2beta1.Context>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateContextByConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CreateContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Context.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("CreateContextByConversation"))
              .build();
        }
      }
    }
    return getCreateContextByConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getUpdateContextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateContext",
      requestType = com.google.cloud.dialogflow.v2beta1.UpdateContextRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Context.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getUpdateContextMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateContextRequest, com.google.cloud.dialogflow.v2beta1.Context> getUpdateContextMethod;
    if ((getUpdateContextMethod = ContextsGrpc.getUpdateContextMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getUpdateContextMethod = ContextsGrpc.getUpdateContextMethod) == null) {
          ContextsGrpc.getUpdateContextMethod = getUpdateContextMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.UpdateContextRequest, com.google.cloud.dialogflow.v2beta1.Context>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateContext"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.UpdateContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Context.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("UpdateContext"))
              .build();
        }
      }
    }
    return getUpdateContextMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getUpdateContextByConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateContextByConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.UpdateContextRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Context.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateContextRequest,
      com.google.cloud.dialogflow.v2beta1.Context> getUpdateContextByConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateContextRequest, com.google.cloud.dialogflow.v2beta1.Context> getUpdateContextByConversationMethod;
    if ((getUpdateContextByConversationMethod = ContextsGrpc.getUpdateContextByConversationMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getUpdateContextByConversationMethod = ContextsGrpc.getUpdateContextByConversationMethod) == null) {
          ContextsGrpc.getUpdateContextByConversationMethod = getUpdateContextByConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.UpdateContextRequest, com.google.cloud.dialogflow.v2beta1.Context>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateContextByConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.UpdateContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Context.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("UpdateContextByConversation"))
              .build();
        }
      }
    }
    return getUpdateContextByConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteContextRequest,
      com.google.protobuf.Empty> getDeleteContextMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteContext",
      requestType = com.google.cloud.dialogflow.v2beta1.DeleteContextRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteContextRequest,
      com.google.protobuf.Empty> getDeleteContextMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteContextRequest, com.google.protobuf.Empty> getDeleteContextMethod;
    if ((getDeleteContextMethod = ContextsGrpc.getDeleteContextMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getDeleteContextMethod = ContextsGrpc.getDeleteContextMethod) == null) {
          ContextsGrpc.getDeleteContextMethod = getDeleteContextMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeleteContextRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteContext"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeleteContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("DeleteContext"))
              .build();
        }
      }
    }
    return getDeleteContextMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteContextRequest,
      com.google.protobuf.Empty> getDeleteContextByConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteContextByConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.DeleteContextRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteContextRequest,
      com.google.protobuf.Empty> getDeleteContextByConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteContextRequest, com.google.protobuf.Empty> getDeleteContextByConversationMethod;
    if ((getDeleteContextByConversationMethod = ContextsGrpc.getDeleteContextByConversationMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getDeleteContextByConversationMethod = ContextsGrpc.getDeleteContextByConversationMethod) == null) {
          ContextsGrpc.getDeleteContextByConversationMethod = getDeleteContextByConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeleteContextRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteContextByConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeleteContextRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("DeleteContextByConversation"))
              .build();
        }
      }
    }
    return getDeleteContextByConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest,
      com.google.protobuf.Empty> getDeleteAllContextsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteAllContexts",
      requestType = com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest,
      com.google.protobuf.Empty> getDeleteAllContextsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest, com.google.protobuf.Empty> getDeleteAllContextsMethod;
    if ((getDeleteAllContextsMethod = ContextsGrpc.getDeleteAllContextsMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getDeleteAllContextsMethod = ContextsGrpc.getDeleteAllContextsMethod) == null) {
          ContextsGrpc.getDeleteAllContextsMethod = getDeleteAllContextsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteAllContexts"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("DeleteAllContexts"))
              .build();
        }
      }
    }
    return getDeleteAllContextsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest,
      com.google.protobuf.Empty> getDeleteAllContextsByConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteAllContextsByConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest,
      com.google.protobuf.Empty> getDeleteAllContextsByConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest, com.google.protobuf.Empty> getDeleteAllContextsByConversationMethod;
    if ((getDeleteAllContextsByConversationMethod = ContextsGrpc.getDeleteAllContextsByConversationMethod) == null) {
      synchronized (ContextsGrpc.class) {
        if ((getDeleteAllContextsByConversationMethod = ContextsGrpc.getDeleteAllContextsByConversationMethod) == null) {
          ContextsGrpc.getDeleteAllContextsByConversationMethod = getDeleteAllContextsByConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteAllContextsByConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new ContextsMethodDescriptorSupplier("DeleteAllContextsByConversation"))
              .build();
        }
      }
    }
    return getDeleteAllContextsByConversationMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ContextsStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ContextsStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ContextsStub>() {
        @java.lang.Override
        public ContextsStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ContextsStub(channel, callOptions);
        }
      };
    return ContextsStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static ContextsBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ContextsBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ContextsBlockingV2Stub>() {
        @java.lang.Override
        public ContextsBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ContextsBlockingV2Stub(channel, callOptions);
        }
      };
    return ContextsBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ContextsBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ContextsBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ContextsBlockingStub>() {
        @java.lang.Override
        public ContextsBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ContextsBlockingStub(channel, callOptions);
        }
      };
    return ContextsBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ContextsFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ContextsFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ContextsFutureStub>() {
        @java.lang.Override
        public ContextsFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ContextsFutureStub(channel, callOptions);
        }
      };
    return ContextsFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Service for managing [Contexts][google.cloud.dialogflow.v2beta1.Context].
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * </pre>
     */
    default void listContexts(com.google.cloud.dialogflow.v2beta1.ListContextsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListContextsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListContextsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * Alpha users: Please always use
     * [ListContexts][google.cloud.dialogflow.v2beta1.Contexts.ListContexts]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    default void listContextsByConversation(com.google.cloud.dialogflow.v2beta1.ListContextsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListContextsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListContextsByConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * </pre>
     */
    default void getContext(com.google.cloud.dialogflow.v2beta1.GetContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetContextMethod(), responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * Alpha users: Please always use
     * [GetContext][google.cloud.dialogflow.v2beta1.Contexts.GetContext]. It also
     * accepts names with `conversations`. This method only exists because of a
     * REST visibility issue.
     * </pre>
     */
    default void getContextByConversation(com.google.cloud.dialogflow.v2beta1.GetContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetContextByConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * </pre>
     */
    default void createContext(com.google.cloud.dialogflow.v2beta1.CreateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateContextMethod(), responseObserver);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * Alpha users: Please always use
     * [CreateContext][google.cloud.dialogflow.v2beta1.Contexts.CreateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    default void createContextByConversation(com.google.cloud.dialogflow.v2beta1.CreateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateContextByConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Updates the specified context.
     * </pre>
     */
    default void updateContext(com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateContextMethod(), responseObserver);
    }

    /**
     * <pre>
     * Updates the specified context.
     * Alpha users: Please always use
     * [UpdateContext][google.cloud.dialogflow.v2beta1.Contexts.UpdateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    default void updateContextByConversation(com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateContextByConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * </pre>
     */
    default void deleteContext(com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteContextMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * Alpha users: Please always use
     * [DeleteContext][google.cloud.dialogflow.v2beta1.Contexts.DeleteContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    default void deleteContextByConversation(com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteContextByConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * </pre>
     */
    default void deleteAllContexts(com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteAllContextsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * Alpha users: Please always use
     * [DeleteAllContexts][google.cloud.dialogflow.v2beta1.Contexts.DeleteAllContexts].
     * It also accepts names with `conversations`. This method only exists because
     * of a REST visibility issue.
     * </pre>
     */
    default void deleteAllContextsByConversation(com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteAllContextsByConversationMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service Contexts.
   * <pre>
   * Service for managing [Contexts][google.cloud.dialogflow.v2beta1.Context].
   * </pre>
   */
  public static abstract class ContextsImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return ContextsGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service Contexts.
   * <pre>
   * Service for managing [Contexts][google.cloud.dialogflow.v2beta1.Context].
   * </pre>
   */
  public static final class ContextsStub
      extends io.grpc.stub.AbstractAsyncStub<ContextsStub> {
    private ContextsStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContextsStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ContextsStub(channel, callOptions);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * </pre>
     */
    public void listContexts(com.google.cloud.dialogflow.v2beta1.ListContextsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListContextsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListContextsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * Alpha users: Please always use
     * [ListContexts][google.cloud.dialogflow.v2beta1.Contexts.ListContexts]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public void listContextsByConversation(com.google.cloud.dialogflow.v2beta1.ListContextsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListContextsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListContextsByConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * </pre>
     */
    public void getContext(com.google.cloud.dialogflow.v2beta1.GetContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetContextMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * Alpha users: Please always use
     * [GetContext][google.cloud.dialogflow.v2beta1.Contexts.GetContext]. It also
     * accepts names with `conversations`. This method only exists because of a
     * REST visibility issue.
     * </pre>
     */
    public void getContextByConversation(com.google.cloud.dialogflow.v2beta1.GetContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetContextByConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * </pre>
     */
    public void createContext(com.google.cloud.dialogflow.v2beta1.CreateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateContextMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * Alpha users: Please always use
     * [CreateContext][google.cloud.dialogflow.v2beta1.Contexts.CreateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public void createContextByConversation(com.google.cloud.dialogflow.v2beta1.CreateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateContextByConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Updates the specified context.
     * </pre>
     */
    public void updateContext(com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateContextMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Updates the specified context.
     * Alpha users: Please always use
     * [UpdateContext][google.cloud.dialogflow.v2beta1.Contexts.UpdateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public void updateContextByConversation(com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateContextByConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * </pre>
     */
    public void deleteContext(com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteContextMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * Alpha users: Please always use
     * [DeleteContext][google.cloud.dialogflow.v2beta1.Contexts.DeleteContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public void deleteContextByConversation(com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteContextByConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * </pre>
     */
    public void deleteAllContexts(com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteAllContextsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * Alpha users: Please always use
     * [DeleteAllContexts][google.cloud.dialogflow.v2beta1.Contexts.DeleteAllContexts].
     * It also accepts names with `conversations`. This method only exists because
     * of a REST visibility issue.
     * </pre>
     */
    public void deleteAllContextsByConversation(com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteAllContextsByConversationMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service Contexts.
   * <pre>
   * Service for managing [Contexts][google.cloud.dialogflow.v2beta1.Context].
   * </pre>
   */
  public static final class ContextsBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<ContextsBlockingV2Stub> {
    private ContextsBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContextsBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ContextsBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListContextsResponse listContexts(com.google.cloud.dialogflow.v2beta1.ListContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListContextsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * Alpha users: Please always use
     * [ListContexts][google.cloud.dialogflow.v2beta1.Contexts.ListContexts]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListContextsResponse listContextsByConversation(com.google.cloud.dialogflow.v2beta1.ListContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListContextsByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context getContext(com.google.cloud.dialogflow.v2beta1.GetContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetContextMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * Alpha users: Please always use
     * [GetContext][google.cloud.dialogflow.v2beta1.Contexts.GetContext]. It also
     * accepts names with `conversations`. This method only exists because of a
     * REST visibility issue.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context getContextByConversation(com.google.cloud.dialogflow.v2beta1.GetContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetContextByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context createContext(com.google.cloud.dialogflow.v2beta1.CreateContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateContextMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * Alpha users: Please always use
     * [CreateContext][google.cloud.dialogflow.v2beta1.Contexts.CreateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context createContextByConversation(com.google.cloud.dialogflow.v2beta1.CreateContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateContextByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified context.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context updateContext(com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateContextMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified context.
     * Alpha users: Please always use
     * [UpdateContext][google.cloud.dialogflow.v2beta1.Contexts.UpdateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context updateContextByConversation(com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateContextByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * </pre>
     */
    public com.google.protobuf.Empty deleteContext(com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteContextMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * Alpha users: Please always use
     * [DeleteContext][google.cloud.dialogflow.v2beta1.Contexts.DeleteContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.protobuf.Empty deleteContextByConversation(com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteContextByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * </pre>
     */
    public com.google.protobuf.Empty deleteAllContexts(com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteAllContextsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * Alpha users: Please always use
     * [DeleteAllContexts][google.cloud.dialogflow.v2beta1.Contexts.DeleteAllContexts].
     * It also accepts names with `conversations`. This method only exists because
     * of a REST visibility issue.
     * </pre>
     */
    public com.google.protobuf.Empty deleteAllContextsByConversation(com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteAllContextsByConversationMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service Contexts.
   * <pre>
   * Service for managing [Contexts][google.cloud.dialogflow.v2beta1.Context].
   * </pre>
   */
  public static final class ContextsBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<ContextsBlockingStub> {
    private ContextsBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContextsBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ContextsBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListContextsResponse listContexts(com.google.cloud.dialogflow.v2beta1.ListContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListContextsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * Alpha users: Please always use
     * [ListContexts][google.cloud.dialogflow.v2beta1.Contexts.ListContexts]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListContextsResponse listContextsByConversation(com.google.cloud.dialogflow.v2beta1.ListContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListContextsByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context getContext(com.google.cloud.dialogflow.v2beta1.GetContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetContextMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * Alpha users: Please always use
     * [GetContext][google.cloud.dialogflow.v2beta1.Contexts.GetContext]. It also
     * accepts names with `conversations`. This method only exists because of a
     * REST visibility issue.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context getContextByConversation(com.google.cloud.dialogflow.v2beta1.GetContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetContextByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context createContext(com.google.cloud.dialogflow.v2beta1.CreateContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateContextMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * Alpha users: Please always use
     * [CreateContext][google.cloud.dialogflow.v2beta1.Contexts.CreateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context createContextByConversation(com.google.cloud.dialogflow.v2beta1.CreateContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateContextByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified context.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context updateContext(com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateContextMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified context.
     * Alpha users: Please always use
     * [UpdateContext][google.cloud.dialogflow.v2beta1.Contexts.UpdateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Context updateContextByConversation(com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateContextByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * </pre>
     */
    public com.google.protobuf.Empty deleteContext(com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteContextMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * Alpha users: Please always use
     * [DeleteContext][google.cloud.dialogflow.v2beta1.Contexts.DeleteContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.protobuf.Empty deleteContextByConversation(com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteContextByConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * </pre>
     */
    public com.google.protobuf.Empty deleteAllContexts(com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteAllContextsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * Alpha users: Please always use
     * [DeleteAllContexts][google.cloud.dialogflow.v2beta1.Contexts.DeleteAllContexts].
     * It also accepts names with `conversations`. This method only exists because
     * of a REST visibility issue.
     * </pre>
     */
    public com.google.protobuf.Empty deleteAllContextsByConversation(com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteAllContextsByConversationMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service Contexts.
   * <pre>
   * Service for managing [Contexts][google.cloud.dialogflow.v2beta1.Context].
   * </pre>
   */
  public static final class ContextsFutureStub
      extends io.grpc.stub.AbstractFutureStub<ContextsFutureStub> {
    private ContextsFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ContextsFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ContextsFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListContextsResponse> listContexts(
        com.google.cloud.dialogflow.v2beta1.ListContextsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListContextsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Returns the list of all contexts in the specified session.
     * Alpha users: Please always use
     * [ListContexts][google.cloud.dialogflow.v2beta1.Contexts.ListContexts]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListContextsResponse> listContextsByConversation(
        com.google.cloud.dialogflow.v2beta1.ListContextsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListContextsByConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Context> getContext(
        com.google.cloud.dialogflow.v2beta1.GetContextRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetContextMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Retrieves the specified context.
     * Alpha users: Please always use
     * [GetContext][google.cloud.dialogflow.v2beta1.Contexts.GetContext]. It also
     * accepts names with `conversations`. This method only exists because of a
     * REST visibility issue.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Context> getContextByConversation(
        com.google.cloud.dialogflow.v2beta1.GetContextRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetContextByConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Context> createContext(
        com.google.cloud.dialogflow.v2beta1.CreateContextRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateContextMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Creates a context.
     * If the specified context already exists, overrides the context.
     * Alpha users: Please always use
     * [CreateContext][google.cloud.dialogflow.v2beta1.Contexts.CreateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Context> createContextByConversation(
        com.google.cloud.dialogflow.v2beta1.CreateContextRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateContextByConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Updates the specified context.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Context> updateContext(
        com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateContextMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Updates the specified context.
     * Alpha users: Please always use
     * [UpdateContext][google.cloud.dialogflow.v2beta1.Contexts.UpdateContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Context> updateContextByConversation(
        com.google.cloud.dialogflow.v2beta1.UpdateContextRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateContextByConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteContext(
        com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteContextMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Deletes the specified context.
     * Alpha users: Please always use
     * [DeleteContext][google.cloud.dialogflow.v2beta1.Contexts.DeleteContext]. It
     * also accepts names with `conversations`. This method only exists because of
     * a REST visibility issue.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteContextByConversation(
        com.google.cloud.dialogflow.v2beta1.DeleteContextRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteContextByConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteAllContexts(
        com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteAllContextsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Deletes all active contexts in the specified session.
     * Alpha users: Please always use
     * [DeleteAllContexts][google.cloud.dialogflow.v2beta1.Contexts.DeleteAllContexts].
     * It also accepts names with `conversations`. This method only exists because
     * of a REST visibility issue.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteAllContextsByConversation(
        com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteAllContextsByConversationMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_LIST_CONTEXTS = 0;
  private static final int METHODID_LIST_CONTEXTS_BY_CONVERSATION = 1;
  private static final int METHODID_GET_CONTEXT = 2;
  private static final int METHODID_GET_CONTEXT_BY_CONVERSATION = 3;
  private static final int METHODID_CREATE_CONTEXT = 4;
  private static final int METHODID_CREATE_CONTEXT_BY_CONVERSATION = 5;
  private static final int METHODID_UPDATE_CONTEXT = 6;
  private static final int METHODID_UPDATE_CONTEXT_BY_CONVERSATION = 7;
  private static final int METHODID_DELETE_CONTEXT = 8;
  private static final int METHODID_DELETE_CONTEXT_BY_CONVERSATION = 9;
  private static final int METHODID_DELETE_ALL_CONTEXTS = 10;
  private static final int METHODID_DELETE_ALL_CONTEXTS_BY_CONVERSATION = 11;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_LIST_CONTEXTS:
          serviceImpl.listContexts((com.google.cloud.dialogflow.v2beta1.ListContextsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListContextsResponse>) responseObserver);
          break;
        case METHODID_LIST_CONTEXTS_BY_CONVERSATION:
          serviceImpl.listContextsByConversation((com.google.cloud.dialogflow.v2beta1.ListContextsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListContextsResponse>) responseObserver);
          break;
        case METHODID_GET_CONTEXT:
          serviceImpl.getContext((com.google.cloud.dialogflow.v2beta1.GetContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context>) responseObserver);
          break;
        case METHODID_GET_CONTEXT_BY_CONVERSATION:
          serviceImpl.getContextByConversation((com.google.cloud.dialogflow.v2beta1.GetContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context>) responseObserver);
          break;
        case METHODID_CREATE_CONTEXT:
          serviceImpl.createContext((com.google.cloud.dialogflow.v2beta1.CreateContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context>) responseObserver);
          break;
        case METHODID_CREATE_CONTEXT_BY_CONVERSATION:
          serviceImpl.createContextByConversation((com.google.cloud.dialogflow.v2beta1.CreateContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context>) responseObserver);
          break;
        case METHODID_UPDATE_CONTEXT:
          serviceImpl.updateContext((com.google.cloud.dialogflow.v2beta1.UpdateContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context>) responseObserver);
          break;
        case METHODID_UPDATE_CONTEXT_BY_CONVERSATION:
          serviceImpl.updateContextByConversation((com.google.cloud.dialogflow.v2beta1.UpdateContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Context>) responseObserver);
          break;
        case METHODID_DELETE_CONTEXT:
          serviceImpl.deleteContext((com.google.cloud.dialogflow.v2beta1.DeleteContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_DELETE_CONTEXT_BY_CONVERSATION:
          serviceImpl.deleteContextByConversation((com.google.cloud.dialogflow.v2beta1.DeleteContextRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_DELETE_ALL_CONTEXTS:
          serviceImpl.deleteAllContexts((com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_DELETE_ALL_CONTEXTS_BY_CONVERSATION:
          serviceImpl.deleteAllContextsByConversation((com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getListContextsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListContextsRequest,
              com.google.cloud.dialogflow.v2beta1.ListContextsResponse>(
                service, METHODID_LIST_CONTEXTS)))
        .addMethod(
          getListContextsByConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListContextsRequest,
              com.google.cloud.dialogflow.v2beta1.ListContextsResponse>(
                service, METHODID_LIST_CONTEXTS_BY_CONVERSATION)))
        .addMethod(
          getGetContextMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GetContextRequest,
              com.google.cloud.dialogflow.v2beta1.Context>(
                service, METHODID_GET_CONTEXT)))
        .addMethod(
          getGetContextByConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GetContextRequest,
              com.google.cloud.dialogflow.v2beta1.Context>(
                service, METHODID_GET_CONTEXT_BY_CONVERSATION)))
        .addMethod(
          getCreateContextMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CreateContextRequest,
              com.google.cloud.dialogflow.v2beta1.Context>(
                service, METHODID_CREATE_CONTEXT)))
        .addMethod(
          getCreateContextByConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CreateContextRequest,
              com.google.cloud.dialogflow.v2beta1.Context>(
                service, METHODID_CREATE_CONTEXT_BY_CONVERSATION)))
        .addMethod(
          getUpdateContextMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.UpdateContextRequest,
              com.google.cloud.dialogflow.v2beta1.Context>(
                service, METHODID_UPDATE_CONTEXT)))
        .addMethod(
          getUpdateContextByConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.UpdateContextRequest,
              com.google.cloud.dialogflow.v2beta1.Context>(
                service, METHODID_UPDATE_CONTEXT_BY_CONVERSATION)))
        .addMethod(
          getDeleteContextMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeleteContextRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_CONTEXT)))
        .addMethod(
          getDeleteContextByConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeleteContextRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_CONTEXT_BY_CONVERSATION)))
        .addMethod(
          getDeleteAllContextsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_ALL_CONTEXTS)))
        .addMethod(
          getDeleteAllContextsByConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeleteAllContextsRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_ALL_CONTEXTS_BY_CONVERSATION)))
        .build();
  }

  private static abstract class ContextsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ContextsBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.google.cloud.dialogflow.v2beta1.ContextProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("Contexts");
    }
  }

  private static final class ContextsFileDescriptorSupplier
      extends ContextsBaseDescriptorSupplier {
    ContextsFileDescriptorSupplier() {}
  }

  private static final class ContextsMethodDescriptorSupplier
      extends ContextsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    ContextsMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ContextsGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ContextsFileDescriptorSupplier())
              .addMethod(getListContextsMethod())
              .addMethod(getListContextsByConversationMethod())
              .addMethod(getGetContextMethod())
              .addMethod(getGetContextByConversationMethod())
              .addMethod(getCreateContextMethod())
              .addMethod(getCreateContextByConversationMethod())
              .addMethod(getUpdateContextMethod())
              .addMethod(getUpdateContextByConversationMethod())
              .addMethod(getDeleteContextMethod())
              .addMethod(getDeleteContextByConversationMethod())
              .addMethod(getDeleteAllContextsMethod())
              .addMethod(getDeleteAllContextsByConversationMethod())
              .build();
        }
      }
    }
    return result;
  }
}
