package com.google.cloud.dialogflow.v2beta1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Service for managing
 * [Conversations][google.cloud.dialogflow.v2beta1.Conversation].
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler",
    comments = "Source: google/cloud/dialogflow/v2beta1/conversation.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ConversationsGrpc {

  private ConversationsGrpc() {}

  public static final java.lang.String SERVICE_NAME = "google.cloud.dialogflow.v2beta1.Conversations";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getCreateConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.CreateConversationRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Conversation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getCreateConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation> getCreateConversationMethod;
    if ((getCreateConversationMethod = ConversationsGrpc.getCreateConversationMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getCreateConversationMethod = ConversationsGrpc.getCreateConversationMethod) == null) {
          ConversationsGrpc.getCreateConversationMethod = getCreateConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CreateConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CreateConversationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Conversation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("CreateConversation"))
              .build();
        }
      }
    }
    return getCreateConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListConversationsRequest,
      com.google.cloud.dialogflow.v2beta1.ListConversationsResponse> getListConversationsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListConversations",
      requestType = com.google.cloud.dialogflow.v2beta1.ListConversationsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListConversationsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListConversationsRequest,
      com.google.cloud.dialogflow.v2beta1.ListConversationsResponse> getListConversationsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListConversationsRequest, com.google.cloud.dialogflow.v2beta1.ListConversationsResponse> getListConversationsMethod;
    if ((getListConversationsMethod = ConversationsGrpc.getListConversationsMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getListConversationsMethod = ConversationsGrpc.getListConversationsMethod) == null) {
          ConversationsGrpc.getListConversationsMethod = getListConversationsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListConversationsRequest, com.google.cloud.dialogflow.v2beta1.ListConversationsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListConversations"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListConversationsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListConversationsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("ListConversations"))
              .build();
        }
      }
    }
    return getListConversationsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getGetConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.GetConversationRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Conversation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getGetConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation> getGetConversationMethod;
    if ((getGetConversationMethod = ConversationsGrpc.getGetConversationMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getGetConversationMethod = ConversationsGrpc.getGetConversationMethod) == null) {
          ConversationsGrpc.getGetConversationMethod = getGetConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GetConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GetConversationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Conversation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("GetConversation"))
              .build();
        }
      }
    }
    return getGetConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest,
      com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber> getAddConversationPhoneNumberMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "AddConversationPhoneNumber",
      requestType = com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest,
      com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber> getAddConversationPhoneNumberMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest, com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber> getAddConversationPhoneNumberMethod;
    if ((getAddConversationPhoneNumberMethod = ConversationsGrpc.getAddConversationPhoneNumberMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getAddConversationPhoneNumberMethod = ConversationsGrpc.getAddConversationPhoneNumberMethod) == null) {
          ConversationsGrpc.getAddConversationPhoneNumberMethod = getAddConversationPhoneNumberMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest, com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "AddConversationPhoneNumber"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("AddConversationPhoneNumber"))
              .build();
        }
      }
    }
    return getAddConversationPhoneNumberMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getActivateConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ActivateConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Conversation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getActivateConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation> getActivateConversationMethod;
    if ((getActivateConversationMethod = ConversationsGrpc.getActivateConversationMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getActivateConversationMethod = ConversationsGrpc.getActivateConversationMethod) == null) {
          ConversationsGrpc.getActivateConversationMethod = getActivateConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ActivateConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Conversation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("ActivateConversation"))
              .build();
        }
      }
    }
    return getActivateConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getDeactivateConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeactivateConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Conversation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getDeactivateConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation> getDeactivateConversationMethod;
    if ((getDeactivateConversationMethod = ConversationsGrpc.getDeactivateConversationMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getDeactivateConversationMethod = ConversationsGrpc.getDeactivateConversationMethod) == null) {
          ConversationsGrpc.getDeactivateConversationMethod = getDeactivateConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeactivateConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Conversation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("DeactivateConversation"))
              .build();
        }
      }
    }
    return getDeactivateConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getCompleteConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CompleteConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Conversation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getCompleteConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation> getCompleteConversationMethod;
    if ((getCompleteConversationMethod = ConversationsGrpc.getCompleteConversationMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getCompleteConversationMethod = ConversationsGrpc.getCompleteConversationMethod) == null) {
          ConversationsGrpc.getCompleteConversationMethod = getCompleteConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CompleteConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Conversation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("CompleteConversation"))
              .build();
        }
      }
    }
    return getCompleteConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getUpdateConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "UpdateConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.Conversation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest,
      com.google.cloud.dialogflow.v2beta1.Conversation> getUpdateConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation> getUpdateConversationMethod;
    if ((getUpdateConversationMethod = ConversationsGrpc.getUpdateConversationMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getUpdateConversationMethod = ConversationsGrpc.getUpdateConversationMethod) == null) {
          ConversationsGrpc.getUpdateConversationMethod = getUpdateConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest, com.google.cloud.dialogflow.v2beta1.Conversation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "UpdateConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.Conversation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("UpdateConversation"))
              .build();
        }
      }
    }
    return getUpdateConversationMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest,
      com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse> getIngestContextReferencesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "IngestContextReferences",
      requestType = com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest,
      com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse> getIngestContextReferencesMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest, com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse> getIngestContextReferencesMethod;
    if ((getIngestContextReferencesMethod = ConversationsGrpc.getIngestContextReferencesMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getIngestContextReferencesMethod = ConversationsGrpc.getIngestContextReferencesMethod) == null) {
          ConversationsGrpc.getIngestContextReferencesMethod = getIngestContextReferencesMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest, com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "IngestContextReferences"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("IngestContextReferences"))
              .build();
        }
      }
    }
    return getIngestContextReferencesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest,
      com.google.cloud.dialogflow.v2beta1.CallMatcher> getCreateCallMatcherMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateCallMatcher",
      requestType = com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.CallMatcher.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest,
      com.google.cloud.dialogflow.v2beta1.CallMatcher> getCreateCallMatcherMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest, com.google.cloud.dialogflow.v2beta1.CallMatcher> getCreateCallMatcherMethod;
    if ((getCreateCallMatcherMethod = ConversationsGrpc.getCreateCallMatcherMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getCreateCallMatcherMethod = ConversationsGrpc.getCreateCallMatcherMethod) == null) {
          ConversationsGrpc.getCreateCallMatcherMethod = getCreateCallMatcherMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest, com.google.cloud.dialogflow.v2beta1.CallMatcher>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateCallMatcher"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CallMatcher.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("CreateCallMatcher"))
              .build();
        }
      }
    }
    return getCreateCallMatcherMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest,
      com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse> getListCallMatchersMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListCallMatchers",
      requestType = com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest,
      com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse> getListCallMatchersMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest, com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse> getListCallMatchersMethod;
    if ((getListCallMatchersMethod = ConversationsGrpc.getListCallMatchersMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getListCallMatchersMethod = ConversationsGrpc.getListCallMatchersMethod) == null) {
          ConversationsGrpc.getListCallMatchersMethod = getListCallMatchersMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest, com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListCallMatchers"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("ListCallMatchers"))
              .build();
        }
      }
    }
    return getListCallMatchersMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest,
      com.google.protobuf.Empty> getDeleteCallMatcherMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteCallMatcher",
      requestType = com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest,
      com.google.protobuf.Empty> getDeleteCallMatcherMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest, com.google.protobuf.Empty> getDeleteCallMatcherMethod;
    if ((getDeleteCallMatcherMethod = ConversationsGrpc.getDeleteCallMatcherMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getDeleteCallMatcherMethod = ConversationsGrpc.getDeleteCallMatcherMethod) == null) {
          ConversationsGrpc.getDeleteCallMatcherMethod = getDeleteCallMatcherMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteCallMatcher"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("DeleteCallMatcher"))
              .build();
        }
      }
    }
    return getDeleteCallMatcherMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest,
      com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse> getBatchCreateMessagesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "BatchCreateMessages",
      requestType = com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest,
      com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse> getBatchCreateMessagesMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest, com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse> getBatchCreateMessagesMethod;
    if ((getBatchCreateMessagesMethod = ConversationsGrpc.getBatchCreateMessagesMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getBatchCreateMessagesMethod = ConversationsGrpc.getBatchCreateMessagesMethod) == null) {
          ConversationsGrpc.getBatchCreateMessagesMethod = getBatchCreateMessagesMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest, com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "BatchCreateMessages"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("BatchCreateMessages"))
              .build();
        }
      }
    }
    return getBatchCreateMessagesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListMessagesRequest,
      com.google.cloud.dialogflow.v2beta1.ListMessagesResponse> getListMessagesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListMessages",
      requestType = com.google.cloud.dialogflow.v2beta1.ListMessagesRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListMessagesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListMessagesRequest,
      com.google.cloud.dialogflow.v2beta1.ListMessagesResponse> getListMessagesMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListMessagesRequest, com.google.cloud.dialogflow.v2beta1.ListMessagesResponse> getListMessagesMethod;
    if ((getListMessagesMethod = ConversationsGrpc.getListMessagesMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getListMessagesMethod = ConversationsGrpc.getListMessagesMethod) == null) {
          ConversationsGrpc.getListMessagesMethod = getListMessagesMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListMessagesRequest, com.google.cloud.dialogflow.v2beta1.ListMessagesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListMessages"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListMessagesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListMessagesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("ListMessages"))
              .build();
        }
      }
    }
    return getListMessagesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest,
      com.google.longrunning.Operation> getExportMessagesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ExportMessages",
      requestType = com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest.class,
      responseType = com.google.longrunning.Operation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest,
      com.google.longrunning.Operation> getExportMessagesMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest, com.google.longrunning.Operation> getExportMessagesMethod;
    if ((getExportMessagesMethod = ConversationsGrpc.getExportMessagesMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getExportMessagesMethod = ConversationsGrpc.getExportMessagesMethod) == null) {
          ConversationsGrpc.getExportMessagesMethod = getExportMessagesMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest, com.google.longrunning.Operation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ExportMessages"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.longrunning.Operation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("ExportMessages"))
              .build();
        }
      }
    }
    return getExportMessagesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest,
      com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse> getSuggestConversationSummaryMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SuggestConversationSummary",
      requestType = com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest,
      com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse> getSuggestConversationSummaryMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest, com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse> getSuggestConversationSummaryMethod;
    if ((getSuggestConversationSummaryMethod = ConversationsGrpc.getSuggestConversationSummaryMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getSuggestConversationSummaryMethod = ConversationsGrpc.getSuggestConversationSummaryMethod) == null) {
          ConversationsGrpc.getSuggestConversationSummaryMethod = getSuggestConversationSummaryMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest, com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SuggestConversationSummary"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("SuggestConversationSummary"))
              .build();
        }
      }
    }
    return getSuggestConversationSummaryMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest,
      com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse> getGenerateStatelessSummaryMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GenerateStatelessSummary",
      requestType = com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest,
      com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse> getGenerateStatelessSummaryMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest, com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse> getGenerateStatelessSummaryMethod;
    if ((getGenerateStatelessSummaryMethod = ConversationsGrpc.getGenerateStatelessSummaryMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getGenerateStatelessSummaryMethod = ConversationsGrpc.getGenerateStatelessSummaryMethod) == null) {
          ConversationsGrpc.getGenerateStatelessSummaryMethod = getGenerateStatelessSummaryMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest, com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GenerateStatelessSummary"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("GenerateStatelessSummary"))
              .build();
        }
      }
    }
    return getGenerateStatelessSummaryMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest,
      com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse> getGenerateStatelessSuggestionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GenerateStatelessSuggestion",
      requestType = com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest,
      com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse> getGenerateStatelessSuggestionMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest, com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse> getGenerateStatelessSuggestionMethod;
    if ((getGenerateStatelessSuggestionMethod = ConversationsGrpc.getGenerateStatelessSuggestionMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getGenerateStatelessSuggestionMethod = ConversationsGrpc.getGenerateStatelessSuggestionMethod) == null) {
          ConversationsGrpc.getGenerateStatelessSuggestionMethod = getGenerateStatelessSuggestionMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest, com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GenerateStatelessSuggestion"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("GenerateStatelessSuggestion"))
              .build();
        }
      }
    }
    return getGenerateStatelessSuggestionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest,
      com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse> getSuggestConversationKeyMomentsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SuggestConversationKeyMoments",
      requestType = com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest,
      com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse> getSuggestConversationKeyMomentsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest, com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse> getSuggestConversationKeyMomentsMethod;
    if ((getSuggestConversationKeyMomentsMethod = ConversationsGrpc.getSuggestConversationKeyMomentsMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getSuggestConversationKeyMomentsMethod = ConversationsGrpc.getSuggestConversationKeyMomentsMethod) == null) {
          ConversationsGrpc.getSuggestConversationKeyMomentsMethod = getSuggestConversationKeyMomentsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest, com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SuggestConversationKeyMoments"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("SuggestConversationKeyMoments"))
              .build();
        }
      }
    }
    return getSuggestConversationKeyMomentsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest,
      com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse> getSearchArticlesMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SearchArticles",
      requestType = com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest,
      com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse> getSearchArticlesMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest, com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse> getSearchArticlesMethod;
    if ((getSearchArticlesMethod = ConversationsGrpc.getSearchArticlesMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getSearchArticlesMethod = ConversationsGrpc.getSearchArticlesMethod) == null) {
          ConversationsGrpc.getSearchArticlesMethod = getSearchArticlesMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest, com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SearchArticles"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("SearchArticles"))
              .build();
        }
      }
    }
    return getSearchArticlesMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest,
      com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse> getListPastCallCompanionEventsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListPastCallCompanionEvents",
      requestType = com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest,
      com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse> getListPastCallCompanionEventsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest, com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse> getListPastCallCompanionEventsMethod;
    if ((getListPastCallCompanionEventsMethod = ConversationsGrpc.getListPastCallCompanionEventsMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getListPastCallCompanionEventsMethod = ConversationsGrpc.getListPastCallCompanionEventsMethod) == null) {
          ConversationsGrpc.getListPastCallCompanionEventsMethod = getListPastCallCompanionEventsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest, com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListPastCallCompanionEvents"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("ListPastCallCompanionEvents"))
              .build();
        }
      }
    }
    return getListPastCallCompanionEventsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest,
      com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse> getStreamingListUpcomingCallCompanionEventsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamingListUpcomingCallCompanionEvents",
      requestType = com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest,
      com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse> getStreamingListUpcomingCallCompanionEventsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest, com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse> getStreamingListUpcomingCallCompanionEventsMethod;
    if ((getStreamingListUpcomingCallCompanionEventsMethod = ConversationsGrpc.getStreamingListUpcomingCallCompanionEventsMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getStreamingListUpcomingCallCompanionEventsMethod = ConversationsGrpc.getStreamingListUpcomingCallCompanionEventsMethod) == null) {
          ConversationsGrpc.getStreamingListUpcomingCallCompanionEventsMethod = getStreamingListUpcomingCallCompanionEventsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest, com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamingListUpcomingCallCompanionEvents"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("StreamingListUpcomingCallCompanionEvents"))
              .build();
        }
      }
    }
    return getStreamingListUpcomingCallCompanionEventsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest,
      com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse> getInjectCallCompanionUserInputMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "InjectCallCompanionUserInput",
      requestType = com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest,
      com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse> getInjectCallCompanionUserInputMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest, com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse> getInjectCallCompanionUserInputMethod;
    if ((getInjectCallCompanionUserInputMethod = ConversationsGrpc.getInjectCallCompanionUserInputMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getInjectCallCompanionUserInputMethod = ConversationsGrpc.getInjectCallCompanionUserInputMethod) == null) {
          ConversationsGrpc.getInjectCallCompanionUserInputMethod = getInjectCallCompanionUserInputMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest, com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "InjectCallCompanionUserInput"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("InjectCallCompanionUserInput"))
              .build();
        }
      }
    }
    return getInjectCallCompanionUserInputMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest,
      com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse> getStreamingListCallCompanionEventsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "StreamingListCallCompanionEvents",
      requestType = com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest,
      com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse> getStreamingListCallCompanionEventsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest, com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse> getStreamingListCallCompanionEventsMethod;
    if ((getStreamingListCallCompanionEventsMethod = ConversationsGrpc.getStreamingListCallCompanionEventsMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getStreamingListCallCompanionEventsMethod = ConversationsGrpc.getStreamingListCallCompanionEventsMethod) == null) {
          ConversationsGrpc.getStreamingListCallCompanionEventsMethod = getStreamingListCallCompanionEventsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest, com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.SERVER_STREAMING)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "StreamingListCallCompanionEvents"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("StreamingListCallCompanionEvents"))
              .build();
        }
      }
    }
    return getStreamingListCallCompanionEventsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest,
      com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse> getInjectCallCompanionInputMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "InjectCallCompanionInput",
      requestType = com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest,
      com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse> getInjectCallCompanionInputMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest, com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse> getInjectCallCompanionInputMethod;
    if ((getInjectCallCompanionInputMethod = ConversationsGrpc.getInjectCallCompanionInputMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getInjectCallCompanionInputMethod = ConversationsGrpc.getInjectCallCompanionInputMethod) == null) {
          ConversationsGrpc.getInjectCallCompanionInputMethod = getInjectCallCompanionInputMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest, com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "InjectCallCompanionInput"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("InjectCallCompanionInput"))
              .build();
        }
      }
    }
    return getInjectCallCompanionInputMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest,
      com.google.protobuf.Empty> getInitializeCallCompanionMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "InitializeCallCompanion",
      requestType = com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest,
      com.google.protobuf.Empty> getInitializeCallCompanionMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest, com.google.protobuf.Empty> getInitializeCallCompanionMethod;
    if ((getInitializeCallCompanionMethod = ConversationsGrpc.getInitializeCallCompanionMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getInitializeCallCompanionMethod = ConversationsGrpc.getInitializeCallCompanionMethod) == null) {
          ConversationsGrpc.getInitializeCallCompanionMethod = getInitializeCallCompanionMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "InitializeCallCompanion"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("InitializeCallCompanion"))
              .build();
        }
      }
    }
    return getInitializeCallCompanionMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest,
      com.google.cloud.dialogflow.v2beta1.CallCompanionSettings> getGetCallCompanionSettingsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetCallCompanionSettings",
      requestType = com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.CallCompanionSettings.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest,
      com.google.cloud.dialogflow.v2beta1.CallCompanionSettings> getGetCallCompanionSettingsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest, com.google.cloud.dialogflow.v2beta1.CallCompanionSettings> getGetCallCompanionSettingsMethod;
    if ((getGetCallCompanionSettingsMethod = ConversationsGrpc.getGetCallCompanionSettingsMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getGetCallCompanionSettingsMethod = ConversationsGrpc.getGetCallCompanionSettingsMethod) == null) {
          ConversationsGrpc.getGetCallCompanionSettingsMethod = getGetCallCompanionSettingsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest, com.google.cloud.dialogflow.v2beta1.CallCompanionSettings>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetCallCompanionSettings"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CallCompanionSettings.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("GetCallCompanionSettings"))
              .build();
        }
      }
    }
    return getGetCallCompanionSettingsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest,
      com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse> getSearchKnowledgeMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "SearchKnowledge",
      requestType = com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest,
      com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse> getSearchKnowledgeMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest, com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse> getSearchKnowledgeMethod;
    if ((getSearchKnowledgeMethod = ConversationsGrpc.getSearchKnowledgeMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getSearchKnowledgeMethod = ConversationsGrpc.getSearchKnowledgeMethod) == null) {
          ConversationsGrpc.getSearchKnowledgeMethod = getSearchKnowledgeMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest, com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "SearchKnowledge"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("SearchKnowledge"))
              .build();
        }
      }
    }
    return getSearchKnowledgeMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest,
      com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse> getGenerateSuggestionsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GenerateSuggestions",
      requestType = com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest,
      com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse> getGenerateSuggestionsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest, com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse> getGenerateSuggestionsMethod;
    if ((getGenerateSuggestionsMethod = ConversationsGrpc.getGenerateSuggestionsMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getGenerateSuggestionsMethod = ConversationsGrpc.getGenerateSuggestionsMethod) == null) {
          ConversationsGrpc.getGenerateSuggestionsMethod = getGenerateSuggestionsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest, com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GenerateSuggestions"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("GenerateSuggestions"))
              .build();
        }
      }
    }
    return getGenerateSuggestionsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest,
      com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse> getInitiatePhoneCallMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "InitiatePhoneCall",
      requestType = com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest,
      com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse> getInitiatePhoneCallMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest, com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse> getInitiatePhoneCallMethod;
    if ((getInitiatePhoneCallMethod = ConversationsGrpc.getInitiatePhoneCallMethod) == null) {
      synchronized (ConversationsGrpc.class) {
        if ((getInitiatePhoneCallMethod = ConversationsGrpc.getInitiatePhoneCallMethod) == null) {
          ConversationsGrpc.getInitiatePhoneCallMethod = getInitiatePhoneCallMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest, com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "InitiatePhoneCall"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationsMethodDescriptorSupplier("InitiatePhoneCall"))
              .build();
        }
      }
    }
    return getInitiatePhoneCallMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ConversationsStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConversationsStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConversationsStub>() {
        @java.lang.Override
        public ConversationsStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConversationsStub(channel, callOptions);
        }
      };
    return ConversationsStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static ConversationsBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConversationsBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConversationsBlockingV2Stub>() {
        @java.lang.Override
        public ConversationsBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConversationsBlockingV2Stub(channel, callOptions);
        }
      };
    return ConversationsBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ConversationsBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConversationsBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConversationsBlockingStub>() {
        @java.lang.Override
        public ConversationsBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConversationsBlockingStub(channel, callOptions);
        }
      };
    return ConversationsBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ConversationsFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConversationsFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConversationsFutureStub>() {
        @java.lang.Override
        public ConversationsFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConversationsFutureStub(channel, callOptions);
        }
      };
    return ConversationsFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Service for managing
   * [Conversations][google.cloud.dialogflow.v2beta1.Conversation].
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Creates a new conversation. Conversations are auto-completed after 24
     * hours.
     * Conversation Lifecycle:
     * There are two stages during a conversation: Automated Agent Stage and
     * Assist Stage.
     * For Automated Agent Stage, there will be a dialogflow agent responding to
     * user queries.
     * For Assist Stage, there's no dialogflow agent responding to user queries.
     * But we will provide suggestions which are generated from conversation.
     * If
     * [Conversation.conversation_profile][google.cloud.dialogflow.v2beta1.Conversation.conversation_profile]
     * is configured for a dialogflow agent, conversation will start from
     * `Automated Agent Stage`, otherwise, it will start from `Assist Stage`. And
     * during `Automated Agent Stage`, once an
     * [Intent][google.cloud.dialogflow.v2beta1.Intent] with
     * [Intent.live_agent_handoff][google.cloud.dialogflow.v2beta1.Intent.live_agent_handoff]
     * is triggered, conversation will transfer to Assist Stage.
     * </pre>
     */
    default void createConversation(com.google.cloud.dialogflow.v2beta1.CreateConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all conversations in the specified project.
     * </pre>
     */
    default void listConversations(com.google.cloud.dialogflow.v2beta1.ListConversationsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListConversationsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListConversationsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specific conversation.
     * </pre>
     */
    default void getConversation(com.google.cloud.dialogflow.v2beta1.GetConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Sets a phone number for this conversation to connect to.
     * Note: The conversation in the request must be in IN_PROGRESS status and
     * must have no phone number attached.
     * </pre>
     */
    default void addConversationPhoneNumber(com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getAddConversationPhoneNumberMethod(), responseObserver);
    }

    /**
     * <pre>
     * Activates the specified conversation.
     * Used for telephony-based conversations that are started with inactive
     * SIP attribute.
     * </pre>
     */
    default void activateConversation(com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getActivateConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deactivates the specified conversation.
     * Sets the SDP direction of the telephony call associated with this
     * conversation to inactive.
     * </pre>
     */
    default void deactivateConversation(com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeactivateConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Completes the specified conversation. Finished conversations are purged
     * from the database after 30 days.
     * </pre>
     */
    default void completeConversation(com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCompleteConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Updates the specified conversation.
     * </pre>
     */
    default void updateConversation(com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getUpdateConversationMethod(), responseObserver);
    }

    /**
     * <pre>
     * Data ingestion API.
     * Ingests context references for an existing conversation.
     * </pre>
     */
    default void ingestContextReferences(com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getIngestContextReferencesMethod(), responseObserver);
    }

    /**
     * <pre>
     * Creates a call matcher that links incoming SIP calls to the specified
     * conversation if they fulfill specified criteria.
     * </pre>
     */
    default void createCallMatcher(com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CallMatcher> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateCallMatcherMethod(), responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all call matchers in the specified conversation.
     * </pre>
     */
    default void listCallMatchers(com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListCallMatchersMethod(), responseObserver);
    }

    /**
     * <pre>
     * Requests deletion of a call matcher.
     * </pre>
     */
    default void deleteCallMatcher(com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteCallMatcherMethod(), responseObserver);
    }

    /**
     * <pre>
     * Batch ingests messages to conversation. Customers can use this RPC to
     * ingest historical messages to conversation.
     * </pre>
     */
    default void batchCreateMessages(com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getBatchCreateMessagesMethod(), responseObserver);
    }

    /**
     * <pre>
     * Lists messages that belong to a given conversation.
     * `messages` are ordered by `create_time` in descending order. To fetch
     * updates without duplication, send request with filter
     * `create_time_epoch_microseconds &gt;
     * [first item's create_time of previous request]` and empty page_token.
     * </pre>
     */
    default void listMessages(com.google.cloud.dialogflow.v2beta1.ListMessagesRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListMessagesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListMessagesMethod(), responseObserver);
    }

    /**
     * <pre>
     * Exports messages from a range of conversations to a Google Cloud Storage
     * bucket. Each conversation is exported as a separate JSON transcript to the
     * bucket. Only closed conversations are exported, and if redaction is
     * configured, the exported text messages are redacted as well.
     * Note: this method is pre-alpha and is subject to incompatible changes.
     * </pre>
     */
    default void exportMessages(com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getExportMessagesMethod(), responseObserver);
    }

    /**
     * <pre>
     * Suggest summary for a conversation based on specific historical messages.
     * The range of the messages to be used for summary can be specified in the
     * request.
     * </pre>
     */
    default void suggestConversationSummary(com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSuggestConversationSummaryMethod(), responseObserver);
    }

    /**
     * <pre>
     * Generates and returns a summary for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    default void generateStatelessSummary(com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGenerateStatelessSummaryMethod(), responseObserver);
    }

    /**
     * <pre>
     * Generates and returns a suggestion for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    default void generateStatelessSuggestion(com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGenerateStatelessSuggestionMethod(), responseObserver);
    }

    /**
     * <pre>
     * Suggest key moments for a conversation based on specific historical
     * messages.
     * </pre>
     */
    default void suggestConversationKeyMoments(com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSuggestConversationKeyMomentsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Gets relevant articles by performing a search using the given query.
     * </pre>
     */
    default void searchArticles(com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSearchArticlesMethod(), responseObserver);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets all Call Companion
     * conversation events that have occurred so far.
     * </pre>
     */
    default void listPastCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListPastCallCompanionEventsMethod(), responseObserver);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets the incoming
     * conversation events as a server-side stream.
     * </pre>
     */
    default void streamingListUpcomingCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamingListUpcomingCallCompanionEventsMethod(), responseObserver);
    }

    /**
     * <pre>
     * For the Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    default void injectCallCompanionUserInput(com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getInjectCallCompanionUserInputMethod(), responseObserver);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI to get conversation events as a stream.
     * </pre>
     */
    default void streamingListCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getStreamingListCallCompanionEventsMethod(), responseObserver);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    default void injectCallCompanionInput(com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getInjectCallCompanionInputMethod(), responseObserver);
    }

    /**
     * <pre>
     * Initialize the resources for Call Companion UI.
     * </pre>
     */
    default void initializeCallCompanion(com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getInitializeCallCompanionMethod(), responseObserver);
    }

    /**
     * <pre>
     * Gets the settings for Call Companion UI.
     * </pre>
     */
    default void getCallCompanionSettings(com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CallCompanionSettings> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetCallCompanionSettingsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Get answers for the given query based on knowledge documents.
     * </pre>
     */
    default void searchKnowledge(com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getSearchKnowledgeMethod(), responseObserver);
    }

    /**
     * <pre>
     * Generates all the suggestions using generators configured in the
     * conversation profile. A generator is used only if its trigger event is
     * matched.
     * </pre>
     */
    default void generateSuggestions(com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGenerateSuggestionsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Initiates an outbound phone call with this conversation.
     * </pre>
     */
    default void initiatePhoneCall(com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getInitiatePhoneCallMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service Conversations.
   * <pre>
   * Service for managing
   * [Conversations][google.cloud.dialogflow.v2beta1.Conversation].
   * </pre>
   */
  public static abstract class ConversationsImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return ConversationsGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service Conversations.
   * <pre>
   * Service for managing
   * [Conversations][google.cloud.dialogflow.v2beta1.Conversation].
   * </pre>
   */
  public static final class ConversationsStub
      extends io.grpc.stub.AbstractAsyncStub<ConversationsStub> {
    private ConversationsStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConversationsStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConversationsStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a new conversation. Conversations are auto-completed after 24
     * hours.
     * Conversation Lifecycle:
     * There are two stages during a conversation: Automated Agent Stage and
     * Assist Stage.
     * For Automated Agent Stage, there will be a dialogflow agent responding to
     * user queries.
     * For Assist Stage, there's no dialogflow agent responding to user queries.
     * But we will provide suggestions which are generated from conversation.
     * If
     * [Conversation.conversation_profile][google.cloud.dialogflow.v2beta1.Conversation.conversation_profile]
     * is configured for a dialogflow agent, conversation will start from
     * `Automated Agent Stage`, otherwise, it will start from `Assist Stage`. And
     * during `Automated Agent Stage`, once an
     * [Intent][google.cloud.dialogflow.v2beta1.Intent] with
     * [Intent.live_agent_handoff][google.cloud.dialogflow.v2beta1.Intent.live_agent_handoff]
     * is triggered, conversation will transfer to Assist Stage.
     * </pre>
     */
    public void createConversation(com.google.cloud.dialogflow.v2beta1.CreateConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all conversations in the specified project.
     * </pre>
     */
    public void listConversations(com.google.cloud.dialogflow.v2beta1.ListConversationsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListConversationsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListConversationsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specific conversation.
     * </pre>
     */
    public void getConversation(com.google.cloud.dialogflow.v2beta1.GetConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Sets a phone number for this conversation to connect to.
     * Note: The conversation in the request must be in IN_PROGRESS status and
     * must have no phone number attached.
     * </pre>
     */
    public void addConversationPhoneNumber(com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getAddConversationPhoneNumberMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Activates the specified conversation.
     * Used for telephony-based conversations that are started with inactive
     * SIP attribute.
     * </pre>
     */
    public void activateConversation(com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getActivateConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Deactivates the specified conversation.
     * Sets the SDP direction of the telephony call associated with this
     * conversation to inactive.
     * </pre>
     */
    public void deactivateConversation(com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeactivateConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Completes the specified conversation. Finished conversations are purged
     * from the database after 30 days.
     * </pre>
     */
    public void completeConversation(com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCompleteConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Updates the specified conversation.
     * </pre>
     */
    public void updateConversation(com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getUpdateConversationMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Data ingestion API.
     * Ingests context references for an existing conversation.
     * </pre>
     */
    public void ingestContextReferences(com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getIngestContextReferencesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Creates a call matcher that links incoming SIP calls to the specified
     * conversation if they fulfill specified criteria.
     * </pre>
     */
    public void createCallMatcher(com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CallMatcher> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateCallMatcherMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all call matchers in the specified conversation.
     * </pre>
     */
    public void listCallMatchers(com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListCallMatchersMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Requests deletion of a call matcher.
     * </pre>
     */
    public void deleteCallMatcher(com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteCallMatcherMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Batch ingests messages to conversation. Customers can use this RPC to
     * ingest historical messages to conversation.
     * </pre>
     */
    public void batchCreateMessages(com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getBatchCreateMessagesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Lists messages that belong to a given conversation.
     * `messages` are ordered by `create_time` in descending order. To fetch
     * updates without duplication, send request with filter
     * `create_time_epoch_microseconds &gt;
     * [first item's create_time of previous request]` and empty page_token.
     * </pre>
     */
    public void listMessages(com.google.cloud.dialogflow.v2beta1.ListMessagesRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListMessagesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListMessagesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Exports messages from a range of conversations to a Google Cloud Storage
     * bucket. Each conversation is exported as a separate JSON transcript to the
     * bucket. Only closed conversations are exported, and if redaction is
     * configured, the exported text messages are redacted as well.
     * Note: this method is pre-alpha and is subject to incompatible changes.
     * </pre>
     */
    public void exportMessages(com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getExportMessagesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Suggest summary for a conversation based on specific historical messages.
     * The range of the messages to be used for summary can be specified in the
     * request.
     * </pre>
     */
    public void suggestConversationSummary(com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSuggestConversationSummaryMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Generates and returns a summary for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    public void generateStatelessSummary(com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGenerateStatelessSummaryMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Generates and returns a suggestion for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    public void generateStatelessSuggestion(com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGenerateStatelessSuggestionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Suggest key moments for a conversation based on specific historical
     * messages.
     * </pre>
     */
    public void suggestConversationKeyMoments(com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSuggestConversationKeyMomentsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Gets relevant articles by performing a search using the given query.
     * </pre>
     */
    public void searchArticles(com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSearchArticlesMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets all Call Companion
     * conversation events that have occurred so far.
     * </pre>
     */
    public void listPastCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListPastCallCompanionEventsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets the incoming
     * conversation events as a server-side stream.
     * </pre>
     */
    public void streamingListUpcomingCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamingListUpcomingCallCompanionEventsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * For the Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    public void injectCallCompanionUserInput(com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getInjectCallCompanionUserInputMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI to get conversation events as a stream.
     * </pre>
     */
    public void streamingListCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncServerStreamingCall(
          getChannel().newCall(getStreamingListCallCompanionEventsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    public void injectCallCompanionInput(com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getInjectCallCompanionInputMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Initialize the resources for Call Companion UI.
     * </pre>
     */
    public void initializeCallCompanion(com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getInitializeCallCompanionMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Gets the settings for Call Companion UI.
     * </pre>
     */
    public void getCallCompanionSettings(com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CallCompanionSettings> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetCallCompanionSettingsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Get answers for the given query based on knowledge documents.
     * </pre>
     */
    public void searchKnowledge(com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getSearchKnowledgeMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Generates all the suggestions using generators configured in the
     * conversation profile. A generator is used only if its trigger event is
     * matched.
     * </pre>
     */
    public void generateSuggestions(com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGenerateSuggestionsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Initiates an outbound phone call with this conversation.
     * </pre>
     */
    public void initiatePhoneCall(com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getInitiatePhoneCallMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service Conversations.
   * <pre>
   * Service for managing
   * [Conversations][google.cloud.dialogflow.v2beta1.Conversation].
   * </pre>
   */
  public static final class ConversationsBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<ConversationsBlockingV2Stub> {
    private ConversationsBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConversationsBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConversationsBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a new conversation. Conversations are auto-completed after 24
     * hours.
     * Conversation Lifecycle:
     * There are two stages during a conversation: Automated Agent Stage and
     * Assist Stage.
     * For Automated Agent Stage, there will be a dialogflow agent responding to
     * user queries.
     * For Assist Stage, there's no dialogflow agent responding to user queries.
     * But we will provide suggestions which are generated from conversation.
     * If
     * [Conversation.conversation_profile][google.cloud.dialogflow.v2beta1.Conversation.conversation_profile]
     * is configured for a dialogflow agent, conversation will start from
     * `Automated Agent Stage`, otherwise, it will start from `Assist Stage`. And
     * during `Automated Agent Stage`, once an
     * [Intent][google.cloud.dialogflow.v2beta1.Intent] with
     * [Intent.live_agent_handoff][google.cloud.dialogflow.v2beta1.Intent.live_agent_handoff]
     * is triggered, conversation will transfer to Assist Stage.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation createConversation(com.google.cloud.dialogflow.v2beta1.CreateConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all conversations in the specified project.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListConversationsResponse listConversations(com.google.cloud.dialogflow.v2beta1.ListConversationsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListConversationsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specific conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation getConversation(com.google.cloud.dialogflow.v2beta1.GetConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Sets a phone number for this conversation to connect to.
     * Note: The conversation in the request must be in IN_PROGRESS status and
     * must have no phone number attached.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber addConversationPhoneNumber(com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddConversationPhoneNumberMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Activates the specified conversation.
     * Used for telephony-based conversations that are started with inactive
     * SIP attribute.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation activateConversation(com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getActivateConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deactivates the specified conversation.
     * Sets the SDP direction of the telephony call associated with this
     * conversation to inactive.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation deactivateConversation(com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeactivateConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Completes the specified conversation. Finished conversations are purged
     * from the database after 30 days.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation completeConversation(com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCompleteConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation updateConversation(com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Data ingestion API.
     * Ingests context references for an existing conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse ingestContextReferences(com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getIngestContextReferencesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates a call matcher that links incoming SIP calls to the specified
     * conversation if they fulfill specified criteria.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.CallMatcher createCallMatcher(com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateCallMatcherMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all call matchers in the specified conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse listCallMatchers(com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListCallMatchersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Requests deletion of a call matcher.
     * </pre>
     */
    public com.google.protobuf.Empty deleteCallMatcher(com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteCallMatcherMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Batch ingests messages to conversation. Customers can use this RPC to
     * ingest historical messages to conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse batchCreateMessages(com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBatchCreateMessagesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Lists messages that belong to a given conversation.
     * `messages` are ordered by `create_time` in descending order. To fetch
     * updates without duplication, send request with filter
     * `create_time_epoch_microseconds &gt;
     * [first item's create_time of previous request]` and empty page_token.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListMessagesResponse listMessages(com.google.cloud.dialogflow.v2beta1.ListMessagesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListMessagesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Exports messages from a range of conversations to a Google Cloud Storage
     * bucket. Each conversation is exported as a separate JSON transcript to the
     * bucket. Only closed conversations are exported, and if redaction is
     * configured, the exported text messages are redacted as well.
     * Note: this method is pre-alpha and is subject to incompatible changes.
     * </pre>
     */
    public com.google.longrunning.Operation exportMessages(com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExportMessagesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Suggest summary for a conversation based on specific historical messages.
     * The range of the messages to be used for summary can be specified in the
     * request.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse suggestConversationSummary(com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSuggestConversationSummaryMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Generates and returns a summary for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse generateStatelessSummary(com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGenerateStatelessSummaryMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Generates and returns a suggestion for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse generateStatelessSuggestion(com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGenerateStatelessSuggestionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Suggest key moments for a conversation based on specific historical
     * messages.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse suggestConversationKeyMoments(com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSuggestConversationKeyMomentsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Gets relevant articles by performing a search using the given query.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse searchArticles(com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSearchArticlesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets all Call Companion
     * conversation events that have occurred so far.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse listPastCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListPastCallCompanionEventsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets the incoming
     * conversation events as a server-side stream.
     * </pre>
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<?, com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse>
        streamingListUpcomingCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest request) {
      return io.grpc.stub.ClientCalls.blockingV2ServerStreamingCall(
          getChannel(), getStreamingListUpcomingCallCompanionEventsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse injectCallCompanionUserInput(com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInjectCallCompanionUserInputMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI to get conversation events as a stream.
     * </pre>
     */
    @io.grpc.ExperimentalApi("https://github.com/grpc/grpc-java/issues/10918")
    public io.grpc.stub.BlockingClientCall<?, com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse>
        streamingListCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest request) {
      return io.grpc.stub.ClientCalls.blockingV2ServerStreamingCall(
          getChannel(), getStreamingListCallCompanionEventsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse injectCallCompanionInput(com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInjectCallCompanionInputMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Initialize the resources for Call Companion UI.
     * </pre>
     */
    public com.google.protobuf.Empty initializeCallCompanion(com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInitializeCallCompanionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Gets the settings for Call Companion UI.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.CallCompanionSettings getCallCompanionSettings(com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCallCompanionSettingsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Get answers for the given query based on knowledge documents.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse searchKnowledge(com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSearchKnowledgeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Generates all the suggestions using generators configured in the
     * conversation profile. A generator is used only if its trigger event is
     * matched.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse generateSuggestions(com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGenerateSuggestionsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Initiates an outbound phone call with this conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse initiatePhoneCall(com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInitiatePhoneCallMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service Conversations.
   * <pre>
   * Service for managing
   * [Conversations][google.cloud.dialogflow.v2beta1.Conversation].
   * </pre>
   */
  public static final class ConversationsBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<ConversationsBlockingStub> {
    private ConversationsBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConversationsBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConversationsBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a new conversation. Conversations are auto-completed after 24
     * hours.
     * Conversation Lifecycle:
     * There are two stages during a conversation: Automated Agent Stage and
     * Assist Stage.
     * For Automated Agent Stage, there will be a dialogflow agent responding to
     * user queries.
     * For Assist Stage, there's no dialogflow agent responding to user queries.
     * But we will provide suggestions which are generated from conversation.
     * If
     * [Conversation.conversation_profile][google.cloud.dialogflow.v2beta1.Conversation.conversation_profile]
     * is configured for a dialogflow agent, conversation will start from
     * `Automated Agent Stage`, otherwise, it will start from `Assist Stage`. And
     * during `Automated Agent Stage`, once an
     * [Intent][google.cloud.dialogflow.v2beta1.Intent] with
     * [Intent.live_agent_handoff][google.cloud.dialogflow.v2beta1.Intent.live_agent_handoff]
     * is triggered, conversation will transfer to Assist Stage.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation createConversation(com.google.cloud.dialogflow.v2beta1.CreateConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all conversations in the specified project.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListConversationsResponse listConversations(com.google.cloud.dialogflow.v2beta1.ListConversationsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListConversationsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specific conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation getConversation(com.google.cloud.dialogflow.v2beta1.GetConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Sets a phone number for this conversation to connect to.
     * Note: The conversation in the request must be in IN_PROGRESS status and
     * must have no phone number attached.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber addConversationPhoneNumber(com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getAddConversationPhoneNumberMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Activates the specified conversation.
     * Used for telephony-based conversations that are started with inactive
     * SIP attribute.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation activateConversation(com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getActivateConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deactivates the specified conversation.
     * Sets the SDP direction of the telephony call associated with this
     * conversation to inactive.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation deactivateConversation(com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeactivateConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Completes the specified conversation. Finished conversations are purged
     * from the database after 30 days.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation completeConversation(com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCompleteConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Updates the specified conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.Conversation updateConversation(com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getUpdateConversationMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Data ingestion API.
     * Ingests context references for an existing conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse ingestContextReferences(com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getIngestContextReferencesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Creates a call matcher that links incoming SIP calls to the specified
     * conversation if they fulfill specified criteria.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.CallMatcher createCallMatcher(com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateCallMatcherMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all call matchers in the specified conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse listCallMatchers(com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListCallMatchersMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Requests deletion of a call matcher.
     * </pre>
     */
    public com.google.protobuf.Empty deleteCallMatcher(com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteCallMatcherMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Batch ingests messages to conversation. Customers can use this RPC to
     * ingest historical messages to conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse batchCreateMessages(com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getBatchCreateMessagesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Lists messages that belong to a given conversation.
     * `messages` are ordered by `create_time` in descending order. To fetch
     * updates without duplication, send request with filter
     * `create_time_epoch_microseconds &gt;
     * [first item's create_time of previous request]` and empty page_token.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListMessagesResponse listMessages(com.google.cloud.dialogflow.v2beta1.ListMessagesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListMessagesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Exports messages from a range of conversations to a Google Cloud Storage
     * bucket. Each conversation is exported as a separate JSON transcript to the
     * bucket. Only closed conversations are exported, and if redaction is
     * configured, the exported text messages are redacted as well.
     * Note: this method is pre-alpha and is subject to incompatible changes.
     * </pre>
     */
    public com.google.longrunning.Operation exportMessages(com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getExportMessagesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Suggest summary for a conversation based on specific historical messages.
     * The range of the messages to be used for summary can be specified in the
     * request.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse suggestConversationSummary(com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSuggestConversationSummaryMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Generates and returns a summary for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse generateStatelessSummary(com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGenerateStatelessSummaryMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Generates and returns a suggestion for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse generateStatelessSuggestion(com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGenerateStatelessSuggestionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Suggest key moments for a conversation based on specific historical
     * messages.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse suggestConversationKeyMoments(com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSuggestConversationKeyMomentsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Gets relevant articles by performing a search using the given query.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse searchArticles(com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSearchArticlesMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets all Call Companion
     * conversation events that have occurred so far.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse listPastCallCompanionEvents(com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListPastCallCompanionEventsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets the incoming
     * conversation events as a server-side stream.
     * </pre>
     */
    public java.util.Iterator<com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse> streamingListUpcomingCallCompanionEvents(
        com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamingListUpcomingCallCompanionEventsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse injectCallCompanionUserInput(com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInjectCallCompanionUserInputMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI to get conversation events as a stream.
     * </pre>
     */
    public java.util.Iterator<com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse> streamingListCallCompanionEvents(
        com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest request) {
      return io.grpc.stub.ClientCalls.blockingServerStreamingCall(
          getChannel(), getStreamingListCallCompanionEventsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse injectCallCompanionInput(com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInjectCallCompanionInputMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Initialize the resources for Call Companion UI.
     * </pre>
     */
    public com.google.protobuf.Empty initializeCallCompanion(com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInitializeCallCompanionMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Gets the settings for Call Companion UI.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.CallCompanionSettings getCallCompanionSettings(com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetCallCompanionSettingsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Get answers for the given query based on knowledge documents.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse searchKnowledge(com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getSearchKnowledgeMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Generates all the suggestions using generators configured in the
     * conversation profile. A generator is used only if its trigger event is
     * matched.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse generateSuggestions(com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGenerateSuggestionsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Initiates an outbound phone call with this conversation.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse initiatePhoneCall(com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getInitiatePhoneCallMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service Conversations.
   * <pre>
   * Service for managing
   * [Conversations][google.cloud.dialogflow.v2beta1.Conversation].
   * </pre>
   */
  public static final class ConversationsFutureStub
      extends io.grpc.stub.AbstractFutureStub<ConversationsFutureStub> {
    private ConversationsFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConversationsFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConversationsFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a new conversation. Conversations are auto-completed after 24
     * hours.
     * Conversation Lifecycle:
     * There are two stages during a conversation: Automated Agent Stage and
     * Assist Stage.
     * For Automated Agent Stage, there will be a dialogflow agent responding to
     * user queries.
     * For Assist Stage, there's no dialogflow agent responding to user queries.
     * But we will provide suggestions which are generated from conversation.
     * If
     * [Conversation.conversation_profile][google.cloud.dialogflow.v2beta1.Conversation.conversation_profile]
     * is configured for a dialogflow agent, conversation will start from
     * `Automated Agent Stage`, otherwise, it will start from `Assist Stage`. And
     * during `Automated Agent Stage`, once an
     * [Intent][google.cloud.dialogflow.v2beta1.Intent] with
     * [Intent.live_agent_handoff][google.cloud.dialogflow.v2beta1.Intent.live_agent_handoff]
     * is triggered, conversation will transfer to Assist Stage.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Conversation> createConversation(
        com.google.cloud.dialogflow.v2beta1.CreateConversationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Returns the list of all conversations in the specified project.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListConversationsResponse> listConversations(
        com.google.cloud.dialogflow.v2beta1.ListConversationsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListConversationsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Retrieves the specific conversation.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Conversation> getConversation(
        com.google.cloud.dialogflow.v2beta1.GetConversationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Sets a phone number for this conversation to connect to.
     * Note: The conversation in the request must be in IN_PROGRESS status and
     * must have no phone number attached.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber> addConversationPhoneNumber(
        com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getAddConversationPhoneNumberMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Activates the specified conversation.
     * Used for telephony-based conversations that are started with inactive
     * SIP attribute.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Conversation> activateConversation(
        com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getActivateConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Deactivates the specified conversation.
     * Sets the SDP direction of the telephony call associated with this
     * conversation to inactive.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Conversation> deactivateConversation(
        com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeactivateConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Completes the specified conversation. Finished conversations are purged
     * from the database after 30 days.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Conversation> completeConversation(
        com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCompleteConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Updates the specified conversation.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.Conversation> updateConversation(
        com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getUpdateConversationMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Data ingestion API.
     * Ingests context references for an existing conversation.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse> ingestContextReferences(
        com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getIngestContextReferencesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Creates a call matcher that links incoming SIP calls to the specified
     * conversation if they fulfill specified criteria.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.CallMatcher> createCallMatcher(
        com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateCallMatcherMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Returns the list of all call matchers in the specified conversation.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse> listCallMatchers(
        com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListCallMatchersMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Requests deletion of a call matcher.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteCallMatcher(
        com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteCallMatcherMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Batch ingests messages to conversation. Customers can use this RPC to
     * ingest historical messages to conversation.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse> batchCreateMessages(
        com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getBatchCreateMessagesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Lists messages that belong to a given conversation.
     * `messages` are ordered by `create_time` in descending order. To fetch
     * updates without duplication, send request with filter
     * `create_time_epoch_microseconds &gt;
     * [first item's create_time of previous request]` and empty page_token.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListMessagesResponse> listMessages(
        com.google.cloud.dialogflow.v2beta1.ListMessagesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListMessagesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Exports messages from a range of conversations to a Google Cloud Storage
     * bucket. Each conversation is exported as a separate JSON transcript to the
     * bucket. Only closed conversations are exported, and if redaction is
     * configured, the exported text messages are redacted as well.
     * Note: this method is pre-alpha and is subject to incompatible changes.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.longrunning.Operation> exportMessages(
        com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getExportMessagesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Suggest summary for a conversation based on specific historical messages.
     * The range of the messages to be used for summary can be specified in the
     * request.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse> suggestConversationSummary(
        com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSuggestConversationSummaryMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Generates and returns a summary for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse> generateStatelessSummary(
        com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGenerateStatelessSummaryMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Generates and returns a suggestion for a conversation that does not have a
     * resource created for it.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse> generateStatelessSuggestion(
        com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGenerateStatelessSuggestionMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Suggest key moments for a conversation based on specific historical
     * messages.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse> suggestConversationKeyMoments(
        com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSuggestConversationKeyMomentsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Gets relevant articles by performing a search using the given query.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse> searchArticles(
        com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSearchArticlesMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * For the Call Companion UI, gets all Call Companion
     * conversation events that have occurred so far.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse> listPastCallCompanionEvents(
        com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListPastCallCompanionEventsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * For the Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse> injectCallCompanionUserInput(
        com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getInjectCallCompanionUserInputMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * For the anonymous Call Companion UI, injects a conversation event
     * which is a user input into the conversation.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse> injectCallCompanionInput(
        com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getInjectCallCompanionInputMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Initialize the resources for Call Companion UI.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> initializeCallCompanion(
        com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getInitializeCallCompanionMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Gets the settings for Call Companion UI.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.CallCompanionSettings> getCallCompanionSettings(
        com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetCallCompanionSettingsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Get answers for the given query based on knowledge documents.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse> searchKnowledge(
        com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getSearchKnowledgeMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Generates all the suggestions using generators configured in the
     * conversation profile. A generator is used only if its trigger event is
     * matched.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse> generateSuggestions(
        com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGenerateSuggestionsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Initiates an outbound phone call with this conversation.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse> initiatePhoneCall(
        com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getInitiatePhoneCallMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_CONVERSATION = 0;
  private static final int METHODID_LIST_CONVERSATIONS = 1;
  private static final int METHODID_GET_CONVERSATION = 2;
  private static final int METHODID_ADD_CONVERSATION_PHONE_NUMBER = 3;
  private static final int METHODID_ACTIVATE_CONVERSATION = 4;
  private static final int METHODID_DEACTIVATE_CONVERSATION = 5;
  private static final int METHODID_COMPLETE_CONVERSATION = 6;
  private static final int METHODID_UPDATE_CONVERSATION = 7;
  private static final int METHODID_INGEST_CONTEXT_REFERENCES = 8;
  private static final int METHODID_CREATE_CALL_MATCHER = 9;
  private static final int METHODID_LIST_CALL_MATCHERS = 10;
  private static final int METHODID_DELETE_CALL_MATCHER = 11;
  private static final int METHODID_BATCH_CREATE_MESSAGES = 12;
  private static final int METHODID_LIST_MESSAGES = 13;
  private static final int METHODID_EXPORT_MESSAGES = 14;
  private static final int METHODID_SUGGEST_CONVERSATION_SUMMARY = 15;
  private static final int METHODID_GENERATE_STATELESS_SUMMARY = 16;
  private static final int METHODID_GENERATE_STATELESS_SUGGESTION = 17;
  private static final int METHODID_SUGGEST_CONVERSATION_KEY_MOMENTS = 18;
  private static final int METHODID_SEARCH_ARTICLES = 19;
  private static final int METHODID_LIST_PAST_CALL_COMPANION_EVENTS = 20;
  private static final int METHODID_STREAMING_LIST_UPCOMING_CALL_COMPANION_EVENTS = 21;
  private static final int METHODID_INJECT_CALL_COMPANION_USER_INPUT = 22;
  private static final int METHODID_STREAMING_LIST_CALL_COMPANION_EVENTS = 23;
  private static final int METHODID_INJECT_CALL_COMPANION_INPUT = 24;
  private static final int METHODID_INITIALIZE_CALL_COMPANION = 25;
  private static final int METHODID_GET_CALL_COMPANION_SETTINGS = 26;
  private static final int METHODID_SEARCH_KNOWLEDGE = 27;
  private static final int METHODID_GENERATE_SUGGESTIONS = 28;
  private static final int METHODID_INITIATE_PHONE_CALL = 29;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_CONVERSATION:
          serviceImpl.createConversation((com.google.cloud.dialogflow.v2beta1.CreateConversationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation>) responseObserver);
          break;
        case METHODID_LIST_CONVERSATIONS:
          serviceImpl.listConversations((com.google.cloud.dialogflow.v2beta1.ListConversationsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListConversationsResponse>) responseObserver);
          break;
        case METHODID_GET_CONVERSATION:
          serviceImpl.getConversation((com.google.cloud.dialogflow.v2beta1.GetConversationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation>) responseObserver);
          break;
        case METHODID_ADD_CONVERSATION_PHONE_NUMBER:
          serviceImpl.addConversationPhoneNumber((com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber>) responseObserver);
          break;
        case METHODID_ACTIVATE_CONVERSATION:
          serviceImpl.activateConversation((com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation>) responseObserver);
          break;
        case METHODID_DEACTIVATE_CONVERSATION:
          serviceImpl.deactivateConversation((com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation>) responseObserver);
          break;
        case METHODID_COMPLETE_CONVERSATION:
          serviceImpl.completeConversation((com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation>) responseObserver);
          break;
        case METHODID_UPDATE_CONVERSATION:
          serviceImpl.updateConversation((com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.Conversation>) responseObserver);
          break;
        case METHODID_INGEST_CONTEXT_REFERENCES:
          serviceImpl.ingestContextReferences((com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse>) responseObserver);
          break;
        case METHODID_CREATE_CALL_MATCHER:
          serviceImpl.createCallMatcher((com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CallMatcher>) responseObserver);
          break;
        case METHODID_LIST_CALL_MATCHERS:
          serviceImpl.listCallMatchers((com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse>) responseObserver);
          break;
        case METHODID_DELETE_CALL_MATCHER:
          serviceImpl.deleteCallMatcher((com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_BATCH_CREATE_MESSAGES:
          serviceImpl.batchCreateMessages((com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse>) responseObserver);
          break;
        case METHODID_LIST_MESSAGES:
          serviceImpl.listMessages((com.google.cloud.dialogflow.v2beta1.ListMessagesRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListMessagesResponse>) responseObserver);
          break;
        case METHODID_EXPORT_MESSAGES:
          serviceImpl.exportMessages((com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest) request,
              (io.grpc.stub.StreamObserver<com.google.longrunning.Operation>) responseObserver);
          break;
        case METHODID_SUGGEST_CONVERSATION_SUMMARY:
          serviceImpl.suggestConversationSummary((com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse>) responseObserver);
          break;
        case METHODID_GENERATE_STATELESS_SUMMARY:
          serviceImpl.generateStatelessSummary((com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse>) responseObserver);
          break;
        case METHODID_GENERATE_STATELESS_SUGGESTION:
          serviceImpl.generateStatelessSuggestion((com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse>) responseObserver);
          break;
        case METHODID_SUGGEST_CONVERSATION_KEY_MOMENTS:
          serviceImpl.suggestConversationKeyMoments((com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse>) responseObserver);
          break;
        case METHODID_SEARCH_ARTICLES:
          serviceImpl.searchArticles((com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse>) responseObserver);
          break;
        case METHODID_LIST_PAST_CALL_COMPANION_EVENTS:
          serviceImpl.listPastCallCompanionEvents((com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse>) responseObserver);
          break;
        case METHODID_STREAMING_LIST_UPCOMING_CALL_COMPANION_EVENTS:
          serviceImpl.streamingListUpcomingCallCompanionEvents((com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse>) responseObserver);
          break;
        case METHODID_INJECT_CALL_COMPANION_USER_INPUT:
          serviceImpl.injectCallCompanionUserInput((com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse>) responseObserver);
          break;
        case METHODID_STREAMING_LIST_CALL_COMPANION_EVENTS:
          serviceImpl.streamingListCallCompanionEvents((com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse>) responseObserver);
          break;
        case METHODID_INJECT_CALL_COMPANION_INPUT:
          serviceImpl.injectCallCompanionInput((com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse>) responseObserver);
          break;
        case METHODID_INITIALIZE_CALL_COMPANION:
          serviceImpl.initializeCallCompanion((com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_GET_CALL_COMPANION_SETTINGS:
          serviceImpl.getCallCompanionSettings((com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.CallCompanionSettings>) responseObserver);
          break;
        case METHODID_SEARCH_KNOWLEDGE:
          serviceImpl.searchKnowledge((com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse>) responseObserver);
          break;
        case METHODID_GENERATE_SUGGESTIONS:
          serviceImpl.generateSuggestions((com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse>) responseObserver);
          break;
        case METHODID_INITIATE_PHONE_CALL:
          serviceImpl.initiatePhoneCall((com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getCreateConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CreateConversationRequest,
              com.google.cloud.dialogflow.v2beta1.Conversation>(
                service, METHODID_CREATE_CONVERSATION)))
        .addMethod(
          getListConversationsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListConversationsRequest,
              com.google.cloud.dialogflow.v2beta1.ListConversationsResponse>(
                service, METHODID_LIST_CONVERSATIONS)))
        .addMethod(
          getGetConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GetConversationRequest,
              com.google.cloud.dialogflow.v2beta1.Conversation>(
                service, METHODID_GET_CONVERSATION)))
        .addMethod(
          getAddConversationPhoneNumberMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.AddConversationPhoneNumberRequest,
              com.google.cloud.dialogflow.v2beta1.ConversationPhoneNumber>(
                service, METHODID_ADD_CONVERSATION_PHONE_NUMBER)))
        .addMethod(
          getActivateConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ActivateConversationRequest,
              com.google.cloud.dialogflow.v2beta1.Conversation>(
                service, METHODID_ACTIVATE_CONVERSATION)))
        .addMethod(
          getDeactivateConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeactivateConversationRequest,
              com.google.cloud.dialogflow.v2beta1.Conversation>(
                service, METHODID_DEACTIVATE_CONVERSATION)))
        .addMethod(
          getCompleteConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CompleteConversationRequest,
              com.google.cloud.dialogflow.v2beta1.Conversation>(
                service, METHODID_COMPLETE_CONVERSATION)))
        .addMethod(
          getUpdateConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.UpdateConversationRequest,
              com.google.cloud.dialogflow.v2beta1.Conversation>(
                service, METHODID_UPDATE_CONVERSATION)))
        .addMethod(
          getIngestContextReferencesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.IngestContextReferencesRequest,
              com.google.cloud.dialogflow.v2beta1.IngestContextReferencesResponse>(
                service, METHODID_INGEST_CONTEXT_REFERENCES)))
        .addMethod(
          getCreateCallMatcherMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CreateCallMatcherRequest,
              com.google.cloud.dialogflow.v2beta1.CallMatcher>(
                service, METHODID_CREATE_CALL_MATCHER)))
        .addMethod(
          getListCallMatchersMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListCallMatchersRequest,
              com.google.cloud.dialogflow.v2beta1.ListCallMatchersResponse>(
                service, METHODID_LIST_CALL_MATCHERS)))
        .addMethod(
          getDeleteCallMatcherMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeleteCallMatcherRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_CALL_MATCHER)))
        .addMethod(
          getBatchCreateMessagesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesRequest,
              com.google.cloud.dialogflow.v2beta1.BatchCreateMessagesResponse>(
                service, METHODID_BATCH_CREATE_MESSAGES)))
        .addMethod(
          getListMessagesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListMessagesRequest,
              com.google.cloud.dialogflow.v2beta1.ListMessagesResponse>(
                service, METHODID_LIST_MESSAGES)))
        .addMethod(
          getExportMessagesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ExportMessagesRequest,
              com.google.longrunning.Operation>(
                service, METHODID_EXPORT_MESSAGES)))
        .addMethod(
          getSuggestConversationSummaryMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryRequest,
              com.google.cloud.dialogflow.v2beta1.SuggestConversationSummaryResponse>(
                service, METHODID_SUGGEST_CONVERSATION_SUMMARY)))
        .addMethod(
          getGenerateStatelessSummaryMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryRequest,
              com.google.cloud.dialogflow.v2beta1.GenerateStatelessSummaryResponse>(
                service, METHODID_GENERATE_STATELESS_SUMMARY)))
        .addMethod(
          getGenerateStatelessSuggestionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionRequest,
              com.google.cloud.dialogflow.v2beta1.GenerateStatelessSuggestionResponse>(
                service, METHODID_GENERATE_STATELESS_SUGGESTION)))
        .addMethod(
          getSuggestConversationKeyMomentsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsRequest,
              com.google.cloud.dialogflow.v2beta1.SuggestConversationKeyMomentsResponse>(
                service, METHODID_SUGGEST_CONVERSATION_KEY_MOMENTS)))
        .addMethod(
          getSearchArticlesMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.SearchArticlesRequest,
              com.google.cloud.dialogflow.v2beta1.SearchArticlesResponse>(
                service, METHODID_SEARCH_ARTICLES)))
        .addMethod(
          getListPastCallCompanionEventsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsRequest,
              com.google.cloud.dialogflow.v2beta1.ListPastCallCompanionEventsResponse>(
                service, METHODID_LIST_PAST_CALL_COMPANION_EVENTS)))
        .addMethod(
          getStreamingListUpcomingCallCompanionEventsMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsRequest,
              com.google.cloud.dialogflow.v2beta1.StreamingListUpcomingCallCompanionEventsResponse>(
                service, METHODID_STREAMING_LIST_UPCOMING_CALL_COMPANION_EVENTS)))
        .addMethod(
          getInjectCallCompanionUserInputMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputRequest,
              com.google.cloud.dialogflow.v2beta1.InjectCallCompanionUserInputResponse>(
                service, METHODID_INJECT_CALL_COMPANION_USER_INPUT)))
        .addMethod(
          getStreamingListCallCompanionEventsMethod(),
          io.grpc.stub.ServerCalls.asyncServerStreamingCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsRequest,
              com.google.cloud.dialogflow.v2beta1.StreamingListCallCompanionEventsResponse>(
                service, METHODID_STREAMING_LIST_CALL_COMPANION_EVENTS)))
        .addMethod(
          getInjectCallCompanionInputMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputRequest,
              com.google.cloud.dialogflow.v2beta1.InjectCallCompanionInputResponse>(
                service, METHODID_INJECT_CALL_COMPANION_INPUT)))
        .addMethod(
          getInitializeCallCompanionMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.InitializeCallCompanionRequest,
              com.google.protobuf.Empty>(
                service, METHODID_INITIALIZE_CALL_COMPANION)))
        .addMethod(
          getGetCallCompanionSettingsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GetCallCompanionSettingsRequest,
              com.google.cloud.dialogflow.v2beta1.CallCompanionSettings>(
                service, METHODID_GET_CALL_COMPANION_SETTINGS)))
        .addMethod(
          getSearchKnowledgeMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.SearchKnowledgeRequest,
              com.google.cloud.dialogflow.v2beta1.SearchKnowledgeResponse>(
                service, METHODID_SEARCH_KNOWLEDGE)))
        .addMethod(
          getGenerateSuggestionsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsRequest,
              com.google.cloud.dialogflow.v2beta1.GenerateSuggestionsResponse>(
                service, METHODID_GENERATE_SUGGESTIONS)))
        .addMethod(
          getInitiatePhoneCallMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallRequest,
              com.google.cloud.dialogflow.v2beta1.InitiatePhoneCallResponse>(
                service, METHODID_INITIATE_PHONE_CALL)))
        .build();
  }

  private static abstract class ConversationsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ConversationsBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.google.cloud.dialogflow.v2beta1.ConversationProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("Conversations");
    }
  }

  private static final class ConversationsFileDescriptorSupplier
      extends ConversationsBaseDescriptorSupplier {
    ConversationsFileDescriptorSupplier() {}
  }

  private static final class ConversationsMethodDescriptorSupplier
      extends ConversationsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    ConversationsMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ConversationsGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ConversationsFileDescriptorSupplier())
              .addMethod(getCreateConversationMethod())
              .addMethod(getListConversationsMethod())
              .addMethod(getGetConversationMethod())
              .addMethod(getAddConversationPhoneNumberMethod())
              .addMethod(getActivateConversationMethod())
              .addMethod(getDeactivateConversationMethod())
              .addMethod(getCompleteConversationMethod())
              .addMethod(getUpdateConversationMethod())
              .addMethod(getIngestContextReferencesMethod())
              .addMethod(getCreateCallMatcherMethod())
              .addMethod(getListCallMatchersMethod())
              .addMethod(getDeleteCallMatcherMethod())
              .addMethod(getBatchCreateMessagesMethod())
              .addMethod(getListMessagesMethod())
              .addMethod(getExportMessagesMethod())
              .addMethod(getSuggestConversationSummaryMethod())
              .addMethod(getGenerateStatelessSummaryMethod())
              .addMethod(getGenerateStatelessSuggestionMethod())
              .addMethod(getSuggestConversationKeyMomentsMethod())
              .addMethod(getSearchArticlesMethod())
              .addMethod(getListPastCallCompanionEventsMethod())
              .addMethod(getStreamingListUpcomingCallCompanionEventsMethod())
              .addMethod(getInjectCallCompanionUserInputMethod())
              .addMethod(getStreamingListCallCompanionEventsMethod())
              .addMethod(getInjectCallCompanionInputMethod())
              .addMethod(getInitializeCallCompanionMethod())
              .addMethod(getGetCallCompanionSettingsMethod())
              .addMethod(getSearchKnowledgeMethod())
              .addMethod(getGenerateSuggestionsMethod())
              .addMethod(getInitiatePhoneCallMethod())
              .build();
        }
      }
    }
    return result;
  }
}
