package com.google.cloud.dialogflow.v2beta1;

import static io.grpc.MethodDescriptor.generateFullMethodName;

/**
 * <pre>
 * Conversation datasets.
 * Conversation datasets contain raw conversation files along with their
 * customizable metadata that can be used to train custom human agent assistant
 * models, evaluate models in regression tests and other stuff.
 * </pre>
 */
@javax.annotation.Generated(
    value = "by gRPC proto compiler",
    comments = "Source: google/cloud/dialogflow/v2beta1/conversation_dataset.proto")
@io.grpc.stub.annotations.GrpcGenerated
public final class ConversationDatasetsGrpc {

  private ConversationDatasetsGrpc() {}

  public static final java.lang.String SERVICE_NAME = "google.cloud.dialogflow.v2beta1.ConversationDatasets";

  // Static method descriptors that strictly reflect the proto.
  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest,
      com.google.longrunning.Operation> getCreateConversationDatasetMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "CreateConversationDataset",
      requestType = com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest.class,
      responseType = com.google.longrunning.Operation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest,
      com.google.longrunning.Operation> getCreateConversationDatasetMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest, com.google.longrunning.Operation> getCreateConversationDatasetMethod;
    if ((getCreateConversationDatasetMethod = ConversationDatasetsGrpc.getCreateConversationDatasetMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getCreateConversationDatasetMethod = ConversationDatasetsGrpc.getCreateConversationDatasetMethod) == null) {
          ConversationDatasetsGrpc.getCreateConversationDatasetMethod = getCreateConversationDatasetMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest, com.google.longrunning.Operation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "CreateConversationDataset"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.longrunning.Operation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("CreateConversationDataset"))
              .build();
        }
      }
    }
    return getCreateConversationDatasetMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest,
      com.google.cloud.dialogflow.v2beta1.ConversationDataset> getGetConversationDatasetMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetConversationDataset",
      requestType = com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ConversationDataset.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest,
      com.google.cloud.dialogflow.v2beta1.ConversationDataset> getGetConversationDatasetMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest, com.google.cloud.dialogflow.v2beta1.ConversationDataset> getGetConversationDatasetMethod;
    if ((getGetConversationDatasetMethod = ConversationDatasetsGrpc.getGetConversationDatasetMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getGetConversationDatasetMethod = ConversationDatasetsGrpc.getGetConversationDatasetMethod) == null) {
          ConversationDatasetsGrpc.getGetConversationDatasetMethod = getGetConversationDatasetMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest, com.google.cloud.dialogflow.v2beta1.ConversationDataset>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetConversationDataset"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ConversationDataset.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("GetConversationDataset"))
              .build();
        }
      }
    }
    return getGetConversationDatasetMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest,
      com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse> getListConversationDatasetsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListConversationDatasets",
      requestType = com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest,
      com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse> getListConversationDatasetsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest, com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse> getListConversationDatasetsMethod;
    if ((getListConversationDatasetsMethod = ConversationDatasetsGrpc.getListConversationDatasetsMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getListConversationDatasetsMethod = ConversationDatasetsGrpc.getListConversationDatasetsMethod) == null) {
          ConversationDatasetsGrpc.getListConversationDatasetsMethod = getListConversationDatasetsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest, com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListConversationDatasets"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("ListConversationDatasets"))
              .build();
        }
      }
    }
    return getListConversationDatasetsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest,
      com.google.longrunning.Operation> getDeleteConversationDatasetMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteConversationDataset",
      requestType = com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest.class,
      responseType = com.google.longrunning.Operation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest,
      com.google.longrunning.Operation> getDeleteConversationDatasetMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest, com.google.longrunning.Operation> getDeleteConversationDatasetMethod;
    if ((getDeleteConversationDatasetMethod = ConversationDatasetsGrpc.getDeleteConversationDatasetMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getDeleteConversationDatasetMethod = ConversationDatasetsGrpc.getDeleteConversationDatasetMethod) == null) {
          ConversationDatasetsGrpc.getDeleteConversationDatasetMethod = getDeleteConversationDatasetMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest, com.google.longrunning.Operation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteConversationDataset"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.longrunning.Operation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("DeleteConversationDataset"))
              .build();
        }
      }
    }
    return getDeleteConversationDatasetMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest,
      com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset> getGetAnnotatedConversationDatasetMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "GetAnnotatedConversationDataset",
      requestType = com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest,
      com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset> getGetAnnotatedConversationDatasetMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest, com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset> getGetAnnotatedConversationDatasetMethod;
    if ((getGetAnnotatedConversationDatasetMethod = ConversationDatasetsGrpc.getGetAnnotatedConversationDatasetMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getGetAnnotatedConversationDatasetMethod = ConversationDatasetsGrpc.getGetAnnotatedConversationDatasetMethod) == null) {
          ConversationDatasetsGrpc.getGetAnnotatedConversationDatasetMethod = getGetAnnotatedConversationDatasetMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest, com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "GetAnnotatedConversationDataset"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("GetAnnotatedConversationDataset"))
              .build();
        }
      }
    }
    return getGetAnnotatedConversationDatasetMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest,
      com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse> getListAnnotatedConversationDatasetsMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ListAnnotatedConversationDatasets",
      requestType = com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest.class,
      responseType = com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest,
      com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse> getListAnnotatedConversationDatasetsMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest, com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse> getListAnnotatedConversationDatasetsMethod;
    if ((getListAnnotatedConversationDatasetsMethod = ConversationDatasetsGrpc.getListAnnotatedConversationDatasetsMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getListAnnotatedConversationDatasetsMethod = ConversationDatasetsGrpc.getListAnnotatedConversationDatasetsMethod) == null) {
          ConversationDatasetsGrpc.getListAnnotatedConversationDatasetsMethod = getListAnnotatedConversationDatasetsMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest, com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ListAnnotatedConversationDatasets"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("ListAnnotatedConversationDatasets"))
              .build();
        }
      }
    }
    return getListAnnotatedConversationDatasetsMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest,
      com.google.protobuf.Empty> getDeleteAnnotatedConversationDatasetMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "DeleteAnnotatedConversationDataset",
      requestType = com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest.class,
      responseType = com.google.protobuf.Empty.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest,
      com.google.protobuf.Empty> getDeleteAnnotatedConversationDatasetMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest, com.google.protobuf.Empty> getDeleteAnnotatedConversationDatasetMethod;
    if ((getDeleteAnnotatedConversationDatasetMethod = ConversationDatasetsGrpc.getDeleteAnnotatedConversationDatasetMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getDeleteAnnotatedConversationDatasetMethod = ConversationDatasetsGrpc.getDeleteAnnotatedConversationDatasetMethod) == null) {
          ConversationDatasetsGrpc.getDeleteAnnotatedConversationDatasetMethod = getDeleteAnnotatedConversationDatasetMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest, com.google.protobuf.Empty>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "DeleteAnnotatedConversationDataset"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.protobuf.Empty.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("DeleteAnnotatedConversationDataset"))
              .build();
        }
      }
    }
    return getDeleteAnnotatedConversationDatasetMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest,
      com.google.longrunning.Operation> getImportConversationDataMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "ImportConversationData",
      requestType = com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest.class,
      responseType = com.google.longrunning.Operation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest,
      com.google.longrunning.Operation> getImportConversationDataMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest, com.google.longrunning.Operation> getImportConversationDataMethod;
    if ((getImportConversationDataMethod = ConversationDatasetsGrpc.getImportConversationDataMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getImportConversationDataMethod = ConversationDatasetsGrpc.getImportConversationDataMethod) == null) {
          ConversationDatasetsGrpc.getImportConversationDataMethod = getImportConversationDataMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest, com.google.longrunning.Operation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "ImportConversationData"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.longrunning.Operation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("ImportConversationData"))
              .build();
        }
      }
    }
    return getImportConversationDataMethod;
  }

  private static volatile io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.LabelConversationRequest,
      com.google.longrunning.Operation> getLabelConversationMethod;

  @io.grpc.stub.annotations.RpcMethod(
      fullMethodName = SERVICE_NAME + '/' + "LabelConversation",
      requestType = com.google.cloud.dialogflow.v2beta1.LabelConversationRequest.class,
      responseType = com.google.longrunning.Operation.class,
      methodType = io.grpc.MethodDescriptor.MethodType.UNARY)
  public static io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.LabelConversationRequest,
      com.google.longrunning.Operation> getLabelConversationMethod() {
    io.grpc.MethodDescriptor<com.google.cloud.dialogflow.v2beta1.LabelConversationRequest, com.google.longrunning.Operation> getLabelConversationMethod;
    if ((getLabelConversationMethod = ConversationDatasetsGrpc.getLabelConversationMethod) == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        if ((getLabelConversationMethod = ConversationDatasetsGrpc.getLabelConversationMethod) == null) {
          ConversationDatasetsGrpc.getLabelConversationMethod = getLabelConversationMethod =
              io.grpc.MethodDescriptor.<com.google.cloud.dialogflow.v2beta1.LabelConversationRequest, com.google.longrunning.Operation>newBuilder()
              .setType(io.grpc.MethodDescriptor.MethodType.UNARY)
              .setFullMethodName(generateFullMethodName(SERVICE_NAME, "LabelConversation"))
              .setSampledToLocalTracing(true)
              .setRequestMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.cloud.dialogflow.v2beta1.LabelConversationRequest.getDefaultInstance()))
              .setResponseMarshaller(io.grpc.protobuf.ProtoUtils.marshaller(
                  com.google.longrunning.Operation.getDefaultInstance()))
              .setSchemaDescriptor(new ConversationDatasetsMethodDescriptorSupplier("LabelConversation"))
              .build();
        }
      }
    }
    return getLabelConversationMethod;
  }

  /**
   * Creates a new async stub that supports all call types for the service
   */
  public static ConversationDatasetsStub newStub(io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConversationDatasetsStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConversationDatasetsStub>() {
        @java.lang.Override
        public ConversationDatasetsStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConversationDatasetsStub(channel, callOptions);
        }
      };
    return ConversationDatasetsStub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports all types of calls on the service
   */
  public static ConversationDatasetsBlockingV2Stub newBlockingV2Stub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConversationDatasetsBlockingV2Stub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConversationDatasetsBlockingV2Stub>() {
        @java.lang.Override
        public ConversationDatasetsBlockingV2Stub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConversationDatasetsBlockingV2Stub(channel, callOptions);
        }
      };
    return ConversationDatasetsBlockingV2Stub.newStub(factory, channel);
  }

  /**
   * Creates a new blocking-style stub that supports unary and streaming output calls on the service
   */
  public static ConversationDatasetsBlockingStub newBlockingStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConversationDatasetsBlockingStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConversationDatasetsBlockingStub>() {
        @java.lang.Override
        public ConversationDatasetsBlockingStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConversationDatasetsBlockingStub(channel, callOptions);
        }
      };
    return ConversationDatasetsBlockingStub.newStub(factory, channel);
  }

  /**
   * Creates a new ListenableFuture-style stub that supports unary calls on the service
   */
  public static ConversationDatasetsFutureStub newFutureStub(
      io.grpc.Channel channel) {
    io.grpc.stub.AbstractStub.StubFactory<ConversationDatasetsFutureStub> factory =
      new io.grpc.stub.AbstractStub.StubFactory<ConversationDatasetsFutureStub>() {
        @java.lang.Override
        public ConversationDatasetsFutureStub newStub(io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
          return new ConversationDatasetsFutureStub(channel, callOptions);
        }
      };
    return ConversationDatasetsFutureStub.newStub(factory, channel);
  }

  /**
   * <pre>
   * Conversation datasets.
   * Conversation datasets contain raw conversation files along with their
   * customizable metadata that can be used to train custom human agent assistant
   * models, evaluate models in regression tests and other stuff.
   * </pre>
   */
  public interface AsyncService {

    /**
     * <pre>
     * Creates a new conversation dataset.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
     * - `response`:
     * [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
     * </pre>
     */
    default void createConversationDataset(com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getCreateConversationDatasetMethod(), responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specified conversation dataset.
     * </pre>
     */
    default void getConversationDataset(com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ConversationDataset> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetConversationDatasetMethod(), responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all conversation datasets in the specified
     * project.
     * </pre>
     */
    default void listConversationDatasets(com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListConversationDatasetsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified conversation dataset and all annotated conversation
     * datasets that belong to it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
     * - `response`: An [Empty
     *   message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
     * </pre>
     */
    default void deleteConversationDataset(com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteConversationDatasetMethod(), responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specified annotated conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    default void getAnnotatedConversationDataset(com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getGetAnnotatedConversationDatasetMethod(), responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all annotated conversation datasets that
     * belong to a given conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    default void listAnnotatedConversationDatasets(com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getListAnnotatedConversationDatasetsMethod(), responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified annotated conversation dataset and annotations that
     * belongs to it.
     * </pre>
     */
    @java.lang.Deprecated
    default void deleteAnnotatedConversationDataset(com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getDeleteAnnotatedConversationDatasetMethod(), responseObserver);
    }

    /**
     * <pre>
     * Import data into the specified conversation dataset. Note that it
     * is not allowed to import data to a conversation dataset that
     * already has data in it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
     * - `response`:
     * [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]
     * </pre>
     */
    default void importConversationData(com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getImportConversationDataMethod(), responseObserver);
    }

    /**
     * <pre>
     * [DEPRECATED].
     * Creates and starts a conversation dataset annotation task.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
     * - `response`:
     * [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]
     * </pre>
     */
    @java.lang.Deprecated
    default void labelConversation(com.google.cloud.dialogflow.v2beta1.LabelConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ServerCalls.asyncUnimplementedUnaryCall(getLabelConversationMethod(), responseObserver);
    }
  }

  /**
   * Base class for the server implementation of the service ConversationDatasets.
   * <pre>
   * Conversation datasets.
   * Conversation datasets contain raw conversation files along with their
   * customizable metadata that can be used to train custom human agent assistant
   * models, evaluate models in regression tests and other stuff.
   * </pre>
   */
  public static abstract class ConversationDatasetsImplBase
      implements io.grpc.BindableService, AsyncService {

    @java.lang.Override public final io.grpc.ServerServiceDefinition bindService() {
      return ConversationDatasetsGrpc.bindService(this);
    }
  }

  /**
   * A stub to allow clients to do asynchronous rpc calls to service ConversationDatasets.
   * <pre>
   * Conversation datasets.
   * Conversation datasets contain raw conversation files along with their
   * customizable metadata that can be used to train custom human agent assistant
   * models, evaluate models in regression tests and other stuff.
   * </pre>
   */
  public static final class ConversationDatasetsStub
      extends io.grpc.stub.AbstractAsyncStub<ConversationDatasetsStub> {
    private ConversationDatasetsStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConversationDatasetsStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConversationDatasetsStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a new conversation dataset.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
     * - `response`:
     * [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
     * </pre>
     */
    public void createConversationDataset(com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getCreateConversationDatasetMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specified conversation dataset.
     * </pre>
     */
    public void getConversationDataset(com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ConversationDataset> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetConversationDatasetMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all conversation datasets in the specified
     * project.
     * </pre>
     */
    public void listConversationDatasets(com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListConversationDatasetsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified conversation dataset and all annotated conversation
     * datasets that belong to it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
     * - `response`: An [Empty
     *   message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
     * </pre>
     */
    public void deleteConversationDataset(com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteConversationDatasetMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Retrieves the specified annotated conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    public void getAnnotatedConversationDataset(com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getGetAnnotatedConversationDatasetMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Returns the list of all annotated conversation datasets that
     * belong to a given conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    public void listAnnotatedConversationDatasets(com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest request,
        io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getListAnnotatedConversationDatasetsMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Deletes the specified annotated conversation dataset and annotations that
     * belongs to it.
     * </pre>
     */
    @java.lang.Deprecated
    public void deleteAnnotatedConversationDataset(com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest request,
        io.grpc.stub.StreamObserver<com.google.protobuf.Empty> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getDeleteAnnotatedConversationDatasetMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * Import data into the specified conversation dataset. Note that it
     * is not allowed to import data to a conversation dataset that
     * already has data in it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
     * - `response`:
     * [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]
     * </pre>
     */
    public void importConversationData(com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getImportConversationDataMethod(), getCallOptions()), request, responseObserver);
    }

    /**
     * <pre>
     * [DEPRECATED].
     * Creates and starts a conversation dataset annotation task.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
     * - `response`:
     * [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]
     * </pre>
     */
    @java.lang.Deprecated
    public void labelConversation(com.google.cloud.dialogflow.v2beta1.LabelConversationRequest request,
        io.grpc.stub.StreamObserver<com.google.longrunning.Operation> responseObserver) {
      io.grpc.stub.ClientCalls.asyncUnaryCall(
          getChannel().newCall(getLabelConversationMethod(), getCallOptions()), request, responseObserver);
    }
  }

  /**
   * A stub to allow clients to do synchronous rpc calls to service ConversationDatasets.
   * <pre>
   * Conversation datasets.
   * Conversation datasets contain raw conversation files along with their
   * customizable metadata that can be used to train custom human agent assistant
   * models, evaluate models in regression tests and other stuff.
   * </pre>
   */
  public static final class ConversationDatasetsBlockingV2Stub
      extends io.grpc.stub.AbstractBlockingStub<ConversationDatasetsBlockingV2Stub> {
    private ConversationDatasetsBlockingV2Stub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConversationDatasetsBlockingV2Stub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConversationDatasetsBlockingV2Stub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a new conversation dataset.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
     * - `response`:
     * [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
     * </pre>
     */
    public com.google.longrunning.Operation createConversationDataset(com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specified conversation dataset.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ConversationDataset getConversationDataset(com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all conversation datasets in the specified
     * project.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse listConversationDatasets(com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListConversationDatasetsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified conversation dataset and all annotated conversation
     * datasets that belong to it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
     * - `response`: An [Empty
     *   message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
     * </pre>
     */
    public com.google.longrunning.Operation deleteConversationDataset(com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specified annotated conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset getAnnotatedConversationDataset(com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetAnnotatedConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all annotated conversation datasets that
     * belong to a given conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse listAnnotatedConversationDatasets(com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListAnnotatedConversationDatasetsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified annotated conversation dataset and annotations that
     * belongs to it.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.protobuf.Empty deleteAnnotatedConversationDataset(com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteAnnotatedConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Import data into the specified conversation dataset. Note that it
     * is not allowed to import data to a conversation dataset that
     * already has data in it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
     * - `response`:
     * [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]
     * </pre>
     */
    public com.google.longrunning.Operation importConversationData(com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getImportConversationDataMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [DEPRECATED].
     * Creates and starts a conversation dataset annotation task.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
     * - `response`:
     * [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.longrunning.Operation labelConversation(com.google.cloud.dialogflow.v2beta1.LabelConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getLabelConversationMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do limited synchronous rpc calls to service ConversationDatasets.
   * <pre>
   * Conversation datasets.
   * Conversation datasets contain raw conversation files along with their
   * customizable metadata that can be used to train custom human agent assistant
   * models, evaluate models in regression tests and other stuff.
   * </pre>
   */
  public static final class ConversationDatasetsBlockingStub
      extends io.grpc.stub.AbstractBlockingStub<ConversationDatasetsBlockingStub> {
    private ConversationDatasetsBlockingStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConversationDatasetsBlockingStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConversationDatasetsBlockingStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a new conversation dataset.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
     * - `response`:
     * [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
     * </pre>
     */
    public com.google.longrunning.Operation createConversationDataset(com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getCreateConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specified conversation dataset.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ConversationDataset getConversationDataset(com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all conversation datasets in the specified
     * project.
     * </pre>
     */
    public com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse listConversationDatasets(com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListConversationDatasetsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified conversation dataset and all annotated conversation
     * datasets that belong to it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
     * - `response`: An [Empty
     *   message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
     * </pre>
     */
    public com.google.longrunning.Operation deleteConversationDataset(com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Retrieves the specified annotated conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset getAnnotatedConversationDataset(com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getGetAnnotatedConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Returns the list of all annotated conversation datasets that
     * belong to a given conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse listAnnotatedConversationDatasets(com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getListAnnotatedConversationDatasetsMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Deletes the specified annotated conversation dataset and annotations that
     * belongs to it.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.protobuf.Empty deleteAnnotatedConversationDataset(com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getDeleteAnnotatedConversationDatasetMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * Import data into the specified conversation dataset. Note that it
     * is not allowed to import data to a conversation dataset that
     * already has data in it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
     * - `response`:
     * [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]
     * </pre>
     */
    public com.google.longrunning.Operation importConversationData(com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getImportConversationDataMethod(), getCallOptions(), request);
    }

    /**
     * <pre>
     * [DEPRECATED].
     * Creates and starts a conversation dataset annotation task.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
     * - `response`:
     * [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.longrunning.Operation labelConversation(com.google.cloud.dialogflow.v2beta1.LabelConversationRequest request) {
      return io.grpc.stub.ClientCalls.blockingUnaryCall(
          getChannel(), getLabelConversationMethod(), getCallOptions(), request);
    }
  }

  /**
   * A stub to allow clients to do ListenableFuture-style rpc calls to service ConversationDatasets.
   * <pre>
   * Conversation datasets.
   * Conversation datasets contain raw conversation files along with their
   * customizable metadata that can be used to train custom human agent assistant
   * models, evaluate models in regression tests and other stuff.
   * </pre>
   */
  public static final class ConversationDatasetsFutureStub
      extends io.grpc.stub.AbstractFutureStub<ConversationDatasetsFutureStub> {
    private ConversationDatasetsFutureStub(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      super(channel, callOptions);
    }

    @java.lang.Override
    protected ConversationDatasetsFutureStub build(
        io.grpc.Channel channel, io.grpc.CallOptions callOptions) {
      return new ConversationDatasetsFutureStub(channel, callOptions);
    }

    /**
     * <pre>
     * Creates a new conversation dataset.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [CreateConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.CreateConversationDatasetOperationMetadata]
     * - `response`:
     * [ConversationDataset][google.cloud.dialogflow.v2beta1.ConversationDataset]
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.longrunning.Operation> createConversationDataset(
        com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getCreateConversationDatasetMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Retrieves the specified conversation dataset.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ConversationDataset> getConversationDataset(
        com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetConversationDatasetMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Returns the list of all conversation datasets in the specified
     * project.
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse> listConversationDatasets(
        com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListConversationDatasetsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Deletes the specified conversation dataset and all annotated conversation
     * datasets that belong to it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [DeleteConversationDatasetOperationMetadata][google.cloud.dialogflow.v2beta1.DeleteConversationDatasetOperationMetadata]
     * - `response`: An [Empty
     *   message](https://developers.google.com/protocol-buffers/docs/reference/google.protobuf#empty)
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.longrunning.Operation> deleteConversationDataset(
        com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteConversationDatasetMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Retrieves the specified annotated conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset> getAnnotatedConversationDataset(
        com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getGetAnnotatedConversationDatasetMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Returns the list of all annotated conversation datasets that
     * belong to a given conversation dataset.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse> listAnnotatedConversationDatasets(
        com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getListAnnotatedConversationDatasetsMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Deletes the specified annotated conversation dataset and annotations that
     * belongs to it.
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.protobuf.Empty> deleteAnnotatedConversationDataset(
        com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getDeleteAnnotatedConversationDatasetMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * Import data into the specified conversation dataset. Note that it
     * is not allowed to import data to a conversation dataset that
     * already has data in it.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [ImportConversationDataOperationMetadata][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationMetadata]
     * - `response`:
     * [ImportConversationDataOperationResponse][google.cloud.dialogflow.v2beta1.ImportConversationDataOperationResponse]
     * </pre>
     */
    public com.google.common.util.concurrent.ListenableFuture<com.google.longrunning.Operation> importConversationData(
        com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getImportConversationDataMethod(), getCallOptions()), request);
    }

    /**
     * <pre>
     * [DEPRECATED].
     * Creates and starts a conversation dataset annotation task.
     * This method is a [long-running
     * operation](https://cloud.google.com/dialogflow/es/docs/how/long-running-operations).
     * The returned `Operation` type has the following method-specific fields:
     * - `metadata`:
     * [LabelConversationOperationMetadata][google.cloud.dialogflow.v2beta1.LabelConversationOperationMetadata]
     * - `response`:
     * [LabelConversationResponse][google.cloud.dialogflow.v2beta1.LabelConversationResponse]
     * </pre>
     */
    @java.lang.Deprecated
    public com.google.common.util.concurrent.ListenableFuture<com.google.longrunning.Operation> labelConversation(
        com.google.cloud.dialogflow.v2beta1.LabelConversationRequest request) {
      return io.grpc.stub.ClientCalls.futureUnaryCall(
          getChannel().newCall(getLabelConversationMethod(), getCallOptions()), request);
    }
  }

  private static final int METHODID_CREATE_CONVERSATION_DATASET = 0;
  private static final int METHODID_GET_CONVERSATION_DATASET = 1;
  private static final int METHODID_LIST_CONVERSATION_DATASETS = 2;
  private static final int METHODID_DELETE_CONVERSATION_DATASET = 3;
  private static final int METHODID_GET_ANNOTATED_CONVERSATION_DATASET = 4;
  private static final int METHODID_LIST_ANNOTATED_CONVERSATION_DATASETS = 5;
  private static final int METHODID_DELETE_ANNOTATED_CONVERSATION_DATASET = 6;
  private static final int METHODID_IMPORT_CONVERSATION_DATA = 7;
  private static final int METHODID_LABEL_CONVERSATION = 8;

  private static final class MethodHandlers<Req, Resp> implements
      io.grpc.stub.ServerCalls.UnaryMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ServerStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.ClientStreamingMethod<Req, Resp>,
      io.grpc.stub.ServerCalls.BidiStreamingMethod<Req, Resp> {
    private final AsyncService serviceImpl;
    private final int methodId;

    MethodHandlers(AsyncService serviceImpl, int methodId) {
      this.serviceImpl = serviceImpl;
      this.methodId = methodId;
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public void invoke(Req request, io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        case METHODID_CREATE_CONVERSATION_DATASET:
          serviceImpl.createConversationDataset((com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest) request,
              (io.grpc.stub.StreamObserver<com.google.longrunning.Operation>) responseObserver);
          break;
        case METHODID_GET_CONVERSATION_DATASET:
          serviceImpl.getConversationDataset((com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ConversationDataset>) responseObserver);
          break;
        case METHODID_LIST_CONVERSATION_DATASETS:
          serviceImpl.listConversationDatasets((com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse>) responseObserver);
          break;
        case METHODID_DELETE_CONVERSATION_DATASET:
          serviceImpl.deleteConversationDataset((com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest) request,
              (io.grpc.stub.StreamObserver<com.google.longrunning.Operation>) responseObserver);
          break;
        case METHODID_GET_ANNOTATED_CONVERSATION_DATASET:
          serviceImpl.getAnnotatedConversationDataset((com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset>) responseObserver);
          break;
        case METHODID_LIST_ANNOTATED_CONVERSATION_DATASETS:
          serviceImpl.listAnnotatedConversationDatasets((com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest) request,
              (io.grpc.stub.StreamObserver<com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse>) responseObserver);
          break;
        case METHODID_DELETE_ANNOTATED_CONVERSATION_DATASET:
          serviceImpl.deleteAnnotatedConversationDataset((com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest) request,
              (io.grpc.stub.StreamObserver<com.google.protobuf.Empty>) responseObserver);
          break;
        case METHODID_IMPORT_CONVERSATION_DATA:
          serviceImpl.importConversationData((com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest) request,
              (io.grpc.stub.StreamObserver<com.google.longrunning.Operation>) responseObserver);
          break;
        case METHODID_LABEL_CONVERSATION:
          serviceImpl.labelConversation((com.google.cloud.dialogflow.v2beta1.LabelConversationRequest) request,
              (io.grpc.stub.StreamObserver<com.google.longrunning.Operation>) responseObserver);
          break;
        default:
          throw new AssertionError();
      }
    }

    @java.lang.Override
    @java.lang.SuppressWarnings("unchecked")
    public io.grpc.stub.StreamObserver<Req> invoke(
        io.grpc.stub.StreamObserver<Resp> responseObserver) {
      switch (methodId) {
        default:
          throw new AssertionError();
      }
    }
  }

  public static final io.grpc.ServerServiceDefinition bindService(AsyncService service) {
    return io.grpc.ServerServiceDefinition.builder(getServiceDescriptor())
        .addMethod(
          getCreateConversationDatasetMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.CreateConversationDatasetRequest,
              com.google.longrunning.Operation>(
                service, METHODID_CREATE_CONVERSATION_DATASET)))
        .addMethod(
          getGetConversationDatasetMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GetConversationDatasetRequest,
              com.google.cloud.dialogflow.v2beta1.ConversationDataset>(
                service, METHODID_GET_CONVERSATION_DATASET)))
        .addMethod(
          getListConversationDatasetsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsRequest,
              com.google.cloud.dialogflow.v2beta1.ListConversationDatasetsResponse>(
                service, METHODID_LIST_CONVERSATION_DATASETS)))
        .addMethod(
          getDeleteConversationDatasetMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeleteConversationDatasetRequest,
              com.google.longrunning.Operation>(
                service, METHODID_DELETE_CONVERSATION_DATASET)))
        .addMethod(
          getGetAnnotatedConversationDatasetMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.GetAnnotatedConversationDatasetRequest,
              com.google.cloud.dialogflow.v2beta1.AnnotatedConversationDataset>(
                service, METHODID_GET_ANNOTATED_CONVERSATION_DATASET)))
        .addMethod(
          getListAnnotatedConversationDatasetsMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsRequest,
              com.google.cloud.dialogflow.v2beta1.ListAnnotatedConversationDatasetsResponse>(
                service, METHODID_LIST_ANNOTATED_CONVERSATION_DATASETS)))
        .addMethod(
          getDeleteAnnotatedConversationDatasetMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.DeleteAnnotatedConversationDatasetRequest,
              com.google.protobuf.Empty>(
                service, METHODID_DELETE_ANNOTATED_CONVERSATION_DATASET)))
        .addMethod(
          getImportConversationDataMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.ImportConversationDataRequest,
              com.google.longrunning.Operation>(
                service, METHODID_IMPORT_CONVERSATION_DATA)))
        .addMethod(
          getLabelConversationMethod(),
          io.grpc.stub.ServerCalls.asyncUnaryCall(
            new MethodHandlers<
              com.google.cloud.dialogflow.v2beta1.LabelConversationRequest,
              com.google.longrunning.Operation>(
                service, METHODID_LABEL_CONVERSATION)))
        .build();
  }

  private static abstract class ConversationDatasetsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoFileDescriptorSupplier, io.grpc.protobuf.ProtoServiceDescriptorSupplier {
    ConversationDatasetsBaseDescriptorSupplier() {}

    @java.lang.Override
    public com.google.protobuf.Descriptors.FileDescriptor getFileDescriptor() {
      return com.google.cloud.dialogflow.v2beta1.ConversationDatasetProto.getDescriptor();
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.ServiceDescriptor getServiceDescriptor() {
      return getFileDescriptor().findServiceByName("ConversationDatasets");
    }
  }

  private static final class ConversationDatasetsFileDescriptorSupplier
      extends ConversationDatasetsBaseDescriptorSupplier {
    ConversationDatasetsFileDescriptorSupplier() {}
  }

  private static final class ConversationDatasetsMethodDescriptorSupplier
      extends ConversationDatasetsBaseDescriptorSupplier
      implements io.grpc.protobuf.ProtoMethodDescriptorSupplier {
    private final java.lang.String methodName;

    ConversationDatasetsMethodDescriptorSupplier(java.lang.String methodName) {
      this.methodName = methodName;
    }

    @java.lang.Override
    public com.google.protobuf.Descriptors.MethodDescriptor getMethodDescriptor() {
      return getServiceDescriptor().findMethodByName(methodName);
    }
  }

  private static volatile io.grpc.ServiceDescriptor serviceDescriptor;

  public static io.grpc.ServiceDescriptor getServiceDescriptor() {
    io.grpc.ServiceDescriptor result = serviceDescriptor;
    if (result == null) {
      synchronized (ConversationDatasetsGrpc.class) {
        result = serviceDescriptor;
        if (result == null) {
          serviceDescriptor = result = io.grpc.ServiceDescriptor.newBuilder(SERVICE_NAME)
              .setSchemaDescriptor(new ConversationDatasetsFileDescriptorSupplier())
              .addMethod(getCreateConversationDatasetMethod())
              .addMethod(getGetConversationDatasetMethod())
              .addMethod(getListConversationDatasetsMethod())
              .addMethod(getDeleteConversationDatasetMethod())
              .addMethod(getGetAnnotatedConversationDatasetMethod())
              .addMethod(getListAnnotatedConversationDatasetsMethod())
              .addMethod(getDeleteAnnotatedConversationDatasetMethod())
              .addMethod(getImportConversationDataMethod())
              .addMethod(getLabelConversationMethod())
              .build();
        }
      }
    }
    return result;
  }
}
